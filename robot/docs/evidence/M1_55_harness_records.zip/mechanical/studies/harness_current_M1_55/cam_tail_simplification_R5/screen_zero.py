"""Fresh zero screening of individual fixed-tail offsets with original ports."""
from pathlib import Path
import datetime
import sys
import json
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'cam_tail_simplification_R2'))
from compare_zero import Context,np,sha,PowerFamily,BSpline,pieces,helpers,inspect,HELPERS
sys.path.insert(0,str(HERE));from per_pin_tail import PerPinFamily


def main():
    started=time.time();native=Context();carrier=PowerFamily();trials=[];selected=None
    prefixes={n:helpers.prepare(pieces(BSpline(carrier.ctx.f.knots,carrier.ctx.f.candidate(n,0)['control'],3)),
                               carrier.ctx.f.radii[n]) for n in carrier.ctx.f.names}
    for offsets in [(12.,8.,8.,8.),(11.,8.,8.,8.),(12.,10.,8.,8.)]:
        family=PerPinFamily(carrier,offsets=offsets);review,arrays=inspect(family,native,carrier,prefixes);trials.append(review)
        print('CAM_PER_PIN_ZERO',offsets,review['status'],len(review['failures']),flush=True)
        if review['status']=='PASS':
            selected=review;np.savez_compressed(HERE/'zero_curves.npz',**arrays);break
    native.record([Path(__file__),HERE/'per_pin_tail.py',PARENT/'cam_tail_simplification_R2/compare_zero.py',
                   HELPERS,HELPERS.parent/'sample_geometry.py',PARENT/'upper_pairs_review_R1/inspect_pairs.py'])
    native.sources.update(carrier.sources);native.unchanged();carrier.unchanged()
    out=dict(status='PASS' if selected else 'BLOCKED',scope='Per-pin fixed-head detour allocations, original ports and service-loop construction; zero only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources,trials=trials,selected=selected,
        arrays_sha256=sha(HERE/'zero_curves.npz') if selected else None,elapsed_s=time.time()-started,
        other_poses='NOT_TESTED',all_angle_clearance='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        real_ports_changed=False,service_loop_construction_changed=False,main_changed=False,animation_changed=False,
        hardware_changed=False,manufacturing_release=False)
    (HERE/'zero_review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CAM_PER_PIN_ZERO_TERMINAL',out['status'],len(trials),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
