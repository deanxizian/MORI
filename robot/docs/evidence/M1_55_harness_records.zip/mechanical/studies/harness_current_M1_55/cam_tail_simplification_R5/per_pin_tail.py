"""Adjust only individual candidate detours to separate tail1 from loop4."""
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'cam_tail_simplification_R4'))
from diverted_tail import DivertedFamily,CAMFamily


class PerPinFamily(CAMFamily):
    def __init__(self,carrier=None,offsets=(12.,8.,8.,8.),top=240.):
        super().__init__(carrier=carrier)
        assert len(offsets)==4
        self.spec=dict(top_z_base_mm=top,outward_x_per_pin_mm=list(offsets),return_radius_mm=9.)
        families={offset:DivertedFamily(self.carrier,top=top,outward=offset,return_radius=9.) for offset in set(offsets)}
        self.tail_changes=[]
        for pin,offset in enumerate(offsets,1):
            selected=families[offset];name=f'CAM_{pin}'
            self.tail_builders[pin]=selected.tail_builders[pin];self.targets[name]=selected.targets[name]
            change=selected.tail_changes[pin-1].copy();change['outward_x_mm']=offset;self.tail_changes.append(change)
        self.ctx.record([Path(__file__)])
