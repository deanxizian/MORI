"""Finite polyline distance with conservative KDTree candidate pruning."""

import numpy as np

from mathutils.kdtree import KDTree

def exact_pair(p,q):
    p=np.asarray(p,dtype=float);q=np.asarray(q,dtype=float)
    assert p.ndim==q.ndim==2 and p.shape[1]==q.shape[1]==3
    assert len(p)>1 and len(q)>1 and np.isfinite(p).all() and np.isfinite(q).all()
    # Exact duplicate points do not add segments to a polyline.
    p=p[np.r_[True,np.any(np.diff(p,axis=0)!=0,axis=1)]]
    q=q[np.r_[True,np.any(np.diff(q,axis=0)!=0,axis=1)]]
    assert len(p)>1 and len(q)>1
    u=p[1:]-p[:-1];v=q[1:]-q[:-1];ma=(p[1:]+p[:-1])/2;mb=(q[1:]+q[:-1])/2
    ha=np.linalg.norm(u,axis=1)/2;hb=np.linalg.norm(v,axis=1)/2
    endpoint_tree=KDTree(len(q))
    for j,point in enumerate(q):endpoint_tree.insert(point.tolist(),j)
    endpoint_tree.balance()
    # The returned pair need not be the exact nearest endpoint: any real pair
    # is a valid upper bound. Recompute its distance in double precision.
    endpoint_indices=np.array([endpoint_tree.find(point.tolist())[1] for point in p])
    d=np.linalg.norm(p-q[endpoint_indices],axis=1);i=int(np.argmin(d));upper=float(d[i]);best=upper*upper
    point_a=p[i].copy();point_b=q[endpoint_indices[i]].copy();ids_best=None
    midpoint_tree=KDTree(len(mb))
    for j,point in enumerate(mb):midpoint_tree.insert(point.tolist(),j)
    midpoint_tree.balance()
    # Blender's KDTree stores floats. Expand its query radius conservatively;
    # the actual segment minimization below remains in double precision.
    tree_margin=float(64*np.finfo(np.float32).eps*max(1.,float(np.max(abs(p))),float(np.max(abs(q)))))
    neighbours=[[entry[1] for entry in midpoint_tree.find_range(point.tolist(),float(upper+half+hb.max()+tree_margin))]
                for point,half in zip(ma,ha)]
    ai=np.repeat(np.arange(len(ma)),[len(n) for n in neighbours]);bi=np.concatenate([np.array(n,int) for n in neighbours])
    comparisons=0
    for start in range(0,len(ai),50000):
        ii=ai[start:start+50000];jj=bi[start:start+50000]
        a=p[ii];b=q[jj];uu=u[ii];vv=v[jj];w=a-b
        A=np.einsum('ij,ij->i',uu,uu);B=np.einsum('ij,ij->i',vv,vv);C=np.einsum('ij,ij->i',uu,vv)
        D=np.einsum('ij,ij->i',uu,w);E=np.einsum('ij,ij->i',vv,w)
        det=A*B-C*C
        candidates=[]
        for s in [np.zeros(len(ii)),np.ones(len(ii))]:
            t=np.clip((C*s-D)/A,0,1);candidates.append((t,s))
        for t in [np.zeros(len(ii)),np.ones(len(ii))]:
            s=np.clip((E+C*t)/B,0,1);candidates.append((t,s))
        den=np.where(det>1e-24,det,1);t=(C*E-B*D)/den;s=(A*E-C*D)/den
        valid=(det>1e-24)&(t>=0)&(t<=1)&(s>=0)&(s<=1)
        candidates.append((t,s))
        for k,(t,s) in enumerate(candidates):
            delta=w+t[:,None]*uu-s[:,None]*vv;distance=np.einsum('ij,ij->i',delta,delta)
            if k==4:distance=np.where(valid,distance,np.inf)
            z=int(np.argmin(distance))
            if distance[z]<best:
                best=float(distance[z]);point_a=a[z]+t[z]*uu[z];point_b=b[z]+s[z]*vv[z];ids_best=[int(ii[z]),int(jj[z])]
        comparisons+=len(ii)
    return dict(centreline_distance_mm=float(np.sqrt(best)),point_a_mm=point_a.tolist(),point_b_mm=point_b.tolist(),
                candidate_segment_pairs=comparisons,segments=[len(u),len(v)],nearest_segments=ids_best,
                exhaustive_pruning_upper_bound_mm=upper,kdtree_query_margin_mm=tree_margin)

def algorithm_checks():
    examples=[
        ('perpendicular_cross',[[-1,0,0],[1,0,0]],[[0,-1,0],[0,1,0]],0.),
        ('parallel_offset',[[0,0,0],[3,0,0]],[[1,1,0],[2,1,0]],1.),
        ('endpoint_minimum',[[0,0,0],[1,0,0]],[[2,1,0],[2,2,0]],np.sqrt(2)),
        ('skew',[[0,0,0],[3,0,0]],[[1,-1,3],[1,1,3]],3.),
        ('collinear_overlap',[[0,0,0],[3,0,0]],[[1,0,0],[4,0,0]],0.),
        ('segmented_cross',[[-2,0,0],[0,0,0],[2,0,0]],[[1,-1,0],[1,0,0],[1,1,0]],0.),
        ('duplicate_endpoint',[[0,0,0],[0,0,0],[1,0,0]],[[2,1,0],[2,1,0],[2,2,0]],np.sqrt(2)),
    ]
    checks=[]
    for name,p,q,expected in examples:
        actual=exact_pair(p,q)['centreline_distance_mm']
        assert abs(actual-expected)<1e-9,(name,actual,expected)
        checks.append(dict(case=name,expected_mm=float(expected),actual_mm=actual,status='PASS'))
    return checks
