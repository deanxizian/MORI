"""Screen a small deliberate set of sideways/lower fixed-tail alternatives."""
from pathlib import Path
import datetime
import sys
import json
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'cam_tail_simplification_R2'))
from compare_zero import Context,np,clear,sha,PowerFamily,BSpline,pieces,RADII,helpers,inspect,HELPERS
sys.path.insert(0,str(PARENT/'cam_tail_simplification_R4'));from diverted_tail import DivertedFamily


def main():
    started=time.time();native=Context();carrier=PowerFamily();trials=[];selected=None
    prefixes={n:helpers.prepare(pieces(BSpline(carrier.ctx.f.knots,carrier.ctx.f.candidate(n,0)['control'],3)),
                               carrier.ctx.f.radii[n]) for n in carrier.ctx.f.names}
    for top,outward,R in [(240.,12.,9.),(245.,12.,9.),(240.,11.,9.),(250.,10.,9.)]:
        family=DivertedFamily(carrier,top,outward,R);checks=[];math_rows=[]
        for name in [f'CAM_{p}' for p in range(1,5)]:
            c,info=family.upper(name,0.,0.);math_rows.append(dict(wire=name,**info))
            if c is None:
                checks.append(dict(wire=name,kind='curve_math',status='BLOCKED',details=info));continue
            pack=helpers.prepare(c,RADII[name])
            for group,targets in [('pitch',native.groups['pitch']),('conditional_USB',native.usb)]:
                hits,near=clear(pack['p'],pack['radius'],targets,error=pack['error'],gap=.3)
                checks.append(dict(wire=name,kind=group,status='PASS' if not hits else 'BLOCKED',
                                   hits=hits,nearest_within_query_AABBs=near))
        okay=all(r['status']=='PASS' for r in checks)
        trials.append(dict(candidate_parameters=family.spec,status='PASS' if okay else 'BLOCKED',checks=checks,numeric_curve_math=math_rows))
        print('CAM_UNIFORM_OFFSET_R6_SCREEN',top,outward,R,okay,flush=True)
        if not okay:continue
        review,arrays=inspect(family,native,carrier,prefixes);trials[-1]['full_zero_review']=review
        print('CAM_UNIFORM_OFFSET_R6_FULL_ZERO',top,outward,R,review['status'],len(review['failures']),flush=True)
        if review['status']=='PASS':
            selected=review;np.savez_compressed(HERE/'zero_curves.npz',**arrays);break
    native.record([Path(__file__),PARENT/'cam_tail_simplification_R4/diverted_tail.py',PARENT/'cam_tail_simplification_R2/compare_zero.py',
                   HELPERS,HELPERS.parent/'sample_geometry.py',PARENT/'upper_pairs_review_R1/inspect_pairs.py'])
    native.sources.update(carrier.sources);native.unchanged();carrier.unchanged()
    out=dict(status='PASS' if selected else 'BLOCKED',scope='Sideways fixed-head detour, original approach and ports; zero pose only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources,trials=trials,selected=selected,
        arrays_sha256=sha(HERE/'zero_curves.npz') if selected else None,elapsed_s=time.time()-started,
        other_poses='NOT_TESTED',all_angle_clearance='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        real_ports_changed=False,service_loop_construction_changed=False,main_changed=False,animation_changed=False,
        hardware_changed=False,manufacturing_release=False)
    (HERE/'zero_review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CAM_UNIFORM_OFFSET_R6_ZERO_TERMINAL',out['status'],len(trials),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
