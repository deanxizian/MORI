"""Publish combined finite progress, with original failures and gates intact."""
from pathlib import Path
import datetime
import hashlib
import html
import json
import re
from urllib.parse import unquote,urlsplit
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent;PROJECT=HERE.parents[3]
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    verified=read(HERE/'verification.json')
    assert verified['status']=='PASS' and verified['recomputed_numeric_curve_poses']==910
    assert verified['final_unique_upper_peer_checks']==2730 and verified['remaining_P1_actual_arc_checks']==260
    assert verified['final_remote_self_and_own_join_checks']==1820
    assert all(sha(p)==h for p,h in verified['sources'].items())
    rows=''.join(f'<tr><td>{html.escape(r["wire"])}</td><td>{r["curve_poses"]}</td><td>{r["previous_numeric_range_mm"]:.6f}</td><td>{r["final_numeric_range_mm"]:.9f}</td><td>PASS</td></tr>' for r in verified['summaries'])
    paths=['../upper_length_match_R1/all_poses_length_match.json','../upper_length_match_R1/all_poses_geometry_inspection.json',
           '../bundle_length_match_R1/all_poses_length_match.json','../bundle_length_match_R1/all_poses_geometry_inspection.json']
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 已知上段长度补偿与间隙</title>
<style>body{{max-width:1080px;margin:35px auto;padding:0 18px 65px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}.scroll{{overflow:auto}}</style>
<h1>M1.55 · 已知上段长度补偿与间隙</h1><p>2026-10-09 · <strong>7条已知参考的130个有限姿态检查PASS；完整线束BLOCKED，候选未采用。</strong></p>
<p class="notice">CAM参考的原余量圈重新匹配已通过的R3前段，圈高最多减少约4.23mm；电源／CC仅调整原五次曲线的两个内部控制点。真实接口、PCB、打印件与各参考端点保持。数值路径尚未对应选定的混合线材、实际接头和固定点，表内长度不是供应商裁线尺寸。</p>
<p><a href="../index.html">线束总览</a> · <a href="../upper_smooth_review_R2/index.html">此前曲率／长度差记录</a> · <a href="../../../../docs/CURRENT_STATUS.md">当前待办</a> · <a href="../../../mori_v1_2.blend">M1.55主模型</a> · <a href="../../../animation/index.html">M1.55-A1装配视频</a></p>
<h2>本轮完成</h2><p>4根CAM×130姿态：520个数值长度、整段三次曲率与切向接续检查，11,180项新间隙／自接近检查通过。电源P_J18_2与CC×130姿态：260个长度／曲率检查和5,850项新间隙／自接近检查通过；此前9个关键姿态的405项结果单独保留。</p>
<p>新曲线直接检查当前201件原生实体及其他前段。远端自接近／自身接续只排除实际曲线弧长上界不超过5mm的相邻区间，用三次段的精确子区间控制多边形给出上界，不借用旧折线弧长。</p>
<p>独立汇总用单项式速度重新计算全部910个完整数值路径长度；精确确认CAM四根与P_J18_1在后续电源／CC候选中没有变化。替换已改动配对后，共2,730项最终上段配对，避免累计不同候选的旧结果。P_J18_1另外执行260项实际弧长的远端自接近／自身接续检查。六条改动参考有2,340个新原生分组检查；P_J18_1的实体间隙沿用完全一致数组的R2偏差证明，未重跑BVH。</p>
<div class="scroll"><table><tr><th>参考</th><th>姿态数</th><th>此前数值长度变化mm</th><th>现在数值长度变化mm</th><th>原0.01mm数值标准</th></tr>{rows}</table></div>
<p>小数只是算法诊断；Gauss32／64对照没有变成完整积分误差证书、线材伸缩公差或制造精度。全部路线仍为PLACEHOLDER / ASSUMED。局部管体／真实拼接、中间角度及材料寿命尚未验证。</p>
<h2>剩余四类工作</h2><ol><li>补齐3条舵机与2条喇叭上段，继续整个运动范围检查。</li><li>以真实材料分段、尾线和固定／滑移点完成长度与余量，形成供应商图。</li><li>确定配对接头和应力释放；CAM供电源端等正式硬件交接，喇叭插头规格待补。</li><li>完整带线穿装、头身连接、拆壳／闭壳复核，确认后同步主模型和动画。</li></ol>
<p>SC-0090-C001舵盘／锁紧配件及微雪FPC／FFC按用户决定到货核对；PA12配合、开放颈壁强度与动态寿命仍需试件。</p>
<h2>原始证据</h2><p><a href="{paths[0]}">CAM长度／曲率</a> · <a href="{paths[1]}">CAM全姿态新间隙</a> · <a href="{paths[2]}">电源／CC长度／曲率</a> · <a href="{paths[3]}">电源／CC全姿态新间隙</a> · <a href="verification.json">最终数组独立汇总与P1弧长检查</a> · <a href="commands.json">实际命令</a> · <a href="README.md">复现边界</a> · <a href="delivery.json">交付哈希</a></p>
<p>初次汇总脚本误将不同报告的长度字段视为相同字段，日志及代码保留在<a href="initial_field_name/receipt.json">初始字段诊断</a>。修正读取后重新计算成功；没有改变候选几何。</p>
<p>主模型、视频及原生硬件未改；没有新commit／push或供应商消息。PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# 已知上段有限长度补偿：未采用

4根CAM的520个长度／曲率检查和11180项新间隙检查通过；两条电源／CC的
260个长度／曲率检查和5850项新间隙检查通过。CAM原圈高按共同前段重新补偿；
电源／CC只移动原五次曲线的两个内部控制点，以128个固定参数区间转换为三次段。
每段实际三次曲率单独检查，不能借原多项式或名义圆弧半径放行。

verify_combined.py独立用单项式速度重算910个完整数值路径长度，并核对数组身份。
最终配对替换电源／CC改动涉及的旧行，得到2730项一致来源的最终配对。
P1还执行260项实际弧长远端自接近／自身接续；未把其原生间隙重跑一遍，
因为数组与R2证明完全相同。相邻区间按实际三次弧长上界<=5mm排除。
此前初始汇总错误是CAM与电源／CC报告的字段名不同，原代码和日志保留。

Gauss64／32相符是数值诊断，不是完整积分误差证明、真实材料长度或裁线公差。
缺失五条上段、中间角度、实际端接／材料分段／固定以及带线装配仍未闭合。
主模型M1.55和视频M1.55-A1、hardware/原生源保持；没有Git动作。
''')
    runtime='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
    blender='/Applications/Blender.app/Contents/MacOS/Blender';commands=[]
    for folder,script,args,log,program in [
        ('upper_length_match_R1','match_cam.py',['--zero'],'match_cam_zero.log',runtime),
        ('upper_length_match_R1','match_cam.py',[],'match_cam_all_poses.log',runtime),
        ('upper_length_match_R1','inspect_changed.py',['--','--zero'],'inspect_zero.log',blender),
        ('upper_length_match_R1','inspect_changed.py',[],'inspect_all_poses.log',blender),
        ('bundle_length_match_R1','match_bundle.py',['--pilot'],'match_pilot.log',runtime),
        ('bundle_length_match_R1','match_bundle.py',[],'match_all_poses.log',runtime),
        ('bundle_length_match_R1','inspect_changed.py',['--','--pilot'],'inspect_pilot.log',blender),
        ('bundle_length_match_R1','inspect_changed.py',[],'inspect_all_poses.log',blender),
        ('complete_known_upper_review_R1','verify_combined.py',[],'verify_combined.log',runtime)]:
        base=PARENT/folder;assert 'Traceback (most recent call last)' not in (base/log).read_text()
        command=[program,*(['-b','mechanical/mori_v1_2.blend','--python'] if program==blender else []),str((base/script).relative_to(PROJECT)),*args]
        commands.append(dict(command=command,cwd=str(PROJECT),log=str((base/log).relative_to(PROJECT)),log_sha256=sha(base/log),exit_code=0))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,Blender='5.2.2 LTS d13f752e3b9c',
        Python='3.13.13',NumPy='2.3.4',initial_failures=['initial_field_name/receipt.json','../upper_length_match_R1/initial_duplicate_kind/inspect_zero.log']),ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_result.log']}
    receipt=dict(status='PASS',scope='Finite numeric upper candidate publication only',files=files,
        source_blend_sha256=verified['main_sha256'],numeric_known_full_length_range_finite='PASS',
        known_upper_curve_poses=910,final_unique_upper_peer_checks=2730,remote_self_and_own_join_checks=1820,
        remaining_work_packages=4,missing_upper_references=verified['remaining_missing_upper'],full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    links=[]
    for value in re.findall(r'(?:href|src)="([^"]+)"',page):
        parsed=urlsplit(value)
        if parsed.scheme or not parsed.path:continue
        p=(HERE/unquote(parsed.path)).resolve();assert p.is_file() and p.is_relative_to(PROJECT)
        with urlopen(Request('http://127.0.0.1:58202/'+str(p.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:assert response.status==200
        links.append(str(p.relative_to(PROJECT)))
    with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
    assert all(sha(p)==h for p,h in verified['sources'].items())
    out=dict(status='PASS',checked_files=len(files),checked_links=links,delivery_sha256=sha(HERE/'delivery.json'),
        published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_harness='BLOCKED',manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('FINAL_KNOWN_UPPER_PUBLISHED',len(files),'files',len(links),'links',flush=True)


if __name__=='__main__':main()
