"""Combine exact final arrays and independently audit finite upper results.

The two previous fresh geometry reports cover six changed references. Their
overlapping pairs are replaced with the later power/CC checks, rather than
adding counts from different candidate arrays. P1's actual-arc self/join
checks are new here. No actual termination or material cut length is inferred.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import itertools
import json
import subprocess
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent;PROJECT=HERE.parents[3]
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import PiecewiseContext,BSpline,pieces,unit,RADII
sys.path.insert(0,str(PARENT/'upper_length_match_R1'))
from sample_geometry import sample
spec=importlib.util.spec_from_file_location('_mori_finite_upper_pair_engine',PARENT/'upper_pairs_review_R1/inspect_pairs.py')
pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
POSES={(y,p) for y in range(-60,61,10) for p in range(-20,26,5)}


def direct_length(c,order):
    # Independent monomial conversion, rather than Bernstein velocity code.
    p0,p1,p2,p3=np.moveaxis(c,1,0)
    a=-p0+3*p1-3*p2+p3;b=3*p0-6*p1+3*p2;d=-3*p0+3*p1
    q,w=np.polynomial.legendre.leggauss(order);t=(q+1)/2
    v=d[:,None,:]+2*b[:,None,:]*t[None,:,None]+3*a[:,None,:]*t[None,:,None]**2
    return float((np.linalg.norm(v,axis=-1)@(w/2)).sum())


def prepare(c,radius):
    sampled=sample(c);pack=pair.prepare(sampled['points'],radius,sampled['error'])
    pack['arc']=sampled['arc_upper'];return pack


def main():
    started=time.time();ctx=PiecewiseContext()
    cam_dir=PARENT/'upper_length_match_R1';bundle_dir=PARENT/'bundle_length_match_R1';old_dir=PARENT/'upper_smooth_review_R2'
    paths=[cam_dir/'all_poses_length_match.json',cam_dir/'all_poses_geometry_inspection.json',
           bundle_dir/'all_poses_length_match.json',bundle_dir/'all_poses_geometry_inspection.json',
           old_dir/'transfer_inspection.json',old_dir/'clearance_transfer.json',old_dir/'numeric_length_inventory.json']
    cam,cam_geometry,bundle,bundle_geometry,old,transfer,inventory=[read(p) for p in paths]
    assert all(r['status']=='PASS' for r in [cam,cam_geometry,bundle,bundle_geometry,old,transfer,inventory])
    assert not cam_geometry['failures'] and not bundle_geometry['failures']
    assert cam_geometry['counts']==cam_geometry['expected_counts'] and sum(cam_geometry['counts'].values())==11180
    assert bundle_geometry['counts']==bundle_geometry['expected_counts'] and sum(bundle_geometry['counts'].values())==5850
    assert {tuple(p) for p in cam['planned_poses']}=={tuple(p) for p in bundle['selected']['planned_poses']}==POSES
    assert len(cam['rows'])==520 and len(bundle['selected']['rows'])==260
    for r in [cam,cam_geometry,bundle,bundle_geometry,old,transfer,inventory]:
        ctx.sources.update(r['sources'])
    assert all(sha(p)==h for p,h in ctx.sources.items())
    cam_arrays=cam_dir/'all_poses_curves.npz';bundle_arrays=bundle_dir/'all_poses_curves.npz';old_arrays=old_dir/'transfer_curves.npz'
    assert sha(cam_arrays)==cam['arrays_sha256']==cam_geometry['source_cubic_arrays_sha256']
    assert sha(bundle_arrays)==bundle['arrays_sha256']==bundle_geometry['source_cubic_arrays_sha256']
    assert sha(old_arrays)==old['arrays_sha256']
    a=np.load(cam_arrays);final=np.load(bundle_arrays);before=np.load(old_arrays)
    expected={f'{n}_y{y}_p{p}_{suffix}' for n in RADII for y,p in POSES for suffix in ['controls','lengths']}
    assert set(a.files)==set(final.files)==set(before.files)==expected
    unchanged=0
    for name in ['CAM_1','CAM_2','CAM_3','CAM_4','P_J18_1']:
        for yaw,pitch in POSES:
            for suffix in ['controls','lengths']:
                key=f'{name}_y{yaw}_p{pitch}_{suffix}';assert np.array_equal(final[key],a[key]);unchanged+=1
                if name=='P_J18_1':assert np.array_equal(final[key],before[key])
    # Replace every earlier pair involving the changed power/CC references.
    changed={'P_J18_2','CC_allocation'};peer_rows={}
    for report,late in [(cam_geometry,False),(bundle_geometry,True)]:
        for r in report['rows']:
            if r['kind']!='upper_peer':continue
            if not late and changed.intersection(r['wires']):continue
            key=(r['yaw_deg'],r['pitch_deg'],*sorted(r['wires']))
            assert key not in peer_rows and r['status']=='PASS'
            peer_rows[key]=r
    assert len(peer_rows)==2730
    assert {(k[2],k[3]) for k in peer_rows}==set(itertools.combinations(sorted(RADII),2))
    known={r['wire']:r for r in inventory['summaries']}
    target={r['wire']:r['target_full_reference_mm'] for r in cam['summaries']}|bundle['selected']['targets']
    metadata={(r['wire'],r['yaw_deg'],r['pitch_deg']):r for r in cam['rows']+bundle['selected']['rows']}
    rows=[];p1_rows=[];prefix_cache={}
    for yaw,pitch in sorted(POSES):
        raw=ctx.upper(yaw,pitch)
        for name in sorted(RADII):
            c=final[f'{name}_y{yaw}_p{pitch}_controls']
            assert np.array_equal(c[0,0],raw[name][0]) and np.array_equal(c[-1,-1],raw[name][-1])
            v0=np.diff(c,axis=1)[:,0];v1=np.diff(c,axis=1)[:,-1]
            v0/=np.linalg.norm(v0,axis=1)[:,None];v1/=np.linalg.norm(v1,axis=1)[:,None]
            incoming,outgoing=ctx.tangents(name,yaw,pitch)
            assert np.linalg.norm(v0[0]-unit(incoming))<1e-8 and np.linalg.norm(v1[-1]-unit(outgoing))<1e-8
            assert np.linalg.norm(v1[:-1]-v0[1:],axis=1).max()<1e-8
            assert np.linalg.norm(c[:-1,-1]-c[1:,0],axis=1).max()<1e-10
            prefix=ctx.f.candidate(name,yaw)['control'];body=float(ctx.f.weights@np.linalg.norm(ctx.f.Q@prefix,axis=1))
            assert abs(body-ctx.f.targets[name])<1e-7
            L64=direct_length(c,64);L32=direct_length(c,32);full=body+L64
            residual=full-target[name] if name in target else None
            if name in target:
                assert abs(residual)<1e-7
                assert abs(L64-metadata[name,yaw,pitch]['upper_Gauss64_length_mm'])<1e-7
            rows.append(dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,status='PASS',
                upper_monomial_Gauss64_mm=L64,body_neck_Gauss64_mm=body,full_numeric_reference_mm=full,
                numeric_target_mm=target.get(name),numeric_residual_mm=residual,
                monomial_Gauss32_64_difference_mm=abs(L32-L64),endpoints_exact=True,
                supplier_cut_length=None,actual_material_split='BLOCKED'))
        if yaw not in prefix_cache:
            c=pieces(BSpline(ctx.f.knots,ctx.f.candidate('P_J18_1',yaw)['control'],3))
            prefix_cache[yaw]=prepare(c,ctx.f.radii['P_J18_1'])
        pack=prepare(final[f'P_J18_1_y{yaw}_p{pitch}_controls'],RADII['P_J18_1'])
        for kind,left in [('self',pack),('own_join',prefix_cache[yaw])]:
            result=pair.compare(left,pack,kind);result.pop('local_excluded_polyline_arc_mm',None)
            row=dict(wire='P_J18_1',yaw_deg=yaw,pitch_deg=pitch,**result,
                local_exclusion_actual_arc_upper_mm=5.,arc_bound_source='Exact cubic restriction control polygons')
            p1_rows.append(row);assert row['status']=='PASS',row
        if pitch==25:print('FINAL_KNOWN_UPPER_YAW',yaw,len(rows),len(p1_rows),flush=True)
    summaries=[]
    for name in sorted(RADII):
        subset=[r for r in rows if r['wire']==name];lengths=[r['full_numeric_reference_mm'] for r in subset]
        spread=max(lengths)-min(lengths);assert spread<.01
        summaries.append(dict(wire=name,curve_poses=len(subset),previous_numeric_range_mm=known[name]['full_reference_range_mm'],
            final_numeric_range_mm=spread,final_numeric_min_mm=min(lengths),final_numeric_max_mm=max(lengths),
            historical_numeric_criterion_mm=.01,numeric_reference_range='PASS',supplier_cut_length=None))
    assert len(rows)==910 and len(p1_rows)==260
    ctx.record(paths+[Path(__file__),cam_arrays,bundle_arrays,old_arrays,
                       cam_dir/'sample_geometry.py',PARENT/'upper_pairs_review_R1/inspect_pairs.py'])
    main_path=PROJECT/'mechanical/mori_v1_2.blend';video_path=PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(main_path)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video_path)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
    assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
    ctx.record([main_path,video_path]);ctx.unchanged()
    out=dict(status='PASS',scope='Seven known upper numeric references at 130 finite poses; missing routes, real materials and wired assembly excluded',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        combined_arrays=str(bundle_arrays),combined_arrays_sha256=sha(bundle_arrays),
        recomputed_numeric_curve_poses=len(rows),exact_unchanged_array_checks=unchanged,
        summaries=summaries,numeric_rows=rows,final_unique_upper_peer_checks=len(peer_rows),
        final_upper_peer_rows=list(peer_rows.values()),remaining_P1_actual_arc_checks=len(p1_rows),P1_actual_arc_rows=p1_rows,
        changed_six_fresh_native_group_checks=2340,
        P1_native_method='Exact arrays unchanged from R2 current-solid clearance transfer proof; no new BVH replay',
        final_remote_self_and_own_join_checks=1820,
        local_smooth_tube_or_splice='NOT_TESTED',between_pose_motion='NOT_TESTED',
        remaining_missing_upper=['P_J9_1','P_J9_2','P_J9_3','SPK_reservation_3','SPK_reservation_6'],
        quadrature_error_certificate='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_sha256=sha(main_path),video_sha256=sha(video_path),git_head=head,elapsed_s=time.time()-started,
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('FINAL_KNOWN_UPPER_TERMINAL',out['status'],len(rows),len(peer_rows),len(p1_rows),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
