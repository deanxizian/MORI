"""Fresh finite pair/self/join checks of the matched three-wire upper study."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from matched_references import MatchedReferences,NAMES,RADII,FRAME,sha,np,PREVIOUS_REVIEW
spec=importlib.util.spec_from_file_location('_mori_upper_pairs_R1',PREVIOUS_REVIEW/'inspect_pairs.py')
prior=importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
prepare,compare,algorithm_checks=prior.prepare,prior.compare,prior.algorithm_checks


def main():
    started=time.time();refs=MatchedReferences();tests=algorithm_checks()
    refs.record([Path(__file__),PREVIOUS_REVIEW/'inspect_pairs.py'])
    rows=[];failures=[];counts={'peer':0,'self':0,'own_join':0}
    compared=0;zero={}
    for yaw in range(-60,61,10):
        prefix=refs.prefixes(yaw)
        prepack={n:prepare(r['points'],r['radius'],r['error']) for n,r in prefix.items()}
        for pitch in range(-20,26,5):
            upper=refs.upper(yaw,pitch)
            packs={n:prepare(p,RADII[n],.0006) for n,p in upper.items()}
            tasks=[(a,b,'peer') for a,b in itertools.combinations(NAMES,2)]
            tasks += [(n,n,'self') for n in NAMES]+[(n,n,'own_join') for n in NAMES]
            for a,b,kind in tasks:
                left=prepack[a] if kind=='own_join' else packs[a]
                result=compare(left,packs[b],kind)
                row=dict(yaw_deg=yaw,pitch_deg=pitch,wires=[a,b],**result)
                rows.append(row);counts[kind]+=1;compared+=result['compared_segment_pairs']
                if result['status']!='PASS':failures.append(row)
            if yaw==pitch==0:zero=upper
            print('MATCHED_UPPER_PAIRS_POSE',yaw,pitch,'checks',len(rows),'failed',len(failures),flush=True)
    assert counts=={'peer':2730,'self':910,'own_join':910}
    assert len(refs.adjustments)==260
    refs.unchanged()
    np.savez_compressed(HERE/'zero_pose_matched_upper.npz',**zero)
    out=dict(status='PASS' if not failures else 'BLOCKED',
        scope='Matched upper-study peer gaps, remote reference-polyline self and own joins at 130 finite poses only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=refs.sources,
        revision='V1.2-M1.55',poses=130,known_upper_references=7,checks=counts,
        checked_rows=len(rows),compared_finite_segment_pairs=compared,algorithm_checks=tests,
        rows=rows,failures=failures,assumed_end_adjustments=refs.adjustments,
        required_gap_mm=.3,local_excluded_reference_polyline_arc_mm=5.,
        local_smooth_tube_or_splice='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',actual_endpoints_and_clamps='BLOCKED',
        actual_mixed_material_length='BLOCKED',wired_assembly_and_closure='BLOCKED',full_harness='BLOCKED',
        native_hardware_moved=False,main_changed=False,animation_changed=False,hardware_changed=False,
        new_commit_or_push=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_UPPER_PAIRS_TERMINAL',out['status'],counts,len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
