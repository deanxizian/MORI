"""Publish matched upper-reference correction, retaining failed predecessors."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def comparison_svg():
    pieces=['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="410" viewBox="0 0 1100 410">',
            '<rect width="1100" height="410" fill="#f6f8f9"/>',
            '<style>text{font-family:Arial,sans-serif;fill:#243841} .small{font-size:17px}</style>',
            '<text x="35" y="38" font-size="23">USB 假定出线位置：参考截面对比</text>',
            '<text x="35" y="68" class="small">未选定的尾线容量候选；没有移动真实接口或 PCB</text>']
    for x,spacing,title,gap,color in [(275,1.05,'旧电源上段＋后来 CC 参考',.0975,'#ab4935'),
                                      (825,1.75,'同组三线配套候选 R2',.7975,'#26765f')]:
        pieces.append(f'<text x="{x}" y="115" text-anchor="middle" font-size="21">{title}</text>')
        for offset,radius,fill,label in [(-spacing,.5842,'#c68b37','P_J18_1'),
                                         (0,.3683,'#3d9faa','CC'),
                                         (spacing,.5842,'#718591','P_J18_2')]:
            cx=x+offset*90
            pieces.append(f'<circle cx="{cx:.4f}" cy="218" r="{radius*90:.4f}" fill="{fill}" fill-opacity=".75" stroke="{fill}" stroke-width="2"/>')
            pieces.append(f'<text x="{cx:.4f}" y="297" text-anchor="middle" class="small">{label}</text>')
        pieces.append(f'<text x="{x}" y="345" text-anchor="middle" font-size="22" fill="{color}">CC 两侧名义净距约 {gap:.4f} mm</text>')
    pieces += ['<text x="550" y="386" text-anchor="middle" class="small">目标 0.3 mm；图示为零位名义圆形线径，实际端接、尾线与固定方式仍待确定。</text>','</svg>']
    return '\n'.join(pieces)+'\n'


def main():
    verified=read(HERE/'result_verification.json')
    assert verified['status']=='PASS' and all(sha(p)==h for p,h in verified['sources'].items())
    native=read(HERE/'native_refinement.json')
    reports=['inspection.json','native_inspection.json','native_refinement.json',
             'replacement_prefix_inspection.json','result_verification.json']
    for name in reports:
        report=read(HERE/name)
        assert all(sha(p)==h for p,h in report['sources'].items())
    digest=sha(MECHANICAL/'mori_v1_2.blend')
    assert digest=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    (HERE/'assumed_exit_comparison.svg').write_text(comparison_svg())
    render=read(HERE/'diagram_render_receipt.json');visual=read(HERE/'diagram_visual_review.json')
    assert render['status']==visual['status']=='PASS'
    assert sha(HERE/render['source'])==render['source_sha256']
    assert sha(HERE/render['output'])==render['output_sha256']
    assert all(sha(p)==h for p,h in visual['sources'].items())
    commands=[]
    for script,runtime,args in [
        ('../upper_pairs_review_R1/capture_transforms.py','/Applications/Blender.app/Contents/MacOS/Blender',['-b','mechanical/mori_v1_2.blend','--python']),
        ('../upper_pairs_review_R1/inspect_pairs.py','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',[]),
        ('inspect_pairs.py','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',[]),
        ('inspect_changed_native.py','/Applications/Blender.app/Contents/MacOS/Blender',['-b','mechanical/mori_v1_2.blend','--python']),
        ('refine_native.py','/Applications/Blender.app/Contents/MacOS/Blender',['-b','mechanical/mori_v1_2.blend','--python']),
        ('inspect_replacement_prefixes.py','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',[]),
        ('verify_results.py','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',[])]:
        path=(HERE/script).resolve();log=path.with_suffix('.log')
        assert 'Traceback (most recent call last)' not in log.read_text()
        commands.append(dict(command=[runtime]+args+[str(path.relative_to(PROJECT))],cwd=str(PROJECT),
            log=str(log.relative_to(PROJECT)),log_sha256=sha(log)))
    diagram_log=HERE/'render_comparison_sharp.log'
    commands.append(dict(command=['/Users/dean/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node',
                                  str((HERE/'render_comparison.cjs').relative_to(PROJECT))],
                         cwd=str(PROJECT),log=str(diagram_log.relative_to(PROJECT)),log_sha256=sha(diagram_log),
                         scope='Rasterize authored vector only; cropped initial QuickLook thumbnail not used'))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,
        retained_initial_logs=['inspect_replacement_prefixes_initial_import.log',
                               'inspect_replacement_prefixes_initial_junction_assumption.log','render_comparison.log'],
        initial_quicklook_command=['qlmanage','-t','-s','1400','-o',str(HERE.relative_to(PROJECT)),
                                   str((HERE/'assumed_exit_comparison.svg').relative_to(PROJECT))],
        initial_attempt_notes='Import error fixed; subsequent junction assertion incorrectly assumed both power stubs ended atZ206. Retry reads actual retained source junctions Z206 andZ208. No path geometry or threshold changed.'),ensure_ascii=False,indent=2)+'\n')
    progress=dict(status='PASS',scope='Finite matched known-upper reference checks only, unadopted',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources={str(HERE/n):sha(HERE/n) for n in reports+["commands.json"]},
        source_blend_sha256=digest,revision='V1.2-M1.55',known_upper_references=7,
        upper_finite_native_gap='PASS',upper_finite_peer_gap='PASS',
        upper_remote_reference_polyline='PASS',mixed_radius_own_join_reference='PASS',
        replaced_power_upper_references=2,assumed_endpoint_change_mm=.7,
        original_incompatible_peer_rows_retained=260,reference_pair_rows=4550,
        new_native_group_checks=780,refined_native_rows=1,
        unchanged_native_group_checks_reused_with_exact_hashes=1950,
        new_stub_checks=312,new_polynomial_to_prefix_bounds=260,
        local_smooth_tube_or_splice='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',complete_upper_tails='BLOCKED',
        actual_mixed_material_length='BLOCKED',actual_endpoints_and_clamps='BLOCKED',
        wired_assembly_and_closure='BLOCKED',remaining_work_packages=4,full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 上段三线配套修正与复核</title>
<style>body{{max-width:1100px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}img{{width:100%;height:auto}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}</style>
<h1>M1.55 · 上段三线配套修正</h1><p>2026-10-09 · <strong>当前7条已知上段的有限参考检查PASS；完整线束BLOCKED／未采用。</strong></p>
<p class="notice">修复的是未采用研究路线的配套不一致。原来保留旧两根电源上段、配后来CC候选，假定USB出口净距不足。现在配套使用同组三线候选；两根电源的假定出口各向外0.7mm，实际USB、PCB、打印件和主模型没有移动。未知真实端接没有因此变为已确认。</p>
<p><a href="../index.html">线束研究总览</a> · <a href="../upper_reference_review_R1/index.html">上一轮实体检查与剩余四项</a> · <a href="../prefix_continuity/frame_family_R3/continuous_gaps_R1/index.html">前段连续几何</a> · <a href="../../../mori_v1_2.blend">当前主模型</a> · <a href="../../../animation/index.html">装配视频</a></p>
<h2>为何需要配套</h2><p>原混用参考中，CC与两根电源的名义净距各约0.0975mm，低于0.3mm目标；130个姿态共260条不足记录保留。采用同组三线候选后，零位假定出口名义净距约0.7975mm，完整上段配对也重新检查。没有把局部出口距离当成全线最小值。</p>
<img src="assumed_exit_comparison.png" alt="旧混用参考和同组三线候选的假定出口线径截面对比"><p><a href="assumed_exit_comparison.svg">原始矢量图</a> · <a href="diagram_visual_review.json">图示目视与数字核对</a></p>
<h2>这轮已完成的有限检查</h2><table><tr><th>项目</th><th>范围</th><th>结果与边界</th></tr>
<tr><td>上段彼此间隙</td><td>7条、21组配对×130姿态，共2,730次</td><td>PASS，原0.3mm目标保持；双精度有限线段及保守曲线偏差</td></tr>
<tr><td>上段远端回环</td><td>7条×130姿态，共910次</td><td>参考折线PASS；排除≤5mm局部相邻弧段，局部平滑管体仍NOT_TESTED</td></tr>
<tr><td>与自身前段接续</td><td>粗细半径分别处理，共910次</td><td>参考远端接近PASS；Z200共享端点不当作跨线碰撞，真实接头及局部连续曲率仍未闭合</td></tr>
<tr><td>当前原生实体</td><td>新两根电源上段780次分组检查；其余5条的1,950次检查按完全一致当前来源保留</td><td>有限姿态PASS；一个保守下界不足行用同一折线加密复核，原路线未移动，下界约{verified['minimum_refined_native_gap_lower_mm']:.6f}mm</td></tr>
<tr><td>新电源上段对全部前段</td><td>12条R3前段；312次不变接续段检查，260个新多项式分离界</td><td>PASS；真实源接续为Z206／Z208，来自原数组。新多项式位于前段上方，按控制凸包证明分离</td></tr>
<tr><td>算法与范围核对</td><td>24次小规模穷举对照，全部姿态／配对覆盖，失败行与精化行对应</td><td>PASS；不扩大到中间角度或实际材料寿命</td></tr></table>
<h2>仍然没有完成的部分</h2><p>3根舵机与2根喇叭参考仍缺完整上段；已知上段的连续中间角度、完整平滑曲率和真实局部接续仍待完成。完整材料长度、厂配SH尾线、压接、第一可弯点、固定／滑移及应力释放未冻结。CAM供电源端、USB完整尾线与喇叭插头规格未正式确定，带线穿入、头身安装与闭壳仍未完成。</p>
<p>当前依然剩4类工作：完整上段、整条材料／线长、真实端接／应力释放、带线装配／闭壳。SC-0090-C001舵盘及微雪FPC／FFC按用户决定到货校准。喇叭150mm含已有插头已记录，不能把它当成150mm自由可弯线长。</p>
<h2>原始证据</h2><p><a href="../upper_pairs_review_R1/inspection.json">原混用参考的260条不足记录</a> · <a href="inspection.json">配套参考的4,550次检查</a> · <a href="native_inspection.json">初次原生实体检查</a> · <a href="native_refinement.json">同一路线的加密复核</a> · <a href="replacement_prefix_inspection.json">新电源对全部前段</a> · <a href="result_verification.json">覆盖及算法独立核对</a></p>
<p><a href="progress.json">范围与进度</a> · <a href="commands.json">实际命令／初次失败与重试</a> · <a href="README.md">复现说明</a> · <a href="delivery.json">发布哈希</a></p><p>PROTOTYPE / UNVALIDATED · 线路PLACEHOLDER / ASSUMED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# M1.55 上段配套候选 R2：未采用

原参考把旧两根电源上段与后来的CC候选混用，假定出口净距约0.0975mm，
130姿态共260个配对不足行。失败原数组、脚本和报告保留。
R2改用同组三线参考，两根假定出口各向外0.7mm；真实硬件没有移动。

有限130姿态：上段2,730个配对、910个远端参考折线、910个混合半径自身接续通过。
新电源上段780次原生分组检查有一行初次下界不足；同一折线保留全部原点，
细分到<=0.002mm后PASS，曲线偏差和0.3mm目标不变。
其余5条上段的1,950次原生检查按完全一致的当前来源复用，不计为本轮新测。
全部12条R3前段：312次不变接续段配对与260个多项式控制凸包分离界通过。
24个小规模穷举对照核对新函数的空间剪枝和显式局部排除规则。

自接近仅针对保存参考折线，<=5mm局部相邻弧段排除；平滑局部管体、真实压接／
接头及完整连续曲率未闭合。不能扩大成全角度、实际线束或制造资格。
实际命令和日志见commands.json。未修改主模型、动画、PCB、正式物料或打印件，
没有commit/push。完整上段、整条材料／线长、端接／应力释放、带线闭壳仍有4类工作。
图示是参考圆形线径截面：原QuickLook缩略图裁切，保留为失败预览；
改由Node/Sharp从原SVG直接渲染1100×410 PNG并目视核对两栏、标签和数值，
没有编辑用户提供的图片。图示检查不代表实际USB线材或端接资格。
''')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file()
           and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_result.log','verify_publication.log']}
    (HERE/'delivery.json').write_text(json.dumps(dict(status='PASS',scope='Matched finite upper-reference publication only',
        source_blend_sha256=digest,upper_finite_native_gap='PASS',upper_finite_peer_gap='PASS',
        upper_remote_reference_polyline='PASS',mixed_radius_own_join_reference='PASS',
        original_incompatible_pair_failures_retained=260,full_harness='BLOCKED',remaining_work_packages=4,
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,
        manufacturing_release=False,files=files),ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_UPPER_PUBLISHED',len(files),'files',flush=True)


if __name__=='__main__':
    main()
