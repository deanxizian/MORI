"""Refine only inconclusive coarse native checks, without moving the path."""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,ROOT,PREVIOUS,np,clear,clean,transform_points,rigidtr,sha
sys.path.insert(0,str(PARENT/'global_bundle_layout'))
from check_upper_seams import upper_tail
HERE=Path(__file__).resolve().parent


def densify(p,step=.002):
    delta=np.diff(p,axis=0)
    counts=np.maximum(1,np.ceil(np.linalg.norm(delta,axis=1)/step).astype(int))
    ids=np.repeat(np.arange(len(counts)),counts)
    starts=np.r_[0,np.cumsum(counts)[:-1]]
    k=np.arange(counts.sum())-np.repeat(starts,counts)
    result=np.vstack([p[ids]+delta[ids]*(k/counts[ids])[:,None],p[-1]])
    assert np.array_equal(result[np.r_[starts,counts.sum()]],p)
    assert abs(np.linalg.norm(np.diff(result,axis=0),axis=1).sum()-np.linalg.norm(delta,axis=1).sum())<1e-7
    assert np.linalg.norm(np.diff(result,axis=0),axis=1).max()<=step+1e-10
    return result


def main():
    started=time.time();ctx=Context()
    coarse_path=HERE/'native_inspection.json'
    coarse=json.loads(coarse_path.read_text())
    assert coarse['status']=='BLOCKED' and coarse['native_group_checks']==780
    assert all(sha(p)==h for p,h in coarse['sources'].items())
    assert len(coarse['failures'])==1
    assert all(not hit.get('inside') for r in coarse['failures'] for hit in r['hits'])
    arrays_path=PREVIOUS/'cc_power_bundle/fixed_length_candidate.npz'
    arrays=np.load(arrays_path)
    ctx.record([Path(__file__),coarse_path,arrays_path,PARENT/'global_bundle_layout/check_upper_seams.py'])
    rows=[]
    for previous in coarse['failures']:
        yaw,pitch,name,group=[previous[n] for n in ['yaw_deg','pitch_deg','wire','group']]
        datum_path=PARENT/'global_bundle_layout/all_yaws_R3'/f'y{yaw}'/'optimization.json'
        datum=json.loads(datum_path.read_text());ctx.record([datum_path])
        pre=(ctx.mixed if name.endswith('1') else ctx.old)[f'{name}_y{yaw}']
        up=arrays[f'{name}_y{yaw}_p{pitch}']
        assert np.linalg.norm(pre[-1]-up[0])<1e-8
        p=upper_tail(clean(np.vstack([pre,up[1:]])),np.asarray(datum['wires'][name]['reference_end_mm']))
        dense=densify(p)
        mat=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
        bad,near=clear(transform_points(dense,mat),.5842,ctx.groups[group],error=.0006)
        rows.append(dict(yaw_deg=yaw,pitch_deg=pitch,wire=name,group=group,status='BLOCKED' if bad else 'PASS',
            hits=bad,nearest_within_query_AABBs=near,original_vertices_preserved=True,
            original_points=len(p),refined_points=len(dense),max_segment_mm=float(np.linalg.norm(np.diff(dense,axis=0),axis=1).max()),
            smooth_chord_error_allowance_mm=.0006,original_coarse_row=previous))
    ctx.unchanged()
    result=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        scope='Refinement of only the original inconclusive native row, same saved polyline and chord allowance',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        rows=rows,superseded_native_rows=len(rows),unchanged_native_PASS_rows=779,
        combined_matched_power_native_status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        polyline_geometry_changed=False,required_gap_mm=.3,full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'native_refinement.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_NATIVE_REFINED_TERMINAL',result['status'],len(rows),result['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
