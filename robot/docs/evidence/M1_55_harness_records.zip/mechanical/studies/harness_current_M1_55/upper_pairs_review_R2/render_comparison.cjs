// Rasterize the authored vector diagram; no supplied image is modified.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sharp = require('/Users/dean/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const source = path.join(__dirname, 'assumed_exit_comparison.svg');
const output = path.join(__dirname, 'assumed_exit_comparison.png');
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
(async () => {
  await sharp(fs.readFileSync(source)).png().toFile(output);
  const metadata = await sharp(output).metadata();
  if (metadata.width !== 1100 || metadata.height !== 410) throw new Error('Unexpected vector raster bounds');
  const receipt = {status: 'PASS', scope: 'Authored SVG raster bounds only, not geometry qualification',
    source: 'assumed_exit_comparison.svg', source_sha256: sha(source),
    output: 'assumed_exit_comparison.png', output_sha256: sha(output),
    width: metadata.width, height: metadata.height, runtime: process.version,
    script_sha256: sha(__filename), prior_quicklook_thumbnail: 'assumed_exit_comparison.svg.png',
    prior_quicklook_result: 'FAIL: thumbnail cropped the authored viewport; not used in the page'};
  fs.writeFileSync(path.join(__dirname, 'diagram_render_receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  process.stdout.write('UPPER_EXIT_VECTOR_RASTER_PASS 1100x410\n');
})().catch(error => {process.stderr.write(error.stack + '\n'); process.exitCode = 1;});
