"""Verify leaf links, exact current sources and finite-check publication."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
from urllib.parse import urlsplit,unquote
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=read(HERE/'delivery.json')
assert d['status']=='PASS' and d['full_harness']=='BLOCKED'
assert all(sha(HERE/n)==h for n,h in d['files'].items())
verified=read(HERE/'result_verification.json')
assert verified['status']=='PASS' and all(sha(p)==h for p,h in verified['sources'].items())
visual=read(HERE/'diagram_visual_review.json')
assert visual['status']=='PASS' and all(sha(p)==h for p,h in visual['sources'].items())
assert visual['both_panels_visible'] and visual['labels_readable'] and visual['assumptions_notice_visible']
assert sha(MECHANICAL/'mori_v1_2.blend')==d['source_blend_sha256']
assert sha(MECHANICAL/'animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
base=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in base['protected_hardware'].items() if '__pycache__' not in Path(n).parts and Path(n).name!='.DS_Store'}
assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
links=[]
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(value)
    if parsed.scheme or not parsed.path:continue
    target=(HERE/unquote(parsed.path)).resolve()
    assert target.is_file() and target.is_relative_to(PROJECT),(value,target)
    with urlopen(Request('http://127.0.0.1:58202/'+str(target.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:assert response.status==200
    links.append(str(target.relative_to(PROJECT)))
with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:
    assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
out=dict(status='PASS',scope='Publication and source preservation; no full harness qualification',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),delivery_sha256=sha(HERE/'delivery.json'),
    source_blend_sha256=d['source_blend_sha256'],checked_files=len(d['files']),checked_links=links,
    HTTP_HEAD='PASS',HTTP_page_content_sha256='PASS',protected_hardware_files=len(protected),
    main_and_animation_unchanged=True,hardware_unchanged=True,Git_HEAD=head,
    full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('MATCHED_UPPER_PUBLICATION_VERIFIED',len(d['files']),'files',len(links),'links',len(protected),'protected hardware',flush=True)
