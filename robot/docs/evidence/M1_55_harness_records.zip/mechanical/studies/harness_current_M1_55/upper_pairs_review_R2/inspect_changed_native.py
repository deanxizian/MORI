"""Current native-solid check of the two substituted upper power references."""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,ROOT,PROJECT,PREVIOUS,np,clear,clean,transform_points,rigidtr,sha,P
sys.path.insert(0,str(PARENT/'global_bundle_layout'))
from check_upper_seams import upper_tail
HERE=Path(__file__).resolve().parent


def main():
    started=time.time();ctx=Context()
    arrays_path=PREVIOUS/'cc_power_bundle/fixed_length_candidate.npz'
    meta_path=PREVIOUS/'cc_power_bundle/length_review.json'
    meta=json.loads(meta_path.read_text())
    assert meta['status']=='PASS' and sha(arrays_path)==meta['arrays_sha256']
    matched=np.load(arrays_path)
    ctx.record([Path(__file__),arrays_path,meta_path,PARENT/'global_bundle_layout/check_upper_seams.py',
                ROOT/'animation/MORI_assembly.mp4'])
    rows=[];conditional=[];failures=[]
    for yaw in range(-60,61,10):
        candidate_meta=PARENT/'global_bundle_layout/all_yaws_R3'/f'y{yaw}'/'optimization.json'
        datum=json.loads(candidate_meta.read_text());ctx.record([candidate_meta])
        for pitch in range(-20,26,5):
            for name in ['P_J18_1','P_J18_2']:
                pre=(ctx.mixed if name.endswith('1') else ctx.old)[f'{name}_y{yaw}']
                up=matched[f'{name}_y{yaw}_p{pitch}']
                assert np.linalg.norm(pre[-1]-up[0])<1e-8
                p=upper_tail(clean(np.vstack([pre,up[1:]])),np.asarray(datum['wires'][name]['reference_end_mm']))
                for group,targets in ctx.groups.items():
                    mat=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                    bad,near=clear(transform_points(p,mat),.5842,targets,error=.0006)
                    row=dict(yaw_deg=yaw,pitch_deg=pitch,wire=name,group=group,
                        status='BLOCKED' if bad else 'PASS',hits=bad,nearest_within_query_AABBs=near)
                    rows.append(row)
                    if bad:failures.append(row)
                mat=np.linalg.inv(np.asarray(rigidtr(yaw,pitch)))
                bad,near=clear(transform_points(p,mat),.5842,ctx.usb,error=.0006)
                conditional.append(dict(yaw_deg=yaw,pitch_deg=pitch,wire=name,status='BLOCKED' if bad else 'PASS',
                    hits=bad,nearest_within_query_AABBs=near,scope='Unselected conditional USB allocation'))
            print('MATCHED_POWER_NATIVE_POSE',yaw,pitch,'failures',len(failures),flush=True)
    assert len(rows)==780 and len(conditional)==260
    ctx.unchanged()
    out=dict(status='PASS' if not failures else 'BLOCKED',
        scope='Two substituted unadopted upper power references against 201 current native solids in 130 finite poses only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        revision=P['revision'],poses=130,changed_upper_references=2,native_parts=201,
        native_group_checks=len(rows),rows=rows,failures=failures,required_gap_mm=.3,
        conditional_USB_checks=conditional,
        conditional_USB_status='PASS' if all(r['status']=='PASS' for r in conditional) else 'BLOCKED',
        old_native_PASS_inherited=False,actual_USB_termination='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'native_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_POWER_NATIVE_TERMINAL',out['status'],len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
