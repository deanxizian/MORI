"""New power uppers against all twelve current R3 prefixes at key poses.

The retained stubs are checked with finite segments to their actual source
junctions (Z206 and Z208). The new polynomial pieces stay above those source
junctions, while every R3 prefix stays at/below Z200
by its positive B-spline control hull. This avoids unnecessary repeated tests.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from matched_references import MatchedReferences,PREVIOUS_REVIEW,PREVIOUS,FRAME,sha,np,upper_tail
from references import BSpline
spec=importlib.util.spec_from_file_location('_mori_upper_pairs_R1',PREVIOUS_REVIEW/'inspect_pairs.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)


def main():
    started=time.time();refs=MatchedReferences()
    source_path=PREVIOUS/'cc_power_bundle/length_review.json'
    source=json.loads(source_path.read_text())
    metadata={(r['name'],r['yaw'],r['pitch']):r for r in source['selected']['meta']}
    refs.record([Path(__file__),PREVIOUS_REVIEW/'inspect_pairs.py',source_path])
    rows=[];bounds=[];fails=[]
    for yaw in range(-60,61,10):
        packs={};hulls={}
        for name in refs.f.names:
            c=refs.f.candidate(name,yaw)['control'];s=BSpline(refs.f.knots,c,3)
            t=np.linspace(0,1,6001);p=s(t)
            a=float(np.linalg.norm(s.derivative(2)(np.unique(refs.f.knots)),axis=1).max())
            error=a*(t[1]-t[0])**2/8+1e-9
            packs[name]=prior.prepare(p,refs.f.radii[name],error)
            hulls[name]=dict(max_Z_mm=float(c[:,2].max()),radius_mm=refs.f.radii[name],error_mm=error)
            assert c[:,2].max()<=200+1e-8
        assert len(packs)==12
        for power in ['P_J18_1','P_J18_2']:
            pre=(refs.mixed if power.endswith('1') else refs.old)[f'{power}_y{yaw}']
            stub=upper_tail(pre,refs.f.controls[yaw][power][-1])
            junction_Z=float(pre[-1,2])
            assert abs(stub[-1,2]-junction_Z)<1e-8
            b=prior.prepare(stub,.5842,.0006)
            for name,a in packs.items():
                kind='own_join' if name==power else 'peer'
                r=prior.compare(a,b,kind)
                row=dict(yaw_deg=yaw,prefix=name,upper=power,
                         upper_piece='Unchanged source stub to retained polynomial junction',
                         source_junction_Z_mm=junction_Z,**r)
                rows.append(row)
                if r['status']!='PASS':fails.append(row)
            for pitch in range(-20,26,5):
                meta=metadata[power,yaw,pitch]
                ctrl=np.asarray(meta['controls_yaw_local_mm'])
                mat=np.asarray(refs.tr['transforms'][f'y{yaw}_p0'])
                world=ctrl@mat[:3,:3].T+mat[:3,3]
                lo=float(world[:,2].min())
                assert lo>=junction_Z-1e-8
                margins={name:lo-v['max_Z_mm']-.5842-v['radius_mm']-.0006-v['error_mm']-1e-8
                         for name,v in hulls.items()}
                lower=min(margins.values())
                assert lower>=.3
                stored=refs.matched[f'{power}_y{yaw}_p{pitch}']
                assert stored[:,2].min()>=lo-1e-8
                bounds.append(dict(yaw_deg=yaw,pitch_deg=pitch,upper=power,
                    status='PASS',polynomial_control_min_Z_mm=lo,
                    all_prefix_control_max_Z_mm=max(v['max_Z_mm'] for v in hulls.values()),
                    surface_gap_lower_mm=lower,checked_prefixes=12,
                    source_polyline_unchanged=True))
        print('REPLACEMENT_PREFIX_YAW',yaw,'stub_checks',len(rows),'failures',len(fails),flush=True)
    refs.unchanged()
    assert len(rows)==312 and len(bounds)==260
    out=dict(status='PASS' if not fails else 'BLOCKED',
        scope='Two changed upper power allocations against all12 R3 prefixes at 13 key yaws and ten stored pitches',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=refs.sources,
        retained_stub_checks=rows,new_polynomial_separation_bounds=bounds,failures=fails,
        changed_upper_references=2,prefixes=12,required_gap_mm=.3,
        upper_between_pose_motion='NOT_TESTED',local_smooth_join='NOT_TESTED',
        actual_endpoints_and_clamps='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'replacement_prefix_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('REPLACEMENT_PREFIX_TERMINAL',out['status'],len(rows),len(bounds),out['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
