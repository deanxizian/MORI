"""Pair the retained CC with its own matched two power upper candidates.

All three assumed exits belong to one unadopted bundle study. This corrects
research-array compatibility, not selected USB hardware or native PCB geometry.
"""
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
PREVIOUS_REVIEW=HERE.parent/'upper_pairs_review_R1'
sys.path.insert(0,str(PREVIOUS_REVIEW))
from references import References,NAMES,RADII,FRAME,PREVIOUS,sha,np,clean,upper_tail


class MatchedReferences(References):
    def __init__(self):
        super().__init__()
        previous_path=PREVIOUS_REVIEW/'inspection.json'
        previous=json.loads(previous_path.read_text())
        assert previous['status']=='BLOCKED' and len(previous['failures'])==260
        assert all(r['kind']=='peer' and r['wires'][1]=='CC_allocation'
                   and r['wires'][0] in ['P_J18_1','P_J18_2'] for r in previous['failures'])
        assert all(sha(p)==h for p,h in previous['sources'].items())
        self.matched_path=PREVIOUS/'cc_power_bundle/fixed_length_candidate.npz'
        meta_path=PREVIOUS/'cc_power_bundle/length_review.json'
        meta=json.loads(meta_path.read_text())
        assert meta['status']=='PASS' and sha(self.matched_path)==meta['arrays_sha256']
        # Only the array pairing is received. Old native or whole-curve PASS
        # is not inherited; current pairs/native solids are checked anew.
        self.matched=np.load(self.matched_path)
        assert set(self.matched.files)=={f'{n}_y{y}_p{p}' for n in ['P_J18_1','P_J18_2','CC']
                                        for y in range(-60,61,10) for p in range(-20,26,5)}
        self.record([Path(__file__),previous_path,self.matched_path,meta_path])
        self.adjustments=[]

    def upper(self,yaw,pitch):
        result=super().upper(yaw,pitch)
        for name in ['P_J18_1','P_J18_2']:
            pre=(self.mixed if name.endswith('1') else self.old)[f'{name}_y{yaw}']
            up=self.matched[f'{name}_y{yaw}_p{pitch}']
            assert np.linalg.norm(pre[-1]-up[0])<1e-8
            p=upper_tail(clean(np.vstack([pre,up[1:]])),self.f.controls[yaw][name][-1])
            old=result[name]
            assert np.linalg.norm(p[0]-old[0])<1e-8
            self.adjustments.append(dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,
                unchanged_seam_mm=p[0].tolist(),old_assumed_end_mm=old[-1].tolist(),
                matched_assumed_end_mm=p[-1].tolist(),assumed_end_displacement_mm=float(np.linalg.norm(p[-1]-old[-1])),
                actual_USB_termination='BLOCKED',native_hardware_moved=False))
            result[name]=p
        return result
