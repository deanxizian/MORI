"""Independent finite coverage, substitution and pruning verification."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from matched_references import NAMES,RADII,PREVIOUS_REVIEW,FRAME,sha,np
spec=importlib.util.spec_from_file_location('_mori_upper_pairs_R1',PREVIOUS_REVIEW/'inspect_pairs.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
read=lambda p:json.loads(Path(p).read_text())


def brute(a,b,kind):
    ii,jj=np.meshgrid(np.arange(len(a['u'])),np.arange(len(b['u'])),indexing='ij')
    ii,jj=ii.ravel(),jj.ravel()
    if kind=='self':
        mask=(jj>ii)&((a['arc'][jj+1]-a['arc'][ii])>5.)
        ii,jj=ii[mask],jj[mask]
    elif kind=='own_join':
        mask=(a['arc'][-1]-a['arc'][ii]+b['arc'][jj+1])>5.
        ii,jj=ii[mask],jj[mask]
    if not len(ii):return np.inf
    distance=prior.distances(a['p'][ii],b['p'][jj],a['u'][ii],b['u'][jj])[0]
    return float(distance.min()-a['radius']-b['radius']-a['error']-b['error']-1e-8)


def algorithm_checks():
    rng=np.random.default_rng(55102009);checks=[]
    for mode in ['peer','self','own_join']:
        for i in range(8):
            p=np.cumsum(rng.normal(size=(12,3)),axis=0)
            q=np.cumsum(rng.normal(size=(10,3)),axis=0)
            if i%2:q+=np.array([15.,0,0])
            if mode=='own_join':q=q-q[0]+p[-1]
            a=prior.prepare(p,.12+i*.01,.0002)
            b=a if mode=='self' else prior.prepare(q,.18,.0003)
            exact=brute(a,b,mode);result=prior.compare(a,b,mode)
            expected='PASS' if exact>=.3 else 'BLOCKED'
            assert result['status']==expected,(mode,i,exact,result)
            if result['status']=='BLOCKED':
                w=result['witness']
                pa,pb=np.asarray(w['point_a_mm']),np.asarray(w['point_b_mm'])
                assert abs(np.linalg.norm(pa-pb)-w['centreline_distance_mm'])<1e-10
                assert w['gap_lower_mm']<.3
            checks.append(dict(mode=mode,case=i,status='PASS',expected_result=expected,
                               actual_result=result['status'],brute_gap_mm=exact if np.isfinite(exact) else None))
    return checks


def main():
    paths=[HERE/'inspection.json',HERE/'native_inspection.json',HERE/'native_refinement.json',
           HERE/'replacement_prefix_inspection.json',PREVIOUS_REVIEW/'inspection.json',
           HERE.parent/'upper_reference_review_R1/inspection.json']
    pair,native,refined,replacement,old,available=[read(p) for p in paths]
    assert pair['status']==refined['status']==replacement['status']==available['status']=='PASS'
    assert native['status']==old['status']=='BLOCKED'
    assert all(sha(p)==h for r in [pair,native,refined,replacement,old,available] for p,h in r['sources'].items())
    yaws=range(-60,61,10);pitches=range(-20,26,5)
    tasks=[(a,b,'peer') for a,b in itertools.combinations(NAMES,2)]
    tasks += [(n,n,'self') for n in NAMES]+[(n,n,'own_join') for n in NAMES]
    wanted={(y,p,a,b,k) for y,p in itertools.product(yaws,pitches) for a,b,k in tasks}
    actual={(r['yaw_deg'],r['pitch_deg'],*r['wires'],r['kind']) for r in pair['rows']}
    assert actual==wanted and len(pair['rows'])==4550
    assert all(r['status']=='PASS' and r['gap_lower_mm']>=.3 for r in pair['rows'])
    assert len(old['failures'])==260
    assert {(r['yaw_deg'],r['pitch_deg'],r['wires'][0]) for r in old['failures']}=={
        (y,p,n) for y,p,n in itertools.product(yaws,pitches,['P_J18_1','P_J18_2'])}
    key=lambda r:(r['yaw_deg'],r['pitch_deg'],r['wire'],r['group'])
    combined={key(r):r for r in native['rows']}
    assert len(combined)==780 and len(native['failures'])==len(refined['rows'])==1
    assert key(refined['rows'][0])==key(native['failures'][0])
    combined[key(refined['rows'][0])]=refined['rows'][0]
    assert set(combined)==set(itertools.product(yaws,pitches,['P_J18_1','P_J18_2'],['body','yaw','pitch']))
    assert all(r['status']=='PASS' and not r['hits'] for r in combined.values())
    assert refined['polyline_geometry_changed'] is False
    unchanged={n for n in NAMES if not n.startswith('P_J18')}
    carried=[r for r in available['rows'] if r['wire'] in unchanged]
    assert len(carried)==650 and all(r['status']=='PASS' for r in carried)
    assert len(replacement['retained_stub_checks'])==312
    assert len(replacement['new_polynomial_separation_bounds'])==260
    assert all(r['status']=='PASS' for r in replacement['retained_stub_checks'])
    assert all(r['status']=='PASS' and r['surface_gap_lower_mm']>=.3 for r in replacement['new_polynomial_separation_bounds'])
    adjustments=pair['assumed_end_adjustments']
    assert len(adjustments)==260 and all(abs(r['assumed_end_displacement_mm']-.7)<1e-4 for r in adjustments)
    assert all(r['native_hardware_moved'] is False and r['actual_USB_termination']=='BLOCKED' for r in adjustments)
    checks=algorithm_checks()
    sources={str(p):sha(p) for p in paths+[Path(__file__),PREVIOUS_REVIEW/'inspect_pairs.py',FRAME/'continuous_gaps_R1/pair_fields.py']}
    out=dict(status='PASS',scope='Finite reference coverage, mixed-radius pairing and query-pruning verification only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        upper_peer_checks=2730,upper_remote_reference_polyline_checks=910,
        mixed_radius_own_join_reference_checks=910,query_pruning_brute_force_checks=checks,
        new_power_native_group_checks=780,refined_native_rows=1,
        unchanged_upper_native_group_checks_carried_with_exact_current_source_hashes=1950,
        current_all_known_upper_native_group_checks=2730,
        replacement_stub_to_prefix_checks=312,replacement_above_prefix_bounds=260,
        minimum_refined_native_gap_lower_mm=refined['rows'][0]['nearest_within_query_AABBs']['gap_lower_bound_mm'],
        old_incompatible_upper_pair_failures_retained=260,
        assumed_end_changes_mm=.7,actual_USB_termination='BLOCKED',
        local_smooth_tube_or_splice='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',actual_mixed_material_length='BLOCKED',
        actual_endpoints_and_clamps='BLOCKED',wired_assembly_and_closure='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'result_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_UPPER_RESULTS_VERIFIED',len(pair['rows']),'reference checks',len(checks),'brute-force algorithm checks',flush=True)


if __name__=='__main__':
    main()
