"""Unadopted four-wire bundle: shared lower path, distinct upper references.

Uses an AWG28 maximum-OD capacity candidate, never replacing the factory SH
tail. All routing, splice sites, lengths and offsets are unselected. No main
part, connector datum, formal terminal definition or hardware is changed.
"""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *
from bounded_curve_checks import pair_threshold
from curve_self_partition import self_clear
from polyline_pair_distance import exact_pair,algorithm_checks

RADIUS=.565
ERROR=.0006
def smooth(t):
    t=np.clip(t,0,1);return t*t*t*(10-15*t+6*t*t)
def prefix(p,z=200.):
    i=int(np.flatnonzero((p[:-1,2]<z)&(p[1:,2]>=z))[-1])
    t=(z-p[i,2])/(p[i+1,2]-p[i,2])
    return clean(np.vstack([p[:i+1],p[i]+t*(p[i+1]-p[i])]))
def sampled_radius(p):
    a=p[1:-1]-p[:-2];b=p[2:]-p[1:-1];c=p[2:]-p[:-2]
    cross=2*np.linalg.norm(np.cross(a,b),axis=1)
    product=np.linalg.norm(a,axis=1)*np.linalg.norm(b,axis=1)*np.linalg.norm(c,axis=1)
    values=np.full(len(cross),np.inf);valid=cross>1e-13;values[valid]=product[valid]/cross[valid]
    i=int(np.argmin(values))
    return dict(radius_mm=float(values[i]),point_mm=p[i+1].tolist(),
                method='Three-point radius diagnostic; not continuous curvature or dynamic-life proof')
def common_lower(raw,plane):
    # Body pins are a row along X. First bends turn toward +Y, maintaining
    # the row spacing rather than turning the four leads across each other.
    start=raw[0].copy();radius=7.;lead_top=plane-radius
    assert lead_top>start[2]
    vertical=np.c_[np.full(80,start[0]),np.full(80,start[1]),np.linspace(start[2],lead_top,80)]
    angle=np.linspace(0,np.pi/2,400)
    arc=np.c_[np.full(len(angle),start[0]),start[1]+radius*(1-np.cos(angle)),lead_top+radius*np.sin(angle)]
    # Join a retained frontward section with horizontal endpoint tangents.
    ids=np.flatnonzero((raw[:,1]>=-12.)&(raw[:,2]<145.))
    i=int(ids[0]);end=raw[i].copy();end[2]=plane
    tangent=raw[i+1]-raw[i-1];tangent[2]=0;tangent/=np.linalg.norm(tangent)
    a=arc[-1];b=a+np.array([0.,8.,0.]);c=end-8.*tangent
    t=np.linspace(0,1,1000)[:,None]
    join=(1-t)**3*a+3*(1-t)**2*t*b+3*(1-t)*t*t*c+t**3*end
    tail=raw[i:].copy()
    down=(144.73999938964844-plane)*(1-smooth((tail[:,2]-146.)/14.))
    tail[:,2]-=down
    assert np.linalg.norm(join[-1]-tail[0])<1e-5
    return clean(np.vstack([vertical,arc[1:],join[1:],tail[1:]]))
def bundle(raws,plane,spacing,splay,inset):
    spine=common_lower(raws[4],plane);delta=np.gradient(spine,axis=0)
    normals=np.c_[-delta[:,1],delta[:,0],np.zeros(len(delta))]
    norm=np.linalg.norm(normals,axis=1)
    # At the vertical connector lead the horizontal direction is +Y.
    normals[norm<1e-10]=[-1.,0.,0.];norm[norm<1e-10]=1.
    normals/=norm[:,None]
    s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(spine,axis=0),axis=1))]
    fan=smooth((s-11.)/18.)
    paths={}
    for pin,raw in raws.items():
        n=4-pin;initial=np.tile([-2.*n,0.,0.],(len(spine),1))
        lower=spine+(1-fan)[:,None]*initial+fan[:,None]*normals*(spacing*n)
        # After the lower neck, recover each retained upper reference with a
        # smooth angular spread. The reference junction remains unselected.
        ids=np.flatnonzero(raw[:,2]>=148.)
        upper=raw[ids].copy();assert np.all(np.diff(upper[:,2])>0)
        radius=np.linalg.norm(upper[:,:2],axis=1)
        theta=np.arctan2(upper[:,1],upper[:,0])
        blend=smooth((upper[:,2]-150.)/12.)
        radius-=blend*(inset+(.2 if pin==1 else 0.))
        theta+=blend*np.radians(splay*(2.5-pin))
        upper[:,0]=radius*np.cos(theta);upper[:,1]=radius*np.sin(theta)
        target=np.c_[np.interp(lower[:,2],upper[:,2],upper[:,0]),
                     np.interp(lower[:,2],upper[:,2],upper[:,1]),lower[:,2]]
        weight=smooth((lower[:,2]-148.)/15.)
        new=lower+(target-lower)*weight[:,None]
        assert np.max(abs(new[0]-raw[0]))<1e-9
        paths[pin]=clean(new)
    return paths
def pair_check(a,b):
    fast=pair_threshold(a,b)
    if fast['status']=='PASS':return fast
    exact=exact_pair(a['p'],b['p'])
    gap=exact['centreline_distance_mm']-a['radius']-b['radius']
    lower=gap-a['error']-b['error']-.0001
    return dict(status='PASS' if lower>=.3 else 'BLOCKED',gap_lower_bound_mm=lower,
                polyline_surface_gap_mm=gap,point_mm=exact['point_a_mm'],other_point_mm=exact['point_b_mm'],
                method='Exact finite polyline segment minimum after inconclusive conservative screen',
                initial_conservative_screen=fast)
def main():
    started=time.time();checks=algorithm_checks();ctx=Context();attempts=[];accepted=None
    out=HERE/'body_bundle_R5';out.mkdir(exist_ok=True)
    poses=[(0,0)]+[(y,p) for y in [-60,0,60] for p in [-20,0,25] if (y,p)!=(0,0)]
    variants=[(139.44,1.5,3.,.6),(139.44,1.7,4.,.8),(140.14,1.5,3.,.6),(140.14,1.7,4.,.8)]
    for plane,spacing,splay,inset in variants:
        name=f'z{plane:g}_s{spacing:g}_a{splay:g}_i{inset:g}'
        folder=out/name;folder.mkdir(exist_ok=True);rows=[];curves={};meta=[]
        for yaw,pitch in poses:
            raws={pin:prefix(ctx.old[f'CAM_{pin}_y{yaw}_p{pitch}'][:ctx.joins[f'CAM_{pin}_y{yaw}_p{pitch}']+1]) for pin in range(1,5)}
            paths=bundle(raws,plane,spacing,splay,inset)
            packs={pin:prepared(path,RADIUS,ERROR) for pin,path in paths.items()}
            others={n:d for n,d in ctx.refs(yaw,pitch).items() if not n.startswith('CAM_')}
            for pin,new in paths.items():
                curves[f'CAM_{pin}_y{yaw}_p{pitch}']=new
                sampled=sampled_radius(new)
                meta.append(dict(pin=pin,yaw_deg=yaw,pitch_deg=pitch,length_mm=length(new),
                                 proposed_splice_reference_mm=new[-1].tolist(),sampled_bend=sampled))
                tests=[]
                for group,targets in ctx.groups.items():
                    inverse=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                    bad,near=clear(transform_points(new,inverse),RADIUS,targets,error=ERROR)
                    tests.append(dict(test='native',group=group,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near))
                tests.append(dict(test='remote_self',**self_clear(packs[pin])))
                for other in range(1,pin):tests.append(dict(test='PH_peer',other_pin=other,**pair_check(packs[pin],packs[other])))
                for n,d in others.items():tests.append(dict(test='retained_reference',other=n,**pair_check(packs[pin],d)))
                # The manufacturer's bend datum and dynamic suitability remain
                # unresolved even when a sampled nominal radius is large.
                tests.append(dict(test='sampled_bend_screen',status='PASS' if sampled['radius_mm']>=6.865 else 'BLOCKED',
                                  threshold_mm=6.865,**sampled))
                bad=[t for t in tests if t['status']!='PASS']
                rows.append(dict(pin=pin,yaw_deg=yaw,pitch_deg=pitch,status='BLOCKED' if bad else 'PASS',tests=tests))
                print('BUNDLE_PIN',name,yaw,pitch,pin,[(t['test'],t.get('other',t.get('other_pin',t.get('group')))) for t in bad],flush=True)
            if any(r['status']!='PASS' for r in rows):break
        np.savez_compressed(folder/'curves.npz',**curves)
        status='PASS' if len(rows)==36 and all(r['status']=='PASS' for r in rows) else 'BLOCKED'
        result=dict(candidate=name,status=status,checked_prefixes=len(rows),rows=rows,path_metadata=meta,
                    shared_lower_plane_mm=plane,spacing_mm=spacing,upper_spread_deg=splay,upper_inset_mm=inset,
                    constant_material_length='NOT_TESTED',continuous_curvature='NOT_TESTED',actual_splices='BLOCKED',
                    factory_SH_tail='BLOCKED',material_dynamic_life='NOT_TESTED',full_harness='BLOCKED')
        (folder/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        attempts.append(dict(candidate=name,status=status,checked_prefixes=len(rows),
                             first_failure=next((r for r in rows if r['status']!='PASS'),None)))
        if status=='PASS':accepted=name;break
    ctx.record([Path(__file__),HERE/'polyline_pair_distance.py',HERE/'materials/source_facts.json'])
    ctx.unchanged()
    (out/'review.json').write_text(json.dumps(dict(status='PASS' if accepted else 'BLOCKED',revision=P['revision'],sources=ctx.sources,
        scope='Unadopted four-wire PH-side capacity prefixes. Static nominal gap and sampled-bend screening only.',
        OD_capacity_mm=1.13,required_nominal_gap_mm=.3,planned_poses=poses,attempts=attempts,accepted=accepted,
        algorithm_checks=checks,formal_wire_and_terminals_unchanged=True,main_changed=False,hardware_changed=False,
        factory_SH_tail='BLOCKED',full_wired_assembly='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-started),
        ensure_ascii=False,indent=2)+'\n')
    print('BODY_BUNDLE_R5',accepted or 'NO_ACCEPTED_ROUTE',flush=True)
if __name__=='__main__':main()
