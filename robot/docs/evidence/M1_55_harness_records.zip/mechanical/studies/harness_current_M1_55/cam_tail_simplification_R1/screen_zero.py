"""Fresh zero-pose screening of the shorter fixed CAM tail candidate."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT));from context import Context,np,clear,sha
sys.path.insert(0,str(HERE));from short_tail import ShortTailFamily
from power_family import PowerFamily
from piecewise_geometry import BSpline,pieces,RADII
HELPERS=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_short_tail_distance_helpers',HELPERS)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)


def main():
    started=time.time();native=Context();carrier=PowerFamily();family=ShortTailFamily(carrier)
    math_rows=[];geometry=[];failures=[];curves={};arrays={}
    for name in RADII:
        c,info=(family if name.startswith('CAM_') else carrier).upper(name,0.,0.)
        math_rows.append(dict(wire=name,**info));assert c is not None,(name,info)
        curves[name]=helpers.prepare(c,RADII[name]);arrays[name+'_controls']=c
    prefixes={n:helpers.prepare(pieces(BSpline(carrier.ctx.f.knots,carrier.ctx.f.candidate(n,0)['control'],3)),carrier.ctx.f.radii[n]) for n in carrier.ctx.f.names}
    changed={f'CAM_{p}' for p in range(1,5)}
    for name in sorted(changed):
        pack=curves[name]
        for group,targets in list(native.groups.items())+[('conditional_USB',native.usb)]:
            hits,near=clear(pack['p'],pack['radius'],targets,error=pack['error'],gap=.3)
            row=dict(wire=name,kind='native' if group!='conditional_USB' else group,group=group,
                status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near)
            geometry.append(row)
            if hits:failures.append(row)
        for other,pack2 in prefixes.items():
            if other==name:continue
            row=dict(wires=[name,other],**helpers.compare(pack,pack2));row['kind']='other_prefix';geometry.append(row)
            if row['status']!='PASS':failures.append(row)
        for kind,left in [('self',pack),('own_join',prefixes[name])]:
            row=dict(wires=[name,name],**helpers.compare(left,pack,kind));geometry.append(row)
            if row['status']!='PASS':failures.append(row)
    for a,b in itertools.combinations(RADII,2):
        if a not in changed and b not in changed:continue
        row=dict(wires=[a,b],**helpers.compare(curves[a],curves[b]));row['kind']='upper_peer';geometry.append(row)
        if row['status']!='PASS':failures.append(row)
    assert len(geometry)==86
    native.record([Path(__file__),HERE/'short_tail.py',HELPERS,HELPERS.parent/'sample_geometry.py',PARENT/'upper_pairs_review_R1/inspect_pairs.py'])
    native.sources.update(family.sources);native.unchanged();carrier.unchanged()
    np.savez_compressed(HERE/'zero_curves.npz',**arrays)
    out=dict(status='PASS' if not failures else 'BLOCKED',scope='Shorter fixed-tail allocation at zero pose only; source ports and service loops unchanged',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources,
        candidate_parameters=family.spec,tail_changes=family.tail_changes,numeric_curve_math=math_rows,
        geometry_checks=geometry,failures=failures,arrays_sha256=sha(HERE/'zero_curves.npz'),elapsed_s=time.time()-started,
        complete_numeric_targets=family.targets,other_poses='NOT_TESTED',all_angle_clearance='NOT_TESTED',
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'zero_review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('SHORT_CAM_FIXED_TAIL_ZERO_TERMINAL',out['status'],len(geometry),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
