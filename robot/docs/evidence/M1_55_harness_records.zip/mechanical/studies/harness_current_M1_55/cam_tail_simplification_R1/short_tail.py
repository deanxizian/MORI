"""Shorter fixed-head CAM tail allocation; original endpoints stay fixed.

Concentric final arcs avoid crossing the four one-millimetre-pitch references.
The old service-loop construction and R3 prefixes remain unchanged; numeric
targets reduce by the fixed-tail length saving, not by removing motion slack.
"""
from pathlib import Path
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from cam_family import CAMFamily,Builder,unit,upper_length,sha


def rounded_variable(points,radii):
    points=np.array(points,float);radii=np.array(radii,float)
    assert len(radii)==len(points)-2
    lengths=np.linalg.norm(np.diff(points,axis=0),axis=1);tangents=[];angles=[]
    for a,b,c,r in zip(points,points[1:],points[2:],radii):
        angle=math.acos(float(np.clip(unit(b-a)@unit(c-b),-1,1)))
        angles.append(angle);tangents.append(r*math.tan(angle/2))
    assert lengths[0]>=tangents[0] and lengths[-1]>=tangents[-1]
    assert all(lengths[k+1]>=tangents[k]+tangents[k+1]+.05 for k in range(len(tangents)-1))
    builder=Builder();cursor=points[0]
    for a,b,c,r,angle,tangent in zip(points,points[1:],points[2:],radii,angles,tangents):
        incoming=unit(b-a);outgoing=unit(c-b);normal=unit(outgoing-(incoming@outgoing)*incoming)
        start=b-tangent*incoming;finish=b+tangent*outgoing
        builder.line(cursor,start);builder.arc(start+r*normal,-normal,incoming,r,0,angle)
        assert np.linalg.norm(builder.end-finish)<1e-8
        cursor=finish
    builder.line(cursor,points[-1]);return builder


class ShortTailFamily(CAMFamily):
    def __init__(self,carrier=None,top=242.,rear=-40.,center_x=23.5):
        super().__init__(carrier=carrier)
        self.spec=dict(top_z_base_mm=top,rear_y_base_mm=rear,final_arc_center_x_mm=center_x)
        self.tail_changes=[]
        for pin in range(1,5):
            j=pin-1;tail=self.ctx.cam[f'pin{pin}'];start,end=tail[[0,-1]]
            r=10.5-j;right=center_x+r;low=210.-1.3*j;back=rear-1.3*j;high=top+j
            points=[start,[start[0],start[1],low],[start[0],back,low],[start[0],back,high],
                    [right,back,high],[right,end[1],high],[right,end[1],end[2]],end]
            candidate=rounded_variable(points,[7.5]*5+[r])
            old=self.tail_builders[pin]
            old_length=upper_length(np.array(old.controls),64);new_length=upper_length(np.array(candidate.controls),64)
            assert np.linalg.norm(candidate.controls[0][0]-start)<1e-10 and np.linalg.norm(candidate.end-end)<1e-10
            assert np.linalg.norm(unit(candidate.controls[0][1]-candidate.controls[0][0])-[0,0,-1])<1e-10
            assert np.linalg.norm(unit(candidate.controls[-1][-1]-candidate.controls[-1][-2])-[-1,0,0])<1e-10
            self.tail_builders[pin]=candidate
            self.targets[f'CAM_{pin}']-=old_length-new_length
            self.tail_changes.append(dict(wire=f'CAM_{pin}',old_fixed_tail_numeric_mm=old_length,
                new_fixed_tail_numeric_mm=new_length,saving_mm=old_length-new_length,
                source_start_mm=start.tolist(),source_end_mm=end.tolist(),final_arc_radius_mm=r,
                corners=6,waypoints_mm=np.array(points).tolist(),actual_cut_length=None))
        self.ctx.record([Path(__file__)])
