"""Screen retained PH-side paths using a documented AWG28 max OD.

Tensility 30-02600 is an independent unselected capacity candidate. Its SH-side
factory tail/splice is not replaced or assigned the same wire diameter. This
test covers only the retained PH-side prefix and current native clearances.
"""
from pathlib import Path
import sys,json,itertools,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *
from bounded_curve_checks import pair_threshold

OD_MAX=1.13
RADIUS=OD_MAX/2
CHORD_ERROR=.0006
def main():
    start=time.time();ctx=Context();rows=[];curves={};prefix_meta=[]
    poses=[(0,0)]+[(y,p) for y in [-60,0,60] for p in [-20,0,25] if (y,p)!=(0,0)]
    for yaw,pitch in poses:
        packs={};pose_curves={}
        for pin in range(1,5):
            key=f'CAM_{pin}_y{yaw}_p{pitch}';j=ctx.joins[key]
            p=clean(ctx.old[key][:j+1]);pose_curves[pin]=p;packs[pin]=prepared(p,RADIUS,CHORD_ERROR)
            if yaw==pitch==0:
                curves[f'CAM_{pin}_body_prefix']=p
                prefix_meta.append(dict(pin=pin,retained_length_mm=length(p),start_mm=p[0].tolist(),end_mm=p[-1].tolist(),
                                        end_is_unselected_splice_reference=True))
        for pin,p in pose_curves.items():
            tests=[]
            for group,targets in ctx.groups.items():
                inverse=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                hits,near=clear(transform_points(p,inverse),RADIUS,targets,error=CHORD_ERROR)
                tests.append(dict(test='native',group=group,status='BLOCKED' if hits else 'PASS',hits=hits,nearest=near))
            for other in range(1,pin):
                tests.append(dict(test='peer_PH_prefix',other_pin=other,**pair_threshold(packs[pin],packs[other])))
            failures=[t for t in tests if t['status']!='PASS']
            row=dict(pin=pin,yaw_deg=yaw,pitch_deg=pitch,status='BLOCKED' if failures else 'PASS',tests=tests)
            rows.append(row)
            print('PH_BODY_WIRE_SCREEN',pin,yaw,pitch,row['status'],str(failures[:1])[:350],flush=True)
        # Keep all four zero-pose diagnostics; a failure means rerouting is
        # necessary, not that every conceivable physical route is impossible.
        if any(r['status']!='PASS' for r in rows):break
    ctx.record([Path(__file__),HERE/'materials/retrieval.json',HERE/'materials/Tensility_30_02600.pdf',HERE/'materials/JST_PH.pdf'])
    ctx.unchanged();np.savez_compressed(HERE/'formal_body_prefixes.npz',**curves)
    result=dict(status='PASS' if all(r['status']=='PASS' for r in rows) and len(rows)==len(poses)*4 else 'BLOCKED',
        revision=P['revision'],sources=ctx.sources,scope='Finite static screening of retained PH-side reference prefixes at maximum documented candidate OD; no SH-side wire replacement or actual splice qualification',
        unselected_wire_candidate='Tensility 30-02600',AWG=28,wire_OD_nominal_mm=1.05,wire_OD_tolerance_mm=.08,wire_OD_max_mm=OD_MAX,
        PH002_catalogue_AWG_and_OD_fields='PASS_ONLY',SH_same_wire='FAIL_OD_OVER_0_8_MM',
        formal_harness_definition_unchanged=True,body_prefixes=prefix_meta,planned_poses=poses,rows=rows,
        required_nominal_gap_mm=.3,chord_error_mm=CHORD_ERROR,reference_length_changed=False,
        wire_bend_and_life='NOT_TESTED',wire_self_collision='NOT_TESTED',other_retained_wires='NOT_TESTED',
        terminal_crimp_and_protection='BLOCKED',factory_SH_tail_and_splices='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'formal_body_wire_screen.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('FORMAL_BODY_WIRE_DONE',result['status'],len(rows),'prefix samples',flush=True)
main()
