"""Publish current station/material evidence without adopting geometry."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    station=json.loads((HERE/'review.json').read_text())
    fit=json.loads((HERE/'material_fit_zero.json').read_text())
    motion=json.loads((HERE/'body_material_motion.json').read_text())
    datums=json.loads((HERE/'reference_length_datums.json').read_text())
    assert station['status']=='PASS' and station['pose_count']==475 and station['crossing_checks']==3800
    assert fit['status']=='PASS' and len(fit['summaries'])==2
    assert motion['checks']==62*len(motion['checked_yaws'])
    assert datums['status']=='PASS' and len(datums['rows'])==4
    sources=station['sources']|fit['sources']|motion['sources']|datums['sources']
    assert all(sha(p)==h for p,h in sources.items())
    motion_text=(f"身体／颈部的 {len(motion['checked_yaws'])} 个偏航样本、头部 −20°／0°／25° 样本，共 {motion['checks']:,} 项检查{('通过' if motion['status']=='PASS' else '未通过')}。"
                 '这不是全角度或完整接续的资格。')
    table=''.join('<tr><td>'+('偏航导向口' if r['site']=='yaw_sliding_guide' else '头部回线固定点')+
        f"</td><td>{r['pin']}</td><td>{r['material_travel_numeric_mm']:.8f}</td><td>{r['minimum_straight_before_mm']:.2f} / {r['minimum_straight_after_mm']:.2f}</td></tr>"
        for r in station['summaries'])
    length_table=''.join(f"<tr><td>{r['wire']}</td><td>{r['body_neck_numeric_reference_mm']:.2f}</td><td>{r['upper_numeric_reference_mm']:.2f}</td><td>未知</td></tr>" for r in datums['rows'])
    diagram='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 920 300" role="img" aria-label="一毫米中心距的线径对比">
<rect width="920" height="300" fill="#f3f6f7"/>
<g font-family="system-ui" font-size="17" fill="#24343d">
<text x="35" y="32">容量参考 OD 0.6604</text><text x="345" y="32">AWG28 候选最大 OD 1.13</text><text x="680" y="32">原厂 SH 尾线</text>
<circle cx="90" cy="128" r="46.228" fill="#62b8a6"/><circle cx="230" cy="128" r="46.228" fill="#62b8a6"/>
<circle cx="400" cy="128" r="79.1" fill="#cf6b5f" fill-opacity=".55"/><circle cx="540" cy="128" r="79.1" fill="#cf6b5f" fill-opacity=".55"/>
<rect x="705" y="79" width="150" height="98" rx="20" fill="#dfb85f"/><text x="748" y="136" font-size="32">?</text>
<text x="35" y="235">名义表面间隙 0.3396 mm</text><text x="345" y="235">名义相交 0.13 mm</text><text x="690" y="235">外径、尾长待到货</text>
<text x="35" y="278" font-size="15">图示采用当前细线参考的 1 mm 中心距；不是实物接口尺寸测量，也不代表正式 SH 尾线。</text>
</g></svg>'''
    (HERE/'diameter_comparison.svg').write_text(diagram+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM 线材与固定点复核</title><style>body{{max-width:1050px;margin:2.5rem auto;padding:0 1rem;font:16px/1.7 system-ui;color:#24343d}}a{{color:#176687}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #cbd5d9;padding:8px;text-align:left}}.note{{padding:16px;background:#fff2d5;border-left:4px solid #c29030}}img{{width:100%}}</style>
<h1>M1.55 · CAM 线材与固定点</h1><p>本页是独立研究。主模型、视频、正式 H06 与原生硬件保持；没有采用旧导向／固定座。</p>
<p class="note">固定位置的容量参考已重新核对，但真实分段线材、压接与接续仍 BLOCKED。不能以细线参考的 PASS 放行 AWG28 线束。</p>
<h2>现在确认的内容</h2><p>原四根 CAM 路线在 475 个姿态、两处位置共完成 3,800 次材料坐标检查。最新长度补偿后，两处位置的材料坐标变化均低于 0.000020 mm；旧 M1.54 的 8.0–8.5 mm 滑移数值不再代表本候选。数值变化不是实物拉伸／滑动测量，也不自动批准把导向口改成锁紧夹。</p>
<table><thead><tr><th>位置</th><th>线号</th><th>最大材料坐标变化 mm</th><th>单段直线两侧余量 mm</th></tr></thead><tbody>{table}</tbody></table>
<p>固定座的实体间隙、实际夹持长度、装入与扎带工具空间尚未按这组路线重新核对；没有继承旧固定座的 PASS。</p>
<h2>正式线材的边界</h2><p>正式 H06 仍为 PH 端 AWG28／SPH-002T-P0.5S，CAM 端保留厂配 SH 尾线。未选定的 Tensility 30-02600 外径为 1.05±0.08 mm；最大 1.13 mm 的零位身体／颈部 54 项检查通过。{html.escape(motion_text)}</p>
<img src="diameter_comparison.svg" alt="当前参考线径与AWG28候选最大线径对比">
<p>将同一根粗线延续到当前头内细线段的诊断，有三组相邻线未通过，部分位置出现约 0.13 mm 名义相交。这只是直径敏感性诊断，不是建议用该线替换原厂 SH 尾线，也不是发现实物碰撞。</p>
<p>因此仍需确定粗线／厂配细线的接续位置、接续后最大外形、分段长度及固定方式。Z200 数学拼接点没有被指定为实际接头或固定点；参考总长不是裁线长。</p>
<table><thead><tr><th>线号</th><th>身体／颈部数值参考 mm</th><th>上段数值参考 mm</th><th>实际裁线长</th></tr></thead><tbody>{length_table}</tbody></table>
<p>此表只明确现有两段参考的长度基准；不能将上段长度当成原厂 SH 尾线要求，实际材料边界尚未确定。</p>
<h2>还要完成</h2><ol><li>按原厂尾线的真实外径、长度及端接，确定分段接续；等待到货部分保持明确未知。</li><li>按实际分段线材复核姿态间运动、固定座和穿线，不直接沿用容量参考结果。</li><li>补齐头部两舵机总线与喇叭的五条上段；CAM 供电源端等待硬件正式交接。</li><li>完成带线装入、最终理线、闭壳和裁线图，再申请采用到主模型及视频。</li></ol>
<p><a href="review.json">固定位置记录</a> · <a href="material_fit_zero.json">零位直径诊断</a> · <a href="body_material_motion.json">身体段运动诊断</a> · <a href="reference_length_datums.json">长度基准</a> · <a href="commands.json">执行记录</a> · <a href="../upper_motion_family_R1/index.html">原七条容量参考</a> · <a href="../../../index.html">当前主模型入口</a></p>
</html>'''
    (HERE/'index.html').write_text(page+'\n')
    readme=f'''# M1.55 当前 CAM 固定位置与线材边界

原参考 475 姿态／3,800 次位置检查完成；实际分段线材与夹持仍 BLOCKED。
旧 M1.54 的 8.0–8.5 mm 导向滑移数值不能套到当前补偿后路线。
当前两处位置材料坐标变化最大约 0.000020 mm，是数值容量参考，非实测。
不据此把旧滑动导向改成锁紧夹，也不继承旧固定座的实体／装配 PASS。

Tensility 30-02600 未选定；正式 H06 保留 AWG28／PH002 与厂配 SH 尾线。
候选最大 OD1.13 的零位身体／颈部 54 项通过；{motion_text}
粗线继续到当前头内细线段的诊断三组相邻线失败，部分约 0.13 mm 名义相交。
这不是建议替换厂配 SH 尾线；实际尾线及接续尺寸仍未知。

主模型、视频、硬件与正式 H06 不变。Z200 不是实际接头或固定点；无裁线／制造放行。
实际命令见 commands.json；脚本与 JSON 结果保留，终端输出见本对话工具记录。
'''
    (HERE/'README.md').write_text(readme)
    baseline_paths=[PROJECT/'mechanical/mori_v1_2.blend',PROJECT/'mechanical/animation/MORI_assembly.mp4',PROJECT/'contracts/components.json']
    protected={str(p):sources[str(p)] for p in baseline_paths if str(p) in sources}
    # The video is not an input to curve maths; verify its known M1.55-A1 hash separately.
    video=baseline_paths[1]
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    protected[str(video)]=sha(video)
    delivery=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Published current station/material diagnosis; no actual harness release',
        station_checks=3800,station_poses=475,body_material_motion_status=motion['status'],
        body_material_motion_checks=motion['checks'],body_material_motion_yaws=len(motion['checked_yaws']),
        upper_uniform_wire_boundary='BLOCKED',actual_harness='BLOCKED',sources=sources,protected=protected,
        files={p.name:sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ['.py','.json','.svg','.html','.md','.png'] and p.name not in ['delivery.json','publication_verification.json']},
        main_changed=False,hardware_changed=False,animation_changed=False,new_commit_or_push=False,
        manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    print('STATION_MATERIAL_PUBLICATION_PASS',motion['status'],motion['checks'])


if __name__=='__main__':main()
