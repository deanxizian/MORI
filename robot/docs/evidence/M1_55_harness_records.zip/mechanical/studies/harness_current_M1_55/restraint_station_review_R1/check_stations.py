"""Current CAM material stations on the original finite 475-pose family.

Reads saved, checked curves. Does not redraw routes, alter restraints, or
inherit the old M1.54 restraint clearance result. Lengths are numerical
capacity references, not supplier cut lengths or measured wire lengths.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT / 'upper_motion_family_R1'))
from power_family import PowerFamily


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def partial_length(c, t):
    nodes, weights = np.polynomial.legendre.leggauss(64)
    u = (nodes + 1) * t / 2
    d = 3 * np.diff(c, axis=0)
    v = ((1-u)**2)[:,None]*d[0] + (2*u*(1-u))[:,None]*d[1] + (u*u)[:,None]*d[2]
    return float(weights @ np.linalg.norm(v,axis=1) * t / 2)


def crossing(cubics, lengths, transform, point, direction, prefix_length):
    inv = np.linalg.inv(transform)
    local = cubics @ inv[:3,:3].T + inv[:3,3]
    point = np.array(point, float)
    hits = []
    for i,c in enumerate(local):
        if np.max(np.abs(c[:,:2]-point[:2])) > 1e-5:
            continue
        delta = c[-1,2]-c[0,2]
        if delta * direction <= 1e-9:
            continue
        t = (point[2]-c[0,2])/delta
        if not -1e-8 <= t <= 1+1e-8:
            continue
        t = float(np.clip(t, 0, 1))
        expected = c[0] + np.arange(4)[:,None]*(c[-1]-c[0])/3
        if np.max(abs(c-expected)) > 1e-5:
            continue
        s = float(prefix_length + np.sum(lengths[:i]) + partial_length(cubics[i],t))
        before,after=abs(point[2]-c[0,2]),abs(c[-1,2]-point[2])
        hits.append(dict(piece=i, parameter=t, material_station_numeric_mm=s,
            numerical_remaining_mm=float(prefix_length+np.sum(lengths)-s),
            straight_before_mm=float(before),straight_after_mm=float(after),
            line_axis_residual_mm=float(np.max(np.abs(c[:,:2]-point[:2])))))
    # A point shared by two collinear line pieces is one material crossing.
    unique=[]
    for h in hits:
        if not any(abs(h['material_station_numeric_mm']-u['material_station_numeric_mm'])<1e-6 for u in unique):
            unique.append(h)
    return dict(status='PASS' if len(unique)==1 else 'BLOCKED',crossings=unique,
        crossing_count=len(unique),local_point_mm=point.tolist())


def main():
    started=time.time()
    family=PowerFamily()
    math_path=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
    curves_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    receipt=json.loads(math_path.read_text())
    assert receipt['status']=='PASS'
    assert receipt['arrays_sha256']==sha(curves_path)
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    arrays=np.load(curves_path)
    rows=[]
    poses=receipt['planned_poses']
    assert len(poses)==475
    for yaw,pitch in poses:
        for pin in range(1,5):
            name=f'CAM_{pin}'
            key=f'{name}_y{yaw:g}_p{pitch:g}'
            c=arrays[key+'_controls'];L=arrays[key+'_lengths']
            x=-26.600000143051147-pin+1
            for site,frame,y,z,direction in [
                ('yaw_sliding_guide',family.transform(yaw,0),-11.,225.5,1),
                ('pitch_return_anchor',family.transform(yaw,pitch),-20.800000190734863,220.,-1)]:
                result=crossing(c,L,frame,[x,y,z],direction,family.ctx.f.targets[name])
                rows.append(dict(site=site,pin=pin,yaw_deg=yaw,pitch_deg=pitch,**result))
    summaries=[]
    for site in ['yaw_sliding_guide','pitch_return_anchor']:
        for pin in range(1,5):
            rr=[r for r in rows if r['site']==site and r['pin']==pin]
            valid=[r['crossings'][0] for r in rr if r['status']=='PASS']
            if len(valid)!=len(poses):
                summaries.append(dict(site=site,pin=pin,status='BLOCKED',valid_poses=len(valid)))
                continue
            ss=[r['material_station_numeric_mm'] for r in valid]
            travel=max(ss)-min(ss)
            summaries.append(dict(site=site,pin=pin,status='PASS',valid_poses=len(valid),
                station_range_numeric_mm=[min(ss),max(ss)],material_travel_numeric_mm=travel,
                minimum_straight_before_mm=min(r['straight_before_mm'] for r in valid),
                minimum_straight_after_mm=min(r['straight_after_mm'] for r in valid),
                maximum_axis_residual_mm=max(r['line_axis_residual_mm'] for r in valid),
                fixed_clamp_station='PASS' if travel<.01 else 'BLOCKED',
                intended_restraint='SLIDING' if site=='yaw_sliding_guide' else 'FIXED'))
    family.unchanged()
    sources=dict(family.sources)
    sources.update({str(p):sha(p) for p in [Path(__file__),math_path,curves_path]})
    out=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',
        scope='Material crossing and straight extent of original CAM references at 475 finite poses',
        pose_count=len(poses),crossing_checks=len(rows),summaries=summaries,sources=sources,
        historical_restraint_geometry_PASS_inherited=False,restraint_clearance='NOT_TESTED',
        selected_material_and_actual_ports='BLOCKED',supplier_cut_lengths='BLOCKED',
        grip_and_sliding_performance='NOT_TESTED',all_angle_certificate='NOT_TESTED',
        approved=False,main_changed=False,hardware_changed=False,animation_changed=False,
        full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'stations.json').write_text(json.dumps(rows,indent=2)+'\n')
    (HERE/'review.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(status=out['status'],checks=len(rows),summaries=summaries,elapsed_s=out['elapsed_s']),indent=2),flush=True)


if __name__=='__main__':
    main()
