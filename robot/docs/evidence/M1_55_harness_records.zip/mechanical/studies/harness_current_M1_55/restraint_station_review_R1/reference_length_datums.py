"""Length datums for planning a real mixed-material CAM harness.

No Z200 splice is selected. Derives the existing reference region lengths,
so their relation to an actual pigtail can be reviewed after arrival.
"""
from pathlib import Path
import hashlib
import json
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt_path=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
array_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
receipt=json.loads(receipt_path.read_text())
assert receipt['status']=='PASS' and receipt['arrays_sha256']==sha(array_path)
assert all(sha(p)==h for p,h in receipt['sources'].items())
arrays=np.load(array_path);rows=[]
for pin in range(1,5):
    n=f'CAM_{pin}';c=arrays[f'{n}_y0_p0_controls'];L=arrays[f'{n}_y0_p0_lengths']
    whole=receipt['targets'][n];upper=float(L.sum())
    rows.append(dict(wire=n,body_neck_numeric_reference_mm=whole-upper,
        upper_numeric_reference_mm=upper,complete_numeric_reference_mm=whole,
        mathematical_region_start_mm=c[0,0].tolist(),assumed_CAM_reference_end_mm=c[-1,-1].tolist(),
        selected_splice_point=None,supplier_cut_length=None,actual_tail_length=None,
        material_split_status='BLOCKED'))
result=dict(status='PASS',scope='Reproducible numerical region datums, not manufacturing cut lengths',
    rows=rows,sources={str(p):sha(p) for p in [Path(__file__),receipt_path,array_path]},
    source_datums='Capacity reference starts and assumed terminals; no measured termination datum',
    Z200_is_actual_splice=False,formal_H06_changed=False,main_changed=False,hardware_changed=False,
    full_harness='BLOCKED',manufacturing_release=False)
(HERE/'reference_length_datums.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(rows,indent=2))
