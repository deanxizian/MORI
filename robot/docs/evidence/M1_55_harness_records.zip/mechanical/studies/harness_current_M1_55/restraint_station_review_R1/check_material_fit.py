"""Zero-pose OD sensitivity of formal-compatible, unselected AWG28 wire.

Checks the current body/neck references with the documented maximum OD of
Tensility 30-02600. The SH factory tail is not replaced or invented. The
upper enlargement is a boundary diagnostic only, never a proposed harness.
"""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,sha
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from power_family import PowerFamily
from piecewise_geometry import BSpline,pieces,RADII
path=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_material_fit_helpers',path)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)


def nearest_station(pack,point):
    if point is None:return None
    p=pack['p'];d=pack['u'];span=np.linalg.norm(d,axis=1)
    t=np.clip(np.einsum('ij,ij->i',np.asarray(point)-p[:-1],d)/(span*span),0,1)
    distance=np.linalg.norm(p[:-1]+t[:,None]*d-point,axis=1)
    i=int(np.argmin(distance))
    return dict(polyline_station_mm=float(span[:i].sum()+t[i]*span[i]),
                projection_distance_mm=float(distance[i]),datum='Start of this capacity segment; not actual terminal cut datum')


def main():
    started=time.time();ctx=Context();family=PowerFamily()
    fact_path=PARENT/'materials/source_facts.json'
    facts=json.loads(fact_path.read_text());wire=facts['Tensility_30_02600']
    assert not wire['selected'] and wire['OD_max_mm']==1.13
    assert facts['formal_definition']['body_terminal']=='SPH-002T-P0.5S'
    radius=wire['OD_max_mm']/2
    names=[f'CAM_{p}' for p in range(1,5)]
    prefixes={n:helpers.prepare(pieces(BSpline(family.ctx.f.knots,family.ctx.f.candidate(n,0)['control'],3)),
        radius if n in names else family.ctx.f.radii[n]) for n in family.ctx.f.names}
    cam_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    cam_receipt_path=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
    power_path=PARENT/'upper_motion_family_R1/half_grid_curves.npz'
    power_receipt_path=PARENT/'upper_motion_family_R1/half_grid_inspection.json'
    for p,r in [(cam_path,cam_receipt_path),(power_path,power_receipt_path)]:
        data=json.loads(r.read_text());assert data['status']=='PASS' and sha(p)==data['arrays_sha256']
        assert all(sha(s)==h for s,h in data['sources'].items())
    cam=np.load(cam_path);power=np.load(power_path)
    # Upper diagnostic only: no proposal to replace the factory SH tail.
    uppers={n:helpers.prepare((cam if n.startswith('CAM_') else power)[f'{n}_y0_p0_controls'],
                             radius if n in names else r) for n,r in RADII.items()}
    rows=[]
    for region,packs in [('body_neck',prefixes),('upper_OD_boundary',uppers)]:
        for n in names:
            pack=packs[n]
            for group,targets in ctx.groups.items():
                hits,near=clear(pack['p'],pack['radius'],targets,error=pack['error'],gap=.3)
                rows.append(dict(region=region,wire=n,kind='native',group=group,status='PASS' if not hits else 'BLOCKED',
                    hits=hits,nearest_within_query_AABBs=near,wire_radius_mm=radius))
            if region=='upper_OD_boundary':
                hits,near=clear(pack['p'],radius,ctx.usb,error=pack['error'],gap=.3)
                rows.append(dict(region=region,wire=n,kind='conditional_USB',status='PASS' if not hits else 'BLOCKED',
                                 hits=hits,nearest_within_query_AABBs=near))
            own=helpers.compare(pack,pack,'self')
            rows.append(dict(region=region,wires=[n,n],**own))
        for a,b in itertools.combinations(packs,2):
            if a not in names and b not in names:continue
            row=dict(region=region,wires=[a,b],**helpers.compare(packs[a],packs[b]))
            if row['witness']:
                row['witness']['station_a']=nearest_station(packs[a],row['witness']['point_a_mm'])
                row['witness']['station_b']=nearest_station(packs[b],row['witness']['point_b_mm'])
            rows.append(row)
    ctx.record([Path(__file__),path,fact_path,cam_path,cam_receipt_path,power_path,power_receipt_path])
    ctx.unchanged();family.unchanged()
    summary=[]
    for region in ['body_neck','upper_OD_boundary']:
        rr=[r for r in rows if r['region']==region]
        failures=[r for r in rr if r['status']!='PASS']
        summary.append(dict(region=region,status='PASS' if not failures else 'BLOCKED',
            checks=len(rr),failures=len(failures)))
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Completed zero-pose diameter sensitivity diagnosis, not successful complete material fit',
        revision='V1.2-M1.55',sources=ctx.sources|family.sources,wire_candidate=wire,
        required_gap_mm=.3,poses=[[0,0]],summaries=summary,rows=rows,
        selected_wire_fit='BLOCKED',actual_factory_tail='BLOCKED',splice_location_and_envelope='BLOCKED',
        unchanged_formal_H06=True,upper_Tensility_substitution_proposed=False,
        all_angle_material_fit='NOT_TESTED',supplier_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'material_fit_zero.json').write_text(json.dumps(out,indent=2)+'\n')
    print('MATERIAL_FIT_ZERO_DIAGNOSIS',json.dumps(summary),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
