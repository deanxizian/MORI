"""Finite motion check of unselected formal-compatible AWG28 body leads.

Only body/neck curve radii change for this diagnostic; no actual SH tail,
splice, hardware, main geometry or source radius is modified.
"""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,transform_points,rigidtr,sha
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from power_family import PowerFamily
from piecewise_geometry import BSpline,pieces
helper_path=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_body_material_motion_helpers',helper_path)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)


def main():
    started=time.time();native=Context();family=PowerFamily()
    facts_path=PARENT/'materials/source_facts.json'
    facts=json.loads(facts_path.read_text());wire=facts['Tensility_30_02600']
    assert wire['selected'] is False and wire['OD_max_mm']==1.13
    names=[f'CAM_{pin}' for pin in range(1,5)];radius=wire['OD_max_mm']/2
    rows=[];failures=[];checked=[]
    yaw_order=[-60,60,-55,55,-50,50,-45,45,-40,40,-35,35,-30,30,-25,25,-20,20,-15,15,-10,10,-5,5,0]
    for yaw in yaw_order:
        packs={n:helper.prepare(pieces(BSpline(family.ctx.f.knots,family.ctx.f.candidate(n,yaw)['control'],3)),
             radius if n in names else family.ctx.f.radii[n]) for n in family.ctx.f.names}
        for n in names:
            pack=packs[n]
            for group,targets in native.groups.items():
                pitches=[-20,0,25] if group=='pitch' else [0]
                for pitch in pitches:
                    matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                    norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
                    hits,near=clear(transform_points(pack['p'],matrix),radius*norm,targets,error=pack['error']*norm,gap=.3*norm)
                    row=dict(wire=n,yaw_deg=yaw,pitch_deg=pitch,kind='native',group=group,
                        status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near)
                    rows.append(row)
                    if hits:failures.append(row)
            row=dict(wires=[n,n],yaw_deg=yaw,**helper.compare(pack,pack,'self'))
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
        for a,b in itertools.combinations(packs,2):
            if a not in names and b not in names:continue
            row=dict(wires=[a,b],yaw_deg=yaw,**helper.compare(packs[a],packs[b]))
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
        checked.append(yaw)
        print('BODY_AWG28_DIAGNOSTIC_YAW',yaw,'checks',len(rows),'failures',len(failures),'elapsed',time.time()-started,flush=True)
        if failures:break
    native.record([Path(__file__),helper_path,facts_path]);native.unchanged();family.unchanged()
    out=dict(status='PASS' if not failures and len(checked)==25 else 'BLOCKED',
        scope='Finite current body/neck motion sensitivity to documented maximum OD1.13; actual material not selected',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources|family.sources,
        revision='V1.2-M1.55',radius_mm=radius,required_gap_mm=.3,planned_yaws=yaw_order,checked_yaws=checked,
        pitch_samples_deg=[-20,0,25],checks=len(rows),rows=rows,failures=failures,
        all_angle_body_material_fit='NOT_TESTED',upper_material='BLOCKED',actual_splice='BLOCKED',
        crimp_and_dynamic_life='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'body_material_motion.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BODY_AWG28_DIAGNOSTIC_TERMINAL',out['status'],len(checked),len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
