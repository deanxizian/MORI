"""Record public PHR-4 facts and the current detailed-CAD access boundary.

No customer form is submitted, no protected CAD is downloaded, and the
hardware-owned contract/native source is read only. Catalogue dimensions
do not certify internal cavities, crimp shape or a full assembled connector.
"""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import json
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Plain(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,data):self.parts.append(data)


def main():
    render=read(HERE/'catalogue_render_receipt.json')
    assert sha(render['source'])==render['source_sha256']
    assert sha(render['image'])==render['image_sha256']
    assert sha(render['additional_assembly_page']['image'])==render['additional_assembly_page']['image_sha256']
    handoff_path=PROJECT/'hardware/v1_2/handoff/mechanical_P5R7.json'
    contract_path=PROJECT/'contracts/components.json'
    handoff=read(handoff_path)
    connector=next(c for c in handoff['boards']['MORI_motion_P5R7']['connectors'] if c['ref']=='J5')
    assert connector['mpn']=='B4B-PH-K-S(LF)(SN)' and connector['mating']=='PHR-4'
    assert connector['contact']=='SPH-002T-P0.5S'
    config_path=PROJECT/'config/geometry.json';config=read(config_path)
    mesh_path=PROJECT/config['native_electronics']['boards']['motion']['mesh'];mesh=read(mesh_path)
    ports_path=HERE.parent/'port_inspection.json';ports=read(ports_path)
    assert all(sha(p)==h for p,h in ports['sources'].items())
    pcb=next(c for c in mesh['components'] if c['reference']=='PCB')
    top_native=pcb['bounds_xyz_mm'][2][0]+mesh['nominal_board_thickness_mm']
    rotation=ports['J5']['board_rotation'];translation=ports['J5']['board_translation_mm']
    assert rotation==[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
    model_top=top_native+translation[2]
    catalogue_height_reference=model_top+8.
    body_refs_path=HERE.parent/'staged_prefix_entry_review_R1/prefix_entry_review.json'
    body_refs=read(body_refs_path)
    assert all(sha(p)==h for p,h in body_refs['sources'].items())
    starts={r['wire']:r['start_mm'] for r in read(HERE.parent/'moving_bundle_entry_review_R1/bundle_receipt.json')['rows']
            if r['role']=='prefix' and r['wire'].startswith('CAM_')}
    assert len(starts)==4
    urls=[
        'https://www.jst-mfg.com/product/index.php?lang=2&series=199',
        'https://www.jst-mfg.com/product/index.php?lang=2&doc=2&filename=PHR-4.zip&series=199&type=10']
    fetches=[]
    for url in urls:
        with urllib.request.urlopen(url,timeout=15) as response:
            content=response.read();content_type=response.headers.get('Content-Type','')
            assert response.status==200 and 'text/html' in content_type
            parser=Plain();parser.feed(content.decode('utf-8'))
            text=' '.join(' '.join(parser.parts).split())
            entry=dict(url=url,final_url=response.url,status=response.status,content_type=content_type,
                       bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
            if 'doc=2' in url:
                assert 'License Agreement' in text and 'Company name' in text
                assert 'Telephone number' in text and 'E-Mail address' in text
                assert 'email attachment method' in text
                entry.update(customer_form_required=True,email_attachment_delivery=True,
                             protected_CAD_bytes_received=False,form_submitted=False,
                             personal_or_company_fields_supplied=False)
            else:
                assert 'PHR-4' in text and 'SPH-002T-P0.5S' in text
            fetches.append(entry)
    (HERE/'retrieval.json').write_text(json.dumps(dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Public GET responses only; no form submission or protected CAD acquisition',requests=fetches),indent=2)+'\n')
    sources={str(p):sha(p) for p in [Path(__file__),Path(render['source']),Path(render['image']),
        Path(render['additional_assembly_page']['image']),HERE/'catalogue_render_receipt.json',
        HERE/'retrieval.json',handoff_path,contract_path,config_path,mesh_path,ports_path,
        body_refs_path,HERE.parent/'moving_bundle_entry_review_R1/bundle_receipt.json']}
    output=dict(status='PASS',scope='Public catalogue field and formal connector identity review only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        manufacturer='JST',housing_mpn='PHR-4',header_mpn=connector['mpn'],contact_mpn=connector['contact'],
        formal_hardware_source=dict(path=str(handoff_path),pointer='/boards/MORI_motion_P5R7/connectors/4',
            board='MORI_motion_P5R7',ref='J5',value=connector['value']),
        category='PURCHASED_REFERENCE',overall_geometry_status='ASSUMED / partial catalogue fields only',
        documented_fields=dict(units='mm',pole_count=4,pitch_mm=2.,first_to_last_span_A_mm=6.,
            housing_width_B_mm=9.8,housing_depth_mm=4.5,housing_height_mm=6.85,
            top_entry_assembly_height_reference_mm=8.,header_width_mm=9.9,header_body_height_mm=6.,
            housing_material='PA, natural white',evidence='VENDOR_DOCUMENTED: public catalogue pages1/3',
            dimensional_tolerances=None),
        current_model_reference_only=dict(PCB_finished_nominal_top_Z_mm=model_top,
            catalogue_assembly_reference_top_Z_mm=catalogue_height_reference,
            CAM_body_reference_starts_mm=starts,
            current_reference_minus_catalogue_height_mm={n:p[2]-catalogue_height_reference for n,p in starts.items()},
            note='0.04mm source-library/substrate datum difference is recorded, not corrected or declared a real tolerance/defect'),
        unresolved_fields=['Housing interior and terminal entry geometry','Mating insertion depth and full datums',
            'Wire exit position relative to the male pin row','Complete formed/crimped contact and insulation barrel',
            'Manufacturing tolerances','Actual wire/protector and grip envelope'],
        official_detailed_CAD='BLOCKED: personal/company registration and email delivery; no submission authorized',
        CAD_access_url=urls[1],CAD_data_received=False,request_sent=False,customer_form_submitted=False,
        public_catalogue_url=render['source_url'],public_product_url=urls[0],
        current_native_housing='Absent from main native201; no detailed housing added',
        actual_mating='BLOCKED',full_harness='BLOCKED',wire_selected=False,
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'source_facts.json').write_text(json.dumps(output,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items())
    print('PUBLIC_PHR4_SOURCE_FIELDS_RECORDED',9.8,4.5,6.85,'CAD_NOT_RECEIVED',flush=True)


if __name__=='__main__':main()
