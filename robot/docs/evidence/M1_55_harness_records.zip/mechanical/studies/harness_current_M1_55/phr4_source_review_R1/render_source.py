"""Read-only public PH catalogue page for manual dimensional inspection."""
from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import sys
import pypdfium2 as pdfium

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'material_terminal_review_R1/sources/JST_PH_current.pdf'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(SOURCE)=='447624f4f2f7d37c58c1eaa7ee314ad757fe7aff48f6186491ef6f69fbc00b96'
pdf=pdfium.PdfDocument(str(SOURCE))
assert len(pdf)==5
page=pdf[2]
target=HERE/'PH_housing_catalogue_page.png'
page.render(scale=2).to_pil().save(target)
text=page.get_textpage().get_text_range()
(HERE/'housing_catalogue_text.txt').write_text(text)
receipt=dict(status='PASS',scope='Rendering/readout only; fields require visual review',
    source=str(SOURCE.resolve()),source_sha256=sha(SOURCE),source_url='https://www.jst-mfg.com/product/pdf/eng/ePH.pdf',
    page_1_based=3,page_count=5,image=str(target.resolve()),image_sha256=sha(target),scale=2,
    PDFium_version=importlib.metadata.version('pypdfium2'),python=sys.version,
    initial_text_attempt='pypdf extraction has unreadable embedded glyphs; not used for dimensions',
    visual_review='NOT_TESTED',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(HERE/'catalogue_render_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PUBLIC_PH_HOUSING_PAGE_RENDERED',sha(target),flush=True)
