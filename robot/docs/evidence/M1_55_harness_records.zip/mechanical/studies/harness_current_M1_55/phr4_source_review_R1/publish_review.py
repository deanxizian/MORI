"""Publish partial catalogue facts without claiming a retrieved vendor CAD."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote,unquote,urlsplit
import datetime
import hashlib
import json
import sys
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):self.links.extend(v for k,v in attrs if k in ['href','src'])


def main():
    facts=read(HERE/'source_facts.json');audit=read(HERE/'source_verification.json')
    assert facts['status']==audit['status']=='PASS' and audit['manual_field_review']=='PASS'
    assert not facts['CAD_data_received'] and not audit['CAD_acquired']
    sources={**audit['sources'],**{str(p):sha(p) for p in [Path(__file__),HERE/'source_verification.json']}}
    assert all(sha(p)==h for p,h in sources.items())
    assert 'PUBLIC_PHR4_SOURCE_VERIFIED 9 2 846' in (HERE/'verify_source_fields.log').read_text()
    render=read(HERE/'catalogue_render_receipt.json')
    additional=read(HERE/'additional_render_command.json')
    assert additional['status']=='PASS' and additional['exit_code']==0
    commands=dict(status='PASS',cwd=str(PROJECT),renderer_python=render['python'],PDFium=render['PDFium_version'],commands=[
        dict(command=['/Users/dean/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',str(HERE/'render_source.py')],
             log='render_source.log',exit_code=0,additional_page='Page1 additionally rendered from same PDF; receipt records actual source/image hashes'),
        dict(command=[sys.executable,str(HERE/'record_sources.py')],log='record_sources.log',exit_code=0,
             scope='Public GET only; no form POST/email/contact'),
        dict(command=[sys.executable,str(HERE/'verify_source_fields.py')],log='verify_source_fields.log',exit_code=0)],
        additional_render_command='additional_render_command.json',
        initial_verifier_diagnostic='initial_literal_float_check/diagnostic.json',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    (HERE/'index.html').write_text('''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 PHR-4公开资料与CAD边界</title><style>body{font:16px/1.65 system-ui,sans-serif;max-width:950px;margin:32px auto;padding:0 22px;color:#27343b}table{width:100%;border-collapse:collapse;margin:20px 0}td,th{padding:9px;border:1px solid #cbd3d7;text-align:left}a{color:#25566b}.scope{padding:16px;background:#f2f3f1;border-left:4px solid #758082}</style>
<h1>PHR-4身体端插头：已知字段与未取得的详细CAD</h1>
<p class="scope">公开目录字段已核对；完整部件几何与插合仍BLOCKED。PURCHASED_REFERENCE / ASSUMED（仅所列字段VENDOR_DOCUMENTED）· PROTOTYPE / UNVALIDATED。</p>
<p>正式P5R7交接里的运动基板J5（CAM J11 MATCH）采用B4B-PH-K-S(LF)(SN)，配对PHR-4及SPH-002T-P0.5S。电源板同名J5是XT30，已分开核对，没有修改硬件契约或混用型号。</p>
<table><thead><tr><th>公开目录字段（mm）</th><th>数值</th><th>来源</th></tr></thead><tbody>
<tr><td>PHR-4极数／孔距／首末极跨度</td><td>4／2.0／6.0</td><td>目录p3</td></tr>
<tr><td>PHR-4外宽／深／高</td><td>9.8／4.5／6.85</td><td>目录p3</td></tr>
<tr><td>B4B-PH-K-S外宽／本体高</td><td>9.9／6.0</td><td>目录p3</td></tr>
<tr><td>顶插组合安装高度参考</td><td>8.0</td><td>目录p1括号参考值，未含线材弯折空间</td></tr>
</tbody></table>
<p>已完整查看两页目录。PCB实体名义上表面与库模型线口参考之间的0.04mm坐标基准差只记录，没有移动参考端点，也没有把它当作实际配合公差或产品故障。</p>
<p>官网列有PHR-4 STEP及单件图纸，但当前入口要求登记公司、姓名、地址、电话及邮箱后由邮件提供。没有提交表单、填写个人／公司资料或取得CAD。入口同时说明其CAD为简化设计参考；不能据网页列表宣称完整官方模型已取得。</p>
<p>内腔、插深、相对针排的线口位置、压接后的完整金属／绝缘桶、实发公差及实际线材／保护／夹持外形仍待确认。当前主模型201件实体内没有新增详细PHR-4；公开外形尺寸不能替代完整插合或带线装配检查。制造放行false。</p>
<p><a href="https://www.jst-mfg.com/product/index.php?lang=2&series=199">JST官方系列与型号表</a> · <a href="https://www.jst-mfg.com/product/index.php?lang=2&doc=2&filename=PHR-4.zip&series=199&type=10">当前详细CAD申请入口</a> · <a href="https://www.jst-mfg.com/product/pdf/eng/ePH.pdf">公开官方目录</a></p>
<p><a href="source_facts.json">来源字段与未知项</a> · <a href="source_verification.json">身份／来源／范围复核</a> · <a href="catalogue_render_receipt.json">两页渲染来源</a> · <a href="retrieval.json">公开GET记录</a> · <a href="commands.json">实际命令</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# PHR-4 public-source review

Received formal motionP5R7 J5 is B4B-PH-K-S(LF)(SN), paired with PHR-4 and
SPH-002T-P0.5S. PowerP5R6 J5 is a different XT30 interface. Hardware sources
and contracts are read only. Public catalogue pages1/3 are fully rendered
and manually reviewed. Nine numeric fields recorded; outer housing9.8x4.5x6.85,
2mm pitch,6mm pole span,8mm parenthesized assembled-height reference.

Manufacturer detailed CAD/individual drawings currently require personal/
company registration and email delivery. No form submission, contact, data
entry or CAD retrieval. Public GET responses only. The listed CAD is also
declared simplified design support; it cannot substitute physical evidence.

Complete cavities, insertion/wire-exit datums, formed crimp, tolerances and
lead/protector/grip still unknown. No detailed housing added to main201.
Current reference-vs-substrate0.04mm datum difference is recorded, not moved
or described as a real mismatch/tolerance. Actual mating/full harness BLOCKED;
main/video/hardware unchanged;846 protected hardware files; no manufacturing.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
           and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_review.log']}
    delivery=dict(status='PASS',scope='Public field and detailed-CAD access-boundary publication only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        documented_numeric_fields=9,manually_reviewed_pages=2,exact_formal_interface='motionP5R7/J5',
        housing='PHR-4',CAD_data_received=False,customer_form_submitted=False,actual_mating='BLOCKED',
        full_harness='BLOCKED',protected_hardware_files=846,main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items()) and all(sha(HERE/p)==h for p,h in files.items())
    parser=Links();parser.feed((HERE/'index.html').read_text());targets=[HERE/'index.html']
    for link in parser.links:
        u=urlsplit(link)
        if not u.scheme and u.path:targets.append((HERE/unquote(u.path)).resolve())
    served=[]
    for p in dict.fromkeys(targets):
        relative=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(relative),timeout=10) as response:
            assert response.status==200 and response.read()==p.read_bytes()
        served.append(dict(path=relative,sha256=sha(p)))
    verified=dict(status='PASS',delivery_sha256=sha(HERE/'delivery.json'),verified_sources=len(sources),
                  verified_files=len(files),served_links=len(served),served=served,
                  full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(verified,indent=2)+'\n')
    print('PUBLIC_PHR4_PUBLICATION_VERIFIED',len(files),len(served),9,flush=True)


if __name__=='__main__':main()
