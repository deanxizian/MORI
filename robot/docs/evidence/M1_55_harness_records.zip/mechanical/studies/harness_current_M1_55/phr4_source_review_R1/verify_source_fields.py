"""Verify current formal connector identity and partial-public-data boundaries."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    path=HERE/'source_facts.json';facts=read(path)
    assert facts['status']=='PASS' and all(sha(p)==h for p,h in facts['sources'].items())
    render=read(HERE/'catalogue_render_receipt.json')
    assert render['page_1_based']==3 and render['additional_assembly_page']['page_1_based']==1
    assert sha(render['source'])==render['source_sha256']
    assert sha(render['image'])==render['image_sha256']
    assert sha(render['additional_assembly_page']['image'])==render['additional_assembly_page']['image_sha256']
    # Fields manually read from the two complete manufacturer pages in this
    # task; the renderer itself does not certify dimensions or mating fit.
    expected={'pole_count':4,'pitch_mm':2.,'first_to_last_span_A_mm':6.,
              'housing_width_B_mm':9.8,'housing_depth_mm':4.5,'housing_height_mm':6.85,
              'top_entry_assembly_height_reference_mm':8.,'header_width_mm':9.9,'header_body_height_mm':6.}
    assert all(facts['documented_fields'][k]==v for k,v in expected.items())
    assert facts['documented_fields']['dimensional_tolerances'] is None
    handoff=read(PROJECT/'hardware/v1_2/handoff/mechanical_P5R7.json')
    row=handoff['boards']['MORI_motion_P5R7']['connectors'][4]
    assert row['ref']=='J5' and row['value']=='CAM J11 MATCH'
    assert row['mpn']==facts['header_mpn'] and row['mating']==facts['housing_mpn']
    assert row['contact']==facts['contact_mpn']
    assert handoff['boards']['MORI_power_P5R6']['connectors'][14]['mpn']=='AMASS XT30UPB-M'
    config=read(PROJECT/'config/geometry.json')
    mesh=read(PROJECT/config['native_electronics']['boards']['motion']['mesh'])
    pcb=next(c for c in mesh['components'] if c['reference']=='PCB')
    ports=read(HERE.parent/'port_inspection.json')
    top=pcb['bounds_xyz_mm'][2][0]+mesh['nominal_board_thickness_mm']+ports['J5']['board_translation_mm'][2]
    assert abs(top-facts['current_model_reference_only']['PCB_finished_nominal_top_Z_mm'])<1e-12
    height=top+expected['top_entry_assembly_height_reference_mm']
    offsets=facts['current_model_reference_only']['current_reference_minus_catalogue_height_mm']
    starts=facts['current_model_reference_only']['CAM_body_reference_starts_mm']
    assert len(offsets)==4 and all(abs(offsets[n]-(starts[n][2]-height))<1e-12 for n in offsets)
    # .04 is a human-readable approximate datum difference, not a geometric
    # tolerance. The retained Float32 source coordinate is130.63999938964844.
    assert all(abs(x-.04)<1e-5 for x in offsets.values())
    assert not facts['CAD_data_received'] and not facts['customer_form_submitted'] and not facts['request_sent']
    assert facts['actual_mating']==facts['full_harness']=='BLOCKED'
    assert facts['overall_geometry_status'].startswith('ASSUMED') and len(facts['unresolved_fields'])==6
    retrieval=read(HERE/'retrieval.json')
    assert len(retrieval['requests'])==2 and all(r['status']==200 for r in retrieval['requests'])
    portal=retrieval['requests'][1]
    assert portal['email_attachment_delivery'] and portal['customer_form_required']
    assert not portal['form_submitted'] and not portal['personal_or_company_fields_supplied']
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items()
               if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    sources={**facts['sources'],**{str(p):sha(p) for p in [Path(__file__),path]}}
    output=dict(status='PASS',scope='Public fields, exact motionJ5 identity and unknown-data boundary only; no geometric/physical mating qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        manually_reviewed_catalogue_pages=[1,3],manual_field_review='PASS',documented_numeric_fields=9,
        formal_board='MORI_motion_P5R7',formal_ref='J5',source_datum_offsets_mm=offsets,
        complete_housing_shape='BLOCKED',actual_mating='BLOCKED',CAD_acquired=False,request_sent=False,
        initial_verifier_diagnostic='initial_literal_float_check/diagnostic.json',
        protected_hardware_files=846,main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'source_verification.json').write_text(json.dumps(output,indent=2)+'\n')
    print('PUBLIC_PHR4_SOURCE_VERIFIED',9,2,846,'NO_CAD_OR_MATING_RELEASE',flush=True)


if __name__=='__main__':main()
