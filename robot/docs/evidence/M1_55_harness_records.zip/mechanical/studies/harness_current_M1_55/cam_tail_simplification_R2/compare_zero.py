"""Compare outward offsets of the unadopted short tail, retaining all ports."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT));from context import Context,np,clear,sha
sys.path.insert(0,str(PARENT/'cam_tail_simplification_R1'));from short_tail import ShortTailFamily
from power_family import PowerFamily
from piecewise_geometry import BSpline,pieces,RADII
HELPERS=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_short_tail_R2_helpers',HELPERS)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)


def inspect(family,native,carrier,prefixes):
    math_rows=[];curves={};arrays={};rows=[];failures=[]
    for name in RADII:
        c,info=(family if name.startswith('CAM_') else carrier).upper(name,0.,0.)
        math_rows.append(dict(wire=name,**info));assert c is not None,(name,info)
        arrays[name+'_controls']=c;curves[name]=helpers.prepare(c,RADII[name])
    changed={f'CAM_{p}' for p in range(1,5)}
    for name in sorted(changed):
        pack=curves[name]
        for group,targets in list(native.groups.items())+[('conditional_USB',native.usb)]:
            hits,near=clear(pack['p'],pack['radius'],targets,error=pack['error'],gap=.3)
            row=dict(wire=name,kind='native' if group!='conditional_USB' else group,group=group,
                     status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near)
            rows.append(row)
            if hits:failures.append(row)
        for other,pack2 in prefixes.items():
            if other==name:continue
            row=dict(wires=[name,other],**helpers.compare(pack,pack2));row['kind']='other_prefix';rows.append(row)
            if row['status']!='PASS':failures.append(row)
        for kind,left in [('self',pack),('own_join',prefixes[name])]:
            row=dict(wires=[name,name],**helpers.compare(left,pack,kind));rows.append(row)
            if row['status']!='PASS':failures.append(row)
    for a,b in itertools.combinations(RADII,2):
        if a not in changed and b not in changed:continue
        row=dict(wires=[a,b],**helpers.compare(curves[a],curves[b]));row['kind']='upper_peer';rows.append(row)
        if row['status']!='PASS':failures.append(row)
    assert len(rows)==86
    return dict(status='PASS' if not failures else 'BLOCKED',candidate_parameters=family.spec,
                tail_changes=family.tail_changes,numeric_curve_math=math_rows,geometry_checks=rows,failures=failures),arrays


def main():
    started=time.time();native=Context();carrier=PowerFamily();trials=[];selected=None;full=[]
    prefixes={n:helpers.prepare(pieces(BSpline(carrier.ctx.f.knots,carrier.ctx.f.candidate(n,0)['control'],3)),
                               carrier.ctx.f.radii[n]) for n in carrier.ctx.f.names}
    for center in [24.3,27.,29.,31.,32.]:
        family=ShortTailFamily(carrier,top=242.,rear=-40.,center_x=center)
        checks=[]
        for name in [f'CAM_{p}' for p in range(1,5)]:
            c,info=family.upper(name,0.,0.);assert c is not None,(name,info)
            pack=helpers.prepare(c,RADII[name])
            hits,near=clear(pack['p'],pack['radius'],native.usb,error=pack['error'],gap=.3)
            checks.append(dict(wire=name,status='PASS' if not hits else 'BLOCKED',hits=hits,
                               nearest_within_query_AABBs=near,numeric_curve_math=info))
        usb_ok=all(r['status']=='PASS' for r in checks)
        trials.append(dict(candidate_parameters=family.spec,USB_screen_status='PASS' if usb_ok else 'BLOCKED',checks=checks))
        print('SHORT_TAIL_R2_USB',center,usb_ok,flush=True)
        if not usb_ok:continue
        review,arrays=inspect(family,native,carrier,prefixes);full.append(review)
        print('SHORT_TAIL_R2_FULL_ZERO',center,review['status'],len(review['failures']),flush=True)
        if review['status']=='PASS':
            selected=review;np.savez_compressed(HERE/'zero_curves.npz',**arrays);break
    native.record([Path(__file__),HELPERS,HELPERS.parent/'sample_geometry.py',PARENT/'upper_pairs_review_R1/inspect_pairs.py'])
    native.sources.update(carrier.sources);native.unchanged();carrier.unchanged()
    out=dict(status='PASS' if selected else 'BLOCKED',scope='Outward-offset short fixed CAM tail allocations at zero only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources,
        trials=trials,full_zero_attempts=full,selected=selected,
        arrays_sha256=sha(HERE/'zero_curves.npz') if selected else None,elapsed_s=time.time()-started,
        required_gap_mm=.3,real_ports_changed=False,service_loop_geometry_changed=False,
        all_angle_clearance='NOT_TESTED',other_poses='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'zero_review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('SHORT_TAIL_R2_ZERO_TERMINAL',out['status'],len(trials),len(full),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
