"""Independent source/closed-interval audit and interior-pose cross-checks."""
from pathlib import Path
import hashlib
import json
import math
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sys.path[:0]=[str(PROJECT/'mechanical/scripts/vendor'),
              '/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313']
import manifold3d as manifold
from scipy.spatial.transform import Rotation,Slerp

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    started=time.time()
    proof_path=HERE/'bare_replay_continuous.json';proof=read(proof_path)
    receipt=read(HERE/'current_native_receipt.json')
    assert proof['status']==receipt['status']=='PASS'
    assert proof['enclosure_method'].startswith('R*theta^2/8')
    assert all(sha(p)==h for p,h in proof['sources'].items())
    rawdir=HERE.parent.parent/'harness_current_M1_54/cam_terminal_feed'
    upper,lower=np.load(rawdir/'connected_smooth_dense/path.npz'),np.load(rawdir/'connected_neck_joined/path.npz')
    p=np.vstack([upper['rear_mm'],lower['rear_mm'][1:]])
    raw=np.concatenate([upper['rotations'],lower['rotations'][1:]])
    u,_,vt=np.linalg.svd(raw);r=u@vt
    repair=float(np.linalg.norm(r-raw,ord=2,axis=(1,2)).max())
    relative=np.einsum('nji,njk->nik',r[:-1],r[1:])
    theta=np.arccos(np.clip((np.trace(relative,axis1=1,axis2=2)-1)/2,-1.,1.))
    data=np.load(HERE/'current_native_parts.npz')
    names={row['id'] for row in receipt['native_parts']}
    excluded={'Body_Front','Body_Rear','Head_Front','Head_Rear'}
    expected=sorted(names-excluded)
    assert len(names)==201 and len(expected)==197
    assert set(data.files)=={n+tail for n in names for tail in ['__vertices_mm','__triangles']}
    assert proof['native_parts']==expected and set(proof['not_installed'])==excluded
    assert proof['native_part_count']==197 and proof['source_poses']==len(p)==3046
    assert 'Plug_motion_J5' not in names and proof['actual_body_housing'].startswith('BLOCKED')
    targets={}
    for n in expected:
        v,f=data[n+'__vertices_mm'],data[n+'__triangles'].astype(np.uint64)
        m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError,n
        targets[n]=dict(m=m,lo=v.min(0),hi=v.max(0))
    labels=[('catalogue_capacity',[2.08,1.5,5.7]),('protection_capacity',[2.28,1.7,6.7])]
    assert [(result['capacity'],result['dimensions_mm']) for result in proof['results']]==labels
    intervals=0;interior_checks=0;enclosure_checks=0;point_probes=0
    for result,(label,dims) in zip(proof['results'],labels):
        assert result['status']=='PASS' and result['first_failure'] is None
        assert result['planned_intervals']==result['checked_intervals']==len(p)-1==3045
        assert [row['interval'] for row in result['rows']]==list(range(len(p)-1))
        x,y,z=dims
        local=np.array([[a,b,c] for a in [-x/2,x/2] for b in [-y/2,y/2] for c in [0.,z]])
        radius=math.sqrt((x/2)**2+(y/2)**2+z*z)
        assert abs(result['local_vertex_radius_mm']-radius)<1e-12
        assert abs(result['source_attitude_repair_operator_norm']-repair)<1e-15
        vertices=np.einsum('nij,kj->nki',r,local)+p[:,None,:]
        for i,row in enumerate(result['rows']):
            reserve=radius*theta[i]**2/8+radius*repair+2e-5
            assert abs(reserve-row['enclosure_reserve_mm'])<2e-12
            assert abs(theta[i]-row['rotation_angle_rad'])<1e-6
            cloud=np.vstack([vertices[i],vertices[i+1]])
            lo,hi=cloud.min(0),cloud.max(0)
            near=[n for n,t in targets.items() if np.all(lo<=t['hi']+.6+row['enclosure_reserve_mm'])
                  and np.all(hi+.6+row['enclosure_reserve_mm']>=t['lo'])]
            assert near==row['tested_native_parts']
            assert row['status']=='PASS' and row['interval_gap_lower_bound_mm']>=.3
            if row['nearest'] is not None:
                n=row['nearest']
                assert n['object'] in near
                assert abs(n['raw_hull_gap_mm']-row['enclosure_reserve_mm']-row['interval_gap_lower_bound_mm'])<1e-12
            intervals+=1
        minimum=min(row['interval_gap_lower_bound_mm'] for row in result['rows'])
        assert abs(minimum-result['minimum_certified_native_gap_lower_mm'])<1e-12
        # Reconstruct unrecorded interior poses independently, without the
        # screen or certifier kernels. These are implementation cross-checks,
        # not a replacement for the complete hull/remainder coverage above.
        for i in np.linspace(0,len(p)-2,64,dtype=int):
            tau=np.linspace(0.,1.,17)
            rotations=Slerp([0.,1.],Rotation.from_matrix(r[i:i+2]))(tau).as_matrix()
            actual=np.einsum('nij,kj->nki',rotations,local)+(1-tau)[:,None,None]*p[i]+tau[:,None,None]*p[i+1]
            chord=(1-tau)[:,None,None]*vertices[i]+tau[:,None,None]*vertices[i+1]
            distance=float(np.linalg.norm(actual-chord,axis=-1).max())
            assert distance<=result['rows'][i]['enclosure_reserve_mm']+1e-12
            enclosure_checks+=1;point_probes+=len(tau)*len(local)
            for j in [3,8,13]:
                v=actual[j];lo,hi=v.min(0),v.max(0)
                near=[n for n,t in targets.items() if np.all(lo<=t['hi']+.600001) and np.all(hi+.600001>=t['lo'])]
                box=manifold.Manifold.hull_points(v);assert box.status()==manifold.Error.NoError
                for n in near:
                    volume=abs(float((box^targets[n]['m']).volume()))
                    gap=0. if volume>1e-7 else float(box.min_gap(targets[n]['m'],.600001))
                    assert gap>=.3,(label,i,j,n,gap,volume)
                interior_checks+=1
    assert intervals==6090 and enclosure_checks==128 and interior_checks==384
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    assert all(sha(p)==h for p,h in proof['sources'].items())
    out=dict(status='PASS',scope='Independent source/interval coverage and finite interior-pose implementation checks only',
             sources={**proof['sources'],str(proof_path):sha(proof_path),str(Path(__file__)):sha(Path(__file__))},
             bare_contact_capacity='PASS',closed_intervals=6090,current_native_parts_at_stage=197,
             capacity_variants=2,enclosure_implementation_checks=enclosure_checks,
             interior_native_pose_checks=interior_checks,interpolated_vertex_probes=point_probes,
             actual_crimp_and_protection='BLOCKED',attached_wire_shape='NOT_TESTED',
             peer_CAM_and_other_wire_clearance='NOT_TESTED',actual_wire_bend_limit='BLOCKED',
             full_harness='BLOCKED',protected_hardware_files=846,main_changed=False,
             hardware_changed=False,animation_changed=False,manufacturing_release=False,
             elapsed_s=time.time()-started)
    (HERE/'bare_replay_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CURRENT_BARE_REPLAY_VERIFIED',intervals,interior_checks,len(expected),len(protected),flush=True)


if __name__=='__main__':main()
