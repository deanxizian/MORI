"""Read-only M1.55 native world-mesh receipt for terminal-entry screening."""
from pathlib import Path
import datetime
import json
import sys

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT))
from context import Context, np, sha, PROJECT, ROOT


def main():
    ctx = Context()
    ctx.record([Path(__file__), ROOT / 'animation/manifest.json'])
    arrays = {}
    rows = []
    for name, solid in sorted(ctx.ss.items()):
        arrays[name + '__vertices_mm'] = solid.v.copy()
        arrays[name + '__triangles'] = solid.f.copy()
        rows.append(dict(id=name, group=solid.group, category=solid.o.get('category'),
                         data_status=solid.o.get('data_status'),
                         vertices=len(solid.v), triangles=len(solid.f),
                         matrix_world=np.asarray(solid.o.matrix_world).tolist()))
    target = HERE / 'current_native_parts.npz'
    np.savez_compressed(target, **arrays)
    baseline = json.loads((ROOT / 'input_assets/M1_55_reaction_entry_baseline.json').read_text())
    protected = {p: h for p, h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT / p) == h for p, h in protected.items())
    ctx.unchanged()
    receipt = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   scope='Read-only exact current201 native validation world meshes; no entry qualification',
                   sources=ctx.sources, output_sha256=sha(target), native_parts=rows,
                   native_part_count=len(rows), revision='V1.2-M1.55',
                   protected_hardware_files=846, main_changed=False, animation_changed=False,
                   hardware_changed=False, full_harness='BLOCKED', manufacturing_release=False)
    (HERE / 'current_native_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('CURRENT_TERMINAL_NATIVE_EXPORTED', len(rows), len(protected), flush=True)


if __name__ == '__main__':
    main()
