# Current bare-contact capacity and gentler-path diagnostics

Read-only current201 native validation meshes. Body front/rear and head
front/rear shells are deferred; every other197 native mesh remains. No real
PH housing is represented, and no old clearance PASS is inherited.

Original single-contact capacity path:3046 poses, two boxes, each3045 closed
linear/SO(3) intervals PASS against current197 solids. R*theta^2/8 rotation
interpolation remainder, source-frame repair and numeric reserves enclose
each complete interval. Original0.3mm requirement remains. Independent
coverage/source audit:6090 intervals;128 enclosure implementation checks,
384 interior native poses and17408 interpolated vertex probes PASS.

Boxes2.08x1.5x5.7 and2.28x1.7x6.7 are family/protection capacities,
not selected crimp/protector dimensions. Source poses are zero-assembly
reference poses, not full operational yaw/pitch, full wired assembly or grip.

Gentler-path searches:8 transport/36 radial/54 retained-attitude candidates
FAIL or stop at trajectory-radius prefilter. They do not prove impossibility
and do not condemn the main model. Contact trajectory radius is not attached
wire bend radius. Actual wire/crimp/protection, four-contact sequential feed,
peer wires, strain relief and wired closure remain BLOCKED / NOT_TESTED.

Daburn technical inquiry is DRAFT / NOT_SENT and awaits explicit user
authorization. Speaker connector parameters await user after reaching office;
the measured150mm lead is unchanged. No main, animation, hardware or material
selection change; manufacturing_release=false.
