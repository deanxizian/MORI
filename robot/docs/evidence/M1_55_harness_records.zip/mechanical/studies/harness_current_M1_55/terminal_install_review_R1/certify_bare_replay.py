"""Current-native continuous bare-contact capacity replay, not wire approval.

Each original pair defines a linear rear translation and shortest SO(3)
interpolation. The hull of both endpoint boxes, expanded by the R*theta^2/8
interpolation remainder and frame-repair/numeric reserves, encloses the interval.
All current197 stage obstacles remain; no old clearance PASS is inherited.
"""
from pathlib import Path
import json
import math
import time
import numpy as np
from screen_entry import HERE, sha, read, GAP, DEFERRED, manifold
from scipy.spatial.transform import Rotation


def main():
    started=time.time()
    receipt=read(HERE/'current_native_receipt.json')
    replay=read(HERE/'retained_attitude_entry_screen.json')
    assert receipt['status']=='PASS' and receipt['native_part_count']==201
    assert all(r['status']=='PASS' for r in replay['historical_pose_replay'])
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    assert sha(HERE/'current_native_parts.npz')==receipt['output_sha256']
    old=HERE.parent.parent/'harness_current_M1_54/cam_terminal_feed'
    lower_path,upper_path=old/'connected_neck_joined/path.npz',old/'connected_smooth_dense/path.npz'
    lower,upper=np.load(lower_path),np.load(upper_path)
    points=np.vstack([upper['rear_mm'],lower['rear_mm'][1:]])
    raw=np.concatenate([upper['rotations'],lower['rotations'][1:]])
    u,_,vt=np.linalg.svd(raw);proper=u@vt
    assert np.min(np.linalg.det(proper))>.999999999
    repair=float(np.linalg.norm(proper-raw,ord=2,axis=(1,2)).max())
    assert repair<1e-6
    q=Rotation.from_matrix(proper).as_quat()
    dots=np.clip(np.abs(np.einsum('ij,ij->i',q[:-1],q[1:])),0.,1.)
    angles=2*np.arccos(dots)
    data=np.load(HERE/'current_native_parts.npz')
    names={r['id'] for r in receipt['native_parts']}
    selected=sorted(names-set(DEFERRED));assert len(selected)==197
    targets={}
    for n in selected:
        v,f=data[n+'__vertices_mm'],data[n+'__triangles'].astype(np.uint64)
        m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError
        targets[n]=dict(m=m,lo=v.min(0),hi=v.max(0))
    paths=[Path(__file__),HERE/'screen_entry.py',HERE/'current_native_receipt.json',HERE/'current_native_parts.npz',
           HERE/'retained_attitude_entry_screen.json',lower_path,upper_path]
    sources={**receipt['sources'],**{str(p):sha(p) for p in paths}}
    results=[]
    for label,dims in [('catalogue_capacity',[2.08,1.5,5.7]),('protection_capacity',[2.28,1.7,6.7])]:
        x,y,z=dims
        local=np.array([[a,b,c] for a in [-x/2,x/2] for b in [-y/2,y/2] for c in [0.,z]])
        radius=float(np.linalg.norm(local,axis=1).max())
        # A local vertex has ||d2v/dt2|| <= R*theta^2 for constant-speed SO(3)
        # rotation. Linear interpolation error is <= max||d2v/dt2||/8.
        # Rear translation is exactly linear and contributes no remainder.
        reserves=radius*angles**2/8+radius*repair+2e-5
        vertices=np.einsum('nij,kj->nki',proper,local)+points[:,None,:]
        rows=[];failed=None
        for i,error in enumerate(reserves):
            cloud=np.vstack([vertices[i],vertices[i+1]])
            lo,hi=cloud.min(0),cloud.max(0)
            near=[n for n,t in targets.items() if np.all(lo<=t['hi']+.6+error)
                  and np.all(hi+.6+error>=t['lo'])]
            minimum=.6;witness=None
            hull=None
            if near:
                hull=manifold.Manifold.hull_points(cloud)
                assert hull.status()==manifold.Error.NoError
            for n in near:
                overlap=abs(float((hull^targets[n]['m']).volume()))
                rawgap=0. if overlap>1e-7 else float(hull.min_gap(targets[n]['m'],.6+error))
                lowergap=rawgap-error
                if lowergap<minimum:
                    minimum=lowergap
                    witness=dict(object=n,convex_hull_overlap_mm3=overlap,
                                 raw_hull_gap_mm=rawgap,interval_gap_lower_bound_mm=lowergap)
                if lowergap<GAP:
                    failed=dict(interval=i,witness=witness);break
            rows.append(dict(interval=i,rotation_angle_rad=float(angles[i]),
                             enclosure_reserve_mm=float(error),tested_native_parts=near,
                             interval_gap_lower_bound_mm=minimum,nearest=witness,
                             status='FAIL' if failed else 'PASS'))
            if failed:break
            if i%500==0:print('BARE_REPLAY_INTERVAL',label,i,len(reserves),flush=True)
        result=dict(capacity=label,dimensions_mm=dims,status='FAIL' if failed else 'PASS',
                    planned_intervals=len(reserves),checked_intervals=len(rows),rows=rows,
                    local_vertex_radius_mm=radius,source_attitude_repair_operator_norm=repair,
                    minimum_certified_native_gap_lower_mm=min(r['interval_gap_lower_bound_mm'] for r in rows),
                    maximum_enclosure_reserve_mm=float(reserves.max()),first_failure=failed)
        results.append(result)
    assert all(sha(p)==h for p,h in sources.items())
    out=dict(status='PASS' if all(r['status']=='PASS' for r in results) else 'FAIL',
             scope='Continuous bare-contact capacity only against current197 native stage meshes',
             sources=sources,results=results,native_parts=selected,native_part_count=197,
             not_installed=DEFERRED,required_gap_mm=GAP,source_poses=len(points),
             interval_motion='Linear rear translation plus shortest proper SO(3) interpolation between original saved poses',
             enclosure_method='R*theta^2/8 second-derivative interpolation remainder plus frame repair and numeric reserve',
             geometry_inherited_PASS=False,actual_crimp_and_protection='BLOCKED',
             actual_body_housing='BLOCKED: absent from current native meshes',
             attached_wire_shape='NOT_TESTED',peer_CAM_and_other_wire_clearance='NOT_TESTED',
             actual_wire_bend_limit='BLOCKED',full_harness='BLOCKED',
             main_changed=False,hardware_changed=False,animation_changed=False,
             manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'bare_replay_continuous.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CURRENT_BARE_REPLAY_CONTINUOUS_DONE',out['status'],len(points)-1,len(selected),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
