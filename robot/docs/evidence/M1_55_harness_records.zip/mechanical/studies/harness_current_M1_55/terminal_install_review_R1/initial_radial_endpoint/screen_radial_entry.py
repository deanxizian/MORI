"""Finite bare-contact screen with the narrow side radial in the neck.

Retain the failed parallel-transport candidates separately. Stage, all native
meshes, unchanged trajectory endpoints and capacity boxes remain explicit.
This never certifies the attached wire or an actual crimp/protector.
"""
from pathlib import Path
import json
import time
import numpy as np
from screen_entry import (HERE, PROJECT, sha, read, unit, frames, native_probe,
                          GAP, DEFERRED, manifold, CubicSpline)


def radial_frames(p, d, start, finish, s):
    base = frames(d, start, finish, s)
    forward = unit(d)
    radial = p.copy()
    radial[:, 2] = 0.
    radial = unit(radial)
    desired = unit(np.cross(radial, forward))
    angle = np.unwrap(np.arctan2(np.einsum('ij,ij->i', np.cross(base[:, :, 0], desired), forward),
                                np.einsum('ij,ij->i', base[:, :, 0], desired)))
    q = np.clip((235. - p[:, 2]) / 23., 0., 1.)
    weight = 6*q**5 - 15*q**4 + 10*q**3
    angle *= weight
    u = np.cos(angle)[:, None] * base[:, :, 0] + np.sin(angle)[:, None] * np.cross(forward, base[:, :, 0])
    r = np.stack([u, np.cross(forward, u), forward], axis=-1)
    assert np.max(np.abs(r[0]-start)) < 1e-8
    assert np.max(np.abs(r[-1]-finish)) < 1e-8
    assert np.max(np.abs(np.einsum('nij,nik->njk', r, r)-np.eye(3))) < 1e-8
    return r


def main():
    started = time.time()
    receipt = read(HERE / 'current_native_receipt.json')
    assert receipt['status'] == 'PASS' and receipt['native_part_count'] == 201
    assert all(sha(p) == h for p, h in receipt['sources'].items())
    assert sha(HERE / 'current_native_parts.npz') == receipt['output_sha256']
    previous = HERE.parent.parent / 'harness_current_M1_54/cam_terminal_feed'
    lower_path, upper_path = previous / 'connected_neck_joined/path.npz', previous / 'connected_smooth_dense/path.npz'
    lower, upper = np.load(lower_path), np.load(upper_path)
    points = np.vstack([upper['rear_mm'], lower['rear_mm'][1:]])
    s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    start, finish = upper['rotations'][0], lower['rotations'][-1]
    data = np.load(HERE / 'current_native_parts.npz')
    names = {r['id'] for r in receipt['native_parts']}
    assert set(DEFERRED) <= names and 'Plug_motion_J5' not in names
    selected = sorted(names-set(DEFERRED))
    assert len(selected) == 197
    targets = {}
    for n in selected:
        v, f = data[n+'__vertices_mm'], data[n+'__triangles'].astype(np.uint64)
        m = manifold.Manifold(manifold.Mesh64(v, f))
        assert m.status() == manifold.Error.NoError, n
        targets[n] = dict(m=m, lo=v.min(0), hi=v.max(0))
    paths = [Path(__file__), HERE/'screen_entry.py', HERE/'current_native_receipt.json',
             HERE/'current_native_parts.npz', HERE/'entry_screen.json', lower_path, upper_path,
             HERE.parent/'material_terminal_review_R1/preflight.json']
    sources = {**receipt['sources'], **{str(p):sha(p) for p in paths}}
    required = read(paths[-1])['constraints']['current_body_required_centreline_radius_mm']
    boxes = [('catalogue_capacity',[2.08,1.5,5.7]),('protection_capacity',[2.28,1.7,6.7])]
    rows = []
    accepted = None
    for spacing in [20.,18.,22.]:
        knots = np.r_[np.arange(0.,s[-1],spacing),s[-1]]
        initial = np.stack([np.interp(knots,s,points[:,axis]) for axis in range(3)],axis=1)
        def smooth(x):
            x=np.clip(x,0.,1.)
            return 6*x**5-15*x**4+10*x**3
        window=smooth((225.-initial[:,2])/15.)*smooth((initial[:,2]-175.)/15.)
        for dx in [0.,.5,1.,1.5]:
            for dy in [0.,.4,-.4]:
                values=initial.copy()
                values[:,0]+=dx*window
                values[:,1]+=dy*window
                curve=CubicSpline(knots,values,axis=0,bc_type=((1,start[:,2]),(1,finish[:,2])))
                fine=np.linspace(0.,s[-1],3001)
                d,d2=curve(fine,1),curve(fine,2)
                speed=np.linalg.norm(d,axis=1)
                curvature=np.linalg.norm(np.cross(d,d2),axis=1)/speed**3
                radius=float(1./max(curvature))
                row=dict(knot_spacing_mm=spacing,neck_offset_X_mm=dx,neck_offset_Y_mm=dy,
                         minimum_sampled_path_radius_mm=radius,radius_target_mm=required,
                         minimum_sampled_speed=float(speed.min()),
                         radius_sample_status='PASS' if radius>=required else 'FAIL')
                rows.append(row)
                if radius<required:
                    row['status']='FAIL';row['native_sample_status']='NOT_TESTED'
                    continue
                sample=np.linspace(0.,s[-1],151)
                p=curve(sample)
                r=radial_frames(p,curve(sample,1),start,finish,sample)
                tests=[dict(capacity=n,dimensions_mm=dims,**native_probe(p,r,dims,targets)) for n,dims in boxes]
                row['coarse_native']=tests
                row['status']='PASS' if all(t['status']=='PASS' for t in tests) else 'FAIL'
                print('RADIAL_ENTRY',spacing,dx,dy,radius,row['status'],[t.get('first_failure') for t in tests if t['status']!='PASS'][:1],flush=True)
                if row['status']!='PASS':
                    continue
                sample=np.linspace(0.,s[-1],1501)
                p=curve(sample)
                r=radial_frames(p,curve(sample,1),start,finish,sample)
                tests=[dict(capacity=n,dimensions_mm=dims,**native_probe(p,r,dims,targets)) for n,dims in boxes]
                row['refined_native']=tests
                row['status']='PASS' if all(t['status']=='PASS' for t in tests) else 'FAIL'
                if row['status']=='PASS':
                    accepted=row
                    np.savez_compressed(HERE/'radial_candidate_path.npz',rear_mm=p,rotations=r,
                                        knots=knots,cubic_coefficients=curve.c,parameter=sample,
                                        original_endpoints=points[[0,-1]],initial_attitude=start,final_attitude=finish)
                    break
            if accepted:break
        if accepted:break
    assert all(sha(p)==h for p,h in sources.items())
    result=dict(status='PASS' if accepted else 'FAIL',sources=sources,
                scope='Finite bare-contact capacity screen against current197 native solids only',
                rows=rows,accepted=accepted,native_part_count=197,native_parts=selected,not_installed=DEFERRED,
                required_gap_mm=GAP,orientation='Parallel-transport base; smooth neck radial narrow-side orientation',
                original_endpoints_mm=points[[0,-1]].tolist(),actual_body_housing='BLOCKED: absent from current native meshes',
                actual_crimp_and_protection='BLOCKED',attached_wire_shape='NOT_TESTED',
                peer_CAM_and_other_wire_clearance='NOT_TESTED',continuous_motion='NOT_TESTED',
                actual_wire_bend_limit='BLOCKED',full_harness='BLOCKED',main_changed=False,
                hardware_changed=False,animation_changed=False,manufacturing_release=False,
                elapsed_s=time.time()-started)
    (HERE/'radial_entry_screen.json').write_text(json.dumps(result,indent=2)+'\n')
    print('RADIAL_ENTRY_SCREEN_DONE',result['status'],len(rows),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
