"""Publish the current bare-contact capacity scope and retained failed searches."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote, unquote, urlsplit
import datetime
import hashlib
import json
import subprocess
import sys
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
NUMERIC='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):
        super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        self.links.extend(v for k,v in attrs if k in ['href','src'])


def main():
    audit=read(HERE/'bare_replay_verification.json')
    proof=read(HERE/'bare_replay_continuous.json')
    assert audit['status']==proof['status']=='PASS' and audit['closed_intervals']==6090
    assert audit['current_native_parts_at_stage']==197 and audit['interior_native_pose_checks']==384
    assert audit['full_harness']=='BLOCKED' and not audit['manufacturing_release']
    sources=dict(audit['sources'])
    sources[str(HERE/'bare_replay_verification.json')]=sha(HERE/'bare_replay_verification.json')
    sources[str(Path(__file__))]=sha(Path(__file__))
    inquiries=PROJECT/'mechanical/procurement/Daburn_2420_28_技术资料询问_DRAFT.md'
    sources[str(inquiries)]=sha(inquiries)
    searches=[]
    for filename,key,count in [('entry_screen.json','candidates',8),('radial_entry_screen.json','rows',36),
                               ('retained_attitude_entry_screen.json','rows',54)]:
        p=HERE/filename;d=read(p)
        assert d['status']=='FAIL' and len(d[key])==count and not d['main_changed']
        assert all(sha(p)==h for p,h in d['sources'].items())
        sources[str(p)]=sha(p)
        searches.append(dict(file=filename,candidates=count,status='FAIL'))
    assert all(sha(p)==h for p,h in sources.items())
    versions=json.loads(subprocess.check_output([NUMERIC,'-c',
        "import sys,json,importlib.metadata;sys.path[:0]=['"+str(PROJECT/'mechanical/scripts/vendor')+"','/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313'];import numpy,scipy;print(json.dumps(dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,manifold3d=importlib.metadata.version('manifold3d'))))"],text=True))
    commands=dict(status='PASS',versions=versions,commands=[
        dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','mechanical/mori_v1_2.blend','--python',str(HERE/'export_current.py')],log='export_current.log',exit_code=0),
        *[dict(command=[NUMERIC,str(HERE/script)],log=log,exit_code=0) for script,log in [
            ('screen_entry.py','screen_entry.log'),('screen_radial_entry.py','screen_radial_entry.log'),
            ('screen_retained_attitude.py','screen_retained_attitude.log'),
            ('certify_bare_replay.py','certify_bare_replay.log'),('verify_bare_replay.py','verify_bare_replay.log')]]],
        note='Search scripts executed successfully and retain failed geometry candidates; no failing candidate adopted',
        initial_diagnostics=['initial_fixture_membership/diagnostic.json','initial_radial_endpoint/diagnostic.json',
                             'initial_sagitta_bound/diagnostic.json'],
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    table=''.join(f"<tr><td>{r['capacity']}</td><td>{r['checked_intervals']:,}</td><td>{r['minimum_certified_native_gap_lower_mm']:.6f} mm</td><td>PASS</td></tr>" for r in proof['results'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 裸端子容量装入与改缓路径诊断</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:32px auto;padding:0 22px;color:#27343b}}table{{width:100%;border-collapse:collapse;margin:20px 0}}td,th{{padding:10px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}</style>
<h1>裸端子容量轨迹：当前模型检查与改缓诊断</h1>
<p class="scope">PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED。单枚未入壳端子的容量检查；没有选定真实压接端子或保护件。完整线束与带线装配 BLOCKED，主模型／动画保持。</p>
<p>只读重新取得M1.55的201件原生实体，保留200件原实体与R2头托修改。装入阶段暂不安装身体前后壳及头前后壳，其余197件原生实体均保留。没有借用旧模型的间隙PASS。当前原生模型没有Plug_motion_J5塑壳，实际入壳／插合仍须单独处理。</p>
<p>旧单端子轨迹的3,046个原位置与朝向先在当前197件实体上回读通过，再对完整3,045个闭运动区间独立检查，两种容量包络共6,090个区间。</p>
<table><thead><tr><th>包络（非实际压接尺寸）</th><th>闭区间</th><th>当前实体最小下界</th><th>范围内状态</th></tr></thead><tbody>{table}</tbody></table>
<p>目录家族参考为2.08×1.5×5.7mm；保护容量包络为2.28×1.7×6.7mm。它们不证明所选PH002、压接后线桶或真实保护件的完整尺寸。接触后端按直线移入、朝向按最短SO(3)插值；端点凸包加Rθ²/8二阶插值余量、原朝向归一化余量与数值预留包住整段运动。原0.3mm目标保持。</p>
<p>独立审计重建197件阶段集合、全部闭区间与实体候选集合；另有128个包络实现核对、384个未记录的区间内部姿态实体重查及17,408个插值顶点探针。这是模型／算法检查，不是物理插拔或压接验证。</p>
<h2>改缓路径搜索：未采用</h2>
<p>8个平滑路径、36个颈部径向朝向候选及54个保留原朝向的候选均未得到范围内通过；部分在路径曲率预筛阶段已停止，没有执行其余实体检查。可见失败涉及头托、Yaw舵机或反力轴。有限搜索不证明没有其他可行路径；原单端子包络轨迹在当前模型中通过，不能把这些候选失败解释为主模型故障。</p>
<p>接触后端的运动轨迹曲率也不是附着导线的实际弯折半径。后续仍须构造保长导线形状、确认实际材料与端子保护外形，再检查四根线逐根送入、已穿线路让位、其他八条参考、夹持及完整装入／闭壳。当前旧临时整理的小半径不获得线材资格。</p>
<h2>仍缺的数据与交接</h2>
<p>实际线径公差、安装／动态弯折数据和压接外形仍未闭合。已备好<a href="../../../procurement/Daburn_2420_28_技术资料询问_DRAFT.md">Daburn资料询问稿</a>，向外部厂家发信待用户明确授权；没有选料或采购。喇叭插头参数仍待用户到公司后补充；已确认150mm线长保持。</p>
<p>主模型、视频和846个受保护硬件文件保持；manufacturing_release=false。初次阶段集合断言和径向终点朝向断言的错误已保留，并在几何检查前修正；先前包络方法的记录亦保留，当前使用明确的Rθ²/8插值余量。</p>
<p><a href="bare_replay_continuous.json">当前完整裸端子容量区间</a> · <a href="bare_replay_verification.json">独立覆盖与实现检查</a> · <a href="retained_attitude_entry_screen.json">原姿态回读及搜索</a> · <a href="entry_screen.json">平滑搜索</a> · <a href="radial_entry_screen.json">径向朝向搜索</a> · <a href="current_native_receipt.json">当前实体来源</a> · <a href="commands.json">实际命令与版本</a> · <a href="../material_terminal_review_R1/index.html">端接与线材预筛</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# Current bare-contact capacity and gentler-path diagnostics

Read-only current201 native validation meshes. Body front/rear and head
front/rear shells are deferred; every other197 native mesh remains. No real
PH housing is represented, and no old clearance PASS is inherited.

Original single-contact capacity path:3046 poses, two boxes, each3045 closed
linear/SO(3) intervals PASS against current197 solids. R*theta^2/8 rotation
interpolation remainder, source-frame repair and numeric reserves enclose
each complete interval. Original0.3mm requirement remains. Independent
coverage/source audit:6090 intervals;128 enclosure implementation checks,
384 interior native poses and17408 interpolated vertex probes PASS.

Boxes2.08x1.5x5.7 and2.28x1.7x6.7 are family/protection capacities,
not selected crimp/protector dimensions. Source poses are zero-assembly
reference poses, not full operational yaw/pitch, full wired assembly or grip.

Gentler-path searches:8 transport/36 radial/54 retained-attitude candidates
FAIL or stop at trajectory-radius prefilter. They do not prove impossibility
and do not condemn the main model. Contact trajectory radius is not attached
wire bend radius. Actual wire/crimp/protection, four-contact sequential feed,
peer wires, strain relief and wired closure remain BLOCKED / NOT_TESTED.

Daburn technical inquiry is DRAFT / NOT_SENT and awaits explicit user
authorization. Speaker connector parameters await user after reaching office;
the measured150mm lead is unchanged. No main, animation, hardware or material
selection change; manufacturing_release=false.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
           and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_review.log']}
    out=dict(status='PASS',scope='Current bare-contact capacity publication only; gentler candidates unadopted',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
             bare_contact_continuous_native_clearance='PASS',closed_intervals=6090,current_native_parts_at_stage=197,
             source_poses=3046,capacity_variants=2,enclosure_implementation_checks=128,interior_native_pose_checks=384,
             gentler_candidates=98,gentler_candidates_adopted=False,actual_crimp_and_protection='BLOCKED',
             attached_wire_shape='NOT_TESTED',actual_wire_bend_limit='BLOCKED',full_harness='BLOCKED',
             technical_inquiry='NOT_SENT: explicit user authorization pending',protected_hardware_files=846,
             main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items())
    assert all(sha(HERE/p)==h for p,h in files.items())
    parser=Links();parser.feed((HERE/'index.html').read_text())
    targets=[HERE/'index.html']
    for link in parser.links:
        url=urlsplit(link)
        if not url.scheme and url.path:targets.append((HERE/unquote(url.path)).resolve())
    served=[]
    for p in dict.fromkeys(targets):
        relative=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(relative),timeout=10) as response:
            assert response.status==200 and response.read()==p.read_bytes(),relative
        served.append(dict(path=relative,sha256=sha(p)))
    result=dict(status='PASS',scope='Current source/files and served-byte verification only',
                delivery_sha256=sha(HERE/'delivery.json'),verified_sources=len(sources),verified_files=len(files),
                served_links=len(served),served=served,full_harness='BLOCKED',main_changed=False,
                hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('CURRENT_BARE_REPLAY_PUBLICATION_VERIFIED',len(files),len(served),6090,flush=True)


if __name__=='__main__':main()
