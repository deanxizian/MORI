"""Separate contact attitude from a gentler centre-trajectory candidate.

Replay the exact old capacity poses first against current native meshes. Then
retain their SO(3) attitude field while changing only unadopted centre motion.
Attached-wire tangency, bend limits and deformation remain untested.
"""
from pathlib import Path
import json
import time
import numpy as np
from screen_entry import (HERE, sha, read, native_probe, GAP, DEFERRED,
                          manifold, CubicSpline)
from scipy.spatial.transform import Rotation, Slerp


def main():
    started=time.time()
    receipt=read(HERE/'current_native_receipt.json')
    assert receipt['status']=='PASS' and receipt['native_part_count']==201
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    assert sha(HERE/'current_native_parts.npz')==receipt['output_sha256']
    old=HERE.parent.parent/'harness_current_M1_54/cam_terminal_feed'
    lower_path,upper_path=old/'connected_neck_joined/path.npz',old/'connected_smooth_dense/path.npz'
    lower,upper=np.load(lower_path),np.load(upper_path)
    points=np.vstack([upper['rear_mm'],lower['rear_mm'][1:]])
    rotations=np.concatenate([upper['rotations'],lower['rotations'][1:]])
    s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    assert np.min(np.diff(s))>0
    u,_,vt=np.linalg.svd(rotations)
    proper=u@vt
    assert np.max(np.abs(proper-rotations))<1e-6
    attitude=Slerp(s,Rotation.from_matrix(proper))
    data=np.load(HERE/'current_native_parts.npz')
    names={r['id'] for r in receipt['native_parts']}
    assert set(DEFERRED)<=names and 'Plug_motion_J5' not in names
    selected=sorted(names-set(DEFERRED));assert len(selected)==197
    targets={}
    for n in selected:
        v,f=data[n+'__vertices_mm'],data[n+'__triangles'].astype(np.uint64)
        m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError
        targets[n]=dict(m=m,lo=v.min(0),hi=v.max(0))
    paths=[Path(__file__),HERE/'screen_entry.py',HERE/'current_native_receipt.json',HERE/'current_native_parts.npz',
           lower_path,upper_path,HERE/'entry_screen.json',HERE/'radial_entry_screen.json',
           HERE.parent/'material_terminal_review_R1/preflight.json']
    sources={**receipt['sources'],**{str(p):sha(p) for p in paths}}
    boxes=[('catalogue_capacity',[2.08,1.5,5.7]),('protection_capacity',[2.28,1.7,6.7])]
    replay=[dict(capacity=n,dimensions_mm=dims,**native_probe(points,proper,dims,targets)) for n,dims in boxes]
    print('EXACT_OLD_POSE_CURRENT_NATIVE_REPLAY',[r['status'] for r in replay],
          [r.get('first_failure') for r in replay if r['status']!='PASS'],flush=True)
    required=read(paths[-1])['constraints']['current_body_required_centreline_radius_mm']
    rows=[];accepted=None
    for spacing in [20.,18.,22.]:
        knots=np.r_[np.arange(0.,s[-1],spacing),s[-1]]
        initial=np.stack([np.interp(knots,s,points[:,axis]) for axis in range(3)],axis=1)
        def smooth(q):
            q=np.clip(q,0.,1.);return 6*q**5-15*q**4+10*q**3
        window=smooth((225.-initial[:,2])/15.)*smooth((initial[:,2]-175.)/15.)
        for dx in [0.,.5,1.,1.5,-.5,-1.]:
            for dy in [0.,.4,-.4]:
                values=initial.copy();values[:,0]+=dx*window;values[:,1]+=dy*window
                curve=CubicSpline(knots,values,axis=0,
                                  bc_type=((1,proper[0,:,2]),(1,proper[-1,:,2])))
                fine=np.linspace(0.,s[-1],3001)
                d,d2=curve(fine,1),curve(fine,2);speed=np.linalg.norm(d,axis=1)
                curvature=np.linalg.norm(np.cross(d,d2),axis=1)/speed**3
                radius=float(1./max(curvature))
                row=dict(knot_spacing_mm=spacing,neck_offset_X_mm=dx,neck_offset_Y_mm=dy,
                         minimum_sampled_centre_trajectory_radius_mm=radius,
                         radius_target_mm=required,minimum_sampled_speed=float(speed.min()),
                         radius_sample_status='PASS' if radius>=required else 'FAIL')
                rows.append(row)
                if radius<required:
                    row['status']='FAIL';row['native_sample_status']='NOT_TESTED';continue
                sample=np.linspace(0.,s[-1],151);p=curve(sample);r=attitude(sample).as_matrix()
                tests=[dict(capacity=n,dimensions_mm=dims,**native_probe(p,r,dims,targets)) for n,dims in boxes]
                row['coarse_native']=tests;row['status']='PASS' if all(t['status']=='PASS' for t in tests) else 'FAIL'
                print('RETAINED_ATTITUDE_ENTRY',spacing,dx,dy,radius,row['status'],
                      [t.get('first_failure') for t in tests if t['status']!='PASS'][:1],flush=True)
                if row['status']!='PASS':continue
                sample=np.linspace(0.,s[-1],1501);p=curve(sample);r=attitude(sample).as_matrix()
                tests=[dict(capacity=n,dimensions_mm=dims,**native_probe(p,r,dims,targets)) for n,dims in boxes]
                row['refined_native']=tests;row['status']='PASS' if all(t['status']=='PASS' for t in tests) else 'FAIL'
                if row['status']=='PASS':
                    accepted=row
                    np.savez_compressed(HERE/'retained_attitude_candidate_path.npz',rear_mm=p,rotations=r,
                                        knots=knots,cubic_coefficients=curve.c,parameter=sample,
                                        original_endpoints=points[[0,-1]],initial_attitude=proper[0],final_attitude=proper[-1])
                    break
            if accepted:break
        if accepted:break
    assert all(sha(p)==h for p,h in sources.items())
    result=dict(status='PASS' if accepted else 'FAIL',sources=sources,rows=rows,accepted=accepted,
                scope='Finite current197 native-solid bare-contact capacity only; preserved old attitude field',
                historical_pose_replay=replay,native_parts=selected,native_part_count=197,not_installed=DEFERRED,
                required_gap_mm=GAP,actual_body_housing='BLOCKED: absent from native meshes',
                actual_crimp_and_protection='BLOCKED',attached_wire_shape='NOT_TESTED',
                peer_CAM_and_other_wire_clearance='NOT_TESTED',continuous_motion='NOT_TESTED',
                actual_wire_bend_limit='BLOCKED',full_harness='BLOCKED',main_changed=False,
                hardware_changed=False,animation_changed=False,manufacturing_release=False,
                elapsed_s=time.time()-started)
    (HERE/'retained_attitude_entry_screen.json').write_text(json.dumps(result,indent=2)+'\n')
    print('RETAINED_ATTITUDE_ENTRY_DONE',result['status'],len(rows),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
