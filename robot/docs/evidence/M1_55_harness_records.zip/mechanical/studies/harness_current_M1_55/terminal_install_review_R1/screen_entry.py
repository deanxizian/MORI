"""Finite current-solid screens for a gentler bare-contact entry candidate.

The contact trajectory is not an attached-wire deformation or a bend-life
qualification. Catalog/protection boxes are capacity probes only. No main or
electrical geometry is changed, and no historical clearance PASS is inherited.
"""
from pathlib import Path
import hashlib
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
sys.path[:0] = [str(PROJECT / 'mechanical/scripts/vendor'),
               '/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313']
import manifold3d as manifold
from scipy.interpolate import CubicSpline

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
GAP = .3
DEFERRED = ['Body_Front', 'Body_Rear', 'Head_Front', 'Head_Rear']


def unit(v):
    return v / np.linalg.norm(v, axis=-1, keepdims=True)


def frames(tangents, start, finish, station):
    """Parallel transport with a smooth roll to the unchanged final attitude."""
    w = unit(tangents)
    u = np.empty_like(w)
    u[0] = unit(start[:, 0] - w[0] * np.dot(start[:, 0], w[0]))
    for i in range(1, len(w)):
        axis = np.cross(w[i-1], w[i])
        sn = np.linalg.norm(axis)
        co = np.clip(np.dot(w[i-1], w[i]), -1., 1.)
        assert co > -.9
        u[i] = u[i-1]
        if sn > 1e-14:
            axis /= sn
            u[i] = (co * u[i-1] + sn * np.cross(axis, u[i-1])
                    + (1-co) * axis * np.dot(axis, u[i-1]))
        u[i] = unit(u[i] - w[i] * np.dot(u[i], w[i]))
    desired = unit(finish[:, 0] - w[-1] * np.dot(finish[:, 0], w[-1]))
    angle = np.arctan2(np.dot(np.cross(u[-1], desired), w[-1]), np.dot(u[-1], desired))
    t = (station - station[0]) / (station[-1] - station[0])
    a = angle * (6*t**5 - 15*t**4 + 10*t**3)
    u = np.cos(a)[:, None] * u + np.sin(a)[:, None] * np.cross(w, u)
    r = np.stack([u, np.cross(w, u), w], axis=-1)
    assert np.max(np.abs(r[0] - start)) < 1e-8
    assert np.max(np.abs(r[-1] - finish)) < 1e-8
    return r


def native_probe(points, rotations, dims, targets):
    x, y, z = dims
    local = np.array([[a, b, c] for a in [-x/2, x/2] for b in [-y/2, y/2] for c in [0., z]])
    checks = 0
    minimum = .6
    witness = None
    for i, (p, r) in enumerate(zip(points, rotations)):
        vertices = local @ r.T + p
        lo, hi = vertices.min(0), vertices.max(0)
        near = [n for n, t in targets.items() if np.all(lo <= t['hi'] + .600001)
                and np.all(hi + .600001 >= t['lo'])]
        if not near:
            continue
        box = manifold.Manifold.hull_points(vertices)
        assert box.status() == manifold.Error.NoError
        for n in near:
            overlap = float((box ^ targets[n]['m']).volume())
            gap = 0. if overlap > 1e-7 else float(box.min_gap(targets[n]['m'], .600001))
            checks += 1
            if gap < minimum:
                minimum = gap
                witness = dict(sample=i, object=n, rear_mm=p.tolist(), gap_mm=gap,
                               overlap_mm3=overlap)
            if gap < GAP:
                return dict(status='FAIL', planned_poses=len(points), checked_poses=i+1,
                            native_pair_checks=checks, minimum_sampled_gap_mm=minimum,
                            first_failure=witness)
    return dict(status='PASS', planned_poses=len(points), checked_poses=len(points),
                native_pair_checks=checks, minimum_sampled_gap_mm=minimum,
                nearest_sample=witness, first_failure=None)


def main():
    started = time.time()
    receipt_path = HERE / 'current_native_receipt.json'
    receipt = read(receipt_path)
    assert receipt['status'] == 'PASS' and receipt['native_part_count'] == 201
    assert all(sha(p) == h for p, h in receipt['sources'].items())
    assert sha(HERE / 'current_native_parts.npz') == receipt['output_sha256']
    previous = HERE.parent.parent / 'harness_current_M1_54/cam_terminal_feed'
    lower_path = previous / 'connected_neck_joined/path.npz'
    upper_path = previous / 'connected_smooth_dense/path.npz'
    lower, upper = np.load(lower_path), np.load(upper_path)
    assert np.linalg.norm(upper['rear_mm'][-1] - lower['rear_mm'][0]) < 1e-8
    points = np.vstack([upper['rear_mm'], lower['rear_mm'][1:]])
    stations = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    start, finish = upper['rotations'][0], lower['rotations'][-1]
    data = np.load(HERE / 'current_native_parts.npz')
    names = {r['id'] for r in receipt['native_parts']}
    assert set(DEFERRED) <= names
    assert 'Plug_motion_J5' not in names
    selected = sorted(names - set(DEFERRED))
    assert len(selected) == 197
    targets = {}
    for n in selected:
        v = data[n + '__vertices_mm']
        f = data[n + '__triangles'].astype(np.uint64)
        m = manifold.Manifold(manifold.Mesh64(v, f))
        assert m.status() == manifold.Error.NoError, n
        targets[n] = dict(m=m, lo=v.min(0), hi=v.max(0))
    source_paths = [Path(__file__), receipt_path, HERE / 'current_native_parts.npz',
                    lower_path, upper_path, previous / 'connected_neck_joined/review.json',
                    previous / 'connected_smooth_dense/review.json',
                    HERE.parent / 'material_terminal_review_R1/preflight.json']
    sources = {**receipt['sources'], **{str(p): sha(p) for p in source_paths}}
    requirement = read(source_paths[-1])['constraints']['current_body_required_centreline_radius_mm']
    boxes = [('catalogue_capacity', [2.08, 1.5, 5.7]), ('protection_capacity', [2.28, 1.7, 6.7])]
    candidates = []
    accepted = None
    for spacing in [4., 6., 8., 10., 12., 16., 20., 25.]:
        knots = np.r_[np.arange(0., stations[-1], spacing), stations[-1]]
        values = np.stack([np.interp(knots, stations, points[:, axis]) for axis in range(3)], axis=1)
        curve = CubicSpline(knots, values, axis=0,
                            bc_type=((1, start[:, 2]), (1, finish[:, 2])))
        fine = np.linspace(0., stations[-1], 3001)
        d, d2 = curve(fine, 1), curve(fine, 2)
        speed = np.linalg.norm(d, axis=1)
        curvature = np.linalg.norm(np.cross(d, d2), axis=1) / speed**3
        radius = float(1. / max(curvature))
        metrics = dict(knot_spacing_mm=spacing, minimum_sampled_path_radius_mm=radius,
                       minimum_sampled_speed=float(speed.min()),
                       endpoint_position_error_mm=float(np.max(np.abs(curve([0., stations[-1]]) - points[[0, -1]]))),
                       radius_target_mm=requirement, radius_sample_status='PASS' if radius >= requirement else 'FAIL')
        samples = np.linspace(0., stations[-1], 151)
        p = curve(samples)
        r = frames(curve(samples, 1), start, finish, samples)
        tests = [dict(capacity=n, dimensions_mm=dims, **native_probe(p, r, dims, targets)) for n, dims in boxes]
        ok = metrics['radius_sample_status'] == 'PASS' and all(t['status'] == 'PASS' for t in tests)
        row = dict(**metrics, status='PASS' if ok else 'FAIL', coarse_native=tests)
        candidates.append(row)
        print('CURRENT_ENTRY_CANDIDATE', spacing, radius, row['status'],
              [t.get('first_failure') for t in tests if t['status'] != 'PASS'][:1], flush=True)
        if not ok:
            continue
        samples = np.linspace(0., stations[-1], 1501)
        p = curve(samples)
        r = frames(curve(samples, 1), start, finish, samples)
        refined = [dict(capacity=n, dimensions_mm=dims, **native_probe(p, r, dims, targets)) for n, dims in boxes]
        row['refined_native'] = refined
        if all(t['status'] == 'PASS' for t in refined):
            accepted = row
            np.savez_compressed(HERE / 'candidate_path.npz', rear_mm=p, rotations=r,
                                knots=knots, cubic_coefficients=curve.c, parameter=samples)
            break
    assert all(sha(p) == h for p, h in sources.items())
    result = dict(status='PASS' if accepted else 'FAIL',
                  scope='Finite current197 native-solid bare-contact capacity screens only; not wired assembly',
                  sources=sources, native_parts=selected, native_part_count=len(selected),
                  not_installed=DEFERRED, reasons=dict(
                      body_shells='Later closure', head_shells='Head cavity open for temporary terminal feeding'),
                  actual_body_housing='BLOCKED: historical Plug_motion_J5 allocation is absent from current native meshes; no actual mating clearance claimed',
                  candidates=candidates, accepted=accepted, required_gap_mm=GAP,
                  actual_crimp_and_protection='BLOCKED', attached_wire_shape='NOT_TESTED',
                  peer_CAM_and_other_wire_clearance='NOT_TESTED', continuous_motion='NOT_TESTED',
                  actual_wire_bend_limit='BLOCKED', full_harness='BLOCKED',
                  main_changed=False, hardware_changed=False, animation_changed=False,
                  manufacturing_release=False, elapsed_s=time.time()-started)
    (HERE / 'entry_screen.json').write_text(json.dumps(result, indent=2) + '\n')
    print('CURRENT_ENTRY_SCREEN_DONE', result['status'], len(candidates), result['elapsed_s'], flush=True)


if __name__ == '__main__':
    main()
