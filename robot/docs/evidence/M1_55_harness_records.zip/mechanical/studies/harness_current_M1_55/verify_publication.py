"""Check research/source hashes and every published local study link."""
from pathlib import Path
import datetime,hashlib,json,re
from urllib.parse import urlsplit,unquote
from urllib.request import Request,urlopen
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=ROOT.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
delivery=read(HERE/'delivery.json')
assert delivery['status']=='PASS' and delivery['full_harness']=='BLOCKED'
assert sha(ROOT/'mori_v1_2.blend')==delivery['source_blend_sha256']
assert all((HERE/p).is_file() and sha(HERE/p)==h for p,h in delivery['files'].items())
joint=read(HERE/'global_bundle_layout/delivery.json')
assert joint['status']=='PASS' and joint['prefix_geometry']=='PASS' and joint['prefix_static_poses']==130
assert sha(HERE/'global_bundle_layout/delivery.json')==delivery['joint_prefix_delivery_sha256']
assert all(sha(HERE/'global_bundle_layout'/p)==h for p,h in joint['files'].items())
joint_verified=read(HERE/'global_bundle_layout/publication_verification.json')
assert joint_verified['status']=='PASS' and joint_verified['delivery_sha256']==sha(HERE/'global_bundle_layout/delivery.json')
continuity=read(HERE/'prefix_continuity/delivery.json')
assert continuity['status']=='PASS' and continuity['full_harness']=='BLOCKED'
assert delivery['continuity_delivery_sha256']==sha(HERE/'prefix_continuity/delivery.json')
assert all(sha(HERE/'prefix_continuity'/p)==h for p,h in continuity['files'].items())
continuity_verified=read(HERE/'prefix_continuity/publication_verification.json')
assert continuity_verified['status']=='PASS' and continuity_verified['delivery_sha256']==sha(HERE/'prefix_continuity/delivery.json')
upper_path=HERE/'upper_reference_review_R1/delivery.json'
upper=read(upper_path)
assert upper['status']=='PASS' and upper['full_harness']=='BLOCKED'
assert delivery['upper_reference_delivery_sha256']==sha(upper_path)
assert all(sha(upper_path.parent/p)==h for p,h in upper['files'].items())
upper_verified=read(upper_path.parent/'publication_verification.json')
assert upper_verified['status']=='PASS' and upper_verified['delivery_sha256']==sha(upper_path)
matched_upper_path=HERE/'upper_pairs_review_R2/delivery.json'
matched_upper=read(matched_upper_path)
assert matched_upper['status']=='PASS' and matched_upper['full_harness']=='BLOCKED'
assert delivery['matched_upper_delivery_sha256']==sha(matched_upper_path)
assert all(sha(matched_upper_path.parent/p)==h for p,h in matched_upper['files'].items())
matched_upper_verified=read(matched_upper_path.parent/'publication_verification.json')
assert matched_upper_verified['status']=='PASS' and matched_upper_verified['delivery_sha256']==sha(matched_upper_path)
complete_upper_path=HERE/'complete_known_upper_review_R1/delivery.json'
complete_upper=read(complete_upper_path)
assert complete_upper['status']=='PASS' and complete_upper['full_harness']=='BLOCKED'
assert delivery['complete_known_upper_delivery_sha256']==sha(complete_upper_path)
assert complete_upper['numeric_known_full_length_range_finite']=='PASS' and complete_upper['known_upper_curve_poses']==910
assert all(sha(complete_upper_path.parent/p)==h for p,h in complete_upper['files'].items())
complete_upper_verified=read(complete_upper_path.parent/'publication_verification.json')
assert complete_upper_verified['status']=='PASS' and complete_upper_verified['delivery_sha256']==sha(complete_upper_path)
for name in ['context_receipt.json','saved_inspection_readback.json','independent_pair_diagnostic.json']:
    report=read(HERE/name)
    assert report['status']=='PASS'
    assert all(sha(p)==h for p,h in report['sources'].items())
motion_path=HERE/'upper_motion_family_R1/verification.json'
motion=read(motion_path);motion_pub=read(HERE/'upper_motion_family_R1/publication_verification.json')
assert motion['status']==motion_pub['status']=='PASS'
assert delivery['upper_motion_verification_sha256']==sha(motion_path)
assert delivery['upper_motion_sampled_poses']==motion['finite_poses']==475
assert motion['unique_geometry_checks']==66500 and motion['curve_math_checks']==3325
assert all(sha(p)==h for p,h in motion['sources'].items())
assert all(sha(p)==h for p,h in motion['input_hashes'].items())
assert all(sha(HERE/'upper_motion_family_R1'/p)==h for p,h in motion_pub['files'].items())
station_path=HERE/'restraint_station_review_R1/delivery.json'
station=read(station_path)
assert delivery['station_material_delivery_sha256']==sha(station_path)
assert station['status']=='PASS' and station['station_checks']==3800
assert station['body_material_motion_status']=='PASS' and station['body_material_motion_checks']==1550
assert station['actual_harness']=='BLOCKED' and not station['manufacturing_release']
assert all(sha(p)==h for p,h in station['sources'].items())
assert all(sha(station_path.parent/p)==h for p,h in station['files'].items())
body_path=HERE/'body_restraint_review_R1/delivery.json'
body=read(body_path);body_verified=read(body_path.parent/'publication_verification.json')
assert body['status']==body_verified['status']=='PASS' and body['actual_harness']=='BLOCKED'
assert delivery['body_restraint_delivery_sha256']==sha(body_path)==body_verified['delivery_sha256']
assert body['body_curve_checks']==100 and body['body_native_pair_checks']==3650
assert body['body_fixture_checks']==600 and body['feature_checks']==552
assert all(sha(p)==h for p,h in body['sources'].items())
assert all(sha(body_path.parent/p)==h for p,h in body['files'].items())
upper_math_path=HERE/'upper_continuity_review_R1/delivery.json'
upper_math=read(upper_math_path);upper_math_verified=read(upper_math_path.parent/'publication_verification.json')
assert upper_math['status']==upper_math_verified['status']=='PASS' and upper_math['full_harness']=='BLOCKED'
assert delivery['upper_power_math_delivery_sha256']==sha(upper_math_path)==upper_math_verified['delivery_sha256']
assert upper_math['continuous_power_root_and_bending']=='PASS' and upper_math['accepted_rectangles']==18095
assert upper_math['saved_source_curve_poses']==1425 and upper_math['offgrid_source_comparisons']==18
assert upper_math['continuous_native_clearance']=='PASS' and upper_math['native_angular_rectangles']==19068
assert delivery['upper_power_continuous_native_gap']=='PASS' and delivery['upper_power_native_angular_rectangles']==19068
assert upper_math['continuous_peer_clearance']==upper_math['continuous_CAM_math']=='PASS'
assert delivery['upper_power_continuous_peer_gap']==delivery['upper_CAM_continuous_math']=='PASS'
assert delivery['upper_power_peer_angular_rectangles']==upper_math['power_peer_angular_rectangles']
assert delivery['upper_CAM_positive_length_rectangles']==2592 and delivery['upper_CAM_saved_curve_readbacks']==1900
assert delivery['upper_CAM_continuous_native_gap']==delivery['upper_CAM_continuous_peer_gap']=='PASS'
assert delivery['upper_CAM_peer_unordered_pairs']==6 and delivery['upper_CAM_power_cross_pairs']=='PASS'
assert delivery['upper_CAM_power_cross_unordered_pairs']==12
assert delivery['known_upper_continuous_mutual']=='PASS' and delivery['known_upper_unordered_pairs']==21
assert delivery['upper_power_continuous_remote_self']==delivery['known_upper_continuous_remote_self']=='PASS'
assert delivery['known_upper_remote_self_references']==7 and delivery['upper_power_self_angular_rectangles']==418
assert delivery['known_continuous_own_prefix']==delivery['known_continuous_other_prefix']=='PASS'
assert delivery['prefix_upper_comparisons']==84 and delivery['own_prefix_pairs']==7 and delivery['other_prefix_pairs']==77
assert delivery['prefix_upper_angular_rectangles']==9072 and delivery['prefix_upper_parameter_rectangles']==4185
assert delivery['upper_CAM_native_angular_rectangles']==upper_math['CAM_native_angular_rectangles']
assert delivery['upper_CAM_native_source_math_rectangles']==2592 and delivery['known_upper_native_references']==7
assert delivery['upper_CAM_fixed_tail_remote_self']=='PASS' and delivery['upper_CAM_fixed_tail_self_parameter_cells']==64000
assert delivery['upper_CAM_moving_lower_self']==delivery['upper_CAM_continuous_upper_remote_self']=='PASS'
assert delivery['upper_CAM_self_mixed_angular_rectangles']==2592
assert upper_math['CAM_tiny_angle_origin_diagnostic']=='PASS' and upper_math['CAM_tiny_angle_diagnosed_samples']==8
assert all(sha(p)==h for p,h in upper_math['sources'].items())
assert all(sha(upper_math_path.parent/p)==h for p,h in upper_math['files'].items())
terminal_path=HERE/'material_terminal_review_R1/delivery.json'
terminal_preflight=read(terminal_path)
terminal_verified=read(terminal_path.parent/'publication_verification.json')
assert terminal_preflight['status']==terminal_verified['status']=='PASS'
assert terminal_verified['delivery_sha256']==sha(terminal_path)
assert delivery['terminal_material_preflight_delivery_sha256']==sha(terminal_path)
assert delivery['terminal_range_preflight']=='PASS' and not delivery['formal_H06_changed']
assert delivery['actual_material_and_connection_qualification']=='BLOCKED'
assert terminal_preflight['formal_pin_rows']==4 and not terminal_preflight['wire_selected']
assert all(sha(p)==h for p,h in terminal_preflight['sources'].items())
assert all(sha(terminal_path.parent/p)==h for p,h in terminal_preflight['files'].items())
entry_path=HERE/'terminal_install_review_R1/delivery.json'
entry_review=read(entry_path)
entry_verified=read(entry_path.parent/'publication_verification.json')
assert entry_review['status']==entry_verified['status']=='PASS'
assert entry_verified['delivery_sha256']==sha(entry_path)
assert delivery['bare_contact_entry_delivery_sha256']==sha(entry_path)
assert delivery['bare_contact_continuous_native_clearance']=='PASS'
assert delivery['bare_contact_closed_intervals']==6090 and delivery['bare_contact_current_native_parts_at_stage']==197
assert delivery['bare_contact_interior_pose_checks']==384 and delivery['actual_attached_wire_entry']=='NOT_TESTED'
assert entry_review['full_harness']=='BLOCKED' and not entry_review['gentler_candidates_adopted']
assert all(sha(p)==h for p,h in entry_review['sources'].items())
assert all(sha(entry_path.parent/p)==h for p,h in entry_review['files'].items())
prelaid_path=HERE/'staged_prefix_entry_review_R1/delivery.json'
prelaid=read(prelaid_path)
prelaid_verified=read(prelaid_path.parent/'publication_verification.json')
assert prelaid['status']==prelaid_verified['status']=='PASS'
assert prelaid_verified['delivery_sha256']==sha(prelaid_path)
assert delivery['prelaid_prefix_entry_delivery_sha256']==sha(prelaid_path)
assert delivery['prelaid_prefix_entry']=='BLOCKED'
assert delivery['prelaid_prefix_verified_collision_witnesses']==12
assert prelaid['collision_witness_verification']=='PASS' and not prelaid['assembly_order_changed']
assert all(sha(p)==h for p,h in prelaid['sources'].items())
assert all(sha(prelaid_path.parent/p)==h for p,h in prelaid['files'].items())
moving_path=HERE/'moving_bundle_entry_review_R1/delivery.json'
moving_bundle=read(moving_path)
moving_verified=read(moving_path.parent/'publication_verification.json')
assert moving_bundle['status']==moving_verified['status']=='PASS'
assert moving_verified['delivery_sha256']==sha(moving_path)
assert delivery['moving_bundle_entry_delivery_sha256']==sha(moving_path)
assert delivery['moving_bundle_entry']=='BLOCKED' and delivery['moving_bundle_reference_sections']==19
assert delivery['moving_bundle_replayed_collisions']==10 and not moving_bundle['assembly_order_changed']
assert all(sha(p)==h for p,h in moving_bundle['sources'].items())
assert all(sha(moving_path.parent/p)==h for p,h in moving_bundle['files'].items())
phr4_path=HERE/'phr4_source_review_R1/delivery.json'
phr4=read(phr4_path)
phr4_verified=read(phr4_path.parent/'publication_verification.json')
assert phr4['status']==phr4_verified['status']=='PASS'
assert phr4_verified['delivery_sha256']==sha(phr4_path)
assert delivery['PHR4_source_delivery_sha256']==sha(phr4_path)
assert delivery['PHR4_public_documented_numeric_fields']==9 and not delivery['PHR4_detailed_CAD_received']
assert delivery['PHR4_actual_mating']=='BLOCKED' and not phr4['customer_form_submitted']
assert all(sha(p)==h for p,h in phr4['sources'].items())
assert all(sha(phr4_path.parent/p)==h for p,h in phr4['files'].items())
phr4_capacity_path=HERE/'phr4_mating_capacity_R1/delivery.json'
phr4_capacity=read(phr4_capacity_path)
phr4_capacity_verified=read(phr4_capacity_path.parent/'publication_verification.json')
assert phr4_capacity['status']==phr4_capacity_verified['status']=='PASS'
assert delivery['PHR4_capacity_delivery_sha256']==sha(phr4_capacity_path)==phr4_capacity_verified['delivery_sha256']
assert delivery['PHR4_conditional_external_box_capacity']=='PASS' and delivery['PHR4_fixed_head_service_probes']=='BLOCKED'
assert delivery['PHR4_replayed_service_witnesses']==phr4_capacity['independently_replayed_service_witnesses']==20
assert delivery['PHR4_service_capacity_intersections']==18 and delivery['PHR4_service_planning_gap_only_violations']==2
assert phr4_capacity['actual_mating']=='BLOCKED' and phr4_capacity['remaining_work_packages']==4
assert all(sha(p)==h for p,h in phr4_capacity['sources'].items())
assert all(sha(phr4_capacity_path.parent/p)==h for p,h in phr4_capacity['files'].items())
body_first_path=HERE/'body_first_connection_R1/delivery.json'
body_first=read(body_first_path)
body_first_verified=read(body_first_path.parent/'publication_verification.json')
assert body_first['status']==body_first_verified['status']=='PASS'
assert delivery['body_first_sequence_delivery_sha256']==sha(body_first_path)==body_first_verified['delivery_sha256']
assert delivery['body_first_early_connection']==delivery['prelaid_reference_bridge_entry']=='BLOCKED'
assert delivery['body_first_reference_sections']==body_first['reference_sections']==19
assert delivery['body_first_verified_bridge_witnesses']==body_first['verified_bridge_witnesses']==38
assert delivery['body_first_bridge_capacity_intersections']==36 and delivery['body_first_bridge_planning_gap_only_violations']==2
assert delivery['body_first_bridge_actor_readbacks']==85 and not body_first['assembly_order_changed']
assert delivery['general_JST_handling_requirements']=='PASS' and delivery['already_mated_empty_housing_contact_insertion']=='BLOCKED'
assert all(sha(p)==h for p,h in body_first['sources'].items())
assert all(sha(body_first_path.parent/p)==h for p,h in body_first['files'].items())
render=read(HERE/'render_manifest.json');visual=read(HERE/'visual_review.json')
assert visual['status']=='PASS'
assert render['files']==[{k:r[k] for k in ['file','sha256']} for r in visual['files']]
assert all(sha(HERE/r['file'])==r['sha256'] for r in visual['files'])
baseline=read(ROOT/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in baseline['protected_hardware'].items()
           if '__pycache__' not in n and Path(n).name!='.DS_Store'}
assert all((PROJECT/n).is_file() and sha(PROJECT/n)==h for n,h in protected.items())
links=[]
for page in [HERE/'index.html',ROOT/'index.html']:
    for link in re.findall(r'(?:href|src)="([^"]+)"',page.read_text()):
        parsed=urlsplit(link)
        if parsed.scheme or not parsed.path:continue
        target=(page.parent/unquote(parsed.path)).resolve()
        assert target.is_file() and target.is_relative_to(PROJECT),(page,link)
        url='http://127.0.0.1:58202/'+str(target.relative_to(PROJECT))
        with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
        links.append(dict(page=str(page.relative_to(PROJECT)),target=str(target.relative_to(PROJECT))))
result=dict(status='PASS',scope='Published hashes, local links and source preservation only; not harness fit or manufacturing qualification',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',
    source_blend_sha256=delivery['source_blend_sha256'],delivery_sha256=sha(HERE/'delivery.json'),
    checked_delivery_files=len(delivery['files']),local_HTTP_HEAD='PASS',checked_links=links,
    protected_hardware_files=len(protected),protected_hardware_unchanged=True,
    latest_render_images_directly_inspected=True,visual_review_sha256=sha(HERE/'visual_review.json'),
    main_changed=False,hardware_changed=False,
    full_wired_assembly='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('M1_55_HARNESS_PUBLICATION_VERIFIED',len(delivery['files']),'files',len(links),'links',len(protected),'protected hardware sources',flush=True)
