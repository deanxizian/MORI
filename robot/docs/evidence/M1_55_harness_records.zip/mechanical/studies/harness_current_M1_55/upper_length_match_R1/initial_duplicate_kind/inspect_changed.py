"""Fresh finite native/pair/actual-arc checks of the matched CAM references."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,ROOT,PROJECT,np,clear,transform_points,rigidtr,sha
sys.path.insert(0,str(HERE));sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import PiecewiseContext,BSpline,pieces,RADII
from sample_geometry import sample
PAIR=PARENT/'upper_pairs_review_R1'
spec=importlib.util.spec_from_file_location('_mori_existing_upper_pair_query',PAIR/'inspect_pairs.py')
pair=importlib.util.module_from_spec(spec);spec.loader.exec_module(pair)


def prepare(c,radius):
    sampled=sample(c);pack=pair.prepare(sampled['points'],radius,sampled['error'])
    pack['arc']=sampled['arc_upper']
    return pack


def compare(a,b,kind='peer'):
    result=pair.compare(a,b,kind)
    result.pop('local_excluded_polyline_arc_mm',None)
    result['local_excluded_actual_arc_upper_mm']=5. if kind!='peer' else None
    result['arc_bound_source']='Exact cubic restriction control polygons, not saved chord lengths' if kind!='peer' else 'NOT_APPLICABLE'
    return result


def main():
    started=time.time();native=Context();references=PiecewiseContext()
    zero='--zero' in sys.argv;suffix='zero' if zero else 'all_poses'
    receipt_path=HERE/f'{suffix}_length_match.json';receipt=json.loads(receipt_path.read_text())
    assert receipt['status']=='PASS' and all(sha(p)==h for p,h in receipt['sources'].items())
    source=HERE/f'{suffix}_curves.npz';assert sha(source)==receipt['arrays_sha256'];data=np.load(source)
    native.record([Path(__file__),HERE/'sample_geometry.py',PAIR/'inspect_pairs.py',receipt_path,source])
    names=list(RADII);changed={f'CAM_{p}' for p in range(1,5)}
    rows=[];fails=[];counts={'native':0,'conditional_USB':0,'upper_peer':0,'other_prefix':0,'self':0,'own_join':0}
    prefix_cache={}
    for yaw,pitch in receipt['planned_poses']:
        if yaw not in prefix_cache:
            prefix_cache[yaw]={}
            for name in references.f.names:
                control=references.f.candidate(name,yaw)['control']
                c=pieces(BSpline(references.f.knots,control,3))
                prefix_cache[yaw][name]=prepare(c,references.f.radii[name])
        prefixes=prefix_cache[yaw]
        packs={name:prepare(data[f'{name}_y{yaw}_p{pitch}_controls'],RADII[name]) for name in names}
        for name in sorted(changed):
            pack=packs[name]
            for group,targets in native.groups.items():
                matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
                hits,near=clear(transform_points(pack['p'],matrix),pack['radius']*norm,targets,
                                error=pack['error']*norm,gap=.3*norm)
                row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,kind='native',group=group,
                    status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near,
                    points=len(pack['p']),cubic_chord_error_mm=pack['error'],frame_operator_norm=norm)
                rows.append(row);counts['native']+=1
                if hits:fails.append(row)
            matrix=np.linalg.inv(np.asarray(rigidtr(yaw,pitch)));norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
            hits,near=clear(transform_points(pack['p'],matrix),pack['radius']*norm,native.usb,
                            error=pack['error']*norm,gap=.3*norm)
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,kind='conditional_USB',status='PASS' if not hits else 'BLOCKED',
                     hits=hits,nearest_within_query_AABBs=near,actual_USB_tail='BLOCKED')
            rows.append(row);counts['conditional_USB']+=1
            if hits:fails.append(row)
            for other,item in prefixes.items():
                if other==name:continue
                row=dict(wires=[name,other],yaw_deg=yaw,pitch_deg=pitch,kind='other_prefix',**compare(pack,item))
                # Keep the target role explicit; compare's kind is 'peer'.
                row['kind']='other_prefix';rows.append(row);counts['other_prefix']+=1
                if row['status']!='PASS':fails.append(row)
            for kind,left,right in [('self',pack,pack),('own_join',prefixes[name],pack)]:
                row=dict(wires=[name,name],yaw_deg=yaw,pitch_deg=pitch,**compare(left,right,kind))
                rows.append(row);counts[kind]+=1
                if row['status']!='PASS':fails.append(row)
        for a,b in itertools.combinations(names,2):
            if a not in changed and b not in changed:continue
            row=dict(wires=[a,b],yaw_deg=yaw,pitch_deg=pitch,**compare(packs[a],packs[b]))
            row['kind']='upper_peer';rows.append(row);counts['upper_peer']+=1
            if row['status']!='PASS':fails.append(row)
        print('MATCHED_CAM_POSE',yaw,pitch,'checks',len(rows),'failures',len(fails),flush=True)
        if fails:break
    native.unchanged();references.unchanged()
    count=len(receipt['planned_poses'])
    expected={'native':12*count,'conditional_USB':4*count,'upper_peer':18*count,'other_prefix':44*count,'self':4*count,'own_join':4*count}
    out=dict(status='PASS' if not fails and counts==expected else 'BLOCKED',
        scope='Fresh changed-CAM finite geometry checks on current 201 native solids; local smooth tube and actual terminations excluded',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',
        sources=native.sources|references.sources,planned_poses=receipt['planned_poses'],native_parts=201,
        counts=counts,expected_counts=expected,rows=rows,failures=fails,elapsed_s=time.time()-started,
        source_cubic_arrays_sha256=receipt['arrays_sha256'],required_gap_mm=.3,
        self_local_exclusion_actual_arc_upper_mm=5.,local_smooth_tube='NOT_TESTED',
        between_pose_motion='NOT_TESTED',actual_material_and_cut_length='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/f'{suffix}_geometry_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('MATCHED_CAM_GEOMETRY_TERMINAL',out['status'],len(rows),len(fails),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
