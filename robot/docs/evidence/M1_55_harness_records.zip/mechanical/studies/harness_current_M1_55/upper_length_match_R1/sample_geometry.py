"""Tessellate actual cubics with chord-error and actual arc upper bounds."""
import numpy as np


def sample(c,max_step=.015):
    points=[];arc_increments=[];errors=[]
    for piece in np.asarray(c,float):
        velocity=3*np.diff(piece,axis=0);acceleration=2*np.diff(velocity,axis=0)
        speed_bound=float(np.linalg.norm(velocity,axis=1).max())
        count=max(1,int(np.ceil(speed_bound/max_step)))
        t=np.linspace(0,1,count+1);u=t[:,None]
        p=(1-u)**3*piece[0]+3*u*(1-u)**2*piece[1]+3*u*u*(1-u)*piece[2]+u**3*piece[3]
        d=(1-u)**2*velocity[0]+2*u*(1-u)*velocity[1]+u*u*velocity[2]
        # Exact restriction of each cubic interval. The control-polygon
        # length bounds actual arc by positive Bernstein derivative weights.
        sub=np.stack([p[:-1],p[:-1]+d[:-1]/(3*count),p[1:]-d[1:]/(3*count),p[1:]],axis=1)
        arc_increments.append(np.linalg.norm(np.diff(sub,axis=1),axis=-1).sum(1)+1e-9)
        errors.append(float(np.linalg.norm(acceleration,axis=1).max())/(8*count*count)+1e-8)
        if points:assert np.linalg.norm(points[-1][-1]-p[0])<1e-10
        points.append(p if not points else p[1:])
    p=np.concatenate(points);arc=np.r_[0.,np.cumsum(np.concatenate(arc_increments))]
    assert len(arc)==len(p) and np.all(np.diff(arc)>0)
    assert np.linalg.norm(np.diff(p,axis=0),axis=1).max()<=max_step+1e-9
    return dict(points=p,error=max(errors),arc_upper=arc,
                arc_upper_method='Cubic restriction control-polygon sum with 1e-9 mm/cell numeric reserve')
