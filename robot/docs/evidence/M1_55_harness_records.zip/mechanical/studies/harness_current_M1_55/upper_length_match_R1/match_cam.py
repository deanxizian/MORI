"""Match each complete CAM capacity reference by its existing return height.

Preserve the R3 body/neck family and every retained endpoint/tangent. This
changes an unadopted upper reference only, not a clamp, port or printed part.
Common Gauss64 reference lengths are not actual mixed-material cut lengths.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/'upper_smooth_review_R2'
sys.path.insert(0,str(PREVIOUS))
from piecewise_geometry import PiecewiseContext,radius_bound,unit,MINIMUM_RADIUS,sha
from inspect_complete_numeric_lengths import upper_length


def shape_check(c,incoming,outgoing):
    left=np.diff(c,axis=1)[:,-1];right=np.diff(c,axis=1)[:,0]
    left/=np.linalg.norm(left,axis=1)[:,None];right/=np.linalg.norm(right,axis=1)[:,None]
    return dict(internal_tangent_unit_error=float(np.linalg.norm(left[:-1]-right[1:],axis=1).max()),
                internal_position_error_mm=float(np.linalg.norm(c[:-1,-1]-c[1:,0],axis=1).max()),
                end_tangent_unit_error=float(max(np.linalg.norm(right[0]-unit(incoming)),np.linalg.norm(left[-1]-unit(outgoing)))))


def main():
    started=time.time();ctx=PiecewiseContext()
    inventory_path=PREVIOUS/'numeric_length_inventory.json';receipt_path=PREVIOUS/'transfer_inspection.json'
    inventory=json.loads(inventory_path.read_text());receipt=json.loads(receipt_path.read_text())
    assert inventory['status']==receipt['status']=='PASS' and inventory['numeric_reference_range_status']=='FAIL'
    assert all(sha(p)==h for r in [inventory,receipt] for p,h in r['sources'].items())
    source=PREVIOUS/'transfer_curves.npz';assert sha(source)==receipt['arrays_sha256']
    old=np.load(source);arrays={k:old[k] for k in old.files}
    old_lengths={(r['yaw_deg'],r['pitch_deg'],r['wire']):r for r in inventory['rows']}
    # A small positive numerical reserve above the shortest retained route
    # avoids eliminating the source's half-millimetre return straights.
    reserve=.02
    targets={r['wire']:r['full_reference_min_mm']+reserve for r in inventory['summaries'] if r['wire'].startswith('CAM_')}
    rows=[];failures=[];zero='--zero' in sys.argv
    poses=[(0,0)] if zero else [(y,p) for y in range(-60,61,10) for p in range(-20,26,5)]
    ctx.record([Path(__file__),inventory_path,receipt_path,source,PREVIOUS/'inspect_complete_numeric_lengths.py'])
    for yaw,pitch in poses:
        raw_curves=ctx.upper(yaw,pitch)
        my=np.asarray(ctx.tr['transforms'][f'y{yaw}_p0']);height_length_rate=2*float(np.linalg.norm(my[:3,:3]@np.array([0.,0.,1.])))
        for pin in range(1,5):
            name=f'CAM_{pin}';raw=raw_curves[name];m=ctx.loop[pin,yaw,pitch]
            initial_height=m['upper_lead_mm'];initial_return=m['return_straight_mm'];base=old_lengths[yaw,pitch,name]
            body=base['body_neck_Gauss64_length_mm'];target=targets[name]-body
            delta=(target-base['upper_Gauss64_length_mm'])/height_length_rate
            attempts=[]
            try:
                for _ in range(3):
                    m['upper_lead_mm']=initial_height+delta
                    assert m['upper_lead_mm']>=.5-1e-7 and initial_return+delta>=.5-1e-7
                    builder,details=ctx.cam_curve(pin,yaw,pitch,raw)
                    c=np.asarray(builder.controls);lengths=np.asarray(builder.lengths)
                    actual=upper_length(c,64);residual=actual-target
                    attempts.append(dict(height_delta_mm=float(delta),residual_mm=float(residual)))
                    if abs(residual)<1e-8:break
                    delta-=residual/height_length_rate
                bend=radius_bound(c);joins=shape_check(c,*ctx.tangents(name,yaw,pitch))
                exact=np.array_equal(c[0,0],raw[0]) and np.array_equal(c[-1,-1],raw[-1])
                ok=(abs(residual)<1e-8 and bend['radius_lower_mm']>=MINIMUM_RADIUS[name] and exact and
                    joins['internal_tangent_unit_error']<1e-8 and joins['internal_position_error_mm']<1e-10 and joins['end_tangent_unit_error']<1e-8)
                row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,status='PASS' if ok else 'BLOCKED',
                    original_height_mm=initial_height,new_height_mm=initial_height+delta,height_delta_mm=float(delta),
                    new_return_straight_mm=initial_return+delta,root_attempts=attempts,
                    original_full_reference_length_mm=base['full_known_reference_Gauss64_length_mm'],
                    target_full_reference_length_mm=targets[name],body_neck_Gauss64_length_mm=body,
                    actual_full_reference_Gauss64_length_mm=body+actual,length_residual_mm=float(residual),
                    upper_Gauss32_64_difference_mm=abs(upper_length(c,32)-actual),
                    continuous_bending=bend,required_reference_radius_mm=MINIMUM_RADIUS[name],
                    endpoints_exact=exact,**joins,supplier_cut_length=None)
                key=f'{name}_y{yaw}_p{pitch}';arrays[key+'_controls']=c;arrays[key+'_lengths']=lengths
                rows.append(row)
                if not ok:failures.append(row)
                print('CAM_REFERENCE_LENGTH_MATCH',yaw,pitch,name,row['status'],residual,'height_delta',delta,flush=True)
            finally:m['upper_lead_mm']=initial_height
        if failures:break
    ctx.unchanged();suffix='zero' if zero else 'all_poses'
    np.savez_compressed(HERE/f'{suffix}_curves.npz',**arrays)
    summaries=[]
    for name in targets:
        selected=[r for r in rows if r['wire']==name]
        lengths=[r['actual_full_reference_Gauss64_length_mm'] for r in selected]
        summaries.append(dict(wire=name,checked_poses=len(selected),target_full_reference_mm=targets[name],
            full_reference_length_range_mm=max(lengths)-min(lengths),minimum_height_mm=min(r['new_height_mm'] for r in selected),
            minimum_return_straight_mm=min(r['new_return_straight_mm'] for r in selected),
            height_delta_range_mm=[min(r['height_delta_mm'] for r in selected),max(r['height_delta_mm'] for r in selected)],
            minimum_radius_lower_mm=min(r['continuous_bending']['radius_lower_mm'] for r in selected)))
    out=dict(status='PASS' if len(rows)==4*len(poses) and not failures else 'BLOCKED',
        scope='Four complete CAM numeric-reference lengths with unchanged R3 prefixes at specified finite poses only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        planned_poses=poses,checked_CAM_curve_poses=len(rows),rows=rows,failures=failures,summaries=summaries,
        numeric_length_reserve_mm=reserve,arrays_sha256=sha(HERE/f'{suffix}_curves.npz'),elapsed_s=time.time()-started,
        changed_upper_families=['CAM_1','CAM_2','CAM_3','CAM_4'],unchanged_upper_families=['P_J18_1','P_J18_2','CC_allocation'],
        native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',actual_arc_self_and_join='NOT_TESTED',
        between_pose_motion='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/f'{suffix}_length_match.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CAM_REFERENCE_LENGTH_MATCH_TERMINAL',out['status'],len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
