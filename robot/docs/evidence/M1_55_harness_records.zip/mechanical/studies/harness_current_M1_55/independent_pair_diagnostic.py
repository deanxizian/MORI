"""Exact polyline segment distances for conservative screening witnesses.

Global endpoint distance is an upper bound on the minimum segment distance.
KDTree searches all midpoint pairs that could beat it, including segment
half-length bounds. Each candidate pair is minimized over its parameter square.
This does not certify a future smoothed wire, crimp, material or motion path.
"""
from pathlib import Path
import sys,json,time
from mathutils.kdtree import KDTree
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *

from polyline_pair_distance import exact_pair, algorithm_checks

start=time.time();checks=algorithm_checks();ctx=Context();overview=json.loads((HERE/'body_relayout_R4/review.json').read_text())
name=overview['accepted'] or overview['attempts'][0]['candidate'];folder=HERE/'body_relayout_R4'/name
review=json.loads((folder/'review.json').read_text());curves=np.load(folder/'curves.npz');refs=ctx.refs(0,0);rows=[]
for item in review['rows']:
    if item['yaw_deg'] or item['pitch_deg']:continue
    pin=item['pin'];p=curves[f'CAM_{pin}_y0_p0']
    for t in item['tests']:
        if t['status']=='PASS' or t['test'] not in ['PH_peer','retained_reference']:continue
        if t['test']=='PH_peer':
            other=t['other_pin'];q=curves[f'CAM_{other}_y0_p0'];radius=.565;error=0.;label='PH_'+str(other)
        else:
            label=t['other'];q=refs[label]['p'];radius=float(refs[label]['radius']);error=float(refs[label]['error'])
        d=exact_pair(p,q);gap=d['centreline_distance_mm']-.565-radius
        lower=gap-error-.0001
        rows.append(dict(pin=pin,other=label,conservative_screen_witness_mm=t.get('gap_lower_bound_mm'),
             polyline_surface_gap_mm=gap,retained_reference_chord_error_mm=error,surface_gap_lower_mm=lower,
             status='PASS' if lower>=.3 else 'BLOCKED',**d))
        print('EXACT_POLYLINE_PAIR',pin,label,round(gap,6),rows[-1]['status'],flush=True)
ctx.record([Path(__file__),HERE/'polyline_pair_distance.py',folder/'review.json',folder/'curves.npz']);ctx.unchanged()
(HERE/'independent_pair_diagnostic.json').write_text(json.dumps(dict(status='PASS',revision=P['revision'],sources=ctx.sources,
 candidate=name,method='Exact finite polyline segment-to-segment minima; all potentially closer pairs retained by midpoint-radius bound',
 rows=rows,algorithm_checks=checks,scope='Diagnostic execution only: zero-pose flagged pairs. Rerouted candidate is the explicit stored polyline; no smoothing/curvature qualification.',
 smoothed_wire='NOT_TESTED',material_bend='NOT_TESTED',dynamic_assembly='NOT_TESTED',factory_SH_tail='BLOCKED',
 full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
