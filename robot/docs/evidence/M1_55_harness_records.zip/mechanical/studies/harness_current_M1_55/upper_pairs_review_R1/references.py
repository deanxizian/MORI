"""Pure array readback of exactly the seven retained upper references.

No ports, terminal dimensions or unknown upper routes are fabricated.
"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
PREVIOUS=PARENT.parent/'harness_current_M1_54'
FRAME=PARENT/'prefix_continuity/frame_family_R3'
sys.path.insert(0,str(FRAME))
from selected_family import SelectedFamily,BSpline
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
NAMES=['P_J18_1','P_J18_2','CAM_1','CAM_2','CAM_3','CAM_4','CC_allocation']
RADII={'P_J18_1':.5842,'P_J18_2':.5842,'CAM_1':.3302,'CAM_2':.3302,'CAM_3':.3302,'CAM_4':.3302,'CC_allocation':.3683}


def clean(p):
    p=np.asarray(p,dtype=float)
    return p[np.r_[True,np.linalg.norm(np.diff(p,axis=0),axis=1)>0]]


def transform(p,mat):
    return p@mat[:3,:3].T+mat[:3,3]


def upper_tail(points,seam):
    u=np.diff(points,axis=0)
    t=np.clip(np.sum((seam-points[:-1])*u,axis=1)/np.maximum(np.sum(u*u,axis=1),1e-18),0,1)
    projected=points[:-1]+t[:,None]*u
    ids=np.flatnonzero(np.linalg.norm(projected-seam,axis=1)<1e-7)
    assert len(ids),(seam.tolist(),float(np.linalg.norm(projected-seam,axis=1).min()))
    i=int(ids[0]);tail=clean(np.vstack([projected[i],points[i+1:]]))
    while len(tail)>1 and np.linalg.norm(tail[1]-tail[0])<1e-9:
        tail=np.vstack([tail[0],tail[2:]])
    return tail


class References:
    def __init__(self):
        self.f=SelectedFamily()
        self.sources=dict(self.f.sources)
        proof_path=PARENT/'upper_reference_review_R1/inspection.json'
        self.proof=read(proof_path)
        assert self.proof['status']=='PASS' and self.proof['wire_pose_checks']==910
        assert all(sha(p)==h for p,h in self.proof['sources'].items())
        self.sources.update(self.proof['sources'])
        self.sources[str(proof_path)]=sha(proof_path)
        transform_path=HERE/'reference_transforms.json'
        self.tr=read(transform_path)
        assert self.tr['status']=='PASS' and all(sha(p)==h for p,h in self.tr['sources'].items())
        self.sources.update(self.tr['sources']);self.sources[str(transform_path)]=sha(transform_path)
        self.sources[str(Path(__file__))]=sha(Path(__file__))
        old_path=Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49/remaining_routes/cam_side_fans/c6_join/candidate_curves.npz')
        paths=[old_path,MECHANICAL/'studies/harness_current_M1_53/power_yaw_compensation/mixed/candidate_curves.npz',
               PREVIOUS/'usb_power_routes/separated_candidates.npz',PREVIOUS/'usb_complete_reference/final_tails.npz',
               PREVIOUS/'usb_complete_reference/join_final_review.json',
               PREVIOUS/'cc_power_bundle/body_candidate.npz',
               PREVIOUS/'cc_thin_reference/adaptive_between_candidate.npz',
               PREVIOUS/'cc_power_bundle/fixed_length_candidate.npz']
        assert all(sha(p)==self.proof['sources'][str(p)] for p in paths)
        self.old,self.mixed,self.power,self.cam=[np.load(p) for p in paths[:4]]
        self.joins={r['key']:r['index'] for r in read(paths[4])['joins']}
        self.body=np.load(paths[5])['CC_body'];self.necks=np.load(paths[6]);self.cc=np.load(paths[7])
        self.record(paths)
        self.zero_path=PARENT/'upper_reference_review_R1/zero_pose_upper_references.npz'
        self.zero=np.load(self.zero_path);self.record([self.zero_path])

    def record(self,paths):
        for p in paths:self.sources[str(p)]=sha(p)

    def upper(self,yaw,pitch):
        mat=np.asarray(self.tr['transforms'][f'y{yaw}_p{pitch}'])
        full={}
        for name in ['P_J18_1','P_J18_2']:
            pre=(self.mixed if name.endswith('1') else self.old)[f'{name}_y{yaw}']
            up=self.power[f'{name}_y{yaw}_p{pitch}']
            assert np.linalg.norm(pre[-1]-up[0])<1e-8
            full[name]=clean(np.vstack([pre,up[1:]]))
        for pin in range(1,5):
            key=f'CAM_{pin}_y{yaw}_p{pitch}'
            pre=self.old[key][:self.joins[key]+1]
            up=transform(self.cam[f'pin{pin}'],mat)
            assert np.linalg.norm(pre[-1]-up[0])<1e-5
            full[f'CAM_{pin}']=clean(np.vstack([pre,up[1:]]))
        neck=self.necks[f'CC_y{yaw}'];up=self.cc[f'CC_y{yaw}_p{pitch}']
        assert np.linalg.norm(self.body[-1]-neck[0])<1e-8 and np.linalg.norm(neck[-1]-up[0])<1e-8
        full['CC_allocation']=clean(np.vstack([self.body,neck[1:],up[1:]]))
        result={name:upper_tail(p,self.f.controls[yaw][name][-1]) for name,p in full.items()}
        if yaw==pitch==0:
            assert all(np.array_equal(p,self.zero[name]) for name,p in result.items())
        return result

    def prefixes(self,yaw,count=6001):
        result={}
        t=np.linspace(0,1,count)
        for name in NAMES:
            c=self.f.candidate(name,yaw)['control']
            spl=BSpline(self.f.knots,c,3)
            p=spl(t)
            max_acc=float(np.linalg.norm(spl.derivative(2)(np.unique(self.f.knots)),axis=1).max())
            result[name]=dict(points=p,radius=self.f.radii[name],error=max_acc*(t[1]-t[0])**2/8+1e-9)
            assert np.linalg.norm(p[-1]-self.f.controls[yaw][name][-1])<1e-9
        return result

    def unchanged(self):
        assert all(sha(p)==h for p,h in self.sources.items())
