"""Capture exactly the float32 rigid transforms used by the native audit."""
from pathlib import Path
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
sys.path.insert(0,str(MECHANICAL/'scripts'))
from common import bpy,np,P,D
from validate import rigidtr
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert Path(bpy.data.filepath).resolve()==MECHANICAL/'mori_v1_2.blend'
assert P['revision']=='V1.2-M1.55'
source_files=[Path(__file__),PROJECT/'config/geometry.json',MECHANICAL/'mori_v1_2.blend',
              MECHANICAL/'scripts/common.py',MECHANICAL/'scripts/validate.py']
sources={str(p):sha(p) for p in source_files}
out=dict(status='PASS',scope='Reference rigid transforms only, no scene or geometry edits',
         sources=sources,head_center_mm=[0,0,D['head_z']],
         transforms={f'y{y}_p{p}':np.asarray(rigidtr(y,p)).tolist()
                     for y in range(-60,61,10) for p in range(-20,26,5)},
         main_changed=False,hardware_changed=False,manufacturing_release=False)
assert all(sha(p)==h for p,h in sources.items())
(HERE/'reference_transforms.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('UPPER_PAIR_TRANSFORMS_CAPTURED',len(out['transforms']),flush=True)
