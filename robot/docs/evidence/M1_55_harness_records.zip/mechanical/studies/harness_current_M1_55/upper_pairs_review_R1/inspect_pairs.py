"""Finite known-upper pairs and mixed-radius join reference inspection.

Self checks exclude only the explicitly stated <=5mm neighbourhood of the
saved reference polyline. Local tube/continuous bend and actual material joins
remain unqualified. Exact finite segments use double precision spatial queries.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from references import References,NAMES,RADII,FRAME,sha,np
sys.path.insert(0,str(FRAME/'continuous_gaps_R1'))
from pair_fields import distances,algorithm_checks,cKDTree


def prepare(p,radius,error):
    p=np.asarray(p,dtype=float)
    u=np.diff(p,axis=0);span=np.linalg.norm(u,axis=1)
    assert span.min()>1e-10
    mid=(p[:-1]+p[1:])/2
    return dict(p=p,u=u,mid=mid,half=span/2,tree=cKDTree(mid),radius=radius,error=error,
                arc=np.r_[0.,np.cumsum(span)])


def compare(a,b,kind='peer',gap=.3):
    allowance=a['error']+b['error']+1e-8
    radius=a['radius']+b['radius']
    query=radius+allowance+gap+a['half']+float(b['half'].max())+1e-8
    near=b['tree'].query(a['mid'],k=1)[0]
    possible=np.flatnonzero(near<=query)
    rows=b['tree'].query_ball_point(a['mid'][possible],query[possible])
    ii=np.repeat(possible,[len(r) for r in rows])
    jj=np.concatenate([np.asarray(r,int) for r in rows]) if len(ii) else np.array([],int)
    if kind=='self':
        # This criterion is for the saved reference polyline. It is not an
        # all-angle material-arc bound and cannot establish local tube safety.
        mask=(jj>ii)&((a['arc'][jj+1]-a['arc'][ii])>5.)
        ii,jj=ii[mask],jj[mask]
    elif kind=='own_join':
        # a is the body/neck prefix; b is its upper reference. Their shared
        # endpoint is intentional, not a peer collision. Retain any segment
        # pair whose polyline arc-separation interval extends beyond 5mm.
        mask=(a['arc'][-1]-a['arc'][ii]+b['arc'][jj+1])>5.
        ii,jj=ii[mask],jj[mask]
    checked=0;lower=gap;witness=None
    for start in range(0,len(ii),50000):
        ai,bi=ii[start:start+50000],jj[start:start+50000]
        mid_dist=np.linalg.norm(a['mid'][ai]-b['mid'][bi],axis=1)
        mask=mid_dist-a['half'][ai]-b['half'][bi]<=radius+allowance+gap+1e-8
        ai,bi=ai[mask],bi[mask]
        if not len(ai):continue
        ds,t,s=distances(a['p'][ai],b['p'][bi],a['u'][ai],b['u'][bi])
        margins=ds-radius-allowance;k=int(np.argmin(margins));checked+=len(ai)
        if margins[k]<lower:
            lower=float(margins[k])
            witness=dict(segments=[int(ai[k]),int(bi[k])],centreline_distance_mm=float(ds[k]),
                nominal_polyline_surface_gap_mm=float(ds[k]-radius),gap_lower_mm=lower,
                point_a_mm=(a['p'][ai[k]]+t[k]*a['u'][ai[k]]).tolist(),
                point_b_mm=(b['p'][bi[k]]+s[k]*b['u'][bi[k]]).tolist())
        if lower<gap:break
    return dict(status='PASS' if lower>=gap else 'BLOCKED',gap_lower_mm=lower,
                compared_segment_pairs=checked,witness=witness,kind=kind,
                local_excluded_polyline_arc_mm=5. if kind!='peer' else None,
                local_smooth_tube_qualification='NOT_TESTED' if kind!='peer' else 'NOT_APPLICABLE')


def main():
    started=time.time();refs=References();tests=algorithm_checks()
    refs.record([Path(__file__),FRAME/'continuous_gaps_R1/pair_fields.py'])
    rows=[];fails=[];pairs=list(itertools.combinations(NAMES,2));counts={'peer':0,'self':0,'own_join':0}
    compared=0
    for yaw in range(-60,61,10):
        prefix=refs.prefixes(yaw)
        prepack={n:prepare(r['points'],r['radius'],r['error']) for n,r in prefix.items()}
        for pitch in range(-20,26,5):
            upper=refs.upper(yaw,pitch)
            packs={n:prepare(p,RADII[n],.0006) for n,p in upper.items()}
            tasks=[(a,b,'peer') for a,b in pairs]+[(n,n,'self') for n in NAMES]+[(n,n,'own_join') for n in NAMES]
            for a,b,kind in tasks:
                left=prepack[a] if kind=='own_join' else packs[a]
                right=packs[b]
                result=compare(left,right,kind)
                row=dict(yaw_deg=yaw,pitch_deg=pitch,wires=[a,b],**result)
                rows.append(row);counts[kind]+=1;compared+=result['compared_segment_pairs']
                if result['status']!='PASS':fails.append(row)
            print('UPPER_PAIRS_POSE',yaw,pitch,'checks',len(rows),'failed',len(fails),flush=True)
    assert counts=={'peer':2730,'self':910,'own_join':910}
    refs.unchanged()
    out=dict(status='PASS' if not fails else 'BLOCKED',
        scope='Known upper peers, remote saved-polyline self and mixed-radius own joins at 130 finite poses; complete harness excluded',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=refs.sources,
        revision='V1.2-M1.55',poses=130,known_upper_references=7,checks=counts,
        checked_rows=len(rows),compared_finite_segment_pairs=compared,algorithm_checks=tests,
        rows=rows,failures=fails,required_gap_mm=.3,local_excluded_reference_polyline_arc_mm=5.,
        local_smooth_tube_or_splice='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',actual_endpoints_and_clamps='BLOCKED',
        actual_mixed_material_length='BLOCKED',wired_assembly_and_closure='BLOCKED',
        full_harness='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,
        new_commit_or_push=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('UPPER_PAIRS_TERMINAL',out['status'],counts,len(fails),out['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
