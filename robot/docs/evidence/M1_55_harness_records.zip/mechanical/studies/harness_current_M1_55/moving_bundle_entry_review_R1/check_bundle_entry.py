"""Loose capacity bundle translated with the saved head-drive seat.

Both body and head reference ends are unconnected at this preparation stage.
The twelve prefixes plus every available seven upper section move by one
shared translation. This candidate cannot certify five missing upper ends,
actual free terminals, grip, restraint or post-entry flexible reshaping.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]
sys.path[:0]=[str(PARENT),str(PROJECT/'mechanical/scripts/vendor')]
from context import clear,manifold,Vector,BVHTree
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    started=time.time()
    preparation=read(HERE/'bundle_receipt.json')
    assert preparation['status']=='PASS' and preparation['prefix_sections']==12 and preparation['upper_sections']==7
    assert all(sha(p)==h for p,h in preparation['sources'].items())
    array_path=HERE/'bundle_zero.npz'
    assert sha(array_path)==preparation['arrays_sha256']
    arrays=np.load(array_path)
    prior=PARENT/'staged_prefix_entry_review_R1'
    path=read(prior/'prefix_entry_review.json')
    actor_audit=read(prior/'counterexample_verification.json')
    assert actor_audit['status']=='PASS' and actor_audit['verified_collision_witnesses']==12
    assert all(sha(p)==h for r in [path,actor_audit] for p,h in r['sources'].items())
    current=PARENT/'terminal_install_review_R1'
    receipt=read(current/'current_native_receipt.json')
    native_path=current/'current_native_parts.npz'
    assert receipt['native_part_count']==201 and sha(native_path)==receipt['output_sha256']
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    native=np.load(native_path)
    targets={}
    for name in path['moving_native_ids']+path['stationary_prior_native_ids']:
        v=native[name+'__vertices_mm'];f=native[name+'__triangles']
        solid=manifold.Manifold(manifold.Mesh64(v,f.astype(np.uint64)))
        assert solid.status()==manifold.Error.NoError
        targets[name]=dict(m=solid,lo=v.min(0),hi=v.max(0),
                           tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True))
    moving={n:targets[n] for n in path['moving_native_ids']}
    fixed={n:targets[n] for n in path['stationary_prior_native_ids']}
    assert len(moving)==21 and len(fixed)==102
    fixture_lo=np.min([v['lo'] for v in fixed.values()],axis=0)
    fixture_hi=np.max([v['hi'] for v in fixed.values()],axis=0)
    rows=[]
    for meta in preparation['rows']:
        key=meta['key'];points=arrays[key+'__points_mm'];controls=arrays[key+'__controls_mm']
        radius=meta['radius_capacity_mm'];error=meta['chord_error_mm']
        own_hits,own_nearest=clear(points,radius,moving,error=error,gap=.3)
        row=dict(key=key,wire=meta['wire'],section=meta['role'],radius_capacity_mm=radius,
                 moving_native_relative_check=dict(status='PASS' if not own_hits else 'BLOCKED',
                                                   hits=own_hits,nearest=own_nearest),
                 stationary_native_path=[],status='PASS' if not own_hits else 'BLOCKED')
        for index,segment in enumerate(path['path_segments']):
            a=np.array(segment['start_translation_mm']);b=np.array(segment['end_translation_mm'])
            # Exact Bezier convex hull plus the entire axis-aligned translation
            # gives an inexpensive complete-path separation certificate.
            lo=controls.min(axis=(0,1))+np.minimum(a,b)
            hi=controls.max(axis=(0,1))+np.maximum(a,b)
            delta=np.maximum(np.maximum(fixture_lo-hi,lo-fixture_hi),0.)
            aabb_gap=float(np.linalg.norm(delta)-radius-.0001)
            if aabb_gap>=.3:
                row['stationary_native_path'].append(dict(path_segment=index,status='PASS',
                    certificate='Whole cubic-control/translation convex hull versus complete stationary AABB',
                    gap_lower_bound_mm=aabb_gap,intervals=[dict(parameter_interval=[0.,1.])],first_failure=None))
                continue
            todo=[(0.,1.,0)];accepted=[];failure=None
            while todo:
                left,right,depth=todo.pop();mid=(left+right)/2
                offset=a+(b-a)*mid
                motion=float(np.linalg.norm(b-a)*(right-left)/2)
                bad,near=clear(points+offset,radius,fixed,error=error+motion,gap=.3)
                if not bad:
                    accepted.append(dict(parameter_interval=[left,right],translation_radius_mm=motion,
                                         gap_lower_bound_mm=near['gap_lower_bound_mm'] if near else None))
                    continue
                observed,witness=clear(points+offset,radius,fixed,error=error,gap=.3)
                distance_upper=None
                if witness:
                    distance_upper=(witness['gap_lower_bound_mm']+witness['half_step_mm']+
                                    witness['chord_error_mm']+.0001)
                inside=any(h.get('inside') for h in observed)
                if inside or (distance_upper is not None and distance_upper<.3) or depth>=13:
                    failure=dict(parameter_interval=[left,right],midpoint=mid,
                                 bundle_translation_mm=offset.tolist(),nearest=witness,
                                 sampled_surface_clearance_upper_mm=distance_upper,inside_native=inside,
                                 hits=observed,depth=depth)
                    break
                todo.extend([(mid,right,depth+1),(left,mid,depth+1)])
            if failure is None:
                assert accepted[0]['parameter_interval'][0]==0. and accepted[-1]['parameter_interval'][1]==1.
                assert all(a['parameter_interval'][1]==b['parameter_interval'][0]
                           for a,b in zip(accepted[:-1],accepted[1:]))
            row['stationary_native_path'].append(dict(path_segment=index,status='PASS' if failure is None else 'BLOCKED',
                certificate='Fresh current-native point/surface, inside and translation-radius enclosure',
                intervals=accepted,first_failure=failure))
            if failure:
                row['status']='BLOCKED'
                break
        rows.append(row)
        print('MOVING_BUNDLE_ENTRY_SECTION',key,row['status'],flush=True)
    sources={**preparation['sources'],**receipt['sources'],
             **{str(p):sha(p) for p in [Path(__file__),HERE/'bundle_receipt.json',array_path,
                 prior/'prefix_entry_review.json',prior/'counterexample_verification.json',
                 current/'current_native_receipt.json',native_path,PARENT/'context.py',
                 PARENT.parent/'harness_current_M1_54/cam_upper_reroute/current_context.py']}}
    assert all(sha(p)==h for p,h in sources.items())
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items()
               if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    report=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
                scope='Unconnected19 reference sections translating together with the saved head-drive seat; no actual temporary harness qualification',
                recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
                source_native_parts=201,moving_native_ids=sorted(moving),stationary_native_ids=sorted(fixed),
                reused_actor_motion_proof='Exact current saved FCurves and matrices from staged_prefix_entry_review_R1; no wire clearance inherited',
                path_segments=path['path_segments'],rows=rows,prefix_sections=12,available_upper_sections=7,
                complete_available_references=7,missing_upper_references=preparation['missing_upper_references'],
                shape_deformation='None: one shared translation, existing numeric lengths/curvatures and relative geometry unchanged',
                actual_body_connections='Unconnected candidate; real free terminal/protector dimensions BLOCKED',
                actual_head_connections='Unconnected capacity references; later CAM assembly not qualified',
                actual_soft_reshaping_and_grip='NOT_TESTED',full_wired_assembly='BLOCKED',
                manufacturing_release=False,main_changed=False,animation_changed=False,hardware_changed=False,
                assembly_order_changed=False,protected_hardware_files=846,elapsed_s=time.time()-started)
    (HERE/'bundle_entry_review.json').write_text(json.dumps(report,indent=2)+'\n')
    print('MOVING_BUNDLE_ENTRY_TERMINAL',report['status'],len(rows),len(moving),len(fixed),
          round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
