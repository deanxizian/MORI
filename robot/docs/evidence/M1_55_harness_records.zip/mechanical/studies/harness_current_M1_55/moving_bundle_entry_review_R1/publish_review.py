"""Publish the complete available moving-reference preparation and failures."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote,unquote,urlsplit
import datetime
import hashlib
import json
import subprocess
import sys
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
NUMERIC='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):self.links.extend(v for k,v in attrs if k in ['href','src'])


def main():
    proof=read(HERE/'bundle_entry_review.json')
    audit=read(HERE/'counterexample_verification.json')
    preparation=read(HERE/'bundle_receipt.json')
    assert proof['status']=='BLOCKED' and audit['status']==preparation['status']=='PASS'
    assert len(audit['verified_collision_witnesses'])==10 and len(proof['rows'])==19
    assert proof['prefix_sections']==12 and proof['available_upper_sections']==7
    sources={**audit['sources'],**{str(p):sha(p) for p in [Path(__file__),HERE/'counterexample_verification.json']}}
    assert all(sha(p)==h for p,h in sources.items())
    for log,marker in [('prepare_bundle.log','MOVING_BUNDLE_ZERO_RECEIPT 12 7 5'),
                       ('check_bundle_entry.log','MOVING_BUNDLE_ENTRY_TERMINAL BLOCKED 19 21 102'),
                       ('verify_counterexamples.log','MOVING_BUNDLE_COUNTEREXAMPLES_VERIFIED 10 19 21 102 846')]:
        assert marker in (HERE/log).read_text() and 'Traceback (most recent call last)' not in (HERE/log).read_text()
    versions=json.loads(subprocess.check_output([NUMERIC,'-c',
        "import sys,json,importlib.metadata;sys.path[:0]=['"+str(PROJECT/'mechanical/scripts/vendor')+"','/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313'];import numpy,scipy;print(json.dumps(dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,manifold3d=importlib.metadata.version('manifold3d'))))"],text=True))
    versions['blender']=subprocess.check_output(['/Applications/Blender.app/Contents/MacOS/Blender','--version'],text=True).splitlines()[0]
    commands=dict(status='PASS',cwd=str(PROJECT),versions=versions,commands=[
        dict(command=[NUMERIC,str(HERE/'prepare_bundle.py')],log='prepare_bundle.log',exit_code=0),
        dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','--factory-startup',
                      '--python-exit-code','1','--python',str(HERE/'check_bundle_entry.py')],
             log='check_bundle_entry.log',exit_code=0),
        dict(command=[NUMERIC,str(HERE/'verify_counterexamples.py')],log='verify_counterexamples.log',exit_code=0)],
        note='Successful script executions retain a BLOCKED preparation; no geometry or order adopted',
        full_harness='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    table=''.join(f"<tr><td>{r['key']}</td><td>Yaw_Base</td><td>{r['bundle_translation_mm'][2]:.0f}mm</td><td>{r['inscribed_sphere_overlap_mm3']:.6f}mm³</td></tr>" for r in audit['verified_collision_witnesses'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 松线束随驱动座下放诊断</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:32px auto;padding:0 22px;color:#27343b}}table{{width:100%;border-collapse:collapse;margin:20px 0}}td,th{{padding:9px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}</style>
<h1>两端暂不连接，线形随驱动座整体下放</h1>
<p class="scope">候选准备方式BLOCKED／未采用。PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED。完整可用的12条身体前段和7条已知头内上段均参加；仍有5条未知上段，不能当作实际整束线。</p>
<p>各参考两端在此阶段都不插合，19个分段共享同一刚体平移，数值线长、曲率及相对线形保持。回读现有动画的21件驱动座分总成：X130／Z64→X0／Z64→X0／Z0，保留此前102件固定原生实体。没有修改曲线、打印件或装配顺序。</p>
<p>相对驱动座的静态容量检查通过，固定实体路径检查发现10条身体前段在下放Z16或Z32mm时与Yaw_Base相交。两条喇叭预留前段与7条可用上段完成本范围内路径检查；这些局部通过不能放行整束装入。</p>
<table><thead><tr><th>失败参考</th><th>相交实体</th><th>下放余高</th><th>独立内接球相交体积</th></tr></thead><tbody>{table}</tbody></table>
<p>独立审计核对12条前段与原数组一致、4条CAM上段与已保存的名义零位控制点一致；所有9个通过分段的路径覆盖及外包盒证明另检，10处实体相交探针重新计算。当前201件原生来源和846个硬件源哈希保持。没有借用旧间隙结果作为本次搬线路径通过。</p>
<p>现阶段不能把最终线形固定预铺，也不能将最终线形随驱动座整体搬入后立即插合。临时自由端、收线／分步穿线、重新成形和手部夹持仍需设计；实际端子、保护件、材料及5个头部端点仍缺数据。完整带线装入与闭壳BLOCKED，主模型和M1.55-A1视频保持。</p>
<p><a href="bundle_entry_review.json">当前完整19段诊断</a> · <a href="counterexample_verification.json">独立相交复现</a> · <a href="bundle_receipt.json">12前段＋7上段来源</a> · <a href="commands.json">实际命令与版本</a> · <a href="../staged_prefix_entry_review_R1/index.html">固定预铺失败记录</a> · <a href="../phr4_source_review_R1/index.html">PHR-4公开资料与详细CAD边界</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# Moving loose-reference bundle entry

Unadopted preparation:body/head reference ends are unconnected; all12 R3
prefixes and every7 available nominal upper section share one translation.
Five unknown uppers remain. No actual free terminal or temporary harness is
certified. Rigid translation retains numerical length/curvature/relative shape.

Actual saved M1.55-A1 stage13/source21 path:X130,Z64 -> X0,Z64 -> X0,Z0.
Current201 source meshes;21 head-seat moving parts and102 prior fixed parts.
All19 relative-moving checks pass;10 prefixes collide with fixedYaw_Base at
Z16/32. Two speaker-prefix reservations plus7 uppers pass this limited path
scope. Independent source/coverage/AABB checks and10 inscribed-sphere overlap
witnesses are recorded. No full temporary harness/grip/reshaping qualification.

Candidate remains BLOCKED. Main/order/video/hardware unchanged;846 protected
hardware files preserved. Actual terminals/materials, missing5 endpoints,
post-entry reshaping and wired closure remain unresolved. No manufacturing
release or supplier order, and no new commit/push.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
           and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_review.log']}
    delivery=dict(status='PASS',scope='Verified source/counterexample publication; moving bundle preparation BLOCKED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        moving_bundle_entry='BLOCKED',reference_sections=19,prefix_sections=12,available_upper_sections=7,
        failed_prefix_sections=10,independently_replayed_collisions=10,passing_sections_with_coverage_checks=9,
        current_native_parts=201,moving_native_parts=21,stationary_native_parts=102,
        actual_temporary_harness='NOT_TESTED',full_harness='BLOCKED',protected_hardware_files=846,
        main_changed=False,animation_changed=False,hardware_changed=False,assembly_order_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items()) and all(sha(HERE/p)==h for p,h in files.items())
    parser=Links();parser.feed((HERE/'index.html').read_text());targets=[HERE/'index.html']
    for link in parser.links:
        u=urlsplit(link)
        if not u.scheme and u.path:targets.append((HERE/unquote(u.path)).resolve())
    served=[]
    for p in dict.fromkeys(targets):
        assert p.is_file(),p
        rel=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(rel),timeout=10) as response:
            assert response.status==200 and response.read()==p.read_bytes()
        served.append(dict(path=rel,sha256=sha(p)))
    verified=dict(status='PASS',delivery_sha256=sha(HERE/'delivery.json'),verified_sources=len(sources),
                  verified_files=len(files),served_links=len(served),served=served,
                  full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(verified,indent=2)+'\n')
    print('MOVING_BUNDLE_PUBLICATION_VERIFIED',len(files),len(served),10,19,flush=True)


if __name__=='__main__':main()
