# Moving loose-reference bundle entry

Unadopted preparation:body/head reference ends are unconnected; all12 R3
prefixes and every7 available nominal upper section share one translation.
Five unknown uppers remain. No actual free terminal or temporary harness is
certified. Rigid translation retains numerical length/curvature/relative shape.

Actual saved M1.55-A1 stage13/source21 path:X130,Z64 -> X0,Z64 -> X0,Z0.
Current201 source meshes;21 head-seat moving parts and102 prior fixed parts.
All19 relative-moving checks pass;10 prefixes collide with fixedYaw_Base at
Z16/32. Two speaker-prefix reservations plus7 uppers pass this limited path
scope. Independent source/coverage/AABB checks and10 inscribed-sphere overlap
witnesses are recorded. No full temporary harness/grip/reshaping qualification.

Candidate remains BLOCKED. Main/order/video/hardware unchanged;846 protected
hardware files preserved. Actual terminals/materials, missing5 endpoints,
post-entry reshaping and wired closure remain unresolved. No manufacturing
release or supplier order, and no new commit/push.
