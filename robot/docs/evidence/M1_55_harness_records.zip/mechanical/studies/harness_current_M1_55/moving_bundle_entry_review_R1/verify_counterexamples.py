"""Replay loose-bundle counterexamples against independently cached natives."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]
sys.path.insert(0,str(PROJECT/'mechanical/scripts/vendor'))
import manifold3d as manifold
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    started=time.time()
    path=HERE/'bundle_entry_review.json';report=read(path)
    preparation=read(HERE/'bundle_receipt.json')
    assert report['status']=='BLOCKED' and len(report['rows'])==19
    assert all(sha(p)==h for r in [report,preparation] for p,h in r['sources'].items())
    arrays=np.load(HERE/'bundle_zero.npz')
    assert sha(HERE/'bundle_zero.npz')==preparation['arrays_sha256']
    original=np.load(PARENT/'staged_prefix_entry_review_R1/zero_prefixes.npz')
    assert all(np.array_equal(arrays[n+'__prefix__controls_mm'],original[n+'__controls_mm'])
               and np.array_equal(arrays[n+'__prefix__points_mm'],original[n+'__points_mm'])
               for n in {r['wire'] for r in preparation['rows'] if r['role']=='prefix'})
    # Freshly prepared CAM reference geometry must match its existing saved
    # nominal zero-pose data, without treating the old geometry PASS as new.
    saved=np.load(PARENT/'upper_continuity_review_R1/cam_math_review_R1/nominal_half_grid_curves.npz')
    cam_replay=[]
    for pin in range(1,5):
        name=f'CAM_{pin}'
        error=float(np.linalg.norm(arrays[name+'__upper__controls_mm']-
                                   saved[name+'_y0_p0_controls'],axis=-1).max())
        assert error<1e-9,(name,error)
        cam_replay.append(dict(wire=name,saved_control_replay_error_mm=error))
    current=PARENT/'terminal_install_review_R1'
    receipt=read(current/'current_native_receipt.json')
    native_path=current/'current_native_parts.npz'
    assert receipt['native_part_count']==201 and sha(native_path)==receipt['output_sha256']
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    native=np.load(native_path)
    fixed=set(report['stationary_native_ids']);moving=set(report['moving_native_ids'])
    assert len(fixed)==102 and len(moving)==21 and not fixed & moving
    highest=max(float(native[n+'__vertices_mm'][:,2].max()) for n in fixed)
    assert highest==163.8000030517578
    failures=[r for r in report['rows'] if r['status']=='BLOCKED']
    assert len(failures)==10 and all(r['section']=='prefix' for r in failures)
    witnesses=[]
    for row in failures:
        assert row['moving_native_relative_check']['status']=='PASS'
        failed=next(s for s in row['stationary_native_path'] if s['first_failure'] is not None)
        f=failed['first_failure'];p=np.array(f['nearest']['point_mm'])
        offset=np.array(f['bundle_translation_mm']);points=arrays[row['key']+'__points_mm']+offset
        distances=np.linalg.norm(points-p,axis=1);index=int(np.argmin(distances))
        assert distances[index]<1e-10
        assert f['nearest']['object']=='Yaw_Base' and 'Yaw_Base' in fixed
        target=manifold.Manifold(manifold.Mesh64(native['Yaw_Base__vertices_mm'],
                                                native['Yaw_Base__triangles'].astype(np.uint64)))
        probe=manifold.Manifold.sphere(row['radius_capacity_mm'],96).translate(p.tolist())
        overlap=float((probe^target).volume())
        assert overlap>1e-5,(row['key'],overlap)
        witnesses.append(dict(key=row['key'],native='Yaw_Base',bundle_translation_mm=offset.tolist(),
                              exact_sample_index=index,sample_replay_error_mm=float(distances[index]),
                              inscribed_sphere_overlap_mm3=overlap,status='PASS'))
    passed=[r for r in report['rows'] if r['status']=='PASS']
    assert len(passed)==9
    assert {r['wire'] for r in passed if r['section']=='prefix'}=={'SPK_reservation_3','SPK_reservation_6'}
    for row in passed:
        assert row['moving_native_relative_check']['status']=='PASS'
        assert len(row['stationary_native_path'])==2
        for s in row['stationary_native_path']:
            assert s['status']=='PASS' and s['first_failure'] is None
            coverage=[r['parameter_interval'] for r in s['intervals']]
            assert coverage[0][0]==0. and coverage[-1][1]==1.
            assert all(a[1]==b[0] for a,b in zip(coverage[:-1],coverage[1:]))
            if s['certificate'].startswith('Whole cubic-control'):
                a=report['path_segments'][s['path_segment']]['start_translation_mm']
                b=report['path_segments'][s['path_segment']]['end_translation_mm']
                v=arrays[row['key']+'__controls_mm']
                lo=v.min(axis=(0,1))+np.minimum(a,b);hi=v.max(axis=(0,1))+np.maximum(a,b)
                flo=np.min([native[n+'__vertices_mm'].min(0) for n in fixed],axis=0)
                fhi=np.max([native[n+'__vertices_mm'].max(0) for n in fixed],axis=0)
                delta=np.maximum(np.maximum(flo-hi,lo-fhi),0.)
                gap=float(np.linalg.norm(delta)-row['radius_capacity_mm']-.0001)
                assert abs(gap-s['gap_lower_bound_mm'])<1e-10 and gap>=.3
    sources={**report['sources'],**preparation['sources'],**receipt['sources'],
             **{str(p):sha(p) for p in [Path(__file__),path,HERE/'bundle_receipt.json',
                 HERE/'bundle_zero.npz',PARENT/'staged_prefix_entry_review_R1/zero_prefixes.npz',
                 PARENT/'upper_continuity_review_R1/cam_math_review_R1/nominal_half_grid_curves.npz',
                 current/'current_native_receipt.json',native_path]}}
    assert all(sha(p)==h for p,h in sources.items())
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items()
               if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    output=dict(status='PASS',scope='Source, path coverage/AABB and ten current-native capacity counterexamples; not independent full wired qualification',
                recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
                failed_prefix_sections=10,verified_collision_witnesses=witnesses,source_prefix_array_readbacks=12,
                saved_CAM_control_readbacks=cam_replay,passing_section_path_coverages=9,
                current_native_parts=201,moving_native_parts=21,stationary_prior_native_parts=102,
                candidate_bundle_entry='BLOCKED',actual_temporary_harness='NOT_TESTED',full_harness='BLOCKED',
                protected_hardware_files=846,main_changed=False,hardware_changed=False,animation_changed=False,
                assembly_order_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'counterexample_verification.json').write_text(json.dumps(output,indent=2)+'\n')
    print('MOVING_BUNDLE_COUNTEREXAMPLES_VERIFIED',10,19,21,102,846,flush=True)


if __name__=='__main__':main()
