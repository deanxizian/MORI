"""Receipt exact current R3 prefixes and all seven available nominal uppers.

Bodies, source endpoints and selected hardware are untouched. The resulting
nineteen curve sections are unadopted capacity references, not cut wires or
temporary connectors. Five upper endpoints are still missing.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path[:0]=[str(PARENT/'prefix_continuity/frame_family_R3'),
             str(PARENT/'upper_continuity_review_R1/cam_math_review_R1'),
             str(PARENT/'upper_continuity_review_R1/native_clearance_review_R1'),
             str(PARENT/'upper_length_match_R1'), str(PARENT/'upper_smooth_review_R2')]
from selected_family import SelectedFamily,BSpline
from nominal_cam import NominalCAM,lengths
from power_native_envelopes import NativeEnvelopes
from piecewise_geometry import pieces,RADII
from sample_geometry import sample
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    started=time.time()
    prefix=SelectedFamily()
    cam=NominalCAM()
    power=NativeEnvelopes(poly_steps=2,stub_steps=2)
    arrays={};rows=[];full={}
    upper_names=[f'CAM_{i}' for i in range(1,5)]+['P_J18_1','P_J18_2','CC_allocation']
    for name in prefix.names:
        lower=pieces(BSpline(prefix.knots,prefix.candidate(name,0)['control'],3))
        upper=None
        if name.startswith('CAM_'):
            _,upper,_,info=cam.upper(name,0.,0.)
            target=cam.targets[name]
        elif name in upper_names:
            upper=power.reference(name,0.,0.)['controls']
            target=power.e.f.targets[name]
        for role,controls,radius in [('prefix',lower,prefix.radii[name]),
                                     ('upper',upper,RADII.get(name))]:
            if controls is None:
                continue
            prepared=sample(controls,max_step=.03)
            key=f'{name}__{role}'
            arrays[key+'__controls_mm']=controls
            arrays[key+'__points_mm']=prepared['points']
            L=float(lengths(controls).sum())
            rows.append(dict(key=key,wire=name,role=role,radius_capacity_mm=radius,
                             cubic_count=len(controls),point_count=len(prepared['points']),
                             chord_error_mm=prepared['error'],numeric_length_mm=L,
                             start_mm=controls[0,0].tolist(),end_mm=controls[-1,-1].tolist(),
                             endpoint_evidence='Existing reference datums; no physical free-end qualification'))
        if upper is not None:
            seam=float(np.linalg.norm(lower[-1,-1]-upper[0,0]))
            assert seam<1e-8
            L=float(lengths(lower).sum()+lengths(upper).sum())
            assert abs(L-target)<1e-5,(name,L,target)
            full[name]=dict(numeric_reference_mm=L,target_numeric_reference_mm=target,
                            seam_error_mm=seam,supplier_cut_length_mm=None)
        print('MOVING_BUNDLE_PREPARED',name,'complete' if upper is not None else 'prefix_only',flush=True)
    sources={**prefix.sources,**cam.sources,**power.sources,
             **{str(p):sha(p) for p in [Path(__file__),
                PARENT/'upper_length_match_R1/sample_geometry.py',
                PARENT/'upper_smooth_review_R2/piecewise_geometry.py',
                PARENT/'upper_continuity_review_R1/verify_power_math.py']}}
    assert all(sha(p)==h for p,h in sources.items())
    target=HERE/'bundle_zero.npz';np.savez_compressed(target,**arrays)
    output=dict(status='PASS',scope='Exact zero-pose unadopted capacity arrays only; not an entry result',
                recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
                arrays_sha256=sha(target),rows=rows,prefix_sections=12,upper_sections=7,
                known_complete_references=full,missing_upper_references=sorted(set(prefix.names)-set(upper_names)),
                actual_free_ends='BLOCKED',actual_materials_and_terminals='BLOCKED',
                full_wired_assembly='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,
                manufacturing_release=False,elapsed_s=time.time()-started)
    assert len(rows)==19 and len(full)==7 and len(output['missing_upper_references'])==5
    (HERE/'bundle_receipt.json').write_text(json.dumps(output,indent=2)+'\n')
    print('MOVING_BUNDLE_ZERO_RECEIPT',12,7,5,round(output['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
