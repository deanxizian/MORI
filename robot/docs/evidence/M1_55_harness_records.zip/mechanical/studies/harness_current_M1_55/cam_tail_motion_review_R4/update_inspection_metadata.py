"""Mark the tested candidate blocked and label only owned inspection copies."""
from pathlib import Path
import bpy
import hashlib
import json
import datetime

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=HERE/'render_manifest.json';d=json.loads(manifest.read_text())
saved=HERE/d['inspection_file'];assert Path(bpy.data.filepath).resolve()==saved and sha(saved)==d['inspection_sha256']
owner=d['review_owner'];before=sha(saved);scenes=0;copies=0
for scene in bpy.data.scenes:
    if scene.get('review_owner')==owner:
        scene['candidate_status']='BLOCKED';scene['full_harness']='BLOCKED'
        scene['scope']='Zero-pose comparison; candidate failed at pitch15/17.5deg in fuller finite checks'
        scenes+=1
for o in bpy.data.objects:
    if o.get('review_owner')==owner and o.get('source_object'):
        source=bpy.data.objects[o['source_object']]
        o['category']=source.get('category','PLACEHOLDER');o['data_status']=source.get('data_status','ASSUMED')
        o['role']='validation_geometry_copy';o['export_candidate']=False
        copies+=1
assert scenes==2 and copies==34
bpy.ops.wm.save_as_mainfile(filepath=str(saved),compress=True)
d['inspection_sha256']=sha(saved);d['metadata_update_script']=Path(__file__).name
d['metadata_update_script_sha256']=sha(Path(__file__));d['candidate_full_motion_status']='BLOCKED'
manifest.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(HERE/'metadata_update_receipt.json').write_text(json.dumps(dict(status='PASS',scope='Owned inspection metadata only, geometry requires separate readback',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_sha256=before,after_sha256=sha(saved),
    labeled_scenes=scenes,labeled_copies=copies,main_changed=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('INSPECTION_METADATA_UPDATED',scenes,copies,flush=True)
