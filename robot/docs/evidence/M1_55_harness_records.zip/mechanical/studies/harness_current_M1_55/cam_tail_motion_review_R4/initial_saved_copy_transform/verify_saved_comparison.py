"""Read the saved inspection back; retain source native solids and actual curves."""
from pathlib import Path
import sys
import json
import datetime

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT));from context import Context,np,bpy,ROOT,sha,PREFIX,parts,load_collections,assembled
from validate import Solid
sys.path.insert(0,str(HERE));from render_comparison import points


def main():
    ctx=Context();manifest=HERE/'render_manifest.json';d=json.loads(manifest.read_text())
    assert d['status']=='PASS' and all(sha(p)==h for p,h in d['sources'].items())
    expected={n:dict(v=s.v.copy(),f=s.f.copy(),matrix=np.array(s.o.matrix_world)) for n,s in ctx.ss.items()}
    saved=HERE/d['inspection_file'];assert sha(saved)==d['inspection_sha256']
    original_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    candidate_path=PARENT/'cam_tail_simplification_R7/zero_curves.npz'
    original=np.load(original_path);candidate=np.load(candidate_path)
    ctx.record([Path(__file__),HERE/'render_comparison.py',manifest,original_path,candidate_path,saved])
    bpy.ops.wm.open_mainfile(filepath=str(saved))
    bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled();bpy.context.view_layer.update()
    current={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.type=='MESH' and o.get('group') not in ['dock','coupon']}
    assert set(current)==set(expected) and len(current)==201
    for name,s in current.items():
        before=expected[name]
        assert np.array_equal(s.f,before['f']) and np.array_equal(s.v,before['v']),name
        assert np.array_equal(np.asarray(s.o.matrix_world),before['matrix']),name
    rows=[];wire_rows=[]
    for label in ['original','candidate']:
        scene=next(s for s in bpy.data.scenes if s.name in d['scenes'] and s.name.endswith(label.upper()))
        assert scene['full_harness']=='BLOCKED' and scene['manufacturing_release'] is False
        for o in scene.objects:
            if o.get('source_object'):
                key=o['source_object'].removeprefix(PREFIX);s=Solid(o);before=expected[key]
                assert np.array_equal(s.f,before['f']),o.name
                delta=float(np.max(np.abs(s.v-before['v'])))
                assert delta<1e-4,(o.name,delta)
                rows.append(dict(object=o.name,source=key,world_vertex_max_component_error_mm=delta,status='PASS'))
            if o.get('role')=='upper_routing_reference':
                name=o.name.rsplit('_CAM_',1)[-1];wire='CAM_'+name
                arrays=original if label=='original' else candidate
                key=f'{wire}_y0_p0_controls' if label=='original' else wire+'_controls'
                want=points(arrays[key]);actual=np.array([tuple(p.co)[:3] for p in o.data.splines[0].points])
                assert actual.shape==want.shape
                delta=float(np.max(np.linalg.norm(actual-want,axis=1)));assert delta<2e-5,(o.name,delta)
                assert abs(o.data.bevel_depth-.3302)<1e-7
                assert o['category']=='PLACEHOLDER' and o['data_status']=='ASSUMED'
                wire_rows.append(dict(object=o.name,source_key=key,points=len(actual),max_vertex_error_mm=delta,status='PASS'))
    assert len(rows)==2*len(d['copied_native_parts'])==34 and len(wire_rows)==8
    ctx.unchanged()
    out=dict(status='PASS',scope='Saved inspection identities and sampling only; not actual hardware or full motion',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
             original_native_parts_unchanged=201,copied_native_checks=rows,wire_readback_checks=wire_rows,
             copied_native_component_error_limit_mm=1e-4,wire_storage_error_limit_mm=2e-5,
             full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'saved_inspection_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CAM_TAIL_SAVED_COMPARISON_VERIFIED',len(current),len(rows),len(wire_rows),flush=True)


if __name__=='__main__':main()
