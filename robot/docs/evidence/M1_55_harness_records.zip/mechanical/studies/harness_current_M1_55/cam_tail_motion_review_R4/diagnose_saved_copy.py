"""Read transform/proxy metadata for the failed copied reaction-link audit."""
import bpy
import json
names=['MORI_V1_Yaw_Reaction_Link','M155_CAM_TAIL_COMPARISON_R1_original_Yaw_Reaction_Link',
       'M155_CAM_TAIL_COMPARISON_R1_candidate_Yaw_Reaction_Link']
for name in names:
    o=bpy.data.objects.get(name)
    if o is None:
        print('NOT_FOUND',name);continue
    fields={k:o.get(k) for k in ['validation_proxy','validation_solid_source','mori_owner','group','source_object']}
    print('COPY_TRANSFORM_DIAGNOSTIC',json.dumps(dict(name=name,matrix_world=[list(r) for r in o.matrix_world],
        parent=o.parent.name if o.parent else None,fields=fields,
        constraints=[dict(name=c.name,type=c.type) for c in o.constraints],
        animation_data=bool(o.animation_data)),ensure_ascii=False),flush=True)
