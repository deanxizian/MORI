"""Publish a scoped shorter-tail diagnostic without claiming a full harness."""
from pathlib import Path
from collections import Counter
from urllib.parse import urlsplit
from urllib.request import Request,urlopen
import datetime
import hashlib
import html
import json
import re
import sys

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent;PROJECT=HERE.parents[3]
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    zero_path=PARENT/'cam_tail_simplification_R7/zero_review.json'
    math_path=HERE/'curve_math.json';pilot_path=HERE/'pilot_geometry.json';render_path=HERE/'render_manifest.json'
    saved_path=HERE/'saved_inspection_verification.json'
    full_paths=[HERE/f'worker_{i}_geometry.json' for i in [0,1]]
    zero,math,pilot,render=[read(p) for p in [zero_path,math_path,pilot_path,render_path]]
    saved=read(saved_path);full=[read(p) for p in full_paths]
    assert saved['status']=='PASS' and saved['original_native_parts_unchanged']==201
    assert all(d['status']=='BLOCKED' and d['failures'] for d in full)
    assert zero['status']==math['status']==render['status']=='PASS'
    assert math['checked_curve_poses']==len(math['rows'])==1900 and len(math['planned_poses'])==475
    assert math['selected_variant']=='R7' and math['parameters']==zero['selected']['candidate_parameters']
    assert sha(HERE/'curves.npz')==math['arrays_sha256']
    assert pilot['status'] in ['PASS','BLOCKED']
    counts=Counter(r['kind'] for r in pilot['rows']);assert dict(counts)==pilot['counts']
    poses={(r['yaw_deg'],r['pitch_deg']) for r in pilot['rows']}
    assert len(pilot['rows'])==86*len(poses)
    if pilot['status']=='PASS':assert len(pilot['rows'])==1032 and len(poses)==12 and not pilot['failures']
    else:assert pilot['failures'] and len(poses)<=12
    sources={}
    unique={}
    for d in [pilot,*full]:
        for r in d['rows']:
            key=(r['yaw_deg'],r['pitch_deg'],r['kind'],r.get('wire'),tuple(r.get('wires',[])),r.get('group'))
            if key in unique:assert unique[key]['status']==r['status']
            unique[key]=r
    actual_poses={(r['yaw_deg'],r['pitch_deg']) for r in unique.values()}
    failed=[r for r in unique.values() if r['status']!='PASS']
    assert len(unique)==86*len(actual_poses) and failed
    for d in [zero,math,pilot,render,saved,*full]:
        for p,h in d['sources'].items():
            assert p not in sources or sources[p]==h
            sources[p]=h
    assert all(sha(p)==h for p,h in sources.items())
    assert all(sha(HERE/r['file'])==r['sha256'] for r in render['files'])
    assert sha(HERE/render['inspection_file'])==render['inspection_sha256']
    visual=read(HERE/'visual_review.json');assert visual['status']=='PASS' and visual['files']==render['files']
    failures=[]
    for folder in ['cam_tail_simplification_R1','cam_tail_simplification_R2','cam_tail_simplification_R3',
                   'cam_tail_simplification_R4','cam_tail_simplification_R5','cam_tail_simplification_R6']:
        p=PARENT/folder/'zero_review.json';d=read(p)
        failures.append(dict(source=str(p.relative_to(PROJECT)),zero_status=d['status'],sha256=sha(p)))
    for folder,file in [('cam_tail_motion_review_R1','worker_0_geometry.json'),
                        ('cam_tail_motion_review_R1','worker_1_geometry.json'),
                        ('cam_tail_motion_review_R3','pilot_geometry.json')]:
        p=PARENT/folder/file;d=read(p);assert d['status']=='BLOCKED' and d['failures']
        failures.append(dict(source=str(p.relative_to(PROJECT)),status=d['status'],checks=len(d['rows']),sha256=sha(p)))
    main_path=PROJECT/'mechanical/mori_v1_2.blend';video_path=PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(main_path)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video_path)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    rows=''.join(f'<tr><td>{r["wire"]}</td><td>{r["old_fixed_tail_numeric_mm"]:.3f}</td><td>{r["new_fixed_tail_numeric_mm"]:.3f}</td><td>{r["saving_mm"]:.3f}</td></tr>' for r in math['tail_changes'])
    result=dict(status='PASS',scope='Publication and scoped diagnostic audit only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        input_hashes={str(p):sha(p) for p in [zero_path,math_path,pilot_path,render_path,saved_path,*full_paths,HERE/'visual_review.json',Path(__file__)]},
        zero_geometry='PASS',finite_curve_math='PASS',curve_poses=1900,finite_poses=475,
        finite_pilot_geometry=pilot['status'],pilot_actual_poses=len(poses),pilot_planned_poses=12,
        pilot_checks=len(pilot['rows']),pilot_failures=len(pilot['failures']),tail_changes=math['tail_changes'],
        retained_attempt_receipts=failures,full_475_native_geometry='BLOCKED',
        actual_unique_geometry_poses=len(actual_poses),actual_unique_geometry_checks=len(unique),
        failed_geometry_rows=failed,finite_pilot_not_full_motion=True,
        saved_inspection_readback='PASS',full_harness='BLOCKED',
        actual_material_and_cut_lengths='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,
        main_sha256=sha(main_path),video_sha256=sha(video_path),manufacturing_release=False)
    (HERE/'progress_receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 CAM尾线路径比较</title>
<style>body{{max-width:1080px;margin:32px auto;padding:0 18px 60px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}img{{width:100%;height:auto}}.pair{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}figure{{margin:0}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:10px;border-bottom:1px solid #d9e1e5;text-align:left}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}@media(max-width:700px){{.pair{{grid-template-columns:1fr}}}}</style>
<h1>M1.55 · CAM固定尾线路径比较</h1><p>2026-10-09 · <strong>独立参考候选，尚未采用。</strong></p>
<p>保留实际PCB、打印件与原参考端点，四根固定尾段一同侧向绕行，再从USB预留空间下方接入。回转最低点保持；原运动余量圈的构造保留。为避免抬头时靠近电源线，前向回转半径从9增至9.5mm。</p>
<p class="notice">4根CAM×475个有限姿态：1,900条整段曲率、切向接续、端点与公共数值长度检查PASS。12个试探姿态、1,032项间隙检查通过；扩展到完整网格后，在抬头15°／17.5°发现自身及跨线相交，候选<strong>BLOCKED，不采用</strong>。合并重复检查后，实际覆盖{len(actual_poses)}个姿态、{len(unique)}项，失败{len(failed)}项；两分区遇失败即停止，没有执行剩余姿态。所有路线为PLACEHOLDER / ASSUMED，数值长度不能用于供应商裁线。</p>
<table><tr><th>参考</th><th>原固定尾段mm</th><th>候选固定尾段mm</th><th>缩短mm</th></tr>{rows}</table>
<h2>零位对比</h2><p>灰色及板卡使用当前原生验证网格；供应商代理的已有局限保留，不能把这些图当作完整厂家细节或实际装配。壳体为观察而省略。</p><div class="pair"><figure><img src="original_rear.png" alt="原参考后视"><figcaption>原参考后视</figcaption></figure><figure><img src="candidate_rear.png" alt="候选后视"><figcaption>候选后视：橙色线及金色USB均为分配参考</figcaption></figure></div>
<div class="pair"><figure><img src="original_front.png" alt="原参考前视"><figcaption>原参考前视</figcaption></figure><figure><img src="candidate_front.png" alt="候选前视"><figcaption>候选前视；不代表带线装配或实物接头验证</figcaption></figure></div>
<h2>保留的失败与边界</h2><p>从上方直接接入会与USB预留空间相交；简单向外移会碰后壳／头托。降低绕行高度会导致自身／跨线接近。侧向候选R4在低头边界未通过，R6在抬头边界与电源线的净距低于0.3mm目标。这些记录全部保留；零位PASS不能代替运动检查。</p>
<p>继续使用已通过475姿态检查的原7条参考，停止采用这批压低绕行的短尾线。完整线束仍剩4类工作：补齐5条上段与运动、实际材料和线长、端接与应力释放、带线装入与闭壳。舵机／喇叭端点、微雪排线及CAM供电源端仍需资料或实物确认。</p>
<p><a href="progress_receipt.json">本轮独立汇总</a> · <a href="curve_math.json">475姿态曲线检查</a> · <a href="pilot_geometry.json">试探间隙结果</a> · <a href="worker_0_geometry.json">分区0失败见证</a> · <a href="worker_1_geometry.json">分区1失败见证</a> · <a href="saved_inspection_verification.json">保存后回读</a> · <a href="initial_saved_copy_transform/receipt.json">首张对比的变换诊断</a> · <a href="render_manifest.json">渲染来源</a> · <a href="{render['inspection_file']}">可编辑对比Blender</a> · <a href="../cam_tail_simplification_R7/zero_review.json">零位与参数</a> · <a href="../cam_tail_motion_review_R3/pilot_geometry.json">R6抬头不足记录</a> · <a href="../index.html">线束总览</a> · <a href="../upper_motion_family_R1/index.html">原7条参考475姿态结果</a></p>
<p>主模型M1.55、视频M1.55-A1和硬件保持；PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text(f'# CAM尾线比较：拒绝采用\n\n475个姿态、1900条曲线检查PASS。\n12个试探姿态1032项间隙通过；完整网格在15/17.5度抬头出现自碰/跨线相交。\n合并重复后实际{len(actual_poses)}个姿态、{len(unique)}项，失败{len(failed)}项；两分区遇失败停止。\n候选BLOCKED，继续使用原7条475姿态通过的参考，不把曲率/零位/试探通过当作完整运动通过。\n对比的首场景曾有变换复制问题；两次诊断的文件/代码/图/log保留在initial_saved_copy_transform与second_saved_copy_matrix。\n现版复制已捕捉的原生验证世界网格，供应商代理局限保留；回读201原生零件、34复制件和8根显示曲线。\n主模型／动画／硬件未改，完整线束BLOCKED，制造未放行。\n')
    links=[]
    for link in re.findall(r'(?:href|src)="([^"]+)"',page):
        parsed=urlsplit(link)
        if parsed.scheme or not parsed.path:continue
        target=(HERE/parsed.path).resolve();assert target.is_file() and target.is_relative_to(PROJECT)
        url='http://127.0.0.1:58202/'+str(target.relative_to(PROJECT))
        with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
        links.append(str(target.relative_to(PROJECT)))
    files=[HERE/n for n in ['index.html','README.md','progress_receipt.json','publish_progress.py','visual_review.json']]+[HERE/r['file'] for r in render['files']]
    (HERE/'publication_verification.json').write_text(json.dumps(dict(status='PASS',scope='Scoped files, input identities and HTTP only',
        files={p.name:sha(p) for p in files},checked_links=links,full_harness='BLOCKED',manufacturing_release=False,
        publish_command=[sys.executable,str(Path(__file__))],cwd=str(PROJECT)),ensure_ascii=False,indent=2)+'\n')
    print('CAM_TAIL_DIAGNOSTIC_PUBLISHED',pilot['status'],len(pilot['rows']),len(links),flush=True)


if __name__=='__main__':main()
