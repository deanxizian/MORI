"""Recheck and optimize explicit spline knots missed by a uniform search grid.

The previous independent verification rejected CAM1/CAM2 curvature. This
keeps that result, fixes the search sampling, and creates a new candidate.
"""
from pathlib import Path
import datetime
import json
import time
import numpy as np
from optimize_anchored_zero import Search,Context,BeamAnchorFamily,NAMES,sha,engine

HERE=Path(__file__).resolve().parent
OUT=HERE/'anchored_zero_refined';OUT.mkdir(exist_ok=True)


class KnotAwareSearch(Search):
    def __init__(self,native,family,seed,count):
        super().__init__(native,family,seed,count)
        edges=np.unique(family.knots)
        ts=np.unique(np.r_[np.linspace(0,1,count),edges,(edges[:-1]+edges[1:])/2])
        self.problem.n=len(ts)
        for name,it in self.problem.items.items():
            self.problem.ts[name]=ts
            self.problem.B[name]=engine.basis(it['knot'],ts)
            self.problem.D[name]=engine.basis(it['knot'],ts,1)
            self.problem.A[name]=engine.basis(it['knot'],ts,2)
            self.problem.reference[name]=self.problem.B[name]@it['control']
        self.problem.last=None;self.last=None


def main():
    from scipy.optimize import least_squares
    started=time.time();native=Context();family=BeamAnchorFamily(4,4.)
    source=HERE/'anchored_zero_search/candidate_420.npz'
    failed=HERE/'optimized_zero_verification.json';verification=json.loads(failed.read_text())
    assert verification['status']=='BLOCKED' and len(verification['failures'])==2
    assert all(r['wire'] in ['CAM_1','CAM_2'] for r in verification['failures'])
    assert all(sha(p)==h for p,h in verification['sources'].items())
    data=np.load(source);seed={n:data[n+'_controls'] for n in NAMES}
    problem=KnotAwareSearch(native,family,seed,1001);x=problem.base[problem.mask]
    before=problem.evaluate(x)[2]
    print('BODY_ANCHORED_KNOT_REFINE_START',problem.problem.n,before,flush=True)
    calls=[0]
    def callback(values):
        calls[0]+=1
        if calls[0]%5==0:
            print('BODY_ANCHORED_KNOT_REFINE_ITER',calls[0],problem.evaluate(values)[2],time.time()-started,flush=True)
    sol=least_squares(lambda a:problem.evaluate(a)[0],x,jac=lambda a:problem.evaluate(a)[1],
        bounds=(x-2.,x+2.),method='trf',tr_solver='lsmr',tr_options=dict(maxiter=180),
        max_nfev=60,ftol=1e-7,xtol=1e-7,gtol=1e-5,callback=callback)
    controls=problem.controls(sol.x)
    fixed=max(float(np.max(abs(controls[n][:family.locked_controls[n]]-family.fixed[n][:family.locked_controls[n]]))) for n in NAMES)
    assert fixed<1e-12
    target=OUT/'candidate_1001.npz'
    np.savez_compressed(target,**{n+'_controls':c for n,c in controls.items()},knots=family.knots)
    native.record([Path(__file__),HERE/'optimize_anchored_zero.py',source,failed]);native.unchanged();family.unchanged()
    report=dict(status='PASS',scope='Knot-aware optimizer execution only; fresh independent verification required',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources|family.sources,
        samples_per_wire=problem.problem.n,explicit_all_knots_included=True,
        initial=before,final=problem.evaluate(sol.x)[2],solver_success=bool(sol.success),solver_status=int(sol.status),
        message=sol.message,nfev=int(sol.nfev),cost=float(sol.cost),fixed_control_error_mm=fixed,
        candidate_sha256=sha(target),targets={n:family.targets[n] for n in NAMES},anchor_datums=family.anchor_datums,
        native_fit='NOT_TESTED',exact_curve_bending='NOT_TESTED',actual_retention='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (OUT/'optimization.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_ANCHORED_KNOT_REFINE_TERMINAL',report['final'],report['elapsed_s'],flush=True)


if __name__=='__main__':main()
