"""Constrained zero-pose search for genuinely fixed CAM body leads.

Uses current native surfaces and eight unchanged neighbouring references.
The body restraint region and end controls are removed from solver variables.
Solver success is never geometry, physical, or manufacturing qualification.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,sha
sys.path.insert(0,str(HERE))
from beam_anchor_family import BeamAnchorFamily
from fixed_lead_family import NAMES,BSpline
SCIPY=Path('/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
sys.path.insert(0,str(SCIPY))
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix,vstack

SOLVER=PARENT/'global_bundle_layout/solve.py'
spec=importlib.util.spec_from_file_location('_mori_existing_joint_search',SOLVER)
engine=importlib.util.module_from_spec(spec);spec.loader.exec_module(engine)
OUT=HERE/'anchored_zero_search';OUT.mkdir(exist_ok=True)
engine.HERE=OUT
engine.OPT_RADIUS=7.05
engine.OPT_GAP=.42


class Search:
    def __init__(self,native,family,seed,count):
        self.family=family;self.names=NAMES;self.count=count
        items={n:dict(knot=family.knots,control=seed[n],radius=.565,target_length=family.targets[n]) for n in NAMES}
        self.problem=engine.Problem(native,items,count)
        self.base=np.concatenate([seed[n][2:-2].ravel() for n in NAMES])
        self.mask=np.concatenate([np.arange(i*44*3+(family.locked_controls[n]-2)*3,(i+1)*44*3) for i,n in enumerate(NAMES)])
        self.neighbours={}
        ts=np.linspace(0,1,1601)
        for n in family.names:
            if n in NAMES:continue
            p=BSpline(family.knots,family.candidate(n,0)['control'],3)(ts)
            self.neighbours[n]=dict(points=p,tree=cKDTree((p[:-1]+p[1:])/2),radius=family.radii[n])
        self.last=None

    def full(self,x):
        values=self.base.copy();values[self.mask]=x;return values

    def controls(self,x):return self.problem.unpack(self.full(x))

    def evaluate(self,x):
        if self.last is not None and np.array_equal(self.last[0],x):return self.last[1:]
        full=self.full(x);r,j,stats=self.problem.evaluate(full)
        c=self.problem.unpack(full);extra=[];rr=[];cc=[];vv=[];offset=0;peer_min=float('inf')
        for i,n in enumerate(NAMES):
            b=self.problem.B[n];p=b@c[n]
            for other,item in self.neighbours.items():
                q=item['points'];_,near=item['tree'].query(p)
                options=[]
                for k in [np.clip(near-1,0,len(q)-2),near,np.clip(near+1,0,len(q)-2)]:
                    u=q[k+1]-q[k]
                    t=np.clip(np.sum((p-q[k])*u,axis=1)/np.maximum(np.sum(u*u,axis=1),1e-18),0,1)
                    delta=p-(q[k]+t[:,None]*u);d=np.linalg.norm(delta,axis=1)
                    options.append((d,delta))
                ds=np.stack([a[0] for a in options]);idx=np.argmin(ds,axis=0)
                dist=ds[idx,np.arange(len(p))];delta=np.stack([a[1] for a in options])[idx,np.arange(len(p))]
                gap=dist-.565-item['radius'];peer_min=min(peer_min,float(gap.min()))
                pen=np.maximum(.42-gap,0);gradient=-20*delta/np.maximum(dist[:,None],1e-9)*(pen>0)[:,None]
                extra.append(20*pen)
                row,col=np.nonzero((abs(b[:,2:-2])>1e-15)&(pen>0)[:,None])
                axes=np.tile(np.arange(3),len(row))
                rr.append(offset+np.repeat(row,3));cc.append(i*44*3+np.repeat(col,3)*3+axes)
                vv.append(np.repeat(b[row,col+2],3)*gradient[row].ravel());offset+=len(p)
            # True spline Gauss64 arc constraint, rather than the search
            # polyline's low-weight length penalty in the original helper.
            v=self.family.Q@c[n];speed=np.linalg.norm(v,axis=1)
            length=float(self.family.weights@speed)
            gradient=self.family.Q.T@(self.family.weights[:,None]*v/np.maximum(speed[:,None],1e-12))
            values=gradient[2:-2].ravel()*20.;ids=np.flatnonzero(abs(values)>1e-15)
            extra.append(np.array([20*(length-self.family.targets[n])]))
            rr.append(np.full(len(ids),offset));cc.append(i*44*3+ids);vv.append(values[ids]);offset+=1
        added=np.concatenate(extra)
        jac=coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(offset,len(full))).tocsr()
        stats=dict(stats,minimum_sampled_fixed_neighbour_gap_mm=peer_min)
        residual=np.r_[r,added];jacobian=vstack([j,jac],format='csr')[:,self.mask]
        self.last=(x.copy(),residual,jacobian,stats)
        return residual,jacobian,stats


def main():
    started=time.time();native=Context();family=BeamAnchorFamily(4,4.)
    pilot=HERE/'beam_blend4_pilot_geometry.json';proof=json.loads(pilot.read_text())
    assert proof['status']=='BLOCKED' and proof['checked_yaws']==[0]
    seed_path=HERE/'beam_blend4_pilot_controls.npz';assert sha(seed_path)==proof['arrays_sha256']
    seed={n:np.load(seed_path)[f'{n}_y0_controls'] for n in NAMES}
    native.record([Path(__file__),SOLVER,pilot,seed_path]);sources=native.sources|family.sources
    stages=[]
    for count,maximum in [(220,60),(420,60)]:
        search=Search(native,family,seed,count);x=search.base[search.mask];before=search.evaluate(x)[2]
        print('BODY_ANCHORED_SEARCH_START',count,before,flush=True)
        calls=[0]
        def callback(values):
            calls[0]+=1
            if calls[0]%5==0:
                print('BODY_ANCHORED_SEARCH_ITER',count,calls[0],search.evaluate(values)[2],time.time()-started,flush=True)
        sol=least_squares(lambda a:search.evaluate(a)[0],x,jac=lambda a:search.evaluate(a)[1],
            bounds=(x-5.,x+5.),method='trf',tr_solver='lsmr',tr_options=dict(maxiter=180),
            max_nfev=maximum,ftol=1e-7,xtol=1e-7,gtol=1e-5,callback=callback)
        seed=search.controls(sol.x);after=search.evaluate(sol.x)[2]
        fixed=max(float(np.max(abs(seed[n][:family.locked_controls[n]]-family.fixed[n][:family.locked_controls[n]]))) for n in NAMES)
        assert fixed<1e-12
        stages.append(dict(samples=count,solver_success=bool(sol.success),solver_status=int(sol.status),message=sol.message,nfev=int(sol.nfev),cost=float(sol.cost),initial=before,final=after,fixed_control_error_mm=fixed))
        np.savez_compressed(OUT/f'candidate_{count}.npz',**{n+'_controls':c for n,c in seed.items()},knots=family.knots)
        print('BODY_ANCHORED_SEARCH_STAGE',count,after,flush=True)
    native.unchanged();family.unchanged()
    report=dict(status='PASS',scope='Completed constrained search only; independent continuous-curve and native checks still required',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,stages=stages,anchor_datums=family.anchor_datums,
        targets={n:family.targets[n] for n in NAMES},variable_scope='Only four CAM prefixes, after their fixed body contact span; end controls fixed',
        candidate_file='candidate_420.npz',candidate_sha256=sha(OUT/'candidate_420.npz'),
        native_fit='NOT_TESTED',exact_curve_bending='NOT_TESTED',selected_material='BLOCKED',actual_retention='NOT_TESTED',
        main_changed=False,hardware_changed=False,animation_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-started)
    (OUT/'optimization.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_ANCHORED_SEARCH_TERMINAL',time.time()-started,flush=True)


if __name__=='__main__':main()
