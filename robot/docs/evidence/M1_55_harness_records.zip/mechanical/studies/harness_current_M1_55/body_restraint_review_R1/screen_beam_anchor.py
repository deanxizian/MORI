"""Pilot curve math for fixed-bridge lead candidates and explicit slack."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
from beam_anchor_family import BeamAnchorFamily
from fixed_lead_family import NAMES,BSpline,sha

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,radius_bound


def main():
    started=time.time();results=[];arrays={};sources={}
    for blend in [4,8]:
        for extra in [0.,1.,2.,3.,4.,6.]:
            f=BeamAnchorFamily(blend,extra);rr=[]
            for yaw in [-60,0,60]:
                for name in NAMES:
                    try:
                        r=f.candidate(name,yaw);c=r['control'];bound=radius_bound(pieces(BSpline(f.knots,c,3)))
                        n=f.locked_controls[name]
                        fixed_error=float(np.max(abs(c[:n]-f.fixed[name][:n])))
                        ok=(bound['radius_lower_mm']>=6.865 and abs(r['reference_length_residual_mm'])<1e-8 and fixed_error<1e-12)
                        row=dict(wire=name,yaw_deg=yaw,status='PASS' if ok else 'BLOCKED',radius_lower_mm=bound['radius_lower_mm'],
                            required_radius_mm=6.865,reference_length_residual_mm=r['reference_length_residual_mm'],
                            fixed_control_error_mm=fixed_error,root_amplitude_mm=r['amplitude_mm'])
                        arrays[f'{name}_blend{blend}_extra{extra:g}_y{yaw}_controls']=c
                    except Exception as error:
                        row=dict(wire=name,yaw_deg=yaw,status='BLOCKED',error=repr(error))
                    rr.append(row)
            status='PASS' if all(r['status']=='PASS' for r in rr) else 'BLOCKED'
            results.append(dict(blend_controls=blend,extra_length_mm=extra,status=status,rows=rr,anchor_datums=f.anchor_datums))
            f.unchanged();sources.update(f.sources)
            print('BODY_BEAM_ANCHOR_PILOT',blend,extra,status,'failed',sum(r['status']!='PASS' for r in rr),flush=True)
    for p in [Path(__file__),PARENT/'upper_smooth_review_R2/piecewise_geometry.py']:
        sources[str(p)]=sha(p)
    np.savez_compressed(HERE/'beam_anchor_pilot_controls.npz',**arrays)
    out=dict(status='PASS',scope='Completed candidate screening only; no native/peer/physical restraint release',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,results=results,
        arrays_sha256=sha(HERE/'beam_anchor_pilot_controls.npz'),native_clearance='NOT_TESTED',peer_gap='NOT_TESTED',
        main_changed=False,hardware_changed=False,animation_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'beam_anchor_pilot_review.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BODY_BEAM_ANCHOR_PILOT_TERMINAL',[(r['blend_controls'],r['extra_length_mm']) for r in results if r['status']=='PASS'],out['elapsed_s'],flush=True)


if __name__=='__main__':main()
