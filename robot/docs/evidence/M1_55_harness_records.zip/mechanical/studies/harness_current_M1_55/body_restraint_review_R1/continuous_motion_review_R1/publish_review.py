"""Publish the new continuous body-reference proofs with their actual scope."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    names=['continuous_root_verification.json','continuous_bend_verification.json','motion_envelope_crosscheck.json',
           'changed_native_verification.json','changed_peer_verification.json','fixture_gap_verification.json']
    reports={n:json.loads((HERE/n).read_text()) for n in names};sources={}
    for n,d in reports.items():
        assert d['status']=='PASS',(n,d['status'])
        for p,h in d['sources'].items():
            assert sha(p)==h,(n,p)
            assert p not in sources or sources[p]==h;sources[p]=h
    assert reports['continuous_root_verification.json']['wire_count']==4
    assert reports['continuous_bend_verification.json']['wire_count']==4
    assert len(reports['changed_native_verification.json']['results'])==4
    assert reports['changed_peer_verification.json']['wire_pairs_completed']==38
    assert reports['changed_peer_verification.json']['remote_self_completed']==4
    assert len(reports['fixture_gap_verification.json']['results'])==12
    assert len(reports['motion_envelope_crosscheck.json']['unchanged_neighbours'])==8
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 新身体固定参考的连续运动</title><style>body{max-width:1080px;margin:2rem auto;padding:0 1rem;font:16px/1.75 system-ui;color:#24343d}a{color:#176687}.note{padding:16px;background:#fff2d5;border-left:4px solid #bf8b24}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd6dc;padding:8px;text-align:left}</style>
<h1>M1.55 · 新身体固定参考的连续运动</h1>
<p class="note">独立容量候选，未采用到主模型。通过的是所列身体／颈部参考范围；完整上段、实际线材、接续、端接、夹持强度和整机带线装配仍未完成。</p>
<p>新增身体固定点后，重新计算四根CAM线路，保持身体端至固定点的参考线形不动。真实板卡／孔位不动。Tensility最大外径1.13mm未选定；增加4mm为数值余量，不是裁线尺寸。</p>
<table><tr><th>范围</th><th>结果</th><th>边界</th></tr>
<tr><td>四根新身体段的Gauss64长度根</td><td>全−60°～+60°偏航通过</td><td>只有数值参考长度，不是实物拉伸或寿命</td></tr>
<tr><td>四根整段转弯</td><td>全偏航，R6.865mm参考界通过</td><td>不证明实际材料动态弯折性能</td></tr>
<tr><td>四根与当前201件原生实体</td><td>全偏航／−20°～+25°俯仰通过，2,842个偏航区间</td><td>真实供应商模型／测量局限保持；新固定结构另检</td></tr>
<tr><td>所有涉及四根新线的跨线及远端自接近</td><td>38组跨线＋4条远端自身，全偏航通过，12,339个区间</td><td>局部≤5mm相邻段排除有全角度弧长及曲率支持；完整上段不在此范围</td></tr>
<tr><td>12条身体／颈部参考与新短座、带身、扣头</td><td>全偏航通过，3,356个区间／453,060个曲线界单元</td><td>仅指定4根与座／带身允许不穿透接触；其他线、所有扣头关系保持0.3mm</td></tr>
<tr><td>算法与未变线输入</td><td>直接样条一致性检查，8条邻线的控制／方向／标量输入保持</td><td>这些一致性样本本身不是连续间隙证明；本轮未重跑纯未变线配对</td></tr></table>
<p>不是以更密的离散姿态替代连续检查：偏航区间内包含数值根、控制点运动、整段曲率或距离的界。失败的粗根界一致性断言保留；原8条未变线的旧算法检查与精确配置分别注明。</p>
<p><a href="continuous_root_verification.json">数值长度根</a> · <a href="continuous_bend_verification.json">转弯界</a> · <a href="changed_native_verification.json">当前原生实体</a> · <a href="changed_peer_verification.json">跨线与远端自接近</a> · <a href="fixture_gap_verification.json">新固定结构</a> · <a href="motion_envelope_crosscheck.json">一致性与未变输入</a> · <a href="../tie_access_review_R1/index.html">剪尾与装桥候选顺序</a> · <a href="../index.html">固定候选总览</a></p>
<p>PLACEHOLDER / ASSUMED（容量线路）· PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page+'\n')
    (HERE/'README.md').write_text('''# 新身体固定参考的连续运动，未采用

新4根CAM数值长度根、整段转弯、当前201原生实体全偏航／俯仰、38跨线＋4远端自身通过。
12条身体／颈部容量参考与新座、带身、扣头全偏航通过；只有4根与座／带身允许不穿透接触。
实体2842个偏航区间，跨线／远端自身12339个区间，固定结构3356个区间／453060曲线界单元。
8条未变邻线配置一致；未重跑纯未变配对，旧算法检查单独保留来源。
当前候选是容量参考，非实际线材、裁线、端子、夹持、全上段或完整带线装配资格。
主模型／动画／硬件未变，manufacturing_release=false。
''')
    sources[str(Path(__file__))]=sha(Path(__file__))
    for n in names:sources[str(HERE/n)]=sha(HERE/n)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json']}
    delivery=dict(status='PASS',scope='Scoped continuous body/neck candidate geometry, not complete harness fit',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        changed_curves=4,native_parts=201,changed_native_yaw_cells=2842,changed_peer_pairs=38,
        changed_remote_self=4,changed_peer_yaw_cells=12339,fixture_curves=12,fixture_yaw_cells=3356,
        fixture_curve_cells=453060,actual_harness='BLOCKED',full_upper_tails='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    print('BODY_CONTINUOUS_REVIEW_PUBLISHED',len(files),len(sources),flush=True)


if __name__=='__main__':main()
