"""Finite curve-math screening of fixed-body-lead transition variants."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
from blended_fixed_lead_family import BlendedFixedLeadFamily
from fixed_lead_family import NAMES,BSpline,sha
from screen_fixed_lead import partial_arc

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,radius_bound


def main():
    start=time.time();results=[];arrays={};sources={}
    for count in [6,7,8]:
        for blend in [4,6,8,10,12]:
            family=BlendedFixedLeadFamily(count,blend);rows=[]
            for yaw in [-60,0,60]:
                for name in NAMES:
                    try:
                        r=family.candidate(name,yaw);c=r['control'];spl=BSpline(family.knots,c,3)
                        bound=radius_bound(pieces(spl));arc=partial_arc(spl,family.knots[count])
                        ok=bound['radius_lower_mm']>=6.865 and abs(r['reference_length_residual_mm'])<1e-8 and arc>=10.
                        row=dict(wire=name,yaw_deg=yaw,status='PASS' if ok else 'BLOCKED',
                            required_radius_mm=6.865,continuous_curve_radius_lower_mm=bound['radius_lower_mm'],
                            fixed_parameter_end=float(family.knots[count]),fixed_material_length_numeric_mm=arc,
                            numeric_reference_length_residual_mm=r['reference_length_residual_mm'])
                        arrays[f'{name}_lock{count}_blend{blend}_y{yaw}_controls']=c
                    except Exception as error:
                        row=dict(wire=name,yaw_deg=yaw,status='BLOCKED',error=repr(error))
                    rows.append(row)
            status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED'
            results.append(dict(locked_controls=count,blend_controls=blend,status=status,rows=rows))
            family.unchanged();sources.update(family.sources)
            print('BODY_FIXED_BLEND_PILOT',count,blend,status,'failed',sum(r['status']!='PASS' for r in rows),flush=True)
    for p in [Path(__file__),HERE/'screen_fixed_lead.py',PARENT/'upper_smooth_review_R2/piecewise_geometry.py']:
        sources[str(p)]=sha(p)
    np.savez_compressed(HERE/'blended_pilot_controls.npz',**arrays)
    out=dict(status='PASS',scope='Completed finite candidate curve math; native, peer, real port and restraint checks remain required',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,results=results,
        array_sha256=sha(HERE/'blended_pilot_controls.npz'),selected_variant=None,
        native_clearance='NOT_TESTED',wire_pairs='NOT_TESTED',actual_body_restraint='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'blended_pilot_review.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BODY_FIXED_BLEND_PILOT_TERMINAL',[(r['locked_controls'],r['blend_controls']) for r in results if r['status']=='PASS'],out['elapsed_s'],flush=True)


if __name__=='__main__':main()
