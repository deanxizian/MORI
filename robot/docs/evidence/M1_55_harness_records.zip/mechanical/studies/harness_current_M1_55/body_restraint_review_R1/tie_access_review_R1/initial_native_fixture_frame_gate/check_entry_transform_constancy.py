"""Prove earlier animation obstacles are stationary over bridge entry.

Inspect complete scalar FCurve control hulls and all ancestor transforms;
do not promote half-frame readbacks alone into a continuous-motion proof.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import bpy
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
from assembly_animation import AP,SCENE_NAME,curves
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    report_path=HERE/'wired_bridge_entry_verification.json';entry=json.loads(report_path.read_text())
    assert entry['status']=='PASS' and all(sha(p)==h for p,h in entry['sources'].items())
    assert Path(bpy.data.filepath).resolve()==ROOT/'mori_assembly_animation.blend'
    scene=bpy.data.scenes[SCENE_NAME];bpy.context.window.scene=scene
    first=entry['path_control_hull_readback'][0]['frame_interval'][0]
    last=entry['path_control_hull_readback'][-1]['frame_interval'][1]
    scene.frame_set(first);bpy.context.view_layer.update()
    actors={o.name.removeprefix(AP):o for o in scene.objects if o.get('presentation_actor')}
    all_objects={}
    for n in entry['earlier_obstacle_ids']:
        o=actors[n]
        while o:
            all_objects[o.name]=o;o=o.parent
    transform_paths={'location','rotation_euler','rotation_quaternion','scale',
                     'delta_location','delta_rotation_euler','delta_rotation_quaternion','delta_scale'}
    rows=[]
    for name,o in all_objects.items():
        assert not o.constraints,(name,'unsupported constraints')
        assert not o.animation_data or not o.animation_data.drivers,(name,'unsupported drivers')
        channels=[]
        for fc in curves(o):
            if fc.data_path not in transform_paths:continue
            assert not fc.modifiers,(name,fc.data_path,'unsupported FCurve modifiers')
            reference=float(getattr(o,fc.data_path)[fc.array_index]);keys=list(fc.keyframe_points)
            assert keys and keys[0].co[0]<=first and keys[-1].co[0]>=last
            pieces=[]
            for a,b in zip(keys[:-1],keys[1:]):
                if b.co[0]<first or a.co[0]>last:continue
                if a.interpolation=='CONSTANT':values=[float(a.co[1])]
                elif a.interpolation=='LINEAR':values=[float(a.co[1]),float(b.co[1])]
                else:
                    assert a.interpolation=='BEZIER'
                    values=[float(a.co[1]),float(a.handle_right[1]),float(b.handle_left[1]),float(b.co[1])]
                error=max(abs(v-reference) for v in values);assert error<1e-7,(name,fc.data_path,error)
                pieces.append(dict(frame_interval=[float(a.co[0]),float(b.co[0])],
                    interpolation=a.interpolation,control_values=values,maximum_deviation=error,status='PASS'))
            assert pieces
            channels.append(dict(data_path=fc.data_path,array_index=fc.array_index,reference=reference,
                                 status='PASS',pieces=pieces))
        rows.append(dict(object=name,parent=o.parent.name if o.parent else None,
                         status='PASS',transform_channels=channels,constraints=0,drivers=0))
    sources=dict(entry['sources'])
    for p in [Path(__file__),report_path]:sources[str(p)]=sha(p)
    proof=dict(status='PASS',scope='Earlier rigid obstacle local transforms and ancestors constant throughout the saved bridge-entry frame interval',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        frame_interval=[first,last],earlier_obstacles=len(entry['earlier_obstacle_ids']),
        objects_and_ancestors_checked=len(rows),results=rows,transform_channel_control_tolerance=1e-7,
        obstacle_geometry='Current native validation solids; physical and supplier-model limitations retained',
        full_wired_assembly='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False)
    (HERE/'entry_transform_constancy.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('ENTRY_TRANSFORM_CONSTANCY_PASS',len(rows),'objects and ancestors',first,last,flush=True)


if __name__=='__main__':main()
