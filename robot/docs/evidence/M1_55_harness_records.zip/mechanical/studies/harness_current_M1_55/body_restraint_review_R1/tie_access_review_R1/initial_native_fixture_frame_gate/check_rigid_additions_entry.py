"""Continuous incremental pad and trimmed tie fit during bridge entry."""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,manifold,sha


def main():
    started=time.time();ctx=Context()
    entry_path=HERE/'wired_bridge_entry_verification.json';entry=json.loads(entry_path.read_text())
    assert entry['status']=='PASS' and all(sha(p)==h for p,h in entry['sources'].items())
    shape_path=HERE/'oriented_tie_geometry.npz';data=np.load(shape_path)
    shapes={key:manifold.Manifold(manifold.Mesh64(data[key+'_vertices'],data[key+'_faces']))
            for key in ['pad','tie_formed']}
    # The earlier animation fixtures were verified equal to their final
    # native world transforms; the separate ancestor proof supplies the
    # continuous constancy gate before publication.
    identity_error=max(r['earlier_fixture_matrix_error_mm'] for r in entry['actor_matrix_readback'])
    assert identity_error<.00005
    names=entry['earlier_obstacle_ids'];obstacles={n:ctx.targets[n] for n in names}
    results=[];failures=[]
    for key,shape in shapes.items():
        accepted=[]
        for segment,path in enumerate(entry['path_control_hull_readback']):
            a=np.array(path['translation_start_mm']);b=np.array(path['translation_end_mm'])
            todo=[(0.,1.,0)]
            while todo:
                lo,hi,depth=todo.pop();mid=(lo+hi)/2;position=a+(b-a)*mid
                movement=float(np.linalg.norm(b-a)*(hi-lo)/2)
                current=shape.translate(position.tolist());mesh=current.to_mesh64();v=np.array(mesh.vert_properties)[:,:3]
                vmin,vmax=v.min(0),v.max(0);near=[];bad=[]
                for n,t in obstacles.items():
                    cap=.30001+movement
                    if np.any(vmax+cap<t['lo']) or np.any(vmin-cap>t['hi']):continue
                    nominal=float(current.min_gap(t['m'],cap));lower=nominal-movement
                    row=dict(native=n,gap_lower_mm=lower,nominal_gap_mm=nominal)
                    near.append(row)
                    if lower<.3-1e-8:bad.append(row)
                if not bad:
                    accepted.append(dict(path_segment=segment,parameter_interval=[lo,hi],
                        status='PASS',nearby_native=near,translation_motion_bound_mm=movement));continue
                if depth<12:
                    todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
                failures.append(dict(feature=key,path_segment=segment,parameter_interval=[lo,hi],nearby_native=near))
                break
            if any(r['feature']==key for r in failures):break
        good=not any(r['feature']==key for r in failures)
        if good:
            for segment in range(len(entry['path_control_hull_readback'])):
                coverage=sorted(r['parameter_interval'] for r in accepted if r['path_segment']==segment)
                assert coverage[0][0]==0 and coverage[-1][1]==1
                assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        results.append(dict(feature=key,status='PASS' if good else 'BLOCKED',accepted_path_intervals=len(accepted),intervals=accepted))
        print('BRIDGE_RIGID_INCREMENT',key,results[-1]['status'],len(accepted),round(time.time()-started,2),flush=True)
    ctx.record([Path(__file__),shape_path,HERE/'oriented_tie_verification.json',entry_path]);ctx.unchanged()
    report=dict(status='PASS' if len(results)==2 and not failures else 'BLOCKED',
        scope='Incremental new pad and trimmed tie envelopes translated on current bridge entry; original bridge and physical fixtures not recertified',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        earlier_obstacle_ids=names,results=results,failures=failures,required_gap_mm=.3,
        requires_separate_entry_transform_constancy_gate=True,actual_tool_and_tie='NOT_TESTED',
        full_wired_assembly='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'rigid_additions_entry.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BRIDGE_RIGID_INCREMENT_TERMINAL',report['status'],round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
