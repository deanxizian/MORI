"""Editable independent world-mesh comparison, main model never saved here."""
from pathlib import Path
import datetime
import json
import math
import sys

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,bpy,Vector,sha,ROOT,P
sys.path.insert(0,str(HERE))
from flat_key_family import FlatKeyFamily,NAMES,BSpline
from fixed_lead_family import SelectedFamily
from restraint_geometry import PAD_LO,PAD_HI


def main():
    ctx=Context();family=FlatKeyFamily();original=SelectedFamily()
    owner='M155_BODY_RESTRAINT_COMPARISON_R1'
    assert not any(o.get('review_owner')==owner for o in bpy.data.objects)
    geometry_path=HERE/'restraint_geometry.npz';report_path=HERE/'restraint_geometry_verification.json'
    proof=json.loads(report_path.read_text());assert proof['status']=='PASS' and proof['geometry_sha256']==sha(geometry_path)
    assert all(sha(p)==h for p,h in proof['sources'].items())
    data=np.load(geometry_path)
    shown=['Yaw_Base','Yaw_Bearing','Yaw_Anti_Lift_Keeper','Pitch_Yoke','Yaw_Reaction_Link',
           'Load_Frame','MCU_Carrier','MCU_Motion','Plug_motion_J5','CAM_Mainboard']
    meshes={n:(ctx.ss[n].v.copy(),ctx.ss[n].f.copy()) for n in shown if n in ctx.ss}
    source_hash=sha(ROOT/'mori_v1_2.blend');views=[];scenes=[]
    palette=dict(native=(.36,.43,.46,1),board=(.12,.36,.28,1),reference=(.98,.58,.12,1),pad=(.15,.65,.72,1))
    for label in ['original','candidate']:
        scene=bpy.data.scenes.new(owner+'_'+label);bpy.context.window.scene=scene
        scene['review_owner']=owner;scene['source_revision']=P['revision'];scene['main_source_sha256']=source_hash
        scene['full_harness']='BLOCKED';scene['manufacturing_release']=False;scene['adopted']=False
        scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001;scene.unit_settings.length_unit='MILLIMETERS'
        scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1300;scene.render.resolution_y=1000
        scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
        scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
        scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True
        scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
        scene.world=bpy.data.worlds.new(owner+'_'+label+'_WORLD');scene.world.color=(.07,.09,.12)
        collection=bpy.data.collections.new(owner+'_'+label);scene.collection.children.link(collection)
        materials={}
        for key,rgba in palette.items():
            material=bpy.data.materials.new(owner+'_'+label+'_'+key);material.diffuse_color=rgba;materials[key]=material
        for n,(v,f) in meshes.items():
            if label=='candidate' and n=='Yaw_Base':v,f=data['Yaw_Base_candidate_vertices'],data['Yaw_Base_candidate_faces']
            mesh=bpy.data.meshes.new(owner+'_'+label+'_'+n);mesh.from_pydata(v.tolist(),[],f.tolist());mesh.update()
            mesh.materials.append(materials['board' if n=='MCU_Motion' else 'native']);mesh.materials.append(materials['pad'])
            if label=='candidate' and n=='Yaw_Base':
                for polygon in mesh.polygons:
                    center=np.mean(v[list(polygon.vertices)],axis=0)
                    if np.all(center>=PAD_LO-1e-6) and np.all(center<=PAD_HI+1e-6):polygon.material_index=1
            o=bpy.data.objects.new(mesh.name,mesh);collection.objects.link(o)
            o['review_owner']=owner;o['source_object']=ctx.ss[n].o.name;o['export_candidate']=False
            o['display_fidelity']='Native validation world mesh; proxy source limits retained'
            o['candidate_geometry']=label=='candidate' and n=='Yaw_Base'
        if label=='candidate':
            mesh=bpy.data.meshes.new(owner+'_TIE_ENVELOPE');mesh.from_pydata(data['tie_envelope_vertices'].tolist(),[],data['tie_envelope_faces'].tolist());mesh.update()
            mesh.materials.append(materials['reference']);o=bpy.data.objects.new(mesh.name,mesh);collection.objects.link(o)
            o['review_owner']=owner;o['category']='PLACEHOLDER';o['data_status']='ASSUMED'
            o['actual_product_selected']=False;o['formed_shape_verified']=False;o['export_candidate']=False
        for pin,n in enumerate(NAMES,1):
            c=(family if label=='candidate' else original).candidate(n,0)['control']
            xyz=BSpline(family.knots,c,3)(np.linspace(0,1,1801))
            curve=bpy.data.curves.new(owner+'_'+label+'_'+n,'CURVE');curve.dimensions='3D';curve.resolution_u=1
            curve.bevel_depth=.565;curve.bevel_resolution=3;line=curve.splines.new('POLY');line.points.add(len(xyz)-1)
            line.points.foreach_set('co',np.c_[xyz,np.ones(len(xyz))].ravel());curve.materials.append(materials['reference'])
            o=bpy.data.objects.new(curve.name,curve);collection.objects.link(o)
            o['review_owner']=owner;o['category']='PLACEHOLDER';o['data_status']='ASSUMED'
            o['role']='Unselected maxOD 1.13 body conductor routing reference';o['export_candidate']=False
            o['physical_mating']='BLOCKED';o['full_harness']='BLOCKED'
        camdata=bpy.data.cameras.new(owner+'_'+label+'_CAMERA');camera=bpy.data.objects.new(camdata.name,camdata);scene.collection.objects.link(camera)
        camdata.type='ORTHO';camdata.clip_start=.1;camdata.clip_end=800;scene.camera=camera
        for name,position,target,scale in [('underside',(90,-110,99),(27,-23,141),50),('rear',(88,-120,178),(28,-23,142),50)]:
            camera.location=position;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camdata.ortho_scale=scale
            destination=HERE/f'{label}_{name}.png';scene.render.filepath=str(destination);bpy.ops.render.render(write_still=True)
            views.append(dict(file=destination.name,sha256=sha(destination),scene=scene.name,view=name))
        scenes.append(scene.name)
    ctx.record([Path(__file__),geometry_path,report_path,HERE/'restraint_geometry.py'])
    ctx.unchanged();family.unchanged();original.unchanged()
    path=HERE/'M1_55_CAM_body_restraint_UNADOPTED.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(path),compress=True)
    assert sha(ROOT/'mori_v1_2.blend')==source_hash
    receipt=dict(status='PASS',scope='Independent editable zero-pose reference comparison with exact validation world meshes',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources|original.sources,
        review_owner=owner,scenes=scenes,copied_native_parts=list(meshes),files=views,inspection_file=path.name,
        inspection_sha256=sha(path),source_blend_sha256=source_hash,full_harness='BLOCKED',
        actual_wire_and_tie='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'render_manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('BODY_RESTRAINT_COMPARISON_RENDERED',len(views),len(meshes),flush=True)


if __name__=='__main__':main()
