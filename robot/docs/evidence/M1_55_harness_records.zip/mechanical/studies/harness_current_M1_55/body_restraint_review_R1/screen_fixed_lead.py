"""Finite mathematical screening of a genuinely fixed CAM body lead.

Detect the original motion at actual material coordinates, then test explicit
fixed-prefix variants without moving any PCB, plug, port or printed geometry.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from fixed_lead_family import FixedLeadFamily,NAMES,BSpline,sha,SelectedFamily
HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,radius_bound


def partial_arc(spl,t,order=64):
    x,w=np.polynomial.legendre.leggauss(order)
    edges=np.r_[np.unique(spl.t)[np.unique(spl.t)<t],t]
    total=0.
    for a,b in zip(edges[:-1],edges[1:]):
        u=(a+b)/2+(b-a)*x/2
        total+=(b-a)/2*float(w@np.linalg.norm(spl.derivative()(u),axis=1))
    return total


def point_at_material(spl,length):
    # Arc lookup is only a diagnostic of the original family. The new prefix
    # invariance below follows directly from identical B-spline controls.
    t=np.linspace(0,1,18001);p=spl(t)
    s=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
    return np.array([np.interp(length,s,p[:,k]) for k in range(3)])


def main():
    started=time.time();original=SelectedFamily();diagnostic=[]
    for name in NAMES:
        for s in [5.,10.,15.,20.,30.,50.]:
            points={y:point_at_material(BSpline(original.knots,original.candidate(name,y)['control'],3),s) for y in [-60,-30,0,30,60]}
            diagnostic.append(dict(wire=name,material_station_approx_mm=s,zero_point_mm=points[0].tolist(),
                maximum_motion_five_yaw_samples_mm=max(float(np.linalg.norm(p-points[0])) for p in points.values())))
    rows=[];arrays={};sources=dict(original.sources)
    for count in [3,4,5,6,7,8]:
        f=FixedLeadFamily(count);rr=[]
        for yaw in [-60,0,60]:
            for name in NAMES:
                try:
                    result=f.candidate(name,yaw);c=result['control'];spl=BSpline(f.knots,c,3)
                    bound=radius_bound(pieces(spl));end=f.knots[count]
                    arc=partial_arc(spl,end)
                    ok=(bound['radius_lower_mm']>=6.865 and abs(result['reference_length_residual_mm'])<1e-8)
                    row=dict(wire=name,yaw_deg=yaw,locked_controls=count,status='PASS' if ok else 'BLOCKED',
                        required_radius_mm=6.865,continuous_curve_radius_lower_mm=bound['radius_lower_mm'],
                        fixed_parameter_end=float(end),fixed_material_length_numeric_mm=float(arc),
                        original_ports_preserved=True,numeric_reference_length_residual_mm=result['reference_length_residual_mm'])
                    arrays[f'{name}_lock{count}_y{yaw}_controls']=c
                except Exception as error:
                    row=dict(wire=name,yaw_deg=yaw,locked_controls=count,status='BLOCKED',error=repr(error))
                rr.append(row)
        # Require >=10mm of genuinely fixed material for an interior restraint.
        length_ok=all(r.get('fixed_material_length_numeric_mm',0)>=10 for r in rr)
        status='PASS' if all(r['status']=='PASS' for r in rr) and length_ok else 'BLOCKED'
        rows.append(dict(locked_controls=count,status=status,minimum_fixed_material_length_numeric_mm=min(r.get('fixed_material_length_numeric_mm',0) for r in rr),
                         curve_math_rows=rr,minimum_required_fixed_material_mm=10.))
        sources.update(f.sources);f.unchanged()
        print('BODY_FIXED_LEAD_PILOT',count,status,'bad_curve_math',sum(r['status']!='PASS' for r in rr),'fixed_length_ok',length_ok,flush=True)
    original.unchanged();sources[str(Path(__file__))]=sha(Path(__file__))
    source_bound_path=PARENT/'upper_smooth_review_R2/piecewise_geometry.py'
    sources[str(source_bound_path)]=sha(source_bound_path)
    np.savez_compressed(HERE/'pilot_controls.npz',**arrays)
    out=dict(status='PASS',scope='Completed unadopted body-fixed-lead mathematical screening; no native or material release',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,original_station_motion=diagnostic,
        results=rows,selected_locked_controls=None,arrays_sha256=sha(HERE/'pilot_controls.npz'),
        native_clearance='NOT_TESTED',wire_pair_clearance='NOT_TESTED',actual_body_restraint='NOT_TESTED',
        actual_crimp_exit='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'pilot_review.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BODY_FIXED_LEAD_PILOT_TERMINAL',[(r['locked_controls'],r['status']) for r in rows],out['elapsed_s'],flush=True)


if __name__=='__main__':main()
