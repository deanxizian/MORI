"""Continuous yaw/pitch native-solid clearance for the R3 capacity prefixes.

Exact BVH reference samples are reused only with explicit whole-parameter
deformation envelopes, chord/sample allowances and native containment probes.
Each excluded AABB point has a proved capped gap; it is never given infinity.
Failure to enclose motion triggers a fresh reference and angle subdivision.
"""
from pathlib import Path
import sys,json,time,math
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
GENERIC=BASE/'prefix_continuity/frame_family_R3/continuous_gaps_R1'
OLD=GENERIC.parent
sys.path[:0]=[str(HERE),str(HERE.parent),str(BASE),str(GENERIC),str(OLD)]
from motion_envelopes import Envelopes,rotate
from flat_key_family import FlatKeyFamily,NAMES
from context import Context,transform_points,rigidtr,manifold,Vector,sha,P
from common import D
import numpy as np
HERE=Path(__file__).resolve().parent
GAP=.3;CAP=6.

def field(points,radius,error,half,targets):
    allowance=error+half+.0001;bound=radius+CAP+allowance
    values=np.full(len(points),CAP);closest=np.full(len(points),-1,dtype=np.int16);inside=[];queries=0
    names=list(targets)
    for oi,(name,t) in enumerate(targets.items()):
        ids=np.flatnonzero(np.all(points>=t['lo']-bound,axis=1)&np.all(points<=t['hi']+bound,axis=1))
        if not len(ids):continue
        distances=np.array([t['tree'].find_nearest(Vector(points[i]))[3] for i in ids]);queries+=len(ids)
        lower=distances-radius-allowance;use=lower<values[ids]
        values[ids[use]]=lower[use];closest[ids[use]]=oi
        for i in ids[np.r_[True,np.diff(ids)>1]]:
            q=points[i]
            if np.all(q>=t['lo']) and np.all(q<=t['hi']):
                probe=manifold.Manifold.sphere(.005,12).translate(q.tolist())
                if (probe^t['m']).volume()>probe.volume()/2:inside.append(dict(object=name,point_mm=q.tolist()))
    return dict(values=values,closest=closest,names=names,inside=inside,queries=queries,points=points,
                allowance=allowance,cap_mm=CAP)

def main():
    started=time.time();ctx=Context();f=FlatKeyFamily();e=Envelopes(f)
    input_path=HERE/'continuous_root_verification.json';proof=json.loads(input_path.read_text())
    cross=HERE/'motion_envelope_crosscheck.json';checked=json.loads(cross.read_text())
    assert proof['status']==checked['status']=='PASS'
    assert all(sha(p)==h for d in [proof,checked] for p,h in d['sources'].items())
    ctx.sources.update(f.sources)
    ctx.record([Path(__file__),GENERIC/'motion_envelopes.py',cross,input_path,OLD/'frame_motion_bounds.py',
                OLD.parent/'root_direction_R2/root_motion_bounds.py',GENERIC/'certify_native.py'])
    center=float(D['head_z']);pitch_radius=max(float(np.linalg.norm(ctx.ss[n].v[:,1:]-np.array([0.,center]),axis=1).max()) for n in ctx.groups['pitch'])
    cache={};curves={};queries=0;failures=[];results=[];minimum=float('inf');field_count=0
    def get_curve(name,yaw):
        key=name,yaw
        if key not in curves:curves[key]=e.curve(name,yaw)
        return curves[key]
    def get_field(name,yaw,group,pitch=0.):
        nonlocal queries,field_count
        key=name,yaw,group,pitch
        if key not in cache:
            curve=get_curve(name,yaw);p=curve['points']
            if group!='body':p=transform_points(p,np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0))))
            cache[key]=field(p,f.radii[name],curve['chord_error_mm'],curve['half_step_mm'],ctx.groups[group])
            queries+=cache[key]['queries'];field_count+=1
        return cache[key]
    def compare(name,lo,hi,anchor):
        envelope=e.control_envelopes(name,lo,hi,anchor)
        if envelope is None:return dict(status='BLOCKED',type='root_enclosure')
        records=[];bad=[];nominal=[]
        todo=[('body',0.,0.,0),('yaw',0.,0.,0)]+[('pitch',float(p),float(p+5),0) for p in range(-20,25,5)]
        while todo:
            group,pitch_lo,pitch_hi,pdepth=todo.pop()
            pmid=(pitch_lo+pitch_hi)/2
            ref=get_field(name,anchor,group,pmid)
            motion=envelope['world_point_bound_mm'] if group=='body' else envelope['yaw_point_bound_mm']
            pitch_motion=2*pitch_radius*math.sin(math.radians((pitch_hi-pitch_lo)/4)) if group=='pitch' else 0.
            lower=ref['values']-motion-pitch_motion;i=int(np.argmin(lower));gap=float(lower[i])
            oi=int(ref['closest'][i]);object_name=ref['names'][oi] if oi>=0 else 'AABB_EXCLUSION_CAP'
            row=dict(group=group,pitch_interval_deg=[pitch_lo,pitch_hi],gap_lower_mm=gap,
                     reference_nominal_gap_lower_mm=float(ref['values'][i]),wire_motion_bound_mm=float(motion[i]),
                     pitch_surface_motion_bound_mm=pitch_motion,nearest_object=object_name,
                     curve_parameter=float(e.t[i]),reference_point_local_mm=ref['points'][i].tolist())
            yaw_only=float(np.min(ref['values']-motion))
            if group=='pitch' and gap<GAP and yaw_only>GAP+1e-6 and not ref['inside'] and pdepth<8:
                todo.extend([('pitch',pitch_lo,pmid,pdepth+1),('pitch',pmid,pitch_hi,pdepth+1)])
                continue
            records.append(row)
            if gap<GAP or ref['inside']:bad.append(row)
            if float(ref['values'].min())<GAP or ref['inside']:
                nominal.append(dict(group=group,pitch_deg=pmid,nominal_minimum_gap_mm=float(ref['values'].min()),inside=ref['inside']))
        return dict(status='PASS' if not bad else 'BLOCKED',rows=records,failed_bounds=bad,nominal_failures=nominal,
                    yaw_interval_deg=[lo,hi],anchor_yaw_deg=anchor)
    for name in NAMES:
        accepted=[];todo=[(r['yaw_interval_deg'][0],r['yaw_interval_deg'][1],0) for r in proof['certificates']]
        while todo:
            lo,hi,depth=todo.pop();mid=(lo+hi)/2;anchor=float(round(mid/5)*5)
            result=compare(name,lo,hi,anchor)
            if result['status']!='PASS':
                result=compare(name,lo,hi,mid);result['fresh_midpoint_reference']=True
            if result['status']=='PASS':
                accepted.append(result);minimum=min(minimum,min(r['gap_lower_mm'] for r in result['rows']));continue
            if result.get('nominal_failures') or depth>=10:
                failures.append(dict(wire=name,yaw_interval_deg=[lo,hi],**{k:v for k,v in result.items() if k!='yaw_interval_deg'}));break
            todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
        coverage=sorted(r['yaw_interval_deg'] for r in accepted);status='BLOCKED' if any(r['wire']==name for r in failures) else 'PASS'
        if status=='PASS':
            assert coverage[0][0]==-60 and coverage[-1][1]==60
            assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        results.append(dict(wire=name,status=status,accepted_yaw_cells=len(accepted),intervals=accepted))
        print('CONTINUOUS_NATIVE_WIRE',name,status,len(accepted),'cached_fields',field_count,'queries',queries,'elapsed',time.time()-started,flush=True)
        if status!='PASS':break
    ctx.unchanged();status='PASS' if len(results)==4 and not failures else 'BLOCKED'
    report=dict(status=status,scope='Current201 native solids across yaw -60..60 and pitch -20..25 for four changed fixed-body CAM references only; candidate fixtures excluded',
       sources=ctx.sources,results=results,failures=failures,required_gap_mm=GAP,
       minimum_certified_native_gap_lower_mm=minimum,native_parts=201,yaw_coverage_deg=[-60,60],pitch_coverage_deg=[-20,25],
       pitch_native_radius_mm=pitch_radius,reference_curve_samples=len(e.t),cached_reference_fields=field_count,
       BVH_distance_queries=queries,AABB_fallback_gap_mm=CAP,peer_gap='NOT_TESTED',remote_self='NOT_TESTED',
       upper_tails='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
       manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'changed_native_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_NATIVE_TERMINAL',status,len(results),time.time()-started,flush=True)

if __name__=='__main__':main()
