"""CAM body leads fixed through a possible existing-bridge restraint plane.

The source zero-pose lead is fixed through Y=-22 plus a short contact extent.
No bridge, ports or actual splice is changed. Extra reference length is an
explicit new capacity parameter, never silently inherited as a cut length.
"""
from pathlib import Path
import sys
import numpy as np
from fixed_lead_family import SelectedFamily,BSpline,NAMES,sha
from screen_fixed_lead import partial_arc

HERE=Path(__file__).resolve().parent
from scipy.optimize import brentq


class BeamAnchorFamily(SelectedFamily):
    def __init__(self,blend_controls=4,extra_length_mm=0.):
        super().__init__()
        self.blend_controls=int(blend_controls)
        self.extra_length_mm=float(extra_length_mm)
        self.fixed={n:SelectedFamily.candidate(self,n,0)['control'].copy() for n in NAMES}
        self.locked_controls={};self.anchor_datums={}
        for n in NAMES:
            spl=BSpline(self.knots,self.fixed[n],3);t=np.linspace(0,1,4001);p=spl(t)
            ids=np.flatnonzero((p[:-1,1]<-22)&(p[1:,1]>=-22)&(p[:-1,2]>140)&(p[:-1,2]<150))
            assert len(ids)==1
            root=brentq(lambda t:spl(t)[1]+22,t[ids[0]],t[ids[0]+1])
            station=partial_arc(spl,root)
            count=next(i for i in range(4,24) if partial_arc(spl,self.knots[i])>=station+3.)
            self.locked_controls[n]=count
            self.anchor_datums[n]=dict(parameter=root,station_numeric_mm=station,point_mm=spl(root).tolist(),
                fixed_material_length_numeric_mm=partial_arc(spl,self.knots[count]),locked_controls=count,
                restraint_selected=False)
        for n in NAMES:self.targets[n]+=self.extra_length_mm
        for p in [Path(__file__),HERE/'screen_fixed_lead.py',HERE/'fixed_lead_family.py']:
            self.sources[str(p)]=sha(p)

    def base(self,name,yaw):
        raw=super().base(name,yaw)
        if name not in NAMES or not hasattr(self,'locked_controls') or name not in self.locked_controls:
            return raw
        c,cy,cyy,d,dy,dyy=(a.copy() for a in raw)
        count=self.locked_controls[name];blend=self.blend_controls
        w=np.ones(len(c));w[:count]=0
        u=np.arange(1,blend+1)/(blend+1)
        w[count:count+blend]=u**3*(10-15*u+6*u*u)
        c=self.fixed[name]+w[:,None]*(c-self.fixed[name])
        cy*=w[:,None];cyy*=w[:,None];d*=w[:,None];dy*=w[:,None];dyy*=w[:,None]
        return c,cy,cyy,d,dy,dyy

