"""Render exact scoped reference meshes in new private scenes.

Write only these scenes and their dependencies to an independent library;
never delete or save over the authoritative model or unowned data.
"""
from pathlib import Path
import datetime
import json
import sys

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
sys.path[:0]=[str(PARENT),str(BODY)]
from context import Context,np,bpy,Vector,sha,ROOT
from flat_key_family import FlatKeyFamily,NAMES,BSpline
from restraint_geometry import PAD_LO,PAD_HI


def main():
    ctx=Context();family=FlatKeyFamily()
    proof_path=HERE/'bench_tool_verification_R3.json';proof=json.loads(proof_path.read_text())
    geometry_path=HERE/'bench_tool_geometry_R3.npz'
    assert proof['status']=='PASS' and 45 in proof['accepted_angles_deg']
    assert sha(geometry_path)==proof['geometry_sha256']
    assert all(sha(p)==h for p,h in proof['sources'].items())
    d=np.load(geometry_path)
    tie_path=HERE/'oriented_tie_geometry.npz';tie_report=HERE/'oriented_tie_verification.json'
    tie=json.loads(tie_report.read_text());assert tie['status']=='PASS' and sha(tie_path)==tie['geometry_sha256']
    t=np.load(tie_path)
    owner='M155_CAM_BENCH_SEQUENCE_R3'
    assert not any(o.get('review_owner')==owner for o in bpy.data.objects)
    palette=dict(native=(.42,.48,.51,1),pad=(.10,.68,.72,1),board=(.11,.34,.26,1),
                 wire=(.97,.65,.17,1),tie=(.87,.51,.12,1),tail=(.93,.17,.38,1),tool=(.20,.53,.78,1))
    scenes=[];objects=[];views=[]
    main_hash=sha(ROOT/'mori_v1_2.blend')
    for label in ['mounted_uncut','bench_cut','final_reference']:
        scene=bpy.data.scenes.new(owner+'_'+label);bpy.context.window.scene=scene
        scene['review_owner']=owner;scene['source_revision']='V1.2-M1.55';scene['adopted']=False
        scene['full_wired_assembly']='BLOCKED';scene['manufacturing_release']=False
        scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001;scene.unit_settings.length_unit='MILLIMETERS'
        scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1400;scene.render.resolution_y=1000
        scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
        scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
        scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True
        scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
        scene.world=bpy.data.worlds.new(scene.name+'_WORLD');scene.world.color=(.07,.09,.12)
        collection=bpy.data.collections.new(scene.name);scene.collection.children.link(collection)
        materials={}
        for key,color in palette.items():
            material=bpy.data.materials.new(scene.name+'_'+key);material.diffuse_color=color;materials[key]=material

        def mesh_part(key,vertices,faces,color,category='PLACEHOLDER',source=None):
            mesh=bpy.data.meshes.new(scene.name+'_'+key);mesh.from_pydata(vertices.tolist(),[],faces.tolist());mesh.update()
            mesh.materials.append(materials[color])
            if key=='Yaw_Base_candidate':
                mesh.materials.append(materials['pad'])
                for poly in mesh.polygons:
                    center=np.mean(vertices[list(poly.vertices)],axis=0)
                    if np.all(center>=PAD_LO-1e-6) and np.all(center<=PAD_HI+1e-6):poly.material_index=1
            o=bpy.data.objects.new(mesh.name,mesh);collection.objects.link(o)
            o['review_owner']=owner;o['role_key']=key;o['category']=category;o['data_status']='ASSUMED'
            o['export_candidate']=False;o['source_frame']='Validation world coordinates in mm'
            if source:
                o['source_object']=ctx.ss[source].o.name
                o['category']=ctx.ss[source].o.get('category','PLACEHOLDER')
                o['data_status']=ctx.ss[source].o.get('data_status','ASSUMED')
            o['candidate_geometry']=key=='Yaw_Base_candidate'
            objects.append(dict(scene=scene.name,name=o.name,role_key=key,kind='MESH',source=source))
            return o

        mesh_part('Yaw_Base_candidate',d['Yaw_Base_candidate_vertices'],d['Yaw_Base_candidate_faces'],'native','PRINTABLE','Yaw_Base')
        mesh_part('tie_formed',d['tie_formed_vertices'],d['tie_formed_faces'],'tie')
        if label in ['mounted_uncut','bench_cut']:
            mesh_part('extra_tail',t['extra_tail_vertices'],t['extra_tail_faces'],'tail')
        if label=='mounted_uncut':
            for n in ['Load_Frame','Power_Module','Battery_Tray','Battery_Pad_38.0']:
                mesh_part(n,ctx.ss[n].v,ctx.ss[n].f,'board' if n=='Power_Module' else 'native',source=n)
        if label=='bench_cut':
            mesh_part('cutter_final_a45',d['cutter_final_a45_vertices'],d['cutter_final_a45_faces'],'tool')
        if label!='mounted_uncut':
            for n in NAMES:
                if label=='bench_cut':
                    c=d[n+'_stage_cubic'];u=np.linspace(0,1,801)
                    vertices=(1-u)[:,None]*c[0]+u[:,None]*c[-1]
                else:vertices=BSpline(family.knots,family.candidate(n,0)['control'],3)(np.linspace(0,1,1801))
                curve=bpy.data.curves.new(scene.name+'_'+n,'CURVE');curve.dimensions='3D';curve.resolution_u=1
                curve.bevel_depth=.565;curve.bevel_resolution=3;line=curve.splines.new('POLY');line.points.add(len(vertices)-1)
                line.points.foreach_set('co',np.c_[vertices,np.ones(len(vertices))].ravel());curve.materials.append(materials['wire'])
                o=bpy.data.objects.new(curve.name,curve);collection.objects.link(o)
                o['review_owner']=owner;o['category']='PLACEHOLDER';o['data_status']='ASSUMED';o['role_key']=n
                o['export_candidate']=False;o['numeric_material_reference_only']=True
                objects.append(dict(scene=scene.name,name=o.name,role_key=n,kind='CURVE',samples=len(vertices)))
        camera_data=bpy.data.cameras.new(scene.name+'_CAMERA');camera=bpy.data.objects.new(camera_data.name,camera_data)
        scene.collection.objects.link(camera);scene.camera=camera;camera_data.type='ORTHO'
        camera_data.clip_start=.1;camera_data.clip_end=1200
        if label=='mounted_uncut':specs=[('mounted_uncut_tail',(100,-115,113),(34,-23,118),90)]
        elif label=='bench_cut':specs=[('bench_tool_detail',(108,94,119),(31,-24,140),65),
                                     ('bench_tool_overview',(270,-290,350),(48,21,142),305)]
        else:specs=[('trimmed_final_reference',(100,-110,112),(28,-23,142),65)]
        for file,position,target,scale in specs:
            camera.location=position;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
            camera_data.ortho_scale=scale;destination=HERE/(file+'.png');scene.render.filepath=str(destination)
            bpy.ops.render.render(write_still=True)
            views.append(dict(file=destination.name,sha256=sha(destination),scene=scene.name,view=file))
        scenes.append(scene)
    ctx.record([Path(__file__),proof_path,geometry_path,tie_path,tie_report])
    ctx.unchanged();family.unchanged()
    path=HERE/'M1_55_CAM_bench_sequence_UNADOPTED.blend'
    bpy.data.libraries.write(str(path),set(scenes),fake_user=True,compress=True)
    assert sha(ROOT/'mori_v1_2.blend')==main_hash
    report=dict(status='PASS',scope='Editable private scenes of exact validated reference meshes and tool/staging allocations only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        review_owner=owner,scenes=[s.name for s in scenes],objects=objects,files=views,
        inspection_file=path.name,inspection_sha256=sha(path),source_blend_sha256=main_hash,
        saved_only_private_scene_dependencies=True,visual_readback='NOT_TESTED',
        actual_tool='NOT_TESTED',actual_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    (HERE/'bench_render_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_BENCH_SEQUENCE_RENDERED',len(views),len(objects),path.stat().st_size,flush=True)


if __name__=='__main__':main()
