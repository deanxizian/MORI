"""Body-fixed flat clamp span, with existing continuous yaw frame residuals.

Four candidate body leads change. Native ports and the seven retained upper
references do not move. Extra 4 mm is a numeric route budget, not a cut length.
"""
from pathlib import Path
import json
import numpy as np
from fixed_lead_family import SelectedFamily, BSpline, NAMES, sha
from frame_family import rotate, omega

HERE = Path(__file__).resolve().parent


class FlatBodyFamily(SelectedFamily):
    def __init__(self):
        super().__init__()
        report_path = HERE/'flat_zero_verification.json'
        report = json.loads(report_path.read_text())
        assert report['status'] == 'PASS' and report['checks'] == 82
        assert all(sha(p) == h for p, h in report['sources'].items())
        source = HERE/'flat_contact_zero_R2/candidate.npz'
        metadata = HERE/'flat_contact_zero_R2/optimization.json'
        meta = json.loads(metadata.read_text())
        assert sha(source) == meta['candidate_sha256']
        data = np.load(source)
        self.seed = {n: data[n+'_controls'].copy() for n in NAMES}
        self.locked_controls = {n: meta['fixed_span_start_controls'][n]+4 for n in NAMES}
        self.corrections = {n: self.seed[n]-SelectedFamily.base(self, n, 0)[0] for n in NAMES}
        self.anchor_datums = report['anchors']
        for n in NAMES:
            self.targets[n] += 4.
        for p in [Path(__file__), report_path, source, metadata, HERE/'fixed_lead_family.py']:
            self.sources[str(p)] = sha(p)

    def base(self, name, yaw):
        raw = super().base(name, yaw)
        if name not in NAMES or not hasattr(self, 'seed'):
            return raw
        c, cy, cyy, d, dy, dyy = (a.copy() for a in raw)
        frame = self.frame_weights[name]
        correction = self.corrections[name]
        c += rotate(correction, frame*yaw)
        cy += rotate(omega(correction, frame), frame*yaw)
        cyy += rotate(omega(omega(correction, frame), frame), frame*yaw)
        count = self.locked_controls[name]
        weights = np.ones(len(c)); weights[:count] = 0.
        u = np.arange(1, 5)/5
        weights[count:count+4] = u**3*(10-15*u+6*u*u)
        c = self.seed[name]+weights[:, None]*(c-self.seed[name])
        cy *= weights[:, None]; cyy *= weights[:, None]
        d *= weights[:, None]; dy *= weights[:, None]; dyy *= weights[:, None]
        return c, cy, cyy, d, dy, dyy
