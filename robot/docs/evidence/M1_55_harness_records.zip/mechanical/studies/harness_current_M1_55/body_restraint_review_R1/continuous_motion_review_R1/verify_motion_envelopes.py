"""Independent direct-spline consistency checks for the new motion bounds.

Samples diagnose implementation mismatches; they are not themselves a
continuous clearance proof. Record exactly unchanged neighbouring inputs.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
OLD=PARENT/'prefix_continuity/frame_family_R3'
GENERIC=OLD/'continuous_gaps_R1'
sys.path[:0]=[str(BODY),str(GENERIC),str(OLD)]
from flat_key_family import FlatKeyFamily,NAMES,np,sha,BSpline
from selected_family import SelectedFamily
from motion_envelopes import Envelopes


def rotate_direct(points,deg):
    angle=np.deg2rad(deg)
    matrix=np.array([[np.cos(angle),-np.sin(angle),0],
                     [np.sin(angle),np.cos(angle),0],[0,0,1]])
    return points@matrix.T


def main():
    started=time.time();f=FlatKeyFamily();original=SelectedFamily();e=Envelopes(f,count=1501)
    unchanged=[]
    for n in f.names:
        if n in NAMES:continue
        assert f.targets[n]==original.targets[n] and f.radii[n]==original.radii[n]
        assert np.array_equal(f.frame_weights[n],original.frame_weights[n])
        for yaw in range(-60,61,10):
            for k in ['controls','directions','local_controls','local_directions']:
                assert np.array_equal(getattr(f,k)[yaw][n],getattr(original,k)[yaw][n]),(n,yaw,k)
        errors=[]
        for yaw in [-60,-57.3,-35.8,-.6,0,4.8,28.7,54.4,60]:
            errors.append(float(np.max(abs(f.candidate(n,yaw)['control']-original.candidate(n,yaw)['control']))))
        assert max(errors)==0.
        unchanged.append(dict(wire=n,status='PASS',key_controls_directions_frames_and_scalar_inputs_exact=True,
                              sampled_interpolated_control_error_mm=max(errors)))
    original_check_path=GENERIC/'envelope_crosscheck.json'
    original_check=json.loads(original_check_path.read_text())
    assert original_check['status']=='PASS'
    assert all(sha(p)==h for p,h in original_check['sources'].items())
    rows=[]
    intervals=[[-59.75,-59.25],[-47.7,-47.2],[-26.1,-25.6],[-3.85,-3.35],
               [4.,4.5],[17.,17.5],[35.3,35.8],[58.5,59.]]
    for n in NAMES:
        for lo,hi in intervals:
            anchor=float(round((lo+hi)/10)*5)
            bound=e.control_envelopes(n,lo,hi,anchor);assert bound is not None
            ref=e.curve(n,anchor);sref=BSpline(f.knots,ref['control'],3)
            world_excess=yaw_excess=-float('inf')
            chord_max=0.
            for yaw in np.linspace(lo,hi,7):
                c=f.candidate(n,float(yaw))['control']
                world_excess=max(world_excess,float(np.max(np.linalg.norm(c-ref['control'],axis=1)-bound['world_control_bound_mm'])))
                local=rotate_direct(c,-float(yaw));r=rotate_direct(ref['control'],-anchor)
                yaw_excess=max(yaw_excess,float(np.max(np.linalg.norm(local-r,axis=1)-bound['yaw_control_bound_mm'])))
            for fraction in [.25,.5,.75]:
                u=e.t[:-1]+fraction*e.dt
                difference=sref(u)-((1-fraction)*ref['points'][:-1]+fraction*ref['points'][1:])
                chord_max=max(chord_max,float(np.linalg.norm(difference,axis=1).max()))
            assert world_excess<1e-8 and yaw_excess<1e-8 and chord_max<=ref['chord_error_mm']+1e-8
            rows.append(dict(wire=n,yaw_interval_deg=[lo,hi],anchor_yaw_deg=anchor,status='PASS',
                maximum_world_control_excess_mm=world_excess,maximum_yaw_control_excess_mm=yaw_excess,
                measured_reference_chord_deviation_mm=chord_max,chord_deviation_bound_mm=ref['chord_error_mm']))
    f.unchanged();original.unchanged();sources=dict(f.sources)
    for p in [Path(__file__),GENERIC/'motion_envelopes.py',OLD/'frame_motion_bounds.py',
              OLD.parent/'root_direction_R2/root_motion_bounds.py',HERE/'continuous_root_verification.json',
              HERE/'continuous_bend_verification.json',original_check_path,
              HERE/'initial_envelope_assertion/verify_motion_envelopes.py',
              HERE/'initial_envelope_assertion/failure.json']:
        sources[str(p)]=sha(p)
    report=dict(status='PASS',scope='Sampled independent direct-spline motion-envelope consistency of four changed curves and exact eight-neighbour input identity',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,rows=rows,
        unchanged_neighbours=unchanged,checks=len(rows),reference_samples=len(e.t),
        all_angle_native_and_peer_clearance='NOT_TESTED',actual_harness='BLOCKED',
        main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'motion_envelope_crosscheck.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_MOTION_ENVELOPES_CHECKED',len(rows),'neighbours',len(unchanged),round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
