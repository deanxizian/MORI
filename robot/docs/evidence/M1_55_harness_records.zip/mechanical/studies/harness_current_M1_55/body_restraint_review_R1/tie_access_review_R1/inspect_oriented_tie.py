"""Fresh check of the side-root / normal-return tie allocation.

The full head envelope is retained. This checks native rigid geometry and
the four exact straight contact cylinders; it does not certify a pawl,
hand installation, wire grip, or a complete wired assembly.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE = Path(__file__).resolve().parent
BODY = HERE.parent
sys.path[:0] = [str(BODY.parent), str(BODY), str(HERE)]
from context import Context, np, manifold, rigidtr, sha
from restraint_geometry import solids, SOURCE
from oriented_tie import build, untrimmed


def bounds(m):
    vertices = np.array(m.to_mesh64().vert_properties)[:, :3]
    return vertices.min(0), vertices.max(0)


def nearby_checks(feature, targets, excluded=()):
    lo, hi = bounds(feature)
    rows = []
    for name, target in targets.items():
        if name in excluded or np.any(hi + .3 < target['lo']) or np.any(lo - .3 > target['hi']):
            continue
        gap = float(feature.min_gap(target['m'], .30001))
        volume = float((feature ^ target['m']).volume())
        rows.append(dict(native=name, gap_mm=gap, intersection_mm3=volume,
                         status='PASS' if gap >= .3 - 1e-7 and volume < 1e-8 else 'BLOCKED'))
    return rows


def main():
    started = time.time()
    ctx = Context()
    pad, _, _ = solids(manifold)
    tie, band, head, points, details = build(manifold)
    full, full_band, _, full_points, full_details = untrimmed(manifold)
    extra_tail = full_band - band
    host = ctx.ss['Yaw_Base'].m
    merged = host + pad
    assert len(merged.decompose()) == 1
    overlap = float((tie ^ pad).volume())
    assert overlap < 1e-6
    contact_source = BODY / 'flat_contact_zero_R2/optimization.json'
    meta = json.loads(contact_source.read_text())
    contacts = []
    failures = []
    for name, x in meta['straight_span_x_mm'].items():
        wire = manifold.Manifold.cylinder(4.3, .565, .565, 64).rotate([-90, 0, 0]).translate([x, -24.8, 144.6])
        volumes = [float((m ^ wire).volume()) for m in [pad, tie]]
        row = dict(wire=name, pad_intersection_mm3=volumes[0], tie_intersection_mm3=volumes[1],
                   pad_gap_mm=float(pad.min_gap(wire, .01)), tie_gap_mm=float(tie.min_gap(wire, .01)),
                   status='PASS' if max(volumes) < 1e-8 else 'BLOCKED')
        contacts.append(row)
        if row['status'] != 'PASS':
            failures.append(row)
    rows = []
    for group in ['body', 'yaw', 'pitch']:
        poses = ([(0, 0)] if group == 'body' else [(y, 0) for y in range(-60, 61, 5)]
                 if group == 'yaw' else [(y, p) for y in range(-60, 61, 5) for p in range(-20, 26, 5)])
        for yaw, pitch in poses:
            matrix = np.eye(4) if group == 'body' else np.linalg.inv(np.asarray(rigidtr(yaw, pitch)))
            feature = tie.transform(matrix[:3, :].tolist())
            close = nearby_checks(feature, ctx.groups[group])
            row = dict(group=group, yaw_deg=yaw, pitch_deg=pitch, nearby_native=close,
                       status='PASS' if all(r['status'] == 'PASS' for r in close) else 'BLOCKED')
            rows.append(row)
            failures.extend(dict(group=group, yaw_deg=yaw, pitch_deg=pitch, **r)
                            for r in close if r['status'] != 'PASS')
            if group == 'pitch' and pitch == 25 and yaw % 20 == 0:
                print('ORIENTED_TIE_POSE', yaw, len(rows), len(failures), round(time.time()-started, 2), flush=True)

    # Do not silently discard the uncut tail because it is absent from the
    # installed render. Test the remaining physical material explicitly.
    mounted_tail_rows = nearby_checks(extra_tail, ctx.targets)
    mounted_tail_failures = [r for r in mounted_tail_rows if r['status'] != 'PASS']
    detached_bridge_gap = float(full.min_gap(host, .30001))
    detached_bridge_intersection = float((full ^ host).volume())
    detached_bridge_status = ('PASS' if detached_bridge_gap >= .3 - 1e-7 and detached_bridge_intersection < 1e-8 else 'BLOCKED')
    path = HERE / 'oriented_tie_geometry.npz'
    arrays = dict(formed_centerline_xz_mm=points, untrimmed_centerline_xz_mm=full_points)
    for name, m in [('tie_formed', tie), ('band_formed', band), ('head', head),
                    ('tie_untrimmed', full), ('extra_tail', extra_tail), ('pad', pad)]:
        mesh = m.to_mesh64()
        arrays[name+'_vertices'] = np.array(mesh.vert_properties)[:, :3]
        arrays[name+'_faces'] = np.array(mesh.tri_verts)
    np.savez_compressed(path, **arrays)
    ctx.record([Path(__file__), HERE/'oriented_tie.py', HERE/'drawing_review.json',
                BODY/'restraint_geometry.py', SOURCE, contact_source])
    for drawing in json.loads(SOURCE.read_text())['drawings']:
        ctx.record([SOURCE.parent/drawing['file']])
    ctx.unchanged()
    report = dict(status='PASS' if not failures else 'BLOCKED',
        scope='Fresh finite native fit of side-root/normal-return tie allocation; no full wire or installation qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=ctx.sources,
        final_form=details, untrimmed_form=full_details, intended_pad_tie_overlap_mm3=overlap,
        intended_contact_precision_tolerance_mm3=1e-6, exact_straight_wire_contacts=contacts,
        native_pose_checks=len(rows), native_pose_rows=rows, failures=failures,
        untrimmed_in_current_assembly=dict(status='BLOCKED' if mounted_tail_failures else 'PASS',
            scope='Additional uncut tail vs 201 native parts at mechanical zero',
            checked_nearby_parts=mounted_tail_rows, failures=mounted_tail_failures),
        detached_bridge_only=dict(status=detached_bridge_status, gap_mm=detached_bridge_gap,
            intersection_mm3=detached_bridge_intersection,
            scope='Tie including uncut tail vs detached original Yaw_Base only; no hands/tools/staged wires'),
        geometry_sha256=sha(path), full_curve_fit='NOT_TESTED', continuous_angle_clearance='NOT_TESTED',
        pawl_and_feed='NOT_TESTED', wire_grip='NOT_TESTED', full_wired_assembly='BLOCKED',
        proposed_sequence='Preposition/thread/trim on detached bridge before body installation; not yet qualified or adopted',
        main_changed=False, hardware_changed=False, animation_changed=False, manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'oriented_tie_verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print('ORIENTED_TIE_TERMINAL', report['status'], len(failures),
          'mounted_uncut_tail', report['untrimmed_in_current_assembly']['status'],
          'detached_bridge', detached_bridge_status, round(report['elapsed_s'], 2), flush=True)


if __name__ == '__main__':
    main()
