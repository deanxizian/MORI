"""Continuous straight tool approaches on a detached bridge candidate.

Documented catalogue dimensions motivate enlarged rectangular work volumes.
No selected cutter CAD, blade cavity, hand volume, cutting force, or tie pawl
is invented. Keep failed directions and the exact scope of each test.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE = Path(__file__).resolve().parent
BODY = HERE.parent
PARENT = BODY.parent
sys.path[:0] = [str(PARENT), str(BODY), str(HERE), str(PARENT/'upper_smooth_review_R2')]
from context import Context, np, manifold, BVHTree, clear, sha
from oriented_tie import build, untrimmed, HEAD_LO, CAVITY_X, MID_Y
from restraint_geometry import solids
from flat_key_family import FlatKeyFamily, NAMES, BSpline
from piecewise_geometry import pieces
HELPER = PARENT/'upper_length_match_R1/inspect_changed.py'
spec = importlib.util.spec_from_file_location('_mori_bench_curve_helper', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def box(lo, hi):
    lo, hi = np.asarray(lo, float), np.asarray(hi, float)
    return manifold.Manifold.cube((hi-lo).tolist()).translate(lo.tolist())


def gap_records(feature, targets, required=.3):
    rows = []
    for name, target in targets.items():
        gap = float(feature.min_gap(target, required+.00001))
        volume = float((feature ^ target).volume())
        rows.append(dict(obstacle=name, gap_mm=gap, intersection_mm3=volume,
                         status='PASS' if gap >= required-1e-7 and volume < 1e-8 else 'BLOCKED'))
    return rows


def target(feature):
    data = feature.to_mesh64()
    v = np.array(data.vert_properties)[:, :3]
    faces = np.array(data.tri_verts)
    return dict(m=feature, lo=v.min(0), hi=v.max(0),
                tree=BVHTree.FromPolygons(v.tolist(), faces.tolist(), all_triangles=True))


def main():
    started = time.time()
    ctx = Context()
    family = FlatKeyFamily()
    tie, band, head, _, _ = build(manifold)
    uncut, _, _, _, _ = untrimmed(manifold)
    pad, _, _ = solids(manifold)
    host = ctx.ss['Yaw_Base'].m
    cut_z = HEAD_LO[2]-2.
    cut = np.array([CAVITY_X, MID_Y, cut_z])
    # Only the final .3 mm of the remaining vertical cut stub is a named
    # blade contact region. All other band material keeps the .3 mm gap.
    tip_region = box([CAVITY_X-1., MID_Y-2., cut_z-1e-6],
                     [CAVITY_X+1., MID_Y+2., cut_z+.30001])
    tip = band ^ tip_region
    protected_band = band-tip_region
    assert 0 < tip.volume() < 2.
    # Local long axis is -Y, jaw width Z, thickness X. Add 1 mm per side
    # to the overall handle and .3 mm per side to the jaw for work allowance.
    # The cut point lies at the front of the jaws. Nose/edge shape is unknown.
    jaw_lo=np.array([-3.55, -10., -11.]); jaw_hi=np.array([3.55, 1.65, 0.])
    body_lo=np.array([-10.5, -125., -36.5]); body_hi=np.array([10.5, -10., 25.5])
    jaw=box(jaw_lo,jaw_hi);body=box(body_lo,body_hi)
    distance=60.
    jaw_sweep=box(jaw_lo+[0,-distance,0],jaw_hi)
    body_sweep=box(body_lo+[0,-distance,0],body_hi)
    # Unhoused factory-crimped body ends are not connected to their header
    # on the bench. Testing complete zero-reference curves is an explicit
    # spatial test, not a simulation of temporary tail shape or feeding.
    curve_packs={n:helper.prepare(pieces(BSpline(family.knots,family.candidate(n,0)['control'],3)),.565)
                 for n in NAMES}
    trials=[];accepted=[];arrays={}
    directions=list(range(46,61))
    for angle in directions:
        final=(jaw+body).rotate([0,0,angle]).translate(cut.tolist())
        sweep=(jaw_sweep+body_sweep).rotate([0,0,angle]).translate(cut.tolist())
        fixed=gap_records(sweep,dict(detached_Yaw_Base=host, integral_pad=pad,
                                    tie_head=head, protected_band=protected_band))
        # Check no hidden penetration of the retained cut-tip contact material.
        contact_volume=float((sweep^tip).volume())
        wire_rows=[]
        obstacle={'cutter_swept_work_volume':target(sweep)}
        for n,pack in curve_packs.items():
            hits,near=clear(pack['p'],.565,obstacle,error=pack['error'],gap=.3)
            wire_rows.append(dict(wire=n,status='PASS' if not hits else 'BLOCKED',hits=hits,nearest=near))
        good=all(r['status']=='PASS' for r in fixed+wire_rows) and contact_volume<1e-6
        row=dict(angle_about_Z_deg=angle,status='PASS' if good else 'BLOCKED',
                 continuous_approach_mm=distance,rigid_clearances=fixed,wire_clearances=wire_rows,
                 intended_cut_tip_intersection_mm3=contact_volume)
        trials.append(row)
        if good:
            accepted.append(angle)
            for name, m in [('cutter_final',final),('cutter_sweep',sweep)]:
                data=m.to_mesh64()
                arrays[name+f'_a{angle}_vertices']=np.array(data.vert_properties)[:,:3]
                arrays[name+f'_a{angle}_faces']=np.array(data.tri_verts)
        print('BENCH_CUTTER_DIRECTION',angle,row['status'],round(time.time()-started,2),flush=True)
    for name,m in [('tie_formed',tie),('tie_untrimmed',uncut),('pad',pad),('Yaw_Base_candidate',host+pad)]:
        data=m.to_mesh64();arrays[name+'_vertices']=np.array(data.vert_properties)[:,:3];arrays[name+'_faces']=np.array(data.tri_verts)
    path=HERE/'bench_tool_geometry_R2.npz';np.savez_compressed(path,**arrays)
    ctx.record([Path(__file__),HERE/'oriented_tie.py',HERE/'oriented_tie_verification.json',
                BODY/'restraint_geometry.py',HELPER,HERE/'check_bench_tool.py',HERE/'bench_tool_verification.json'])
    ctx.unchanged();family.unchanged()
    report=dict(status='PASS' if accepted else 'BLOCKED',
        scope='Refined continuous swept cutter work boxes on detached bridge plus four complete zero-reference CAM curves only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        tool_reference=dict(manufacturer='KNIPEX',article='79 22 125',selected=False,
            dimension_source_url='https://www.knipex.com/sites/default/files/Product%20data%20sheet%20EN%2079%2022%20125.pdf',
            source_access='Official indexed search extract; direct downloads returned HTTP403, complete PDF NOT_READ',
            catalogue_overall_mm=[125,60,19],catalogue_jaw_A_B_D_mm=[11,10,6.5],
            outline='ASSUMED enlarged rectangular work boxes, not product CAD',
            jaw_lo_relative_cut_mm=jaw_lo.tolist(),jaw_hi_relative_cut_mm=jaw_hi.tolist(),
            body_lo_relative_cut_mm=body_lo.tolist(),body_hi_relative_cut_mm=body_hi.tolist()),
        cut_point_mm=cut.tolist(),remaining_stub_mm=2.,native_obstacle_ids=['Yaw_Base'],
        absent_native_scope='Other assemblies are absent only because this is the detached-bridge bench step',
        wire_scope='Four complete zero-reference curves used as spatial obstacles; temporary material shape NOT_TESTED',
        trials=trials,accepted_angles_deg=accepted,geometry_sha256=sha(path),
        actual_tool_jaw_and_hand='NOT_TESTED',tie_threading_and_tightening='NOT_TESTED',
        actual_wire_ends_and_staging='BLOCKED',bridge_wired_insertion='NOT_TESTED',
        full_wired_assembly='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'bench_tool_verification_R2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('BENCH_TOOL_TERMINAL',report['status'],'accepted',accepted,round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
