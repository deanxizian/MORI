"""Independent four-wire straight clamping span beside the fixed yaw bridge.

This makes a physical contact span possible; it does not design or adopt a
clip. End controls and the four collinear span controls are solver constants.
The wire and tie product variants remain unselected reference envelopes.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from refine_anchored_zero import KnotAwareSearch
from optimize_anchored_zero import Context, BeamAnchorFamily, NAMES, np, sha, engine
from scipy.optimize import least_squares

OUT = HERE/'flat_contact_zero_R1'
OUT.mkdir(exist_ok=True)
engine.HERE = OUT


def main():
    started = time.time()
    ctx = Context(); family = BeamAnchorFamily(4, 4.)
    source = HERE/'anchored_zero_refined/candidate_1001.npz'
    proof_path = HERE/'refined_zero_verification.json'
    proof = json.loads(proof_path.read_text())
    assert proof['status'] == 'PASS' and proof['checks'] == 82
    assert all(sha(p) == h for p, h in proof['sources'].items())
    surfaces = HERE/'support_contact_surfaces.json'
    assert json.loads(surfaces.read_text())['status'] == 'PASS'
    data = np.load(source)
    seed = {n: data[n+'_controls'].copy() for n in NAMES}
    xvalues = dict(CAM_4=27., CAM_3=28.7, CAM_1=30.4, CAM_2=32.1)
    for n in NAMES:
        seed[n][11:15] = np.c_[np.full(4, xvalues[n]), [-29.1, -24.8, -20.5, -16.2], np.full(4, 144.6349)]
    search = KnotAwareSearch(ctx, family, seed, 1001)
    search.mask = np.array([i*44*3+(j-2)*3+axis for i in range(4)
                            for j in range(2, 46) if j not in range(11, 15) for axis in range(3)])
    search.last = None
    x = search.base[search.mask]
    before = search.evaluate(x)[2]
    print('FLAT_CONTACT_ZERO_START', before, flush=True)
    calls = [0]
    def callback(values):
        calls[0] += 1
        if calls[0] % 5 == 0:
            print('FLAT_CONTACT_ZERO_ITER', calls[0], search.evaluate(values)[2], time.time()-started, flush=True)
    sol = least_squares(lambda a: search.evaluate(a)[0], x, jac=lambda a: search.evaluate(a)[1],
                        bounds=(x-4., x+4.), method='trf', tr_solver='lsmr', tr_options=dict(maxiter=180),
                        max_nfev=70, ftol=1e-7, xtol=1e-7, gtol=1e-5, callback=callback)
    controls = search.controls(sol.x)
    error = max(float(np.max(abs(controls[n][11:15]-seed[n][11:15]))) for n in NAMES)
    end_error = max(float(np.max(abs(controls[n][[0,1,-2,-1]]-data[n+'_controls'][[0,1,-2,-1]]))) for n in NAMES)
    assert error == 0. and end_error == 0.
    candidate = OUT/'candidate.npz'
    np.savez_compressed(candidate, **{n+'_controls': c for n, c in controls.items()}, knots=family.knots)
    ctx.record([Path(__file__), HERE/'refine_anchored_zero.py', HERE/'optimize_anchored_zero.py', source, proof_path, surfaces])
    ctx.unchanged(); family.unchanged()
    result = dict(status='PASS', scope='Fixed-span optimizer execution, not independent geometry or retention proof',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=ctx.sources|family.sources,
                  solver_success=bool(sol.success), solver_status=int(sol.status), message=sol.message,
                  nfev=int(sol.nfev), elapsed_s=time.time()-started, initial=before, final=search.evaluate(sol.x)[2],
                  target_radius_mm=engine.OPT_RADIUS, sampling_points_per_curve=search.problem.n,
                  fixed_span_controls=[11,12,13,14], fixed_control_error_mm=error, end_control_error_mm=end_error,
                  straight_span_y_mm=[-24.8,-20.5], straight_span_center_z_mm=144.6349, straight_span_x_mm=xvalues,
                  body_reference_targets_mm={n: family.targets[n] for n in NAMES}, extra_reference_length_mm=4.,
                  candidate_sha256=sha(candidate), actual_restraint='NOT_TESTED', full_harness='BLOCKED',
                  actual_material='BLOCKED', all_angle_motion='NOT_TESTED', main_changed=False,
                  hardware_changed=False, animation_changed=False, manufacturing_release=False)
    (OUT/'optimization.json').write_text(json.dumps(result, indent=2)+'\n')
    print('FLAT_CONTACT_ZERO_TERMINAL', result['final'], result['elapsed_s'], flush=True)


if __name__ == '__main__':
    main()
