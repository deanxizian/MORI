"""Independent native/finite-segment/whole-cubic checks for flat contact R2 after body search."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,sha
sys.path.insert(0,str(HERE))
from beam_anchor_family import BeamAnchorFamily
from fixed_lead_family import NAMES,BSpline
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,radius_bound,RADII
helper_path=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_body_search_independent_helpers',helper_path)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from cam_family import upper_length


def main():
    started=time.time();ctx=Context();family=BeamAnchorFamily(4,4.)
    source=HERE/'flat_contact_zero_R2/candidate.npz'
    receipt_path=source.parent/'optimization.json';receipt=json.loads(receipt_path.read_text())
    assert receipt['status']=='PASS' and receipt['candidate_sha256']==sha(source)
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    data=np.load(source);prefixes={};math=[]
    expected=np.load(HERE/'anchored_zero_refined/candidate_1001.npz')
    starts=receipt['fixed_span_start_controls'];anchors={}
    for n in family.names:
        c=data[n+'_controls'] if n in NAMES else family.candidate(n,0)['control']
        cubics=pieces(BSpline(family.knots,c,3));prefixes[n]=helper.prepare(cubics,.565 if n in NAMES else family.radii[n])
        if n in NAMES:
            bound=radius_bound(cubics,depth=8)
            actual=float(family.weights@np.linalg.norm(family.Q@c,axis=1));error=actual-family.targets[n]
            j=starts[n]
            ideal=np.c_[np.full(4,receipt['straight_span_x_mm'][n]),[-29.1,-24.8,-20.5,-16.2],np.full(4,receipt['straight_span_center_z_mm'])]
            fixed=float(np.max(abs(c[j:j+4]-ideal)))
            endpoint=float(np.max(abs(c[[0,1,-2,-1]]-expected[n+'_controls'][[0,1,-2,-1]])))
            parameter=(family.knots[j+3]+family.knots[j+4])/2
            anchors[n]=dict(point_mm=BSpline(family.knots,c,3)(parameter).tolist(),span_parameter=[float(family.knots[j+3]),float(family.knots[j+4])],span_length_mm=4.3,frozen_body_controls=j+4)
            math.append(dict(wire=n,status='PASS' if bound['radius_lower_mm']>=6.865 and fixed<1e-12 and endpoint<1e-12 and abs(error)<.001 else 'BLOCKED',
                whole_cubic_radius_lower_mm=bound['radius_lower_mm'],numeric_length_residual_mm=error,
                fixed_control_error_mm=fixed,endpoint_control_error_mm=endpoint,optimization_target_mm=family.targets[n]))
    rows=[]
    for n in NAMES:
        pack=prefixes[n]
        for g,targets in ctx.groups.items():
            hits,near=clear(pack['p'],.565,targets,error=pack['error'],gap=.3)
            rows.append(dict(wire=n,kind='native',group=g,status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near))
        rows.append(dict(wires=[n,n],**helper.compare(pack,pack,'self')))
    for a,b in itertools.combinations(prefixes,2):
        if a not in NAMES and b not in NAMES:continue
        rows.append(dict(wires=[a,b],**helper.compare(prefixes[a],prefixes[b])))
    cam_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    power_path=PARENT/'upper_motion_family_R1/half_grid_curves.npz'
    upper_sources=[(cam_path,PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'),
                   (power_path,PARENT/'upper_motion_family_R1/half_grid_inspection.json')]
    for p,r in upper_sources:
        q=json.loads(r.read_text());assert q['status']=='PASS' and q['arrays_sha256']==sha(p)
    cam=np.load(cam_path);power=np.load(power_path)
    uppers={n:helper.prepare((cam if n.startswith('CAM_') else power)[f'{n}_y0_p0_controls'],radius) for n,radius in RADII.items()}
    for n in NAMES:
        for other,pack in uppers.items():
            kind='own_join' if n==other else 'peer'
            row=dict(wires=[n,other],**helper.compare(prefixes[n],pack,kind));row['scope']='changed_prefix_vs_unchanged_upper'
            rows.append(row)
    failures=[r for r in rows+math if r['status']!='PASS']
    ctx.record([Path(__file__),source,receipt_path,helper_path]+[p for pair in upper_sources for p in pair]);ctx.unchanged();family.unchanged()
    result=dict(status='PASS' if not failures else 'BLOCKED',scope='Independent zero-pose geometry of four fixed-body CAM references; not complete physical harness',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        checks=len(rows),rows=rows,curve_math=math,failures=failures,anchors=anchors,
        wire_radius_mm=.565,required_gap_mm=.3,required_centreline_radius_mm=6.865,
        actual_splice_and_terminal='BLOCKED',printed_restraint='NOT_TESTED',between_pose_motion='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'flat_zero_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_FLAT_CONTACT_INDEPENDENT_ZERO',result['status'],len(rows),len(failures),math,time.time()-started,flush=True)


if __name__=='__main__':main()
