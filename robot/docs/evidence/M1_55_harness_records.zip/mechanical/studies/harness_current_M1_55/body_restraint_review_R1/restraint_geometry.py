"""Unadopted flat bridge extension and conservative formed tie envelope.

Tie flat-product maximum dimensions are documented; the installed form,
channel, contact and friction are ASSUMED. This is no selected tie CAD.
"""
from pathlib import Path
import json
import math
import numpy as np

SOURCE = Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/harness_A8/cam_tie_install/sources/dimensions.json')
PAD_LO = np.array([25.5, -24.5, 145.165])
PAD_HI = np.array([33.5, -19.5, 146.8])


def rounded_outline(lo, hi, radius, count=20):
    points = []
    for x,z,angle in [(hi[0]-radius,lo[1]+radius,-90),
                      (hi[0]-radius,hi[1]-radius,0),
                      (lo[0]+radius,hi[1]-radius,90),
                      (lo[0]+radius,lo[1]+radius,180)]:
        for a in np.linspace(angle, angle+90, count+1):
            radians=math.radians(a)
            points.append([x+radius*math.cos(radians),z+radius*math.sin(radians)])
    return np.array(points)


def solids(manifold):
    facts=json.loads(SOURCE.read_text())
    assert not facts['procurement_variant_frozen']
    maximum=facts['screen_upper_dimensions']
    assert maximum == dict(strap_thickness=1.3,strap_width=2.7,head_height=4.3,head_width=5.,head_length=5.3)
    thickness=maximum['strap_thickness']; radius=.6
    inner_lo=np.array([24.9,144.035]);inner_hi=np.array([34.1,146.8])
    inner=manifold.CrossSection([rounded_outline(inner_lo,inner_hi,radius)])
    outer=manifold.CrossSection([rounded_outline(inner_lo-thickness,inner_hi+thickness,radius+thickness)])
    band=(outer-inner).extrude(maximum['strap_width']).rotate([90,0,0]).translate([0,-21.65,0])
    # Head maximum box at the accessible low outside corner. Pawl and return
    # port are not selected; this gross envelope cannot prove tie insertion.
    head_lo=np.array([34.6,-25.5,139.735])
    head_hi=head_lo+np.array([5.3,5.,4.3])
    head=manifold.Manifold.cube((head_hi-head_lo).tolist()).translate(head_lo.tolist())
    tie=band+head
    pad=manifold.Manifold.cube((PAD_HI-PAD_LO).tolist()).translate(PAD_LO.tolist())
    assert not tie.is_empty() and not pad.is_empty()
    return pad,tie,dict(pad_lo_mm=PAD_LO.tolist(),pad_hi_mm=PAD_HI.tolist(),
                       pad_dimensions_mm=(PAD_HI-PAD_LO).tolist(),tie_upper_dimensions_mm=maximum,
                       tie_contact_y_mm=[-24.35,-21.65],inner_radius_mm=radius,
                       head_lo_mm=head_lo.tolist(),head_hi_mm=head_hi.tolist(),
                       tie_product_selected=False,formed_shape='ASSUMED',physical_grip='NOT_TESTED')
