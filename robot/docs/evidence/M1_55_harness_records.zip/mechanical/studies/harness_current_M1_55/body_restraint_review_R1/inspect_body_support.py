"""Read actual body-fixed printed support near the current CAM exit leads.

No mounting features are generated; this prevents choosing a support from a
rendered appearance or an allocation box instead of current native surfaces.
"""
from pathlib import Path
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,sha,Vector
sys.path.insert(0,str(HERE))
from fixed_lead_family import SelectedFamily,BSpline,NAMES


def main():
    ctx=Context();family=SelectedFamily();u=np.linspace(0,1,18001)
    hosts={n:s for n,s in ctx.ss.items() if s.o.get('category')=='PRINTABLE' and s.group not in ['yaw','pitch']}
    ports=[]
    for name in ['MCU_Carrier','Yaw_Base','Load_Frame','Body_Rear','Body_Front','Battery_Tray']:
        if name in ctx.ss:
            s=ctx.ss[name];ports.append(dict(name=name,group=s.group,lo_mm=s.lo.tolist(),hi_mm=s.hi.tolist()))
    rows=[]
    for name in NAMES:
        p=BSpline(family.knots,family.candidate(name,0)['control'],3)(u)
        arc=np.r_[0,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
        for distance in [5.,8.,10.,15.,20.,30.,40.]:
            point=np.array([np.interp(distance,arc,p[:,j]) for j in range(3)])
            near=[]
            for host,s in hosts.items():
                found=s.bvh().find_nearest(Vector(point))
                near.append(dict(host=host,world_point_mm=list(found[0]),distance_to_reference_centre_mm=float(found[3])))
            rows.append(dict(wire=name,station_polyline_approx_mm=distance,point_mm=point.tolist(),
                             closest_body_prints=sorted(near,key=lambda r:r['distance_to_reference_centre_mm'])[:3]))
    ctx.record([Path(__file__),HERE/'fixed_lead_family.py']);ctx.unchanged();family.unchanged()
    out=dict(status='PASS',scope='Current native surface proximity; no restraint or physical port qualification',
        sources=ctx.sources|family.sources,body_prints=len(hosts),ports=ports,rows=rows,
        main_changed=False,hardware_changed=False,manufacturing_release=False,full_harness='BLOCKED')
    (HERE/'body_support_inspection.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BODY_SUPPORT_CURRENT_INSPECTION_PASS',len(rows),'sites',len(hosts),'body prints',flush=True)


if __name__=='__main__':main()
