"""Publish the scoped bench/bridge sequence, preserving every failed attempt."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    names=['oriented_tie_verification.json','bench_tool_verification_R3.json','bench_render_manifest.json',
           'bench_native_source_receipt.json','bench_saved_readback.json','wired_bridge_entry_verification.json',
           'entry_transform_constancy.json','rigid_additions_entry.json']
    reports={n:json.loads((HERE/n).read_text()) for n in names};sources={}
    for n,d in reports.items():
        assert d['status']=='PASS',(n,d['status'])
        for p,h in d['sources'].items():
            assert sha(p)==h,(n,p)
            assert p not in sources or sources[p]==h
            sources[p]=h
    for n in ['bench_tool_verification.json','bench_tool_verification_R2.json']:
        assert json.loads((HERE/n).read_text())['status']=='BLOCKED'
    render=reports['bench_render_manifest.json'];saved=reports['bench_saved_readback.json']
    assert saved['objects_checked']==21 and saved['meshes_checked']==13 and saved['curves_checked']==8
    assert saved['inspection_sha256']==render['inspection_sha256']==sha(HERE/render['inspection_file'])
    assert saved['render_manifest_sha256']==sha(HERE/'bench_render_manifest.json')
    visual_path=HERE/'bench_visual_review.json';visual=json.loads(visual_path.read_text())
    assert visual['status']=='PASS' and visual['files']==render['files']
    assert all(sha(HERE/r['file'])==r['sha256'] for r in visual['files'])
    entry=reports['wired_bridge_entry_verification.json']
    assert entry['earlier_obstacle_count']==83 and len(entry['results'])==8
    assert entry['successful_preparations']==['bench_straight','final_zero_reference']
    assert reports['entry_transform_constancy.json']['objects_and_ancestors_checked']==86
    assert len(reports['rigid_additions_entry.json']['results'])==2
    main=PROJECT/'mechanical/mori_v1_2.blend';video=PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(main)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM 扎带与装桥候选顺序</title><style>body{max-width:1120px;margin:2rem auto;padding:0 1rem;font:16px/1.75 system-ui;color:#24343d}a{color:#176687}.note{padding:16px;background:#fff2d5;border-left:4px solid #bf8b24}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}figure{margin:0 0 20px}img{width:100%;height:auto}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd6dc;padding:8px;text-align:left}@media(max-width:720px){.grid{grid-template-columns:1fr}}</style>
<h1>M1.55 · CAM 扎带与装桥候选顺序</h1>
<p class="note">独立候选，未应用到主模型或视频。只有四根 CAM 容量参考及这处固定结构的局部顺序；完整线束、真实端子、柔性整理、手部支承和闭壳仍未完成。</p>
<p>新增短座并入现有偏航桥，无新增打印件或螺钉。采用当前坐标：+X机器人右方、+Y前方、+Z上方。灰色是当前实体／桥候选，青色是短座，橙色是线与扎带参考，粉红色是待剪长尾，蓝色是剪钳工作包络。</p>
<h2>为什么要先剪尾再装桥</h2>
<div class="grid"><figure><img src="mounted_uncut_tail.png" alt="未剪长尾在身体内碰电源板和托板"><figcaption>未剪尾碰电源板及 Load_Frame。此图显示局部相交，完整余尾由计算检查。</figcaption></figure><figure><img src="bench_tool_detail.png" alt="独立桥下方的绑线座、带根和回穿段"><figcaption>桥外夹持细节：补出侧面带根、垂直回穿及余尾；局部图隐藏剪钳复制件，工具见全景。</figcaption></figure></div>
<h2>候选步骤</h2>
<ol><li>身体端四个端子保持用户确认的“厂家压接、暂不入壳”；两端先不连接。将四根容量参考平直放开，固定点两侧的数值材料长度保持。</li><li>在脱离身体的桥上放好线和扎带。扎带实际穿扣、收紧与抗滑未验证；模型只给出估算成形与回穿方向。</li><li>从机器人右后方进剪钳并剪尾。30°、45°、55°三个角度的60mm连续工具包络路径通过；示意用45°。保留2mm余尾是本候选的工作基准。</li><li>身体壳和电池托盘尚未装时，按现有动画路径装桥：后退14mm的位置下放，再前移14mm，最后下降18mm落座。四根平直参考和四根最终零位参考分别检查，均通过；仍未证明二者之间的实际柔性整理。</li><li>真实插头／端子入壳、其他线路、头部装入和闭壳继续完成，不能据这些局部通过宣布整机带线装配完成。</li></ol>
<div class="grid"><figure><img src="bench_tool_overview.png" alt="完整剪钳工作包络及两端平直参考线"><figcaption>桥外全景：蓝色是扩大后的工具工作包络，完整钳柄及两端参考线均显示；不是采购剪钳CAD。</figcaption></figure><figure><img src="trimmed_final_reference.png" alt="剪尾之后的最终零位参考线形"><figcaption>最后的参考线形。此图与左图属于两个独立状态，不是已验证的柔性变形动画。</figcaption></figure></div>
<h2>已验证的范围</h2>
<table><tr><th>范围</th><th>结果</th><th>限制</th></tr>
<tr><td>新版扎带带根／回穿／剪尾包络</td><td>276项原生姿态检查通过</td><td>扣头通道与成形ASSUMED；不是实物夹持证明</td></tr>
<tr><td>四根临时平直参考</td><td>固定点两侧Gauss128数值长度保持，桥／座接触检查通过</td><td>不是实际裁线长度或端子暂存证明</td></tr>
<tr><td>剪钳进入</td><td>3个方向的60mm连续包络路径通过</td><td>包络为估算；钳口、手部及剪切力未验证</td></tr>
<tr><td>四根CAM装桥</td><td>2种准备×4根线，全部路径通过</td><td>保留83件此前刚体；其他8条线和真实接头未覆盖</td></tr>
<tr><td>此前刚体的姿态</td><td>86个对象及祖先的完整变换通道控制界确认静止</td><td>补充49个姿态读回，不以抽样代替静止证明</td></tr>
<tr><td>新短座及剪尾扎带装桥</td><td>两项增量连续路径通过</td><td>原桥的已有检查另列；强度、手部支承仍未验证</td></tr>
<tr><td>独立Blender文件</td><td>保存并重开，13件网格及8条显示曲线读回通过</td><td>只有自己的三个场景；默认打开桥外工具场景</td></tr></table>
<p>工具基于 KNIPEX 79 22 125 的官方索引目录尺寸，外形为加余量的矩形工作包络；<a href="https://www.knipex.com/sites/default/files/Product%20data%20sheet%20EN%2079%2022%20125.pdf">原厂数据链接</a>直接下载返回403，未声称已阅读完整PDF或取得工具CAD。T18R具体版本未选定，100mm多版目录范围组合也不等于实物扣头通道。旧全形线参考的剪钳失败方向均保留，没有缩小工具或移动真实硬件掩盖问题。</p>
<p><a href="M1_55_CAM_bench_sequence_UNADOPTED.blend">可编辑独立装桥／剪尾候选</a> · <a href="bench_tool_verification_R3.json">剪尾工作空间</a> · <a href="wired_bridge_entry_verification.json">四根参考装桥</a> · <a href="entry_transform_constancy.json">完整变换通道检查</a> · <a href="rigid_additions_entry.json">新增结构装桥</a> · <a href="bench_saved_readback.json">保存后读回</a> · <a href="../continuous_motion_review_R1/index.html">身体参考连续运动</a> · <a href="../index.html">固定候选总览</a></p>
<p>PRINTABLE / ASSUMED（新增短座）· PLACEHOLDER / ASSUMED（线、成形扎带、工具包络）· PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page+'\n')
    (HERE/'README.md').write_text('''# M1.55 CAM 扎带与装桥候选顺序，未采用

先将两端未连接的四根容量参考平直放开，再在桥外剪尾，后按现有动画装桥。
平直参考保持固定点两侧数值材料长度；这不是实际裁线数据或完整柔性整理。
工具30/45/55度的60mm连续包络路径通过；原整形参考各失败方向保留。
工具外形ASSUMED，官方PDF直接下载403，不声称工具CAD、真实钳口或手部操作资格。
扎带回穿通道及成形ASSUMED，穿扣／夹持／抗滑仍待实物验证。

83件此前刚体保留，4根CAM×2种准备的现有装桥路径通过。
86个对象及祖先完整变换通道控制界检查，补充抽样读回。
新增短座／剪尾扎带的增量装入通过；其他8条线、端子／塑壳、柔性整理和闭壳未覆盖。
独立文件仅有自己的三个场景，保存重开后默认工具场景；13网格及8条显示曲线一致。
主模型M1.55、动画M1.55-A1与硬件保持，manufacturing_release=false。
''')
    sources[str(Path(__file__))]=sha(Path(__file__));sources[str(visual_path)]=sha(visual_path)
    for n in names:sources[str(HERE/n)]=sha(HERE/n)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.suffix not in ['.blend1','.blend2'] and p.name not in ['delivery.json','publication_verification.json']}
    delivery=dict(status='PASS',scope='Scoped candidate bench/bridge sequence publication, no actual harness qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        source_blend_sha256=sha(main),source_video_sha256=sha(video),native_tie_pose_checks=276,
        accepted_tool_angles_deg=[30,45,55],CAM_bridge_preparations=2,CAM_bridge_curve_checks=8,
        earlier_rigid_obstacles=83,constant_objects_and_ancestors=86,rigid_increment_checks=2,
        saved_meshes=13,saved_curves=8,actual_harness='BLOCKED',actual_tool_and_grip='NOT_TESTED',
        main_changed=False,hardware_changed=False,animation_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    print('BODY_TIE_SEQUENCE_PUBLISHED',len(files),len(sources),flush=True)


if __name__=='__main__':main()
