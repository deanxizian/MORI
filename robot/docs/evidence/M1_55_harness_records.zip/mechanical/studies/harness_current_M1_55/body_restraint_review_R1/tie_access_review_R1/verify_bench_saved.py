"""Compare all owned saved parts and curves, then save a usable regular blend."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import bpy
import numpy as np

HERE=Path(__file__).resolve().parent;BODY=HERE.parent
sys.path.insert(0,str(BODY))
from flat_key_family import FlatKeyFamily,BSpline
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    render_path=HERE/'bench_render_manifest.json';render=json.loads(render_path.read_text())
    path=HERE/render['inspection_file'];assert Path(bpy.data.filepath).resolve()==path
    assert sha(path)==render['inspection_sha256']
    assert all(sha(p)==h for p,h in render['sources'].items())
    source_path=HERE/'bench_native_source_receipt.json';source=json.loads(source_path.read_text())
    assert source['status']=='PASS' and all(sha(p)==h for p,h in source['sources'].items())
    native_path=HERE/'bench_original_native_sources.npz';assert sha(native_path)==source['arrays_sha256']
    native=np.load(native_path);stage=np.load(HERE/'bench_tool_geometry_R3.npz')
    tie=np.load(HERE/'oriented_tie_geometry.npz');family=FlatKeyFamily()
    owner=render['review_owner'];results=[]

    def compare_all():
        checked=[]
        assert set(s.name for s in bpy.data.scenes)==set(render['scenes'])
        for entry in render['objects']:
            obj=bpy.data.objects[entry['name']];key=entry['role_key']
            assert obj.get('review_owner')==owner and obj.name in bpy.data.scenes[entry['scene']].objects
            assert np.array_equal(np.asarray(obj.matrix_world),np.eye(4))
            assert not obj.get('export_candidate') and obj.get('category') in ['PRINTABLE','PURCHASED_REFERENCE','PLACEHOLDER']
            if entry['kind']=='MESH':
                data=native if key in source['native_ids'] else tie if key=='extra_tail' else stage
                expected=data[key+'_vertices'];faces=data[key+'_faces']
                vertices=np.array([v.co[:] for v in obj.data.vertices])
                actual_faces=np.array([p.vertices[:] for p in obj.data.polygons])
                assert vertices.shape==expected.shape and np.array_equal(actual_faces,faces)
                error=float(np.max(abs(vertices-expected)));assert error<2e-5,(obj.name,error)
            else:
                if entry['scene'].endswith('_bench_cut'):
                    cubic=stage[key+'_stage_cubic'];u=np.linspace(0,1,entry['samples'])
                    expected=(1-u)[:,None]*cubic[0]+u[:,None]*cubic[-1]
                else:expected=BSpline(family.knots,family.candidate(key,0)['control'],3)(np.linspace(0,1,entry['samples']))
                actual=np.array([p.co[:3] for p in obj.data.splines[0].points])
                assert actual.shape==expected.shape and abs(obj.data.bevel_depth-.565)<1e-7
                error=float(np.max(abs(actual-expected)));assert error<2e-5,(obj.name,error)
            checked.append(dict(name=obj.name,scene=entry['scene'],kind=entry['kind'],status='PASS',
                                maximum_world_vertex_error_mm=error))
        return checked

    results=compare_all()
    # The first compact export was a Blender library. A regular owned file
    # stores the window/active-scene state, so opening it shows the bench.
    bpy.context.window.scene=bpy.data.scenes[owner+'_bench_cut']
    bpy.ops.wm.save_as_mainfile(filepath=str(path),compress=True)
    bpy.ops.wm.open_mainfile(filepath=str(path))
    assert bpy.context.window.scene.name==owner+'_bench_cut'
    reopened=compare_all();assert reopened==results
    family.unchanged()
    render['inspection_sha256']=sha(path)
    render['inspection_format']='Regular blend; active bench scene verified after reopening'
    render['sources'][str(Path(__file__))]=sha(Path(__file__))
    render['sources'][str(source_path)]=sha(source_path)
    render['sources'][str(native_path)]=sha(native_path)
    render_path.write_text(json.dumps(render,indent=2)+'\n')
    proof_sources=dict(render['sources'])|family.sources
    proof_sources[str(render_path)]=sha(render_path)
    proof=dict(status='PASS',scope='Saved/reopened owned scene meshes, curves, evidence labels and active scene only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=proof_sources,
        objects_checked=len(results),meshes_checked=sum(r['kind']=='MESH' for r in results),
        curves_checked=sum(r['kind']=='CURVE' for r in results),results=results,
        initial_library_scene_warning='Resolved by regular blend save and verified active bench scene',
        inspection_sha256=sha(path),render_manifest_sha256=sha(render_path),
        main_changed=False,hardware_changed=False,animation_changed=False,
        actual_harness='BLOCKED',manufacturing_release=False)
    (HERE/'bench_saved_readback.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('BODY_BENCH_SAVED_VERIFIED',len(results),'regular active scene',bpy.context.window.scene.name,flush=True)


if __name__=='__main__':main()
