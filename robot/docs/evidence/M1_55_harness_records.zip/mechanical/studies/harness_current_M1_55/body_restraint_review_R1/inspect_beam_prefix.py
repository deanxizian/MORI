"""Current native and peer checks for the anchored AWG28 body-prefix study."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,transform_points,rigidtr,sha
sys.path.insert(0,str(HERE))
from beam_anchor_family import BeamAnchorFamily
from fixed_lead_family import BSpline,NAMES
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,radius_bound
helper_path=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_beam_prefix_geometry_helpers',helper_path)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)


def main():
    start=time.time();native=Context()
    blend=next((int(a.split('=',1)[1]) for a in sys.argv if a.startswith('--blend=')),4)
    mode='full_grid' if '--full-grid' in sys.argv else 'pilot'
    family=BeamAnchorFamily(blend,4.)
    facts_path=PARENT/'materials/source_facts.json'
    facts=json.loads(facts_path.read_text());wire=facts['Tensility_30_02600']
    assert not wire['selected'] and wire['OD_max_mm']==1.13
    radius=wire['OD_max_mm']/2
    planned=([0,-60,60] if mode=='pilot' else [0,-60,60,-55,55,-50,50,-45,45,-40,40,-35,35,-30,30,-25,25,-20,20,-15,15,-10,10,-5,5])
    rows=[];failures=[];checked=[];math=[];arrays={}
    for yaw in planned:
        packs={}
        for n in family.names:
            candidate=family.candidate(n,yaw);c=candidate['control'];cubics=pieces(BSpline(family.knots,c,3))
            packs[n]=helper.prepare(cubics,radius if n in NAMES else family.radii[n])
            if n in NAMES:
                bound=radius_bound(cubics)
                fixed_error=float(np.max(abs(c[:family.locked_controls[n]]-family.fixed[n][:family.locked_controls[n]])))
                row=dict(wire=n,yaw_deg=yaw,status='PASS' if bound['radius_lower_mm']>=6.865 and fixed_error<1e-12 and abs(candidate['reference_length_residual_mm'])<1e-8 else 'BLOCKED',
                    radius_lower_mm=bound['radius_lower_mm'],fixed_control_error_mm=fixed_error,
                    numeric_length_residual_mm=candidate['reference_length_residual_mm'])
                math.append(row)
                if row['status']!='PASS':failures.append(row)
                arrays[f'{n}_y{yaw}_controls']=c
        for n in NAMES:
            pack=packs[n]
            for group,targets in native.groups.items():
                for pitch in ([-20,0,25] if group=='pitch' else [0]):
                    matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                    norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
                    hits,near=clear(transform_points(pack['p'],matrix),radius*norm,targets,error=pack['error']*norm,gap=.3*norm)
                    row=dict(wire=n,yaw_deg=yaw,pitch_deg=pitch,group=group,kind='native',status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near)
                    rows.append(row)
                    if hits:failures.append(row)
            row=dict(wires=[n,n],yaw_deg=yaw,**helper.compare(pack,pack,'self'))
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
        for a,b in itertools.combinations(packs,2):
            if a not in NAMES and b not in NAMES:continue
            row=dict(wires=[a,b],yaw_deg=yaw,**helper.compare(packs[a],packs[b]))
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
        checked.append(yaw)
        print('BODY_BEAM_CURRENT_POSE',blend,yaw,'checks',len(rows),'failures',len(failures),'elapsed',time.time()-start,flush=True)
        if failures:break
    native.record([Path(__file__),helper_path,facts_path]);native.unchanged();family.unchanged()
    filename=f'beam_blend{blend}_{mode}'
    np.savez_compressed(HERE/(filename+'_controls.npz'),**arrays)
    result=dict(status='PASS' if len(checked)==len(planned) and not failures else 'BLOCKED',
        scope='Finite anchored-body-prefix curvature, native and peer clearance; no upper-pair or actual retention qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',sources=native.sources|family.sources,
        blend_controls=blend,extra_reference_length_mm=4.,wire_radius_mm=radius,planned_yaws=planned,checked_yaws=checked,
        pitch_samples_deg=[-20,0,25],checks=len(rows),rows=rows,curve_math=math,failures=failures,
        anchor_datums=family.anchor_datums,body_reference_targets=family.targets,
        arrays_sha256=sha(HERE/(filename+'_controls.npz')),all_angle_clearance='NOT_TESTED',
        upper_pairs='NOT_TESTED',actual_retention='NOT_TESTED',actual_crimp_exit='BLOCKED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/(filename+'_geometry.json')).write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_BEAM_CURRENT_TERMINAL',blend,mode,result['status'],len(checked),len(rows),len(failures),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
