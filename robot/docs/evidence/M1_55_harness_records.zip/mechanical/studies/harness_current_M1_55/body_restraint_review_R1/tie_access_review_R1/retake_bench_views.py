"""Repair only the owned independent scene cameras; preserve all geometry."""
from pathlib import Path
import datetime
import hashlib
import json
import bpy
import numpy as np
from mathutils import Vector

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    path=HERE/'M1_55_CAM_bench_sequence_UNADOPTED.blend'
    assert Path(bpy.data.filepath).resolve()==path
    original=HERE/'initial_view_occlusion/bench_render_manifest.json'
    report=json.loads(original.read_text());owner=report['review_owner']
    assert set(s.name for s in bpy.data.scenes)==set(report['scenes'])
    assert all(s.get('review_owner')==owner for s in bpy.data.scenes)
    scene=bpy.data.scenes[owner+'_bench_cut'];bpy.context.window.scene=scene
    camera=scene.camera
    tool=next(o for o in scene.objects if o.get('role_key')=='cutter_final_a45')
    assert tool.get('review_owner')==owner
    # A clamp-detail view intentionally omits the tool copy. The complete
    # tool and all staged wires remain visible in the separate overview.
    tool.hide_render=True
    camera.location=(55,-125,120)
    camera.rotation_euler=(Vector((31.5,-23,143))-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.ortho_scale=28
    scene.render.filepath=str(HERE/'bench_tool_detail.png');bpy.ops.render.render(write_still=True)
    tool.hide_render=False
    camera.location=(270,-290,350)
    camera.rotation_euler=(Vector((48,21,142))-camera.location).to_track_quat('-Z','Y').to_euler()
    points=[]
    for o in scene.objects:
        if o.type=='MESH':points.append(np.array([v.co[:] for v in o.data.vertices]))
        elif o.type=='CURVE':
            for spline in o.data.splines:points.append(np.array([v.co[:3] for v in spline.points]))
    points=np.vstack(points);matrix=np.asarray(camera.rotation_euler.to_matrix())
    projected=(points-np.asarray(camera.location))@matrix
    lower=projected[:,:2].min(0);upper=projected[:,:2].max(0);center=(lower+upper)/2
    camera.location+=Vector((matrix@np.r_[center,0]).tolist())
    aspect=scene.render.resolution_x/scene.render.resolution_y
    span=upper-lower;camera.data.ortho_scale=1.12*max(float(span[0]),float(span[1])*aspect)
    scene.render.filepath=str(HERE/'bench_tool_overview.png');bpy.ops.render.render(write_still=True)
    for row in report['files']:row['sha256']=sha(HERE/row['file'])
    bpy.data.libraries.write(str(path),set(bpy.data.scenes),fake_user=True,compress=True)
    report['inspection_sha256']=sha(path)
    report['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['sources'][str(Path(__file__))]=sha(Path(__file__))
    report['sources'][str(original)]=sha(original)
    report['camera_correction']=dict(status='PASS',geometry_changed=False,
        close_view='Clamp, root and return only; tool copy hidden only for this render',
        overview='Full-scene projected bounding box with 12 percent border',
        initial_visual_diagnostic='initial_view_occlusion/visual_diagnostic.json')
    (HERE/'bench_render_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_BENCH_VIEWS_REPAIRED',camera.data.ortho_scale,report['inspection_sha256'],flush=True)


if __name__=='__main__':main()
