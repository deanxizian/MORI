"""Continuous reference from newly optimized fixed-body key poses.

Existing body ports, end datums and eight neighbouring references remain.
The former constant-correction family failed and is retained separately.
"""
from pathlib import Path
import json
import numpy as np
from flat_body_family import FlatBodyFamily, NAMES, sha
from frame_family import FrameFamily, BSpline, rotate
from family import smooth

HERE=Path(__file__).resolve().parent


class FlatKeyFamily(FlatBodyFamily):
    def __init__(self):
        super().__init__()
        path=HERE/'flat_keyframes_R2/all_keys_optimization.json'
        receipt=json.loads(path.read_text())
        assert receipt['status']=='PASS' and receipt['planned_yaws_deg']==list(range(-60,61,10))
        assert all(sha(p)==h for p,h in receipt['sources'].items())
        source=path.parent/'all_keys_controls.npz';assert sha(source)==receipt['arrays_sha256']
        data=np.load(source)
        for yaw in range(-60,61,10):
            for n in NAMES:
                c=data[f'{n}_y{yaw}_controls'].copy()
                assert np.max(abs(c[:self.locked_controls[n]]-self.seed[n][:self.locked_controls[n]]))<1e-12
                assert np.max(abs(c[-2:]-self.controls[yaw][n][-2:]))<1e-6
                self.controls[yaw][n]=c
        for n in NAMES:
            self.seed[n]=self.controls[0][n].copy()
            u=np.clip((self.seed[n][:,2]-self.z0)/(self.z1-self.z0),0,1)
            frame=smooth(u);frame[:self.locked_controls[n]]=0;frame[-2:]=1
            self.frame_weights[n]=frame;self.radii[n]=.565
            for yaw in range(-60,61,10):
                c=self.controls[yaw][n];v=self.Q@c
                gradient=self.Q.T@(self.weights[:,None]*v/np.linalg.norm(v,axis=1)[:,None])
                gradient*=np.clip((190.-c[:,2])/20.,0.,1.)[:,None]**2
                gradient[:self.locked_controls[n]]=0;gradient[-2:]=0
                peak=float(np.linalg.norm(gradient,axis=1).max());assert peak>1e-8
                self.directions[yaw][n]=gradient/peak
                self.local_controls[yaw][n]=rotate(c,-frame*yaw)
                self.local_directions[yaw][n]=rotate(self.directions[yaw][n],-frame*yaw)
        for p in [Path(__file__),path,source,HERE/'flat_body_family.py']:
            self.sources[str(p)]=sha(p)

    def base(self,name,yaw):
        return FrameFamily.base(self,name,yaw)
