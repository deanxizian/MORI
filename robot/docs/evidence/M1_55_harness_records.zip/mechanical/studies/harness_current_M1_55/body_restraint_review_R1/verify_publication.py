"""Verify leaf hashes, protected files and bytes actually served locally."""
from pathlib import Path
import datetime
import hashlib
import json
import re
from urllib.parse import urlsplit,unquote,quote
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    delivery=read(HERE/'delivery.json')
    assert delivery['status']=='PASS' and delivery['actual_harness']=='BLOCKED'
    assert delivery['body_curve_checks']==100 and delivery['body_native_pair_checks']==3650
    assert delivery['body_fixture_checks']==600 and delivery['feature_checks']==552
    assert all(sha(p)==h for p,h in delivery['sources'].items())
    assert all((HERE/p).is_file() and sha(HERE/p)==h for p,h in delivery['files'].items())
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={n:h for n,h in baseline['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')==delivery['source_blend_sha256']
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')==delivery['source_video_sha256']
    subreviews=[]
    pages=[HERE/'index.html']
    for name in ['continuous_motion_review_R1','tie_access_review_R1']:
        root=HERE/name
        child=read(root/'delivery.json')
        assert child['status']=='PASS'
        assert all(sha(p)==h for p,h in child['sources'].items())
        assert all((root/p).is_file() and sha(root/p)==h for p,h in child['files'].items())
        subreviews.append(dict(name=name,delivery_sha256=sha(root/'delivery.json'),
            files_checked=len(child['files']),sources_checked=len(child['sources'])))
        pages.append(root/'index.html')
    links=[]
    for page in pages:
        url='http://127.0.0.1:58202/'+quote(str(page.relative_to(PROJECT)))
        with urlopen(url,timeout=10) as response:served=response.read()
        assert hashlib.sha256(served).hexdigest()==sha(page)
        for link in re.findall(r'(?:href|src)="([^"]+)"',page.read_text()):
            parsed=urlsplit(link)
            if parsed.scheme or not parsed.path:continue
            p=(page.parent/unquote(parsed.path)).resolve()
            assert p.is_file() and p.is_relative_to(PROJECT),(link,p)
            url='http://127.0.0.1:58202/'+quote(str(p.relative_to(PROJECT)))
            with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
            if p.suffix in ['.html','.png','.svg','.md']:
                with urlopen(url,timeout=10) as response:served=response.read()
                assert hashlib.sha256(served).hexdigest()==sha(p)
            links.append(dict(page=str(page.relative_to(PROJECT)),link=link,target=str(p.relative_to(PROJECT))))
    result=dict(status='PASS',scope='Source/file preservation and local served-byte publication only, no harness release',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),delivery_sha256=sha(HERE/'delivery.json'),
        files_checked=len(delivery['files']),sources_checked=len(delivery['sources']),links=links,
        subreviews=subreviews,served_pages=len(pages),
        protected_hardware_files=len(protected),main_changed=False,hardware_changed=False,animation_changed=False,
        actual_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
    (HERE/'publication_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_RESTRAINT_PUBLICATION_VERIFIED',len(delivery['files']),len(delivery['sources']),len(links),len(protected),flush=True)


if __name__=='__main__':main()
