"""New all-yaw pair and remote-self bounds for the four changed body leads.

Every pair touching a changed CAM curve is recomputed. Unchanged-only pairs
are excluded explicitly; their old proof is not silently relabelled.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
OLD=PARENT/'prefix_continuity/frame_family_R3';GENERIC=OLD/'continuous_gaps_R1'
sys.path[:0]=[str(BODY),str(GENERIC),str(OLD)]
from flat_key_family import FlatKeyFamily,NAMES,np,sha
from motion_envelopes import Envelopes
from pair_fields import reference,segment_motion,pair_bound,arc_upper,algorithm_checks


def main():
    started=time.time();f=FlatKeyFamily();e=Envelopes(f,count=1501);tests=algorithm_checks()
    root_path=HERE/'continuous_root_verification.json';bend_path=HERE/'continuous_bend_verification.json'
    cross_path=HERE/'motion_envelope_crosscheck.json'
    proof=json.loads(root_path.read_text());bend=json.loads(bend_path.read_text());cross=json.loads(cross_path.read_text())
    assert proof['status']==bend['status']==cross['status']=='PASS'
    assert len(cross['unchanged_neighbours'])==8 and proof['wire_count']==bend['wire_count']==4
    assert all(sha(p)==h for d in [proof,bend,cross] for p,h in d['sources'].items())
    pairs=[(a,b) for a,b in itertools.combinations(f.names,2) if a in NAMES or b in NAMES]
    assert len(pairs)==38
    pairs.extend((n,n) for n in NAMES);assert len(pairs)==42
    cached={};tested=0;results=[];failures=[]
    def get_reference(name,yaw):
        if (name,yaw) not in cached:cached[name,yaw]=reference(e.curve(name,yaw),f.radii[name])
        return cached[name,yaw]
    def compare(left,right,lo,hi,anchor):
        nonlocal tested
        a,b=get_reference(left,anchor),get_reference(right,anchor)
        ea=e.control_envelopes(left,lo,hi,anchor);eb=ea if left==right else e.control_envelopes(right,lo,hi,anchor)
        if ea is None or eb is None:return dict(status='BLOCKED',type='root_enclosure',gap_lower_mm=None)
        aw,ay=segment_motion(ea);bw,by=segment_motion(eb)
        arc=arc_upper(e,left,lo,hi,anchor) if left==right else None
        result=pair_bound(a,b,aw,ay,bw,by,arc_upper=arc);tested+=result['tested_segment_pairs']
        return dict(**result,anchor_yaw_deg=anchor,yaw_interval_deg=[lo,hi])
    for left,right in pairs:
        accepted=[];todo=[(*r['yaw_interval_deg'],0) for r in proof['certificates']]
        while todo:
            lo,hi,depth=todo.pop();mid=(lo+hi)/2;anchor=float(round(mid/5)*5)
            result=compare(left,right,lo,hi,anchor)
            if result['status']!='PASS':
                result=compare(left,right,lo,hi,mid);result['fresh_midpoint_reference']=True
            if result['status']=='PASS':accepted.append(result);continue
            if depth>=12:
                failures.append(dict(wires=[left,right],**result));break
            todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
        status='BLOCKED' if any(r['wires']==[left,right] for r in failures) else 'PASS'
        coverage=sorted(r['yaw_interval_deg'] for r in accepted)
        if status=='PASS':
            assert coverage[0][0]==-60 and coverage[-1][1]==60
            assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        row=dict(wires=[left,right],remote_self=left==right,status=status,accepted_yaw_cells=len(accepted),intervals=accepted)
        results.append(row)
        print('BODY_CHANGED_CONTINUOUS_PAIR',left,right,status,len(accepted),'segment_pairs',tested,
              'elapsed',round(time.time()-started,2),flush=True)
        if status!='PASS':break
    f.unchanged();sources=dict(f.sources)
    for p in [Path(__file__),GENERIC/'motion_envelopes.py',GENERIC/'pair_fields.py',root_path,bend_path,cross_path,
              OLD/'frame_motion_bounds.py',OLD.parent/'root_direction_R2/root_motion_bounds.py']:
        sources[str(p)]=sha(p)
    status='PASS' if len(results)==42 and not failures else 'BLOCKED'
    report=dict(status=status,scope='All-yaw 38 changed-reference peer pairs and four remote-self bounds only; upper tails excluded',
       recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,results=results,
       failures=failures,algorithm_checks=tests,required_gap_mm=.3,
       changed_curve_names=NAMES,wire_pairs_completed=sum(not r['remote_self'] for r in results),
       remote_self_completed=sum(r['remote_self'] for r in results),unchanged_only_pairs_rerun=False,
       yaw_coverage_deg=[-60,60],reference_curve_samples=len(e.t),finite_segment_comparisons=tested,
       self_local_arc_exclusion_mm=5.,self_arc_eligibility_uses_all_yaw_upper_bounds=True,
       local_self_exclusion_supported_by_continuous_radius_mm=6.865,
       actual_harness='BLOCKED',upper_tails='BLOCKED',main_changed=False,hardware_changed=False,
       manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'changed_peer_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_CHANGED_PEER_TERMINAL',status,len(results),tested,round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
