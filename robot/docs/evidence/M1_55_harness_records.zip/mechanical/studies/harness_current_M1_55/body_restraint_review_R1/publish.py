"""Publish scoped body restraint progress; no adoption or manufacturing claim."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    names=['body_pin_identification.json','refined_zero_verification.json','flat_zero_verification.json',
           'flat_key_family_math.json','restraint_geometry_verification.json','flat_motion_verification.json',
           'render_manifest.json','saved_inspection_readback.json',
           'continuous_motion_review_R1/continuous_root_verification.json',
           'continuous_motion_review_R1/continuous_bend_verification.json',
           'tie_access_review_R1/oriented_tie_verification.json',
           'continuous_motion_review_R1/delivery.json','tie_access_review_R1/delivery.json']
    reports={n:json.loads((HERE/n).read_text()) for n in names};sources={}
    for name,report in reports.items():
        assert report['status']=='PASS',(name,report['status'])
        for p,h in report['sources'].items():
            assert sha(p)==h,(name,p)
            assert p not in sources or sources[p]==h
            sources[p]=h
    math=reports['flat_key_family_math.json'];motion=reports['flat_motion_verification.json']
    geometry=reports['restraint_geometry_verification.json'];render=reports['render_manifest.json'];saved=reports['saved_inspection_readback.json']
    assert len(math['rows'])==100 and motion['checks']==3650 and motion['fixture_checks']==600
    assert len(motion['checked_yaws_deg'])==25 and not motion['failures']
    assert geometry['checks']==552 and geometry['merged_connected_components']==1
    assert len(saved['copied_parts'])==19 and len(saved['curves'])==8
    assert saved['inspection_sha256']==render['inspection_sha256']==sha(HERE/render['inspection_file'])
    assert saved['render_manifest_sha256']==sha(HERE/'render_manifest.json')
    roots=reports['continuous_motion_review_R1/continuous_root_verification.json']
    bends=reports['continuous_motion_review_R1/continuous_bend_verification.json']
    oriented=reports['tie_access_review_R1/oriented_tie_verification.json']
    assert roots['wire_count']==bends['wire_count']==4
    assert roots['accepted_yaw_cells']==240 and bends['required_radius_mm']==6.865
    assert oriented['native_pose_checks']==276 and not oriented['failures']
    assert oriented['untrimmed_in_current_assembly']['status']=='BLOCKED'
    assert oriented['detached_bridge_only']['status']=='PASS'
    continuous=reports['continuous_motion_review_R1/delivery.json']
    bench=reports['tie_access_review_R1/delivery.json']
    assert continuous['changed_curves']==4 and continuous['changed_peer_pairs']==38
    assert continuous['changed_remote_self']==4 and continuous['fixture_curves']==12
    assert bench['CAM_bridge_curve_checks']==8 and bench['earlier_rigid_obstacles']==83
    assert bench['constant_objects_and_ancestors']==86 and bench['rigid_increment_checks']==2
    assert all(sha(HERE/folder/p)==h for folder,report in [
        ('continuous_motion_review_R1',continuous),('tie_access_review_R1',bench)] for p,h in report['files'].items())
    main=PROJECT/'mechanical/mori_v1_2.blend';video=PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(main)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    visual=dict(status='PASS',scope='Directly viewed PNGs and pin diagram only; not physical retention',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        files=render['files']+[dict(file='J5_native_pin_views.svg.png',sha256=sha(HERE/'J5_native_pin_views.svg.png'))],
        notes=['Candidate pad is cyan inside the gray existing bridge, with amber unselected wire/tie reference',
               'Original comparison has no body restraint',
               'All four wires and the large assumed tie-head envelope are visible',
               'J5 diagram clearly distinguishes PCB views from housing cavity views'])
    (HERE/'visual_review.json').write_text(json.dumps(visual,indent=2)+'\n')
    commands=[]
    blender='/Applications/Blender.app/Contents/MacOS/Blender';python='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
    outcomes=[('inspect_support_contact.py','PASS'),('solve_flat_contact_zero.py','FAIL sampled curvature, solver execution succeeded'),
              ('solve_flat_contact_zero_R2.py','PASS optimizer execution only'),('inspect_flat_zero.py','PASS zero geometry'),
              ('screen_flat_family.py','BLOCKED seven curvature checks'),('solve_flat_keyframes.py','PASS optimizer execution only'),
              ('solve_flat_keyframes_all.py','PASS optimizer execution only'),('inspect_restraint_geometry.py','FAIL Python intended-contact assertion'),
              ('inspect_restraint_geometry_R2.py','PASS feature geometry'),('check_flat_key_math.py','PASS finite curve math'),
              ('inspect_flat_motion.py','PASS finite native/pair/fixture geometry'),('render_restraint_comparison.py','PASS render'),
              ('verify_saved_restraint.py','PASS saved readback and display metadata')]
    for filename,status in outcomes:
        if filename in ['screen_flat_family.py','check_flat_key_math.py']:
            argv=[python,str((HERE/filename).relative_to(PROJECT))]
        else:
            blend='mechanical/mori_v1_2.blend' if filename!='verify_saved_restraint.py' else str((HERE/render['inspection_file']).relative_to(PROJECT))
            argv=[blender,'--background',blend,'--python',str((HERE/filename).relative_to(PROJECT))]
            if filename=='solve_flat_keyframes_all.py':argv+=['--','--all-keys']
        commands.append(dict(argv=argv,cwd=str(PROJECT),process_exit_code=0,result=status,
                             terminal_log='Conversation tool transcript; exit code alone is not PASS'))
    commands.extend([
        dict(argv=[python,str((HERE/'continuous_motion_review_R1/certify_curve_continuity.py').relative_to(PROJECT))],
             cwd=str(PROJECT),process_exit_code=0,result='PASS new four-wire all-yaw numeric root and whole-curve bend only',
             terminal_log='Conversation tool transcript; no native/peer all-angle clearance claimed'),
        dict(argv=[blender,'--background','mechanical/mori_v1_2.blend','--python',
                   str((HERE/'tie_access_review_R1/inspect_oriented_tie.py').relative_to(PROJECT))],
             cwd=str(PROJECT),process_exit_code=0,result='PASS trimmed reference native fit; BLOCKED uncut tail in assembled body',
             terminal_log='Conversation tool transcript; no installation or full wired assembly qualification')])
    (HERE/'commands.json').write_text(json.dumps(dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        blender='5.2.2 LTS d13f752e3b9c',python='3.13.13',numpy='2.3.4',scipy='1.16.2',commands=commands),indent=2)+'\n')
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM 身体端固定候选</title><style>body{max-width:1100px;margin:2.5rem auto;padding:0 1rem;font:16px/1.7 system-ui;color:#24343d}a{color:#176687}.note{padding:16px;background:#fff2d5;border-left:4px solid #c29030}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}figure{margin:0 0 24px}img{width:100%;height:auto}table{border-collapse:collapse;width:100%}td,th{border:1px solid #cbd5d9;padding:8px;text-align:left}@media(max-width:700px){.grid{grid-template-columns:1fr}}</style>
<h1>M1.55 · CAM 身体端固定候选</h1>
<p class="note">独立研究，尚未采用。主模型 M1.55、视频 M1.55-A1 和原生硬件保持。完整线束仍 BLOCKED；不能放行打印整机或厂家裁线。</p>
<h2>最新进度与具体卡点</h2>
<p>四根新身体段已补齐全偏航数值长度根、整段转弯、当前201件实体的全偏航／俯仰，以及38组跨线／4条远端自接近。12条身体／颈部参考与新短座、带身、扣头的全偏航间隙也已通过；指定夹持面之外仍保持0.3mm要求。完整上段和真实材料资格不在这些通过范围内。</p>
<p>原厂扎带图显示带身从扣头侧面伸出，再沿另一方向穿回。本页下方旧闭合环图只保留为初始空间比较；新版已补带根、回穿段、余尾及图示。成形与扣头通道仍ASSUMED，真实穿扣、夹持、钳口与手部尚未验证。</p>
<p>具体装配约束已确定：先在拆下的桥上把两端未连接的线平直放开、剪尾，再装桥。数值材料坐标保持；工具三个方向的连续包络进入通过。4根参考×2种准备的现有装桥路径通过，保留83件此前刚体；86个对象／祖先变换通道和新增座／扎带增量路径另已核对。其他8条线、实际端子、柔性整理及完整闭壳仍未闭合。</p>
<div class="grid"><figure><img src="tie_access_review_R1/bench_tool_overview.png" alt="候选桥外剪尾与完整工具工作包络"><figcaption>两端先不连接、平直放开；蓝色是剪钳工作包络</figcaption></figure><figure><img src="tie_access_review_R1/trimmed_final_reference.png" alt="剪尾之后的参考线形"><figcaption>最后的参考线形；不是已验证的柔性变形动画</figcaption></figure></div>
<p><a href="continuous_motion_review_R1/index.html">新身体参考连续运动</a> · <a href="tie_access_review_R1/index.html">剪尾及装桥步骤、局部图和独立Blender</a></p>
<p>原参考的身体插头后线段会随转头移动，不能直接增加固定夹。本候选把身体端到固定点的参考线形保持不动，让后面的活动段补偿转头。</p>
<p>偏航桥后侧增加一块 8 × 5 × 1.635 mm 的短平面绑线座，与现有打印件连成一体；不增加打印件或螺钉。原桥不减料，新增净材料约 49.8 mm³。四根线在固定处平行，一根扎带把它们压在座下。该座用于应力释放；实际压紧、抗滑和疲劳尚未验证。</p>
<div class="grid"><figure><img src="original_rear.png" alt="现有参考，没有身体端固定"><figcaption>现有参考：没有身体端固定</figcaption></figure><figure><img src="candidate_rear.png" alt="候选：青色一体绑线座和黄色扎带包络"><figcaption>候选：青色是一体绑线座；黄色是未选定的线材／扎带包络</figcaption></figure></div>
<div class="grid"><figure><img src="original_underside.png" alt="现有参考下方观察"><figcaption>现有参考 · 下方观察</figcaption></figure><figure><img src="candidate_underside.png" alt="候选下方观察，线材贴合与扎带头部可见"><figcaption>候选 · 下方观察</figcaption></figure></div>
<h2>初始有限检查（旧闭合环包络，保留比较）</h2>
<table><tr><th>范围</th><th>结果</th><th>边界</th></tr>
<tr><td>4根身体段 × 25个偏航角</td><td>100条整段曲率／数值长度／固定端检查 PASS</td><td>不是实物线长或拉伸测量</td></tr>
<tr><td>当前201件原生实体、邻线及原七条上段</td><td>3,650项检查 PASS</td><td>偏航每5°，头部俯仰−20°／0°／25°；角度之间仍未证明</td></tr>
<tr><td>12条前段与新固定结构</td><td>600项检查 PASS</td><td>仅四根CAM的指定夹持接触允许零间隙，其他线保持0.3mm</td></tr>
<tr><td>绑线座／扎带包络与原生实体</td><td>552项检查 PASS，覆盖250个头部组合姿态</td><td>只证明参考空间；不证明实际扎带装入或夹持强度</td></tr>
<tr><td>保存后的独立Blender</td><td>19个复制实体及8条显示曲线回读 PASS</td><td>来源为当前验证世界网格，供应商代理局限保持</td></tr></table>
<p>身体段使用未选定的 Tensility AWG28 最大外径 1.13 mm。活动路线增加的 4 mm 是数值余量，不是裁线要求；头内厂配 SH 尾线保持。扎带按 T18R 多份图纸的最大外形估算，安装后的形状、头部通道及摩擦均 ASSUMED。图中的大方块是扎带头部包络，不是新增打印件。</p>
<p>初版平直化急弯、旧恒定修正家族的七处曲率失败，以及接触面数值精度断言失败均保留。最后一项见证深度约3×10⁻⁹mm，仅对命名的扎带／座接触采用10⁻⁶mm³数值容差；没有放宽其他0.3mm间隙。</p>
<h2>身体端针号识别</h2>
<p>按当前原生运动板 P5R7 补齐 J5.1～4 与 CAM J11.1～4 的对应。CAM_RX／CAM_TX 不再交叉；第三针 CAM_3V3 是逻辑参考，不能当作CAM主供电。以下是PCB观察面图，塑壳腔体方向仍待专用资料或到货核对。</p>
<img src="J5_native_pin_views.svg" alt="J5组件面与焊接面针号图">
<p><a href="H06_body_pin_identification.md">逐针与入壳说明</a> · <a href="body_pin_identification.json">原生针号证据</a></p>
<h2>仍要完成</h2>
<ol><li>完整上段的全角度间隙／运动，以及实际扎带穿扣、手部与钳口。新身体固定参考的连续转弯／长度／实体／跨线／固定结构空间已经通过。</li><li>实际线材分段、接续保护、夹持与供应商裁线图；厂配SH尾线待到货核对。</li><li>头部舵机3根线与喇叭2根线的上段，真实接口／出口仍缺资料；CAM供电源端待硬件正式交接。</li><li>其他线路、实际端子、柔性整理、头部装入及闭壳，再提交采用确认并同步主模型和视频。CAM四根及新增固定结构的装桥容量路径已通过。</li></ol>
<p>完整目标仍有4类工作：完整路线与运动、材料和线长、端接及应力释放、带线装配与闭壳。本候选推进身体端固定，不代表其中任何一类整体完成。</p>
<p><a href="M1_55_CAM_body_restraint_UNADOPTED.blend">初始闭合环比较Blender（历史）</a> · <a href="tie_access_review_R1/M1_55_CAM_bench_sequence_UNADOPTED.blend">最新装桥／剪尾独立Blender</a> · <a href="flat_motion_verification.json">初始有限配合检查</a> · <a href="flat_key_family_math.json">曲率与固定端</a> · <a href="restraint_geometry_verification.json">初始固定结构</a> · <a href="saved_inspection_readback.json">初始保存后回读</a> · <a href="commands.json">实际命令与失败</a> · <a href="../index.html">研究总览</a> · <a href="../../../index.html">主模型入口</a></p>
<p>PRINTABLE / ASSUMED（座）· PLACEHOLDER / ASSUMED（未选线材、成形扎带）· PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page+'\n')
    (HERE/'README.md').write_text('''# M1.55 CAM 身体端固定研究，未采用

8×5×1.635 mm 一体绑线座与四根平行信号线；一根未选定扎带，无新增打印件／螺钉。
原桥不减料，净增加49.8mm³。四根的身体端至固定点参考线形不随转头移动。
100条有限曲率／长度／固定端、3650项原生／跨线、600项线与固定座、552项固定座空间检查通过。
覆盖25个偏航角、三个线束头部俯仰样本；固定座本身另覆盖250个组合姿态。
上述有限检查不证明连续角度、实际材料、夹持强度、扎带装入或完整带线装配。

后续continuous_motion_review_R1已补四根新身体段全−60～60°数值长度根与整段转弯界。
后续已补当前201件实体全偏航／俯仰、38跨线／4远端自身，以及12前段对新座／带身／扣头全偏航。
tie_access_review_R1按原厂图补侧面带根、垂直回穿段和余尾；
新版剪尾参考276项原生姿态与四根直线接触检查通过，扣头通道与成形仍ASSUMED。
未剪余尾在已装身体内碰Load_Frame／电源板且靠近电池垫，证据保留为BLOCKED。
两端先不连接、平直放开后剪尾，保持数值材料坐标；工具三个方向的连续包络进入通过。
4根CAM×2种准备装桥通过，保留83件此前刚体；86对象／祖先变换通道和新增座／扎带路径另检。
实际钳口／手部／穿扣、端子、柔性整理、其他线路、完整带线闭壳仍未完成。
下方原有PNG和inspection.blend保持初始闭合环空间包络，不代表新版穿扣／剪尾动画。

材料使用未选定Tensility AWG28最大外径1.13作容量参考，厂配SH尾线未改。
新增4mm为数值活动余量，不是裁线尺寸；扎带成形、通道及摩擦ASSUMED。
保存候选回读了19个复制实体、8条显示曲线；只修复本review owner的证据标签。
原始失败和断言精度见证保留；主模型M1.55、动画M1.55-A1和硬件未改。

J5原生针号识别已补齐；图不是PHR-4腔体观察面，不替代实际入壳与导通检查。
仍剩完整路线／运动、真实材料／线长、端接／应力释放、带线装配／闭壳4类。
manufacturing_release=false。实际命令见commands.json；stdout在对话工具记录。
''')
    sources[str(Path(__file__))]=sha(Path(__file__))
    for n in names:sources[str(HERE/n)]=sha(HERE/n)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.suffix not in ['.blend1','.blend2'] and p.name not in ['delivery.json','publication_verification.json']}
    result=dict(status='PASS',scope='Verified scoped research publication only; body prototype and full harness remain unadopted',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        source_blend_sha256=sha(main),source_video_sha256=sha(video),body_curve_checks=100,
        body_native_pair_checks=3650,body_fixture_checks=600,feature_checks=552,finite_yaw_samples=25,
        new_body_all_yaw_root='PASS',new_body_all_yaw_bend='PASS',new_body_all_yaw_native='PASS',
        new_body_all_yaw_peer_and_self='PASS',all_prefixes_new_fixture_all_yaw='PASS',
        continuous_body_delivery_sha256=sha(HERE/'continuous_motion_review_R1/delivery.json'),
        tie_sequence_delivery_sha256=sha(HERE/'tie_access_review_R1/delivery.json'),
        oriented_tie_native_pose_checks=276,mounted_uncut_tie_tail='BLOCKED',
        oriented_tie_body_reference_fit='PASS',tool_workspace='PASS',actual_tool_and_pawl='NOT_TESTED',
        CAM_bridge_reference_curve_checks=8,rigid_increment_entry_checks=2,
        pin_map_checks=4,copied_parts_readback=19,curves_readback=8,actual_harness='BLOCKED',remaining_work_packages=4,
        main_changed=False,hardware_changed=False,animation_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_RESTRAINT_RESEARCH_PUBLISHED',len(files),len(sources),flush=True)


if __name__=='__main__':main()
