"""Pilot whole-cubic curvature and body station checks, no native-fit claim."""
from pathlib import Path
import datetime
import json
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from flat_key_family import FlatKeyFamily, NAMES, np, sha, BSpline
sys.path.insert(0, str(HERE.parent/'upper_smooth_review_R2'))
from piecewise_geometry import pieces, radius_bound


def main():
    start = time.time(); family = FlatKeyFamily(); rows = []; arrays = {}; failures = []
    yaws = list(range(-60,61,5))
    for yaw in yaws:
        for n in NAMES:
            try:
                candidate = family.candidate(n, yaw)
                c = candidate['control']; radius = radius_bound(pieces(BSpline(family.knots,c,3)),depth=8)
                fixed = float(np.max(abs(c[:family.locked_controls[n]]-family.seed[n][:family.locked_controls[n]])))
                row = dict(wire=n, yaw_deg=yaw, radius_lower_mm=radius['radius_lower_mm'],
                           fixed_control_error_mm=fixed, numeric_length_residual_mm=candidate['reference_length_residual_mm'],
                           root_amplitude_mm=candidate['amplitude_mm'])
                row['status'] = 'PASS' if radius['radius_lower_mm'] >= 6.865 and fixed < 1e-12 and abs(row['numeric_length_residual_mm']) < 1e-8 else 'BLOCKED'
                arrays[f'{n}_y{yaw}_controls'] = c
            except Exception as error:
                row = dict(wire=n, yaw_deg=yaw, status='BLOCKED', exception=repr(error))
            rows.append(row)
            if row['status'] != 'PASS': failures.append(row)
        print('FLAT_BODY_FAMILY_PILOT', yaw, len(failures), time.time()-start, flush=True)
    arrays['knots'] = family.knots
    target = HERE/'flat_key_family_controls.npz'
    np.savez_compressed(target, **arrays)
    family.sources[str(Path(__file__))] = sha(Path(__file__)); family.unchanged()
    report = dict(status='PASS' if not failures else 'BLOCKED',
                  scope='Twenty-five yaw samples of mathematical body-fixed family only',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=family.sources,
                  rows=rows, failures=failures, planned_yaws_deg=yaws, arrays_sha256=sha(target),
                  body_clamp='NOT_TESTED', native_fit='NOT_TESTED', all_angle_motion='NOT_TESTED',
                  main_changed=False, hardware_changed=False, animation_changed=False, manufacturing_release=False)
    (HERE/'flat_key_family_math.json').write_text(json.dumps(report, indent=2)+'\n')
    print('FLAT_BODY_FAMILY_MATH_TERMINAL', report['status'], len(failures), flush=True)


if __name__ == '__main__':
    main()
