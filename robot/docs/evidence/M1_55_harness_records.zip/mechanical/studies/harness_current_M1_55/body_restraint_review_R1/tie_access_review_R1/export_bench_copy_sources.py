"""Independent read-only export of the four displayed original native meshes."""
from pathlib import Path
import datetime
import json
import sys

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,sha


def main():
    ctx=Context();arrays={};names=['Load_Frame','Power_Module','Battery_Tray','Battery_Pad_38.0']
    for name in names:
        arrays[name+'_vertices']=ctx.ss[name].v.copy();arrays[name+'_faces']=ctx.ss[name].f.copy()
    path=HERE/'bench_original_native_sources.npz';np.savez_compressed(path,**arrays)
    ctx.record([Path(__file__)]);ctx.unchanged()
    report=dict(status='PASS',scope='Fresh exact native validation world meshes for independent saved-scene comparison only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        native_ids=names,arrays_sha256=sha(path),main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'bench_native_source_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BENCH_NATIVE_SOURCES_EXPORTED',len(names),flush=True)


if __name__=='__main__':main()
