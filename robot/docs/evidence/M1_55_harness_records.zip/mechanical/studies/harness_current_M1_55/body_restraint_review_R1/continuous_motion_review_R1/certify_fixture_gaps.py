"""All-yaw curve / new pad, oriented band and head envelope checks.

Only the four specified CAM leads may touch the pad/band without penetrating.
Other conductors and every head-envelope pair retain .3 mm clearance.
Exact fixed contact spans are separated from moving curve portions.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
OLD=PARENT/'prefix_continuity/frame_family_R3';GENERIC=OLD/'continuous_gaps_R1'
sys.path[:0]=[str(PARENT),str(BODY),str(GENERIC),str(OLD)]
from context import Context,np,manifold,BVHTree,clear,sha
from flat_key_family import FlatKeyFamily,NAMES
from frame_motion_bounds import RootBounds
from restraint_geometry import PAD_LO,PAD_HI


def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


OPS=module(OLD/'certify_bending.py','_mori_fixture_bezier_ops')
HELPER_PATH=PARENT/'upper_length_match_R1/inspect_changed.py'
HELPER=module(HELPER_PATH,'_mori_fixture_chord_ops')


def main():
    started=time.time();ctx=Context();family=FlatKeyFamily();root=RootBounds(family);operators=OPS.matrices(family)
    shape_path=BODY/'tie_access_review_R1/oriented_tie_geometry.npz'
    shape_report_path=BODY/'tie_access_review_R1/oriented_tie_verification.json'
    geometry=json.loads(shape_report_path.read_text());assert geometry['status']=='PASS'
    assert geometry['geometry_sha256']==sha(shape_path)
    assert all(sha(p)==h for p,h in geometry['sources'].items())
    assert all(r['status']=='PASS' for r in geometry['exact_straight_wire_contacts'])
    data=np.load(shape_path);fixtures={}
    for name,key in [('pad','pad'),('band','band_formed'),('head','head')]:
        v=data[key+'_vertices'];faces=data[key+'_faces']
        fixtures[name]=dict(m=manifold.Manifold(manifold.Mesh64(v,faces)),lo=v.min(0),hi=v.max(0),
                           tree=BVHTree.FromPolygons(v.tolist(),faces.tolist(),all_triangles=True))
    proof_path=HERE/'continuous_root_verification.json';proof=json.loads(proof_path.read_text());assert proof['status']=='PASS'
    anchors=family.anchor_datums
    fixed_checks=[]
    for n in NAMES:
        count=family.locked_controls[n]
        assert np.max(abs(family.frame_weights[n][:count]))==0.
        for yaw in range(-60,61,10):
            assert np.max(abs(family.local_controls[yaw][n][:count]-family.seed[n][:count]))<1e-12
            assert np.max(abs(family.local_directions[yaw][n][:count]))==0.
        fixed_checks.append(dict(wire=n,locked_controls=count,all_key_controls_exact=True,
            zero_frame_and_root_directions=True,maximum_fixed_curve_parameter=float(family.knots[count])))
    cached={};evaluated=0;rows=[];failures=[]

    def evaluate(n,lo,hi):
        nonlocal evaluated
        cert=root.certificate(n,lo,hi)
        if cert['status']!='PASS':return dict(status='BLOCKED',type='root_enclosure',evaluated_cells=0)
        mid=(lo+hi)/2;half=(hi-lo)/2;it=family.candidate(n,mid)
        actual=it['control'];c,cy,cyy,d,dy,dyy=it['base'];amplitude=it['amplitude_mm']
        bounds=root.derivatives(n,lo,hi);width=cert['amplitude_deviation_bound_mm']
        first=cy+amplitude*dy;second=bounds['C2']+abs(amplitude)*bounds['D2']
        counts={};checked=0
        for fixture,target in fixtures.items():
            intended=n in NAMES and fixture in ['pad','band'];gap=0. if intended else .3
            for base,left,right in operators:
                todo=[(base,left,right,0)]
                while todo:
                    M,a,b,depth=todo.pop();checked+=1;evaluated+=1
                    controls=M@actual
                    uncertainty=(half*np.linalg.norm(M@first,axis=1)+.5*half**2*(abs(M)@second)
                        +width*(np.linalg.norm(M@d,axis=1)+half*(abs(M)@bounds['D1']))+1e-13)
                    if n in NAMES:
                        locked=family.locked_controls[n]
                        fixed_rows=np.max(abs(M[:,locked:]),axis=1)<1e-14
                        uncertainty[fixed_rows]=1e-12
                    lower=(controls-uncertainty[:,None]).min(0);upper=(controls+uncertainty[:,None]).max(0)
                    delta=np.maximum(np.maximum(target['lo']-upper,lower-target['hi']),0)
                    separation=float(np.linalg.norm(delta))-family.radii[n]
                    method=None
                    if separation>=gap-1e-9:method='Bezier interval hull AABB ball separator'
                    # The nominal tangent plane is known, not a fabricated
                    # void. This .1 nanometre reserve is only for intended
                    # contact precision; no foreign .3mm gap is relaxed.
                    if intended and fixture=='pad' and upper[2]<=PAD_LO[2]-family.radii[n]+1e-7:
                        method='Pad lower plane, specified tangent contact permitted'
                    fixed=(n in NAMES and b<=float(family.knots[family.locked_controls[n]])+1e-12)
                    straight=(np.ptp(controls[:,0])<1e-9 and np.ptp(controls[:,2])<1e-9
                              and abs(controls[0,2]-144.6)<1e-9)
                    if intended and fixed and straight:
                        span=anchors[n]['span_parameter']
                        assert a>=span[0]-1e-10 and b<=span[1]+1e-10
                        method='Exact fixed straight-cylinder contact, fresh oriented-tie proof'
                    if method:
                        counts[method]=counts.get(method,0)+1;continue
                    # Native/BVH chord validation at the current yaw midpoint,
                    # enlarged by the whole-cell displacement bound. Cached
                    # fixed spans stay at zero yaw, regardless of the pose.
                    key=(n,fixture,a,b,0. if fixed else mid)
                    if key not in cached:
                        reference_control=M@family.candidate(n,0. if fixed else mid)['control']
                        pack=HELPER.prepare(np.array([reference_control]),family.radii[n])
                        cached[key]=(pack,reference_control)
                    pack,reference_control=cached[key]
                    displacement=0. if fixed else float(uncertainty.max())
                    hits,near=clear(pack['p'],family.radii[n],{fixture:target},error=pack['error']+displacement,gap=gap)
                    if not hits:
                        counts['Bounded chord and yaw displacement vs actual fixture']=counts.get('Bounded chord and yaw displacement vs actual fixture',0)+1
                        continue
                    if depth<9:
                        lm,rm=OPS.split(M);center=(a+b)/2
                        todo.extend([(rm,center,b,depth+1),(lm,a,center,depth+1)]);continue
                    return dict(status='BLOCKED',type='fixture_interval_not_enclosed',fixture=fixture,
                        required_gap_mm=gap,curve_parameter_interval=[a,b],hits=hits,nearest=near,
                        displacement_bound_mm=displacement,evaluated_cells=checked)
        return dict(status='PASS',methods=counts,evaluated_cells=checked)

    for n in family.names:
        accepted=[];todo=[(*r['yaw_interval_deg'],0) for r in proof['certificates']]
        while todo:
            lo,hi,depth=todo.pop();result=evaluate(n,lo,hi)
            if result['status']=='PASS':accepted.append(dict(yaw_interval_deg=[lo,hi],**result));continue
            if depth<10:
                mid=(lo+hi)/2;todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
            failures.append(dict(wire=n,yaw_interval_deg=[lo,hi],**result));break
        coverage=sorted(r['yaw_interval_deg'] for r in accepted)
        good=not any(r['wire']==n for r in failures)
        if good:
            assert coverage[0][0]==-60 and coverage[-1][1]==60
            assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        rows.append(dict(wire=n,status='PASS' if good else 'BLOCKED',accepted_yaw_cells=len(accepted),intervals=accepted))
        print('BODY_CONTINUOUS_FIXTURE_WIRE',n,rows[-1]['status'],len(accepted),evaluated,
              round(time.time()-started,2),flush=True)
        if not good:break
    ctx.record([Path(__file__),shape_path,shape_report_path,proof_path,OLD/'certify_bending.py',
                OLD/'frame_motion_bounds.py',OLD.parent/'root_direction_R2/root_motion_bounds.py',HELPER_PATH])
    ctx.unchanged();family.unchanged()
    report=dict(status='PASS' if len(rows)==12 and not failures else 'BLOCKED',
        scope='Whole-curve all-yaw capacity references vs integral pad and new oriented tie band/head only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        results=rows,failures=failures,fixed_curve_identity_checks=fixed_checks,evaluated_curve_cells=evaluated,
        yaw_coverage_deg=[-60,60],foreign_required_gap_mm=.3,
        intended_zero_gap_pairs=[dict(wire=n,fixture=k) for n in NAMES for k in ['pad','band']],
        intended_contact_plane_precision_mm=1e-7,head_zero_gap_pairs=[],
        actual_tie_grip='NOT_TESTED',actual_wire_and_pawl='BLOCKED',upper_tails='NOT_TESTED',
        full_wired_assembly='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'fixture_gap_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_CONTINUOUS_FIXTURE_TERMINAL',report['status'],len(rows),evaluated,round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
