"""Current CAM prefix variant with an explicitly body-fixed first portion.

Only research curves change. The physical crimp exit, actual material and
printed restraint are not selected by this mathematical condition.
"""
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'prefix_continuity/frame_family_R3'))
from selected_family import SelectedFamily,BSpline,sha

NAMES=[f'CAM_{pin}' for pin in range(1,5)]


class FixedLeadFamily(SelectedFamily):
    def __init__(self,locked_controls):
        super().__init__()
        self.locked_controls=int(locked_controls)
        assert 3<=self.locked_controls<=10
        # Preserve the actual compensated original zero-pose control values.
        self.fixed={n:SelectedFamily.candidate(self,n,0)['control'].copy() for n in NAMES}
        self.sources[str(Path(__file__))]=sha(Path(__file__))

    def base(self,name,yaw):
        result=super().base(name,yaw)
        if name not in NAMES or not hasattr(self,'fixed'):
            return result
        c,cy,cyy,d,dy,dyy=(a.copy() for a in result)
        n=self.locked_controls
        c[:n]=self.fixed[name][:n]
        cy[:n]=0;cyy[:n]=0;d[:n]=0;dy[:n]=0;dyy[:n]=0
        return c,cy,cyy,d,dy,dyy

