"""Coupled native-aware key poses with a truly fixed flat body prefix.

Only four reference leads are variables, strictly after their fixed span.
Each pose checks a search field containing three head pitches. Search output
is not geometry qualification; independent all-curve checks must follow.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from flat_body_family import FlatBodyFamily, NAMES, np, sha, BSpline
from refine_anchored_zero import KnotAwareSearch
from optimize_anchored_zero import Context, engine
from context import rigidtr, transform_points, BVHTree
from scipy.optimize import least_squares
from scipy.spatial import cKDTree

OUT=HERE/'flat_keyframes_R1';OUT.mkdir(exist_ok=True)
engine.HERE=OUT;engine.OPT_RADIUS=7.25;engine.OPT_GAP=.40


class PoseContext:
    def __init__(self,ctx,yaw):
        self.targets=dict(ctx.groups['body'])
        for group in ['yaw','pitch']:
            for pitch in ([0] if group=='yaw' else [-20,0,25]):
                matrix=np.asarray(rigidtr(yaw,pitch))
                for name in ctx.groups[group]:
                    s=ctx.ss[name];v=transform_points(s.v,matrix);f=s.f
                    self.targets[f'{name}_p{pitch}']=dict(lo=v.min(0),hi=v.max(0),
                        tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True),
                        m=s.m.transform(matrix[:3,:].tolist()))


def main():
    started=time.time();native=Context();family=FlatBodyFamily()
    proof_path=HERE/'flat_family_pilot.json';proof=json.loads(proof_path.read_text())
    assert proof['status']=='BLOCKED' and len(proof['failures'])==7
    assert all(sha(p)==h for p,h in proof['sources'].items())
    mode='all_keys' if '--all-keys' in sys.argv else 'extremes'
    yaws=[-60,60] if mode=='extremes' else list(range(-60,61,10))
    rows=[];all_arrays={};sources={};sample_ts=np.linspace(0,1,1601)
    for yaw in yaws:
        folder=OUT/f'y{yaw}';folder.mkdir(exist_ok=True)
        initial={n:family.candidate(n,yaw)['control'] for n in NAMES}
        search=KnotAwareSearch(PoseContext(native,yaw),family,initial,601)
        # Search base class first sampled neighbours at zero. Replace them
        # with this yaw's unchanged eight reference prefixes before solving.
        for n in search.neighbours:
            p=BSpline(family.knots,family.candidate(n,yaw)['control'],3)(sample_ts)
            search.neighbours[n]=dict(points=p,tree=cKDTree((p[:-1]+p[1:])/2),radius=family.radii[n])
        search.last=None;x=search.base[search.mask];before=search.evaluate(x)[2]
        print('FLAT_BODY_KEY_START',yaw,before,time.time()-started,flush=True)
        calls=[0]
        def callback(values):
            calls[0]+=1
            if calls[0]%10==0:
                print('FLAT_BODY_KEY_ITER',yaw,calls[0],search.evaluate(values)[2],time.time()-started,flush=True)
        sol=least_squares(lambda a:search.evaluate(a)[0],x,jac=lambda a:search.evaluate(a)[1],
            bounds=(x-5.,x+5.),method='trf',tr_solver='lsmr',tr_options=dict(maxiter=180),
            max_nfev=80,ftol=1e-7,xtol=1e-7,gtol=1e-5,callback=callback)
        controls=search.controls(sol.x)
        fixed=max(float(np.max(abs(controls[n][:family.locked_controls[n]]-family.seed[n][:family.locked_controls[n]]))) for n in NAMES)
        ends=max(float(np.max(abs(controls[n][-2:]-initial[n][-2:]))) for n in NAMES)
        assert fixed<1e-12 and ends==0
        path=folder/'candidate.npz'
        np.savez_compressed(path,**{n+'_controls':c for n,c in controls.items()},knots=family.knots)
        row=dict(yaw_deg=yaw,solver_success=bool(sol.success),solver_status=int(sol.status),message=sol.message,
                 nfev=int(sol.nfev),initial=before,final=search.evaluate(sol.x)[2],fixed_control_error_mm=fixed,
                 end_control_error_mm=ends,candidate_sha256=sha(path),samples_per_curve=search.problem.n)
        (folder/'optimization.json').write_text(json.dumps(row,indent=2)+'\n')
        rows.append(row)
        all_arrays.update({f'{n}_y{yaw}_controls':c for n,c in controls.items()})
        sources[str(path)]=sha(path);sources[str(folder/'optimization.json')]=sha(folder/'optimization.json')
        print('FLAT_BODY_KEY_TERMINAL',yaw,row['final'],time.time()-started,flush=True)
    path=OUT/(mode+'_controls.npz');np.savez_compressed(path,knots=family.knots,**all_arrays)
    native.record([Path(__file__),HERE/'flat_body_family.py',HERE/'refine_anchored_zero.py',
                   HERE/'optimize_anchored_zero.py',proof_path]);native.unchanged();family.unchanged()
    result=dict(status='PASS',scope='Key pose optimizer execution, independent finite geometry still NOT_TESTED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources|family.sources|sources,
        planned_yaws_deg=yaws,rows=rows,arrays_sha256=sha(path),extra_reference_length_mm=4.,
        body_reference_targets_mm={n:family.targets[n] for n in NAMES},locked_controls=family.locked_controls,
        all_angle_motion='NOT_TESTED',actual_material='BLOCKED',body_restraint='NOT_TESTED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (OUT/(mode+'_optimization.json')).write_text(json.dumps(result,indent=2)+'\n')
    print('FLAT_BODY_KEYS_EXECUTION_TERMINAL',mode,len(rows),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
