"""Fixed CAM start with a gradual shape transition into the existing family.

Hard locking alone introduced tight bends at the first movable controls.
This variant blends the following controls and length-root directions, while
keeping a precisely fixed body prefix and unchanged end datums.
"""
from pathlib import Path
import numpy as np
from fixed_lead_family import FixedLeadFamily,SelectedFamily,NAMES,sha


class BlendedFixedLeadFamily(FixedLeadFamily):
    def __init__(self,locked_controls,blend_controls):
        super().__init__(locked_controls)
        self.blend_controls=int(blend_controls)
        assert 2<=self.blend_controls<=14
        self.sources[str(Path(__file__))]=sha(Path(__file__))

    def base(self,name,yaw):
        raw=SelectedFamily.base(self,name,yaw)
        if name not in NAMES or not hasattr(self,'fixed') or not hasattr(self,'blend_controls'):
            return raw
        c,cy,cyy,d,dy,dyy=(a.copy() for a in raw)
        n=self.locked_controls;b=self.blend_controls
        w=np.ones(len(c));w[:n]=0
        u=np.arange(1,b+1)/(b+1)
        w[n:n+b]=u**3*(10-15*u+6*u*u)
        c=self.fixed[name]+w[:,None]*(c-self.fixed[name])
        cy*=w[:,None];cyy*=w[:,None]
        d*=w[:,None];dy*=w[:,None];dyy*=w[:,None]
        return c,cy,cyy,d,dy,dyy

