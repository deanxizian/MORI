"""Fresh body reference/fixture/known-upper checks at 25 yaw samples.

Actual material split and connectors remain unresolved. Only explicitly
named four-wire clamp contacts may have zero gap; other wires keep .3 mm.
"""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,transform_points,rigidtr,sha,BVHTree
sys.path.insert(0,str(HERE))
from flat_key_family import FlatKeyFamily,NAMES,BSpline
from restraint_geometry import PAD_LO,PAD_HI
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces,RADII
HELPER=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_flat_motion_helpers',HELPER)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)


def own_fixture(cubics,target,name):
    rows=[];failures=[]
    for i,c in enumerate(cubics):
        lo=c.min(0);hi=c.max(0)
        if np.any(hi+.565<target['lo']) or np.any(lo-.565>target['hi']):continue
        if name=='pad':
            delta=np.maximum(np.maximum(PAD_LO-hi,lo-PAD_HI),0)
            if np.linalg.norm(delta)>=.565-1e-8:
                rows.append(dict(cubic=i,status='PASS',method='Bezier convex-hull AABB separator, intended tangent permitted'))
                continue
        flat=np.ptp(c[:,0])<1e-10 and np.ptp(c[:,2])<1e-10 and abs(c[0,2]-144.6)<1e-10
        if flat:
            # All points lie on the exact fixed line. The same cylinder was
            # independently checked against pad/tie, including tangent pairs.
            assert lo[1]>=-24.8-1e-8 and hi[1]<=-20.5+1e-8
            rows.append(dict(cubic=i,status='PASS',method='Exact straight cylinder contact'))
            continue
        pack=helper.prepare(np.array([c]),.565)
        hits,near=clear(pack['p'],.565,{name:target},error=pack['error'],gap=0.)
        row=dict(cubic=i,status='PASS' if not hits else 'BLOCKED',method='Bounded cubic chord vs fixture, zero contact gap',hits=hits,nearest=near)
        rows.append(row)
        if hits:failures.append(row)
    return dict(status='PASS' if not failures else 'BLOCKED',rows=rows,failures=failures)


def main():
    started=time.time();ctx=Context();family=FlatKeyFamily()
    math_path=HERE/'flat_key_family_math.json';math=json.loads(math_path.read_text())
    assert math['status']=='PASS' and len(math['rows'])==100
    assert all(sha(p)==h for p,h in math['sources'].items())
    fixture_path=HERE/'restraint_geometry_verification.json';fixture=json.loads(fixture_path.read_text())
    assert fixture['status']=='PASS' and fixture['checks']==552
    assert all(sha(p)==h for p,h in fixture['sources'].items())
    fixture_arrays=HERE/'restraint_geometry.npz';assert sha(fixture_arrays)==fixture['geometry_sha256']
    fdata=np.load(fixture_arrays);targets={}
    for n in ['pad','tie_envelope']:
        v=fdata[n+'_vertices'];f=fdata[n+'_faces']
        from context import manifold
        targets[n]=dict(lo=v.min(0),hi=v.max(0),tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True),
                        m=manifold.Manifold(manifold.Mesh64(v,f)))
    upper_paths=[PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz',PARENT/'upper_motion_family_R1/half_grid_curves.npz']
    upper_reports=[PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json',PARENT/'upper_motion_family_R1/half_grid_inspection.json']
    uppers=[]
    for p,r in zip(upper_paths,upper_reports):
        q=json.loads(r.read_text());assert q['status']=='PASS' and q['arrays_sha256']==sha(p)
        uppers.append(np.load(p))
    planned=[0,-60,60]+[v for i in range(55,0,-5) for v in [-i,i]]
    rows=[];fixture_rows=[];failures=[];checked=[];arrays={}
    for yaw in planned:
        packs={};curves={}
        for n in family.names:
            c=family.candidate(n,yaw)['control'];curves[n]=pieces(BSpline(family.knots,c,3));packs[n]=helper.prepare(curves[n],family.radii[n])
            if n in NAMES:arrays[f'{n}_y{yaw}_controls']=c
        for n in NAMES:
            pack=packs[n]
            for group,items in ctx.groups.items():
                for pitch in ([-20,0,25] if group=='pitch' else [0]):
                    matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch)))
                    norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
                    hits,near=clear(transform_points(pack['p'],matrix),.565*norm,items,error=pack['error']*norm,gap=.3*norm)
                    row=dict(wire=n,kind='native',group=group,yaw_deg=yaw,pitch_deg=pitch,status='PASS' if not hits else 'BLOCKED',hits=hits,nearest=near)
                    rows.append(row)
                    if hits:failures.append(row)
            row=dict(wires=[n,n],yaw_deg=yaw,**helper.compare(pack,pack,'self'));rows.append(row)
            if row['status']!='PASS':failures.append(row)
        for a,b in itertools.combinations(packs,2):
            if a not in NAMES and b not in NAMES:continue
            row=dict(wires=[a,b],yaw_deg=yaw,**helper.compare(packs[a],packs[b]));rows.append(row)
            if row['status']!='PASS':failures.append(row)
        for pitch in [-20,0,25]:
            upper_packs={n:helper.prepare(uppers[0 if n.startswith('CAM_') else 1][f'{n}_y{yaw}_p{pitch}_controls'],r) for n,r in RADII.items()}
            for n in NAMES:
                for other,pack in upper_packs.items():
                    row=dict(wires=[n,other],yaw_deg=yaw,pitch_deg=pitch,scope='changed prefix vs retained upper',
                             **helper.compare(packs[n],pack,'own_join' if n==other else 'peer'))
                    rows.append(row)
                    if row['status']!='PASS':failures.append(row)
        for n in family.names:
            for name,target in targets.items():
                if n in NAMES:
                    result=own_fixture(curves[n],target,name)
                else:
                    pack=packs[n];hits,near=clear(pack['p'],family.radii[n],{name:target},error=pack['error'],gap=.3)
                    result=dict(status='PASS' if not hits else 'BLOCKED',hits=hits,nearest=near)
                row=dict(wire=n,fixture=name,yaw_deg=yaw,**result);fixture_rows.append(row)
                if result['status']!='PASS':failures.append(row)
        checked.append(yaw)
        print('BODY_FLAT_MOTION_POSE',yaw,'native_and_pairs',len(rows),'fixture',len(fixture_rows),'failures',len(failures),'elapsed',time.time()-started,flush=True)
        if failures:break
    destination=HERE/'flat_motion_checked_controls.npz';np.savez_compressed(destination,knots=family.knots,**arrays)
    ctx.record([Path(__file__),HELPER,HERE/'restraint_geometry.py',math_path,fixture_path,fixture_arrays]+upper_paths+upper_reports)
    ctx.unchanged();family.unchanged()
    result=dict(status='PASS' if not failures and len(checked)==25 else 'BLOCKED',
        scope='Finite fixed-body CAM reference/fixture/current native and retained upper clearance checks',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        planned_yaws_deg=planned,checked_yaws_deg=checked,head_pitch_samples_deg=[-20,0,25],
        checks=len(rows),rows=rows,fixture_checks=len(fixture_rows),fixture_rows=fixture_rows,failures=failures,
        arrays_sha256=sha(destination),body_wire_radius_mm=.565,required_other_gap_mm=.3,
        actual_material_split='BLOCKED',splice_envelope='BLOCKED',all_angle_clearance='NOT_TESTED',
        tie_installation='NOT_TESTED',actual_grip='NOT_TESTED',full_wired_assembly='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'flat_motion_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_FLAT_MOTION_TERMINAL',result['status'],len(checked),len(rows),len(fixture_rows),len(failures),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
