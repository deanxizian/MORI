"""Read-only native bridge surface samples for a real body restraint."""
from pathlib import Path
import datetime
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from context import Context, np, Vector, sha


def main():
    ctx = Context()
    s = ctx.ss['Yaw_Base']
    tree = s.bvh()
    rays = []
    for x in [25., 27., 28.7, 30.4, 32.1, 34.]:
        for y in [-24.5, -23., -21.1, -20.9, -20., -19.5, -18.]:
            row = dict(x=x, y=y)
            for label, z, dz in [('bottom', 140., 1.), ('top', 151., -1.)]:
                p, normal, face, distance = tree.ray_cast(Vector((x, y, z)), Vector((0, 0, dz)), 12.)
                row[label] = None if p is None else dict(point_mm=list(p), normal=list(normal), face=int(face))
            rays.append(row)
    source = HERE/'anchored_zero_refined/candidate_1001.npz'
    data = np.load(source)
    rows = {n: data[n+'_controls'][9:18].tolist() for n in ['CAM_1', 'CAM_2', 'CAM_3', 'CAM_4']}
    ctx.record([Path(__file__), source]); ctx.unchanged()
    result = dict(status='PASS', scope='Native surface identification only, no restraint designed or adopted',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  sources=ctx.sources, bridge_rays=rays, control_points_9_to_17=rows,
                  main_changed=False, hardware_changed=False, manufacturing_release=False)
    (HERE/'support_contact_surfaces.json').write_text(json.dumps(result, indent=2)+'\n')
    print('BRIDGE_CONTACT_SURFACE_SAMPLES', flush=True)
    for row in rays:
        print(row['x'], row['y'], None if row['bottom'] is None else row['bottom']['point_mm'][2],
              None if row['top'] is None else row['top']['point_mm'][2], flush=True)


if __name__ == '__main__':
    main()
