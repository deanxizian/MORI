"""Current native J5 identification views and unchanged H06 pin map.

The PCB views are exact design datums. They do not substitute for a PHR-4
cavity-number/latch drawing or certify terminal insertion and physical mating.
"""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
qpath=PROJECT/'config/geometry.json';q=json.loads(qpath.read_text())
inventory_path=PROJECT/q['native_electronics']['inventory'];inv=json.loads(inventory_path.read_text())
board=inv['boards']['motion'];native_path=PROJECT/board['source']
assert sha(native_path)==board['source_sha256']
fp=next(p for p in board['footprints'] if p['reference']=='J5')
assert fp['side']=='F' and fp['rotation_deg']==0 and not fp['dnp']
ports_path=PARENT/'port_inspection.json';ports=json.loads(ports_path.read_text())
assert all(sha(p)==h for p,h in ports['sources'].items())
assert np.array_equal(ports['J5']['board_rotation'],np.eye(3))
translation=np.array(ports['J5']['board_translation_mm'])
csv_path=PROJECT/'hardware/v1_2/wiring_P5R7/03_逐针接线表.csv'
with csv_path.open(encoding='utf-8-sig',newline='') as f:
    wiring=[r for r in csv.DictReader(f) if r['线束']=='H06']
assert len(wiring)==4
rows=[]
for pad in sorted(fp['pads'],key=lambda p:int(p['number'])):
    number=int(pad['number']);r=next(r for r in wiring if int(r['起点针'])==number)
    assert r['起点口']=='J5' and r['终点口']=='J11' and int(r['终点针'])==number
    # KiCad board coordinates have +Y down; exported CAD is +Y forward.
    xy=np.array([pad['xy_mm'][0],-pad['xy_mm'][1]])+translation[:2]
    rows.append(dict(label=f'H06-{number}',motion_pad=number,CAM_pin=number,signal=r['起点信号'],
        native_xy_mm=pad['xy_mm'],world_xy_mm=xy.tolist(),installed_wire_colour=None,
        cavity_visual_orientation='BLOCKED: match PH-specific cavity/key drawing or arrival verification'))
assert [r['world_xy_mm'][0] for r in rows]==[15.5,17.5,19.5,21.5]
assert all(abs(r['world_xy_mm'][1]+44.5)<1e-12 for r in rows)
texts=''
for x,r in zip([120,240,360,480],rows):
    texts+=f'<circle cx="{x}" cy="125" r="26" fill="#397f93"/><text x="{x}" y="133" fill="white" text-anchor="middle" font-size="26">{r["motion_pad"]}</text><text x="{x}" y="183" text-anchor="middle">{r["signal"]}</text>'
mirror=''
for x,r in zip([120,240,360,480],rows[::-1]):
    mirror+=f'<circle cx="{x}" cy="325" r="26" fill="#89969b"/><text x="{x}" y="333" fill="white" text-anchor="middle" font-size="26">{r["motion_pad"]}</text>'
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 680 470" role="img" aria-label="运动板J5组件面与焊接面针号">
<rect width="680" height="470" fill="#f3f6f7"/><g font-family="system-ui" font-size="17" fill="#24343d">
<text x="35" y="42">J5 组件面俯视：从 +Z 看向 PCB</text>{texts}
<path d="M550 125h60l-12-8m12 8l-12 8" stroke="#24343d" fill="none"/><text x="545" y="168">机器人 +X</text>
<text x="35" y="245">同一 PCB 从焊接面看：从 −Z 看向 PCB，左右翻转</text>{mirror}
<text x="35" y="414">这是 PCB 针号识别图，不是 PHR-4 塑壳孔号的观察面图。</text>
<text x="35" y="446">实际入壳必须核对配套塑壳的 1 号腔体和定位键；不能只按左右顺序插线。</text>
</g></svg>'''
(HERE/'J5_native_pin_views.svg').write_text(svg+'\n')
table='\n'.join(f"| {r['label']} | J5.{r['motion_pad']} | J11.{r['CAM_pin']} | {r['signal']} | {r['world_xy_mm'][0]:.1f}, {r['world_xy_mm'][1]:.1f} |" for r in rows)
doc=f'''# H06 身体端：当前 J5 针号识别

按当前主模型 M1.55 与已接收运动板 P5R7 生成；原生 PCB、线序和正式选型均未改。

| 线标 | 运动板 | CAM 板 | 信号 | 主模型针轴 XY，mm |
|---|---|---|---|---|
{table}

针号依据原生 PCB；J5.1 位于机器人 +X 坐标较小的一侧。组件面俯视与焊接面观察
左右相反，见 J5_native_pin_views.svg。图中的信号名以 CAM 端定义，RX/TX 不再交叉。
H06-3 是 U4 VCCB 的 3.3V 参考，不将其当作 CAM 主供电。

用户已确认：厂家压接身体端四个端子，暂不装 PHR-4；穿线后在机内入壳。
厂家应标记 H06-1～4；实际线色未选定。四个塑壳腔体的视觉观察面、定位键和
入壳方向仍需 PH 专用资料或到货核对。本图不替代塑壳孔号图，不能据此盲插。

入壳后须检查锁止和逐针导通，再对插 J5；不用测针直接撑开触点，不把一般
接插件允许的对插偏角当成端子入塑壳允许偏角。具体检查力、压接高度和真实
端子保护外形尚未冻结。旧细线穿线流程的 PASS 不覆盖当前 AWG28 或固定点候选。

此文件闭合设计针号识别，未闭合实际端子入壳、插合、固定和通断实测。
资料来源只读核对：当前 inventory、原生运动 PCB、端口接收记录与正式逐针接线表。
full_harness=BLOCKED；manufacturing_release=false。
'''
(HERE/'H06_body_pin_identification.md').write_text(doc)
sources={str(p):sha(p) for p in [Path(__file__),qpath,inventory_path,native_path,ports_path,csv_path]}
report=dict(status='PASS',scope='Current native PCB pin identification and unchanged formal map; not housing or physical mating qualification',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,rows=rows,
    board_component_view_positive_x_order=[1,2,3,4],board_solder_view_left_to_right_order=[4,3,2,1],
    actual_PHR4_cavity_view='BLOCKED',crimp_and_insertion='NOT_TESTED',continuity='NOT_TESTED',
    main_changed=False,hardware_changed=False,formal_H06_changed=False,manufacturing_release=False,
    svg_sha256=sha(HERE/'J5_native_pin_views.svg'),document_sha256=sha(HERE/'H06_body_pin_identification.md'))
(HERE/'body_pin_identification.json').write_text(json.dumps(report,indent=2)+'\n')
print('BODY_PIN_IDENTIFICATION_PASS',len(rows),'unchanged connections')
