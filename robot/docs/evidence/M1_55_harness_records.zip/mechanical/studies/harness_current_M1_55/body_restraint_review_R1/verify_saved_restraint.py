"""Read back saved comparison world geometry, then label own display copies.

Metadata repair is restricted to this review owner's namespace. Existing
MORI scene objects and main files are preserved. No physical fit claimed.
"""
from pathlib import Path
import datetime
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];PROJECT=ROOT.parent
sys.path[:0]=[str(ROOT/'scripts'),str(HERE)]
from common import bpy,np,assembled,load_collections
from validate import Solid
from flat_key_family import FlatKeyFamily,NAMES,BSpline,sha
from fixed_lead_family import SelectedFamily


def main():
    report_path=HERE/'render_manifest.json';render=json.loads(report_path.read_text())
    path=HERE/render['inspection_file']
    assert Path(bpy.data.filepath).resolve()==path.resolve() and sha(path)==render['inspection_sha256']
    assert all(sha(p)==h for p,h in render['sources'].items())
    owner=render['review_owner'];initial_hash=sha(path)
    bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled();bpy.context.view_layer.update()
    native={n:Solid(bpy.data.objects['MORI_V1__'+n]) for n in render['copied_native_parts']}
    geometries=np.load(HERE/'restraint_geometry.npz');family=FlatKeyFamily();original=SelectedFamily()
    rows=[];curve_rows=[];metadata=0
    for scene_name in render['scenes']:
        scene=bpy.data.scenes[scene_name];label='candidate' if scene_name.endswith('candidate') else 'original'
        bpy.context.window.scene=scene;bpy.context.view_layer.update()
        for o in scene.objects:
            if o.get('review_owner')!=owner:continue
            assert o.parent is None and np.max(abs(np.array(o.matrix_world)-np.eye(4)))<1e-10
            source=o.get('source_object')
            if source:
                n=source.removeprefix('MORI_V1__');s=native[n]
                v,f=(geometries['Yaw_Base_candidate_vertices'],geometries['Yaw_Base_candidate_faces']) if label=='candidate' and n=='Yaw_Base' else (s.v,s.f)
                o.data.calc_loop_triangles();actual_v=np.array([list(p.co) for p in o.data.vertices]);actual_f=np.array([list(t.vertices) for t in o.data.loop_triangles])
                error=float(np.max(abs(v-actual_v)))
                assert error<2e-5 and np.array_equal(f,actual_f),(scene_name,n,error)
                category=s.o.get('category','PLACEHOLDER');status=s.o.get('data_status','ASSUMED')
                assert category in ['PRINTABLE','PURCHASED_REFERENCE','PLACEHOLDER'],(n,category)
                o['category']=category;o['data_status']=status;o['group']=s.group
                o['source_evidence_limits_retained']=True;metadata+=1
                if label=='candidate' and n=='Yaw_Base':o['category']='PRINTABLE';o['data_status']='ASSUMED';o['candidate_status']='UNADOPTED'
                rows.append(dict(scene=scene_name,source=n,status='PASS',maximum_world_vertex_error_mm=error,category=o['category']))
            elif o.type=='CURVE':
                n=o.name.rsplit('_',2)[-2:];name='_'.join(n)
                assert name in NAMES,(o.name,name)
                c=(family if label=='candidate' else original).candidate(name,0)['control'];expected=BSpline(family.knots,c,3)(np.linspace(0,1,1801))
                actual=np.array([list(p.co)[:3] for p in o.data.splines[0].points]);error=float(np.max(abs(actual-expected)))
                assert error<2e-5 and abs(o.data.bevel_depth-.565)<1e-6
                curve_rows.append(dict(scene=scene_name,wire=name,status='PASS',maximum_centerline_error_mm=error))
            else:
                assert o.name.endswith('TIE_ENVELOPE') and o['category']=='PLACEHOLDER'
                v=geometries['tie_envelope_vertices'];o.data.calc_loop_triangles()
                actual=np.array([list(p.co) for p in o.data.vertices]);error=float(np.max(abs(v-actual)))
                assert error<2e-5
                rows.append(dict(scene=scene_name,source='tie_envelope',status='PASS',maximum_world_vertex_error_mm=error,category='PLACEHOLDER'))
    assert len(rows)==2*len(native)+1 and len(curve_rows)==8
    archive=HERE/'initial_metadata_only';archive.mkdir(exist_ok=True)
    (archive/'render_manifest.json').write_text(report_path.read_text())
    bpy.context.window.scene=bpy.data.scenes[render['scenes'][-1]]
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(path),compress=True)
    render['inspection_sha256']=sha(path)
    render['metadata_label_update']=dict(script=Path(__file__).name,source_sha256=sha(Path(__file__)),initial_inspection_sha256=initial_hash,
                                       copied_native_labels_added=metadata,geometry_changed=False)
    render['sources'][str(Path(__file__))]=sha(Path(__file__))
    report_path.write_text(json.dumps(render,indent=2)+'\n')
    assert sha(ROOT/'mori_v1_2.blend')==render['source_blend_sha256']
    result=dict(status='PASS',scope='Saved comparison geometry, world matrices, curve samples and display evidence labels only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=render['sources']|family.sources|original.sources,
        copied_parts=rows,curves=curve_rows,inspection_sha256=sha(path),render_manifest_sha256=sha(report_path),
        metadata_labels_added=metadata,physical_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'saved_inspection_readback.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_RESTRAINT_SAVED_READBACK_PASS',len(rows),len(curve_rows),metadata,flush=True)


if __name__=='__main__':main()
