"""Test two CAM reference preparations on the current bridge insertion path.

Body shells are absent because the saved assembly installs them later. All
earlier rigid parts remain as obstacles, including camera-hidden parts.
This does not qualify terminals, flexible reshaping, hands, or full harness.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
sys.path[:0]=[str(PARENT),str(BODY)]
from context import Context,np,bpy,clear,transform_points,sha,ROOT
from flat_key_family import FlatKeyFamily,NAMES,BSpline
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import pieces
from assembly_animation import AP,SCENE_NAME,curves
HELPER_PATH=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_bridge_entry_chords',HELPER_PATH)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)


def main():
    started=time.time();ctx=Context();family=FlatKeyFamily()
    manifest_path=ROOT/'animation/manifest.json';manifest=json.loads(manifest_path.read_text())
    assert manifest['source_blend_sha256']==sha(ROOT/'mori_v1_2.blend')
    stage=next(s for s in manifest['stages'] if s['index']==manifest['part_stages']['Yaw_Base'])
    final=next(s for s in manifest['stages'] if s['source_step']==8)
    earlier=sorted(n for n in ctx.ss if manifest['part_stages'][n]<stage['index'])
    assert 'Body_Front' not in earlier and 'Body_Rear' not in earlier
    assert 'MCU_Motion' in earlier and 'Power_Module' in earlier
    original_matrices={n:np.asarray(ctx.ss[n].o.matrix_world).copy() for n in ctx.ss}
    pack_final={n:helper.prepare(pieces(BSpline(family.knots,family.candidate(n,0)['control'],3)),.565) for n in NAMES}
    array_path=HERE/'bench_tool_geometry_R3.npz';arrays=np.load(array_path)
    pack_straight={n:helper.prepare(np.array([arrays[n+'_stage_cubic']]),.565) for n in NAMES}
    ctx.record([Path(__file__),manifest_path,ROOT/'scripts/assembly_animation.py',HELPER_PATH,
                HERE/'bench_tool_verification_R3.json',array_path])
    animation_path=ROOT/'mori_assembly_animation.blend';ctx.record([animation_path])
    bpy.ops.wm.open_mainfile(filepath=str(animation_path))
    scene=bpy.data.scenes[SCENE_NAME];bpy.context.window.scene=scene
    actors={o.name.removeprefix(AP):o for o in scene.objects if o.get('presentation_actor')}
    bridge=bpy.data.objects[AP+'Fixed_Bridge']
    assert bridge.parent is None and np.max(abs(np.asarray(bridge.rotation_euler)))==0.
    assert np.array_equal(np.asarray(bridge.scale),np.ones(3))
    waypoints=[(stage['start']+12,[0,-14,144]),(stage['start']+104,[0,-14,18]),
               (stage['start']+110,[0,-14,18]),(stage['end'],[0,0,18]),
               (final['start']+8,[0,0,18]),(final['start']+36,[0,0,0])]
    channels={fc.array_index:fc for fc in curves(bridge) if fc.data_path=='location'}
    assert set(channels)=={0,1,2}
    path_rows=[]
    for (left,a),(right,b) in zip(waypoints[:-1],waypoints[1:]):
        a,b=np.array(a,float),np.array(b,float)
        controls=[]
        for axis in range(3):
            keys={int(k.co[0]):k for k in channels[axis].keyframe_points}
            assert left in keys and right in keys
            ka,kb=keys[left],keys[right]
            assert np.max(abs(np.array([ka.co[1],kb.co[1]])-np.array([a[axis],b[axis]])))<1e-5
            values=np.array([ka.co[1],ka.handle_right[1],kb.handle_left[1],kb.co[1]])
            assert values.min()>=min(a[axis],b[axis])-1e-5 and values.max()<=max(a[axis],b[axis])+1e-5
            if a[axis]==b[axis]:assert np.max(abs(values-a[axis]))<1e-5
            controls.append(values.tolist())
        assert np.count_nonzero(a!=b)<=1
        path_rows.append(dict(frame_interval=[left,right],translation_start_mm=a.tolist(),
            translation_end_mm=b.tolist(),Bezier_channel_values=controls,
            status='PASS',scope='Saved FCurve control hull contained in this axis-aligned segment'))
    first=waypoints[0][0];last=waypoints[-1][0]
    scene.frame_set(first);bpy.context.view_layer.update()
    fixed={n:np.asarray(actors[n].matrix_world)@np.linalg.inv(original_matrices[n]) for n in earlier}
    readback=[]
    for frame in np.linspace(first,last,49):
        scene.frame_set(int(frame),subframe=float(frame%1));bpy.context.view_layer.update()
        maximum=max(float(np.max(abs((np.asarray(actors[n].matrix_world)@np.linalg.inv(original_matrices[n]))-fixed[n]))) for n in earlier)
        assert maximum<.00005
        expected=np.asarray(bridge.matrix_world)
        bridge_actual=np.asarray(actors['Yaw_Base'].matrix_world)@np.linalg.inv(original_matrices['Yaw_Base'])
        error=float(np.max(abs(bridge_actual-expected)));assert error<.00005
        readback.append(dict(frame=float(frame),earlier_fixture_matrix_error_mm=maximum,
                             bridge_actor_root_error_mm=error,status='PASS'))
    obstacles={}
    for n in earlier:
        item=ctx.targets[n];matrix=fixed[n]
        if np.max(abs(matrix-np.eye(4)))<1e-5:obstacles[n]=item;continue
        vertices=transform_points(ctx.ss[n].v,matrix)
        from context import manifold,BVHTree
        obstacles[n]=dict(m=item['m'].transform(matrix[:3,:].tolist()),lo=vertices.min(0),hi=vertices.max(0),
                          tree=BVHTree.FromPolygons(vertices.tolist(),ctx.ss[n].f.tolist(),all_triangles=True))
    results=[];failures=[]
    for preparation,packs in [('bench_straight',pack_straight),('final_zero_reference',pack_final)]:
        for n,pack in packs.items():
            accepted=[];problem=[]
            for segment,path in enumerate(path_rows):
                a=np.array(path['translation_start_mm']);b=np.array(path['translation_end_mm'])
                todo=[(0.,1.,0)]
                while todo:
                    lo,hi,depth=todo.pop();mid=(lo+hi)/2;position=a+(b-a)*mid
                    movement=np.linalg.norm(b-a)*(hi-lo)/2
                    hits,near=clear(pack['p']+position,.565,obstacles,error=pack['error']+movement,gap=.3)
                    if not hits:
                        accepted.append(dict(path_segment=segment,parameter_interval=[lo,hi],
                            gap_lower_mm=near['gap_lower_bound_mm'] if near else None,
                            translation_motion_bound_mm=movement,status='PASS'));continue
                    if depth<12:
                        todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
                    problem.append(dict(path_segment=segment,parameter_interval=[lo,hi],hits=hits,nearest=near))
                    break
                if problem:break
            good=not problem
            if good:
                for segment in range(len(path_rows)):
                    coverage=sorted(r['parameter_interval'] for r in accepted if r['path_segment']==segment)
                    assert coverage[0][0]==0 and coverage[-1][1]==1
                    assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
            row=dict(preparation=preparation,wire=n,status='PASS' if good else 'BLOCKED',
                     accepted_path_intervals=len(accepted),intervals=accepted,failures=problem)
            results.append(row)
            if problem:failures.append(row)
            print('CAM_WIRED_BRIDGE_ENTRY',preparation,n,row['status'],len(accepted),round(time.time()-started,2),flush=True)
    ctx.unchanged();family.unchanged()
    successful=[label for label in ['bench_straight','final_zero_reference']
        if all(r['status']=='PASS' for r in results if r['preparation']==label)]
    report=dict(status='PASS' if successful else 'BLOCKED',
        scope='Four CAM capacity curves translated with the bridge on the actual saved insertion path, earlier rigid parts retained; no connector or reshaping qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources|family.sources,
        earlier_obstacle_ids=earlier,earlier_obstacle_count=len(earlier),path_control_hull_readback=path_rows,
        actor_matrix_readback=readback,results=results,failures=failures,successful_preparations=successful,
        required_gap_mm=.3,rigid_bridge_insertion='Previously checked separately, not rerun here',
        actual_terminal_and_connector='BLOCKED',straight_to_final_flexible_reshaping='NOT_TESTED',
        free_end_hand_control='NOT_TESTED',other_eight_conductors='NOT_TESTED',full_wired_assembly='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'wired_bridge_entry_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('CAM_WIRED_BRIDGE_ENTRY_TERMINAL',report['status'],successful,len(earlier),round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
