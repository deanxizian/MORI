"""Independent new-feature/native checks, with explicit intended contacts.

The pad may overlap only its own host for union. Four exact straight wire
cylinders may touch pad/band. All other native contacts must retain .3 mm.
This does not prove gripping, threading the tie, or complete wired assembly.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from context import Context,np,manifold,rigidtr,sha
sys.path.insert(0,str(HERE))
from restraint_geometry import solids,SOURCE


def bounds(m):
    data=m.to_mesh64();v=np.array(data.vert_properties)[:,:3]
    return v.min(0),v.max(0)


def main():
    start=time.time();ctx=Context();pad,tie,parameters=solids(manifold)
    host=ctx.ss['Yaw_Base'].m;merged=host+pad
    assert len(host.decompose())==len(merged.decompose())==1
    assert (host-merged).volume()<1e-8 and (host^pad).volume()>0
    # Intended tangent contact is within cross-section polygon precision.
    # Keep the witnessed failure and accept only this named mating pair.
    contact_overlap=float((tie^pad).volume())
    assert contact_overlap<1e-6
    source=HERE/'flat_contact_zero_R2/optimization.json';meta=json.loads(source.read_text())
    contact=[]
    for name,x in meta['straight_span_x_mm'].items():
        conductor=manifold.Manifold.cylinder(4.3,.565,.565,64).rotate([-90,0,0]).translate([x,-24.8,144.6])
        a=(pad^conductor).volume();b=(tie^conductor).volume()
        contact.append(dict(wire=name,status='PASS' if a<1e-8 and b<1e-8 else 'BLOCKED',
                            pad_intersection_mm3=a,tie_intersection_mm3=b,
                            pad_gap_mm=pad.min_gap(conductor,.01),tie_gap_mm=tie.min_gap(conductor,.01)))
    rows=[];failures=[r for r in contact if r['status']!='PASS']
    # Body checks once. Yaw and pitch use inverse-transformed tiny fixtures,
    # keeping the authoritative native meshes and evidence IDs unchanged.
    for group in ['body','yaw','pitch']:
        poses=[(0,0)] if group=='body' else [(y,0) for y in range(-60,61,5)] if group=='yaw' else [(y,p) for y in range(-60,61,5) for p in range(-20,26,5)]
        for yaw,pitch in poses:
            matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch)))
            for name,original in [('pad',pad),('tie_envelope',tie)]:
                candidate=original.transform(matrix[:3,:].tolist());lo,hi=bounds(candidate);close=[]
                for native,target in ctx.groups[group].items():
                    if name=='pad' and native=='Yaw_Base':continue
                    if np.any(hi+.3<target['lo']) or np.any(lo-.3>target['hi']):continue
                    gap=float(candidate.min_gap(target['m'],.30001));volume=float((candidate^target['m']).volume())
                    entry=dict(native=native,gap_mm=gap,intersection_mm3=volume)
                    close.append(entry)
                    if gap<.3-1e-7 or volume>1e-8:
                        failures.append(dict(feature=name,group=group,yaw_deg=yaw,pitch_deg=pitch,**entry))
                rows.append(dict(feature=name,group=group,yaw_deg=yaw,pitch_deg=pitch,status='BLOCKED' if any(e['gap_mm']<.3-1e-7 or e['intersection_mm3']>1e-8 for e in close) else 'PASS',nearby_native=close))
            if group=='pitch' and pitch==25 and yaw%20==0:
                print('BODY_CLAMP_FEATURE_POSE',yaw,len(rows),len(failures),time.time()-start,flush=True)
    path=HERE/'restraint_geometry.npz'
    values={}
    for name,m in [('pad',pad),('tie_envelope',tie),('Yaw_Base_candidate',merged)]:
        data=m.to_mesh64();values[name+'_vertices']=np.array(data.vert_properties)[:,:3];values[name+'_faces']=np.array(data.tri_verts)
    np.savez_compressed(path,**values)
    ctx.record([Path(__file__),HERE/'restraint_geometry.py',SOURCE,source,HERE/'flat_zero_verification.json',HERE/'initial_contact_precision/failure.json',HERE/'inspect_restraint_geometry.py'])
    for drawing in json.loads(SOURCE.read_text())['drawings']:
        ctx.record([SOURCE.parent/drawing['file']])
    ctx.unchanged()
    result=dict(status='PASS' if not failures else 'BLOCKED',
        scope='New candidate pad/tie envelope vs current native rigid solids, and exact straight contact cylinders only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        parameters=parameters,intended_pad_tie_overlap_mm3=contact_overlap,intended_contact_volume_tolerance_mm3=1e-6,merged_connected_components=len(merged.decompose()),
        removed_host_volume_mm3=(host-merged).volume(),added_volume_mm3=(merged-host).volume(),
        root_overlap_mm3=(host^pad).volume(),contacts=contact,checks=len(rows),rows=rows,failures=failures,
        geometry_sha256=sha(path),required_other_gap_mm=.3,head_pose_samples=250,
        full_wire_fit='NOT_TESTED',tie_insertion_and_cutting='NOT_TESTED',grip_strength='NOT_TESTED',
        continuous_angle_clearance='NOT_TESTED',main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'restraint_geometry_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_CLAMP_FEATURE_TERMINAL',result['status'],len(rows),len(failures),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
