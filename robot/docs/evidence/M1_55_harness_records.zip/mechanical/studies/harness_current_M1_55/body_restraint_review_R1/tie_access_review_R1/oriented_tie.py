"""Open strap from side root to normal return through the T18R head.

Documented flat-product maxima are retained. Cavity centre, installed bend
and routing are ASSUMED. Keep the full head box for obstacle checking; never
create a fictitious hole to make other objects fit.
"""
from pathlib import Path
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;BODY=HERE.parent
sys.path.insert(0,str(BODY))
from restraint_geometry import SOURCE,PAD_LO,PAD_HI

WIDTH=2.7;THICKNESS=1.3;BEND_RADIUS=1.25
HEAD_LO=np.array([34.6,-25.5,139.735]);HEAD_HI=np.array([39.9,-20.5,144.035])
CAVITY_X=37.2;MID_Y=-23.


def ribbon(manifold,cavity_x=CAVITY_X,tail_mm=2.):
    pts=[];normals=[];radius=BEND_RADIUS
    root_z=HEAD_HI[2]-THICKNESS/2;top_z=PAD_HI[2]+THICKNESS/2
    left_x=24.25;inner_corner_x=left_x+radius
    def emit(p,tangent):
        p=np.array(p,float)
        if pts and np.linalg.norm(p-pts[-1])<1e-10:return
        pts.append(p);normals.append(np.array([-tangent[1],tangent[0]]))
    def line(a,b):
        a,b=np.array(a,float),np.array(b,float);t=(b-a)/np.linalg.norm(b-a)
        for u in np.linspace(0,1,max(2,int(np.ceil(np.linalg.norm(b-a)/.08))+1)):
            emit(a+(b-a)*u,t)
    def clockwise(center,a,b):
        for angle in np.linspace(a,b,65):
            c,s=math.cos(angle),math.sin(angle)
            emit(np.array(center)+radius*np.array([c,s]),[s,-c])
    line([HEAD_LO[0]+.01,root_z],[inner_corner_x,root_z])
    clockwise([inner_corner_x,root_z+radius],-math.pi/2,-math.pi)
    line([left_x,root_z+radius],[left_x,top_z-radius])
    clockwise([inner_corner_x,top_z-radius],math.pi,math.pi/2)
    line([inner_corner_x,top_z],[cavity_x-radius,top_z])
    clockwise([cavity_x-radius,top_z-radius],math.pi/2,0)
    line([cavity_x,top_z-radius],[cavity_x,HEAD_LO[2]-tail_mm])
    pts=np.array(pts);normals=np.array(normals)
    polygon=np.vstack([pts+THICKNESS/2*normals,(pts-THICKNESS/2*normals)[::-1]])
    area=.5*np.sum(polygon[:,0]*np.roll(polygon[:,1],-1)-polygon[:,1]*np.roll(polygon[:,0],-1))
    if area<0:polygon=polygon[::-1]
    band=manifold.CrossSection([polygon.tolist()]).extrude(WIDTH).rotate([90,0,0]).translate([0,MID_Y+WIDTH/2,0])
    length=(HEAD_LO[0]+.01-inner_corner_x+(top_z-radius)-(root_z+radius)
            +(cavity_x-radius-inner_corner_x)+(top_z-radius)-(HEAD_LO[2]-tail_mm)+3*math.pi*radius/2)
    assert band.volume()>1 and len(band.decompose())==1
    assert abs(band.volume()-length*WIDTH*THICKNESS)<.02
    return band,pts,dict(root_point_mm=[HEAD_LO[0]+.01,MID_Y,root_z],
                         root_heading=[-1,0,0],return_axis=[0,0,-1],cavity_x_mm=cavity_x,
                         formed_band_centerline_mm=length,tail_below_head_mm=tail_mm,
                         centerline_includes_inside_head=True,actual_channel='NOT_TESTED')


def build(manifold,cavity_x=CAVITY_X,tail_mm=2.):
    facts=json.loads(SOURCE.read_text())
    assert facts['screen_upper_dimensions']==dict(strap_thickness=1.3,strap_width=2.7,head_height=4.3,head_width=5.,head_length=5.3)
    band,points,details=ribbon(manifold,cavity_x,tail_mm)
    head=manifold.Manifold.cube((HEAD_HI-HEAD_LO).tolist()).translate(HEAD_LO.tolist())
    combined=band+head
    assert len(combined.decompose())==1
    details.update(head_lo_mm=HEAD_LO.tolist(),head_hi_mm=HEAD_HI.tolist(),
                   strap_thickness_mm=THICKNESS,strap_width_mm=WIDTH,
                   centreline_inner_bend_mm=BEND_RADIUS-THICKNESS/2,
                   cavity_centre_evidence='ASSUMED from CSH drawing proportion, not dimensioned',
                   form_evidence='ASSUMED, not tension equilibrium',selected_variant=False)
    return combined,band,head,points,details


def untrimmed(manifold,cavity_x=CAVITY_X):
    _,_,_,_,base=build(manifold,cavity_x,tail_mm=0.)
    # Minimum documented flat length 95 includes the maximum head length5.3.
    # The formed length already includes the strap's segment through the head.
    available=95.-5.3;tail=available-base['formed_band_centerline_mm']
    assert tail>20.
    result=build(manifold,cavity_x,tail)
    result[-1].update(minimum_flat_length_mm=95.,head_length_allowance_mm=5.3,
                      untrimmed_straight_tail_lower_allocation_mm=tail,
                      actual_tip_profile='NOT_TESTED')
    return result
