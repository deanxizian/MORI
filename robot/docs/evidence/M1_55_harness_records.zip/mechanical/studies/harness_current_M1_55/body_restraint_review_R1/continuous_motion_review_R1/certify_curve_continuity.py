"""New four-wire continuous root/bending audit, no inherited route PASS.

Use the existing reviewed analytic operators on the new fixed-body key
family. Old outputs and all native geometry remain untouched. Gauss length
is a numeric reference functional, not actual wire or supplier cut length.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;BODY=HERE.parent;PARENT=BODY.parent
sys.path.insert(0,str(BODY))
from flat_key_family import FlatKeyFamily,NAMES,np,sha,BSpline
OLD=PARENT/'prefix_continuity/frame_family_R3'
sys.path.insert(0,str(OLD))
from frame_motion_bounds import RootBounds
from selected_family import quadrature
SPEC=importlib.util.spec_from_file_location('_mori_retained_bend_operator',OLD/'certify_bending.py')
operators=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(operators)


def sources(f):
    result=dict(f.sources)
    for p in [Path(__file__),OLD/'frame_motion_bounds.py',OLD/'certify_bending.py',
              OLD.parent/'root_direction_R2/root_motion_bounds.py']:
        result[str(p)]=sha(p)
    return result


def main():
    started=time.time();family=FlatKeyFamily();bounds=RootBounds(family)
    tests=[];q,w,_=quadrature(family.knots,128)
    for yaw in [-59.1,-48.7,-26.2,-3.8,4.1,17.3,35.4,58.1]:
        for n in NAMES:
            it=family.candidate(n,yaw);h=.002
            plus=family.candidate(n,yaw+h)['control'];minus=family.candidate(n,yaw-h)['control']
            e1=float(np.max(abs((plus-minus)/(2*h)-it['control_y'])))
            e2=float(np.max(abs((plus-2*it['control']+minus)/h**2-it['control_yy'])))
            error=float(w@np.linalg.norm(q@it['control'],axis=1))-family.targets[n]
            fixed=float(np.max(abs(it['control'][:family.locked_controls[n]]-family.seed[n][:family.locked_controls[n]])))
            assert e1<1e-5 and e2<1e-4 and abs(error)<1e-7 and fixed==0.,(n,yaw,e1,e2,error,fixed)
            tests.append(dict(wire=n,yaw_deg=yaw,first_derivative_error=e1,second_derivative_error=e2,
                              Gauss128_residual_mm=error,fixed_control_error_mm=fixed,status='PASS'))
    rows=[];failed=[]
    for key in range(-60,60,10):
        todo=[(float(a),float(a+.5),0) for a in np.arange(key,key+10,.5)]
        while todo:
            lo,hi,depth=todo.pop()
            certs=[bounds.certificate(n,lo,hi) for n in NAMES]
            if any(c['status']!='PASS' for c in certs):
                if depth<10:
                    mid=(lo+hi)/2;todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
                failed.append(dict(interval=[lo,hi],certificates=certs));continue
            rows.append(dict(yaw_interval_deg=[lo,hi],certificates=certs))
        print('BODY_NEW_ROOT_INTERVAL',key,key+10,len(rows),len(failed),time.time()-started,flush=True)
        if failed:break
    coverage=sorted(r['yaw_interval_deg'] for r in rows)
    complete=bool(not failed and coverage and coverage[0][0]==-60 and coverage[-1][1]==60 and
                  all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:])))
    root_report=dict(status='PASS' if complete else 'BLOCKED',scope='All-yaw Gauss64 reference root for four new fixed-body CAM curves only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources(family),
        wire_count=4,accepted_yaw_cells=len(rows),certificates=rows,derivative_checks=tests,failed_intervals=failed,
        yaw_coverage_deg=[-60,60],native_fit='NOT_TESTED',physical_length='NOT_TESTED',actual_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    root_path=HERE/'continuous_root_verification.json';root_path.write_text(json.dumps(root_report,indent=2)+'\n')
    if not complete:
        print('BODY_NEW_ROOT_TERMINAL',root_report['status'],flush=True);return
    mappings=operators.matrices(family);results=[];failures=[];evaluated=0
    for n in NAMES:
        accepted=[];todo=[(r['yaw_interval_deg'][0],r['yaw_interval_deg'][1],0) for r in rows]
        while todo:
            lo,hi,depth=todo.pop();cert=bounds.certificate(n,lo,hi)
            result=operators.check_curve(family,mappings,n,cert,bounds.derivatives(n,lo,hi)) if cert['status']=='PASS' else dict(status='BLOCKED',type='root_not_enclosed',evaluated_cells=0)
            evaluated+=result['evaluated_cells']
            if result['status']=='PASS':
                accepted.append(dict(yaw_interval_deg=[lo,hi],**result));continue
            if result['status']=='FAIL' or depth>=12:
                failures.append(dict(wire=n,yaw_interval_deg=[lo,hi],**result));break
            mid=(lo+hi)/2;todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
        intervals=sorted(r['yaw_interval_deg'] for r in accepted)
        good=bool(not any(f['wire']==n for f in failures) and intervals and intervals[0][0]==-60 and intervals[-1][1]==60 and
                  all(abs(a[1]-b[0])<1e-12 for a,b in zip(intervals[:-1],intervals[1:])))
        results.append(dict(wire=n,status='PASS' if good else 'BLOCKED',accepted_yaw_cells=len(accepted),
                            minimum_certified_radius_mm=min((a['radius_lower_mm'] for a in accepted),default=None),intervals=accepted))
        print('BODY_NEW_BEND_WIRE',n,results[-1]['status'],len(accepted),evaluated,time.time()-started,flush=True)
        if not good:break
    family.unchanged();source=sources(family);source[str(root_path)]=sha(root_path)
    result=dict(status='PASS' if len(results)==4 and not failures else 'BLOCKED',
        scope='Whole-curve bend across every yaw -60..60 for four new fixed-body reference curves only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=source,
        results=results,failures=failures,evaluated_polynomial_cells=evaluated,required_radius_mm=6.865,
        yaw_coverage_deg=[-60,60],wire_count=len(results),native_clearance='NOT_TESTED',tie_installation='NOT_TESTED',
        physical_material_and_life='NOT_TESTED',actual_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'continuous_bend_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_NEW_CONTINUOUS_BEND_TERMINAL',result['status'],len(results),evaluated,time.time()-started,flush=True)


if __name__=='__main__':main()
