"""Fresh disjoint-worker half-grid checks of all seven upper constructions."""
from pathlib import Path
import datetime
import importlib.util
import itertools
import json
import sys
import time

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT))
from context import Context,np,clear,transform_points,rigidtr,sha
sys.path.insert(0,str(HERE))
from power_family import PowerFamily
from piecewise_geometry import BSpline,pieces,RADII
HELPERS=PARENT/'upper_length_match_R1/inspect_changed.py'
spec=importlib.util.spec_from_file_location('_mori_upper_motion_distance_helpers',HELPERS)
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)


def main():
    started=time.time();native=Context();family=PowerFamily()
    power_path=HERE/'half_grid_inspection.json';cam_path=HERE/'cam_half_grid_inspection.json'
    power=json.loads(power_path.read_text());cam=json.loads(cam_path.read_text())
    assert power['status']==cam['status']=='PASS'
    assert all(sha(p)==h for d in [power,cam] for p,h in d['sources'].items())
    psrc=HERE/'half_grid_curves.npz';csrc=HERE/'cam_half_grid_curves.npz'
    assert sha(psrc)==power['arrays_sha256'] and sha(csrc)==cam['arrays_sha256']
    pa=np.load(psrc);ca=np.load(csrc)
    native.record([Path(__file__),HELPERS,HELPERS.parent/'sample_geometry.py',
                   PARENT/'upper_pairs_review_R1/inspect_pairs.py',power_path,cam_path,psrc,csrc])
    all_poses=power['planned_poses'];assert len(all_poses)==475 and {tuple(p) for p in all_poses}=={tuple(p) for p in cam['planned_poses']}
    worker=next((int(a.split('=',1)[1]) for a in sys.argv if a.startswith('--worker=')),0)
    workers=2;assert 0<=worker<workers
    poses=all_poses[worker::workers]
    native.sources.update(power['sources']);native.sources.update(cam['sources'])
    rows=[];failures=[];cache={};counts={'native':0,'conditional_USB':0,'upper_peer':0,'other_prefix':0,'self':0,'own_join':0}
    for yaw,pitch in poses:
        if yaw not in cache:
            cache[yaw]={n:helpers.prepare(pieces(BSpline(family.ctx.f.knots,family.ctx.f.candidate(n,yaw)['control'],3)),
                                          family.ctx.f.radii[n]) for n in family.ctx.f.names}
        prefixes=cache[yaw];packs={}
        for n in RADII:
            source=ca if n.startswith('CAM_') else pa
            packs[n]=helpers.prepare(source[f'{n}_y{yaw:g}_p{pitch:g}_controls'],RADII[n])
        for name,pack in packs.items():
            for group,targets in native.groups.items():
                matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
                hits,near=clear(transform_points(pack['p'],matrix),pack['radius']*norm,targets,error=pack['error']*norm,gap=.3*norm)
                row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,kind='native',group=group,
                    status='PASS' if not hits else 'BLOCKED',hits=hits,nearest_within_query_AABBs=near,
                    points=len(pack['p']),cubic_chord_error_mm=pack['error'],frame_operator_norm=norm)
                rows.append(row);counts['native']+=1
                if hits:failures.append(row)
            matrix=np.linalg.inv(np.asarray(rigidtr(yaw,pitch)));norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0])
            hits,near=clear(transform_points(pack['p'],matrix),pack['radius']*norm,native.usb,error=pack['error']*norm,gap=.3*norm)
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,kind='conditional_USB',status='PASS' if not hits else 'BLOCKED',
                     hits=hits,nearest_within_query_AABBs=near,actual_USB_tail='BLOCKED')
            rows.append(row);counts['conditional_USB']+=1
            if hits:failures.append(row)
            for other,item in prefixes.items():
                if other==name:continue
                row=dict(wires=[name,other],yaw_deg=yaw,pitch_deg=pitch,**helpers.compare(pack,item))
                row['kind']='other_prefix';rows.append(row);counts['other_prefix']+=1
                if row['status']!='PASS':failures.append(row)
            for kind,left in [('self',pack),('own_join',prefixes[name])]:
                row=dict(wires=[name,name],yaw_deg=yaw,pitch_deg=pitch,**helpers.compare(left,pack,kind))
                rows.append(row);counts[kind]+=1
                if row['status']!='PASS':failures.append(row)
        for a,b in itertools.combinations(RADII,2):
            row=dict(wires=[a,b],yaw_deg=yaw,pitch_deg=pitch,**helpers.compare(packs[a],packs[b]))
            row['kind']='upper_peer';rows.append(row);counts['upper_peer']+=1
            if row['status']!='PASS':failures.append(row)
        print('CONTINUOUS_UPPER_HALF_GRID',yaw,pitch,len(rows),len(failures),flush=True)
        if failures:break
    native.unchanged();family.unchanged();count=len(poses)
    expected={'native':21*count,'conditional_USB':7*count,'upper_peer':21*count,'other_prefix':77*count,'self':7*count,'own_join':7*count}
    out=dict(status='PASS' if not failures and counts==expected else 'BLOCKED',
        scope='Fresh disjoint half-grid worker checks of seven upper references against current201 native solids; not all-angle clearance',worker=worker,workers=workers,
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=native.sources|family.sources,
        planned_poses=poses,counts=counts,expected_counts=expected,rows=rows,failures=failures,elapsed_s=time.time()-started,
        required_gap_mm=.3,actual_arc_local_exclusion_upper_mm=5.,local_smooth_tube='NOT_TESTED',
        all_angle_native_clearance='NOT_TESTED',all_angle_peer_clearance='NOT_TESTED',
        actual_material_and_termination='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/f'half_grid_worker_{worker}_geometry.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_UPPER_HALF_GRID_TERMINAL',out['status'],len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
