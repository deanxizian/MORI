"""Finite pilot/grid checks of the continuous CAM construction."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from cam_family import CAMFamily,NAMES,cubic_lengths,sha
from screen_power_family import PILOT

HERE=Path(__file__).resolve().parent


def main():
    started=time.time();reserve=next((float(a.split('=',1)[1]) for a in sys.argv if a.startswith('--reserve=')),0.)
    family=CAMFamily(reserve=reserve);rows=[];failures=[];arrays={}
    mode='half_grid' if '--half-grid' in sys.argv else 'key_grid' if '--key-grid' in sys.argv else 'pilot'
    poses=(PILOT+[(0.,p) for p in [7.5,12.5,17.5,22.5]] if mode=='pilot' else
           [(float(y),float(p)) for y in range(-60,61,10) for p in range(-20,26,5)] if mode=='key_grid' else
           [(float(y),float(p)) for y in range(-60,61,5) for p in np.arange(-20,25.01,2.5)])
    for yaw,pitch in poses:
        for name in NAMES:
            c,info=family.upper(name,yaw,pitch);row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,**info);rows.append(row)
            if c is None:failures.append(row)
            else:
                key=f'{name}_y{yaw:g}_p{pitch:g}';arrays[key+'_controls']=c;arrays[key+'_lengths']=cubic_lengths(c)
        print('CONTINUOUS_CAM_FAMILY_POSE',yaw,pitch,len(rows),len(failures),flush=True)
        if failures:break
    family.ctx.record([Path(__file__),HERE/'screen_power_family.py']);family.unchanged()
    np.savez_compressed(HERE/f'cam_{mode}_curves.npz',**arrays)
    out=dict(status='PASS' if not failures and len(rows)==4*len(poses) else 'BLOCKED',
        scope='Continuous CAM primitive construction tested at finite samples; no all-angle native/bending proof',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=family.sources,
        planned_poses=poses,checked_curve_poses=len(rows),rows=rows,failures=failures,targets=family.targets,
        additional_numeric_length_reserve_mm=reserve,arrays_sha256=sha(HERE/f'cam_{mode}_curves.npz'),elapsed_s=time.time()-started,
        continuous_all_angle_bending='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        actual_material_endpoints_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/f'cam_{mode}_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_CAM_FAMILY_TERMINAL',out['status'],len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
