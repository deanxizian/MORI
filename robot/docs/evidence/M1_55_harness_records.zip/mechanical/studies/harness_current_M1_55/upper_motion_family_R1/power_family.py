"""Continuous two-angle power/CC capacity references with fixed datums.

Interpolate shape residuals in the yaw frame, while the assumed upper end
follows the same head transform. Numerical matrix residuals reproduce the
retained float32 key frames. Only candidate curves, never hardware, change.
The existing R3 body/neck family and its endpoints are used unchanged.
"""
from pathlib import Path
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import PiecewiseContext,BSpline,unit,MINIMUM_RADIUS,sha
sys.path.insert(0,str(PARENT/'bundle_length_match_R1'))
from match_bundle import candidate,cubic_lengths
sys.path.insert(0,str(PARENT/'prefix_continuity'))
from family import smooth

NAMES=['P_J18_1','P_J18_2','CC_allocation']


def cell(value,lo,hi,step):
    assert lo<=value<=hi
    index=min(round((hi-lo)/step)-1,max(0,int(math.floor((value-lo)/step))))
    a=lo+step*index;b=a+step
    return a,b,smooth((value-a)/step)


def interp(values,yaw,pitch):
    a,b,u=cell(yaw,-60,60,10);c,d,v=cell(pitch,-20,25,5)
    return (1-u)*((1-v)*values[a,c]+v*values[a,d])+u*((1-v)*values[b,c]+v*values[b,d])


def mathematical_transform(center,yaw,pitch):
    y,p=math.radians(yaw),math.radians(pitch);cy,sy=math.cos(y),math.sin(y);cp,sp=math.cos(p),math.sin(p)
    rz=np.array([[cy,-sy,0.],[sy,cy,0.],[0.,0.,1.]])
    rx=np.array([[1.,0.,0.],[0.,cp,-sp],[0.,sp,cp]])
    rotation=rz@rx;matrix=np.eye(4);matrix[:3,:3]=rotation
    matrix[:3,3]=center-rotation@center
    return matrix


class PowerFamily:
    def __init__(self):
        self.ctx=PiecewiseContext();self.center=np.array(self.ctx.tr['head_center_mm'],float)
        bundle_path=PARENT/'bundle_length_match_R1/all_poses_length_match.json'
        combined_path=PARENT/'complete_known_upper_review_R1/verification.json'
        bundle=json.loads(bundle_path.read_text());combined=json.loads(combined_path.read_text())
        assert bundle['status']==combined['status']=='PASS'
        assert all(sha(p)==h for d in [bundle,combined] for p,h in d['sources'].items())
        rows={(r['wire'],r['yaw_deg'],r['pitch_deg']):r for r in bundle['selected']['rows']}
        self.controls={n:{} for n in NAMES};self.frame_residual={}
        for yaw in range(-60,61,10):
            for pitch in range(-20,26,5):
                saved=np.array(self.ctx.tr['transforms'][f'y{yaw}_p{pitch}'])
                self.frame_residual[yaw,pitch]=saved-mathematical_transform(self.center,yaw,pitch)
                for name in NAMES:
                    if name=='P_J18_1':c=self.ctx.upper_meta[name,yaw,pitch]['controls_yaw_local_mm']
                    else:c=rows[name,yaw,pitch]['degree_five_controls_yaw_local_mm']
                    self.controls[name][yaw,pitch]=np.array(c,float)
        self.end_canonical={n:self.controls[n][0,0][4:].copy() for n in NAMES}
        self.end_residual={n:{} for n in NAMES}
        for yaw in range(-60,61,10):
            for pitch in range(-20,26,5):
                local_frame=np.linalg.inv(self.transform(yaw,0))@self.transform(yaw,pitch)
                for name in NAMES:
                    end=self.end_canonical[name]@local_frame[:3,:3].T+local_frame[:3,3]
                    self.end_residual[name][yaw,pitch]=self.controls[name][yaw,pitch][4:]-end
        summaries={r['wire']:r for r in combined['summaries']}
        self.targets={n:(summaries[n]['final_numeric_min_mm']+summaries[n]['final_numeric_max_mm'])/2 for n in NAMES}
        self.ctx.record([Path(__file__),bundle_path,combined_path,PARENT/'bundle_length_match_R1/match_bundle.py'])

    @property
    def sources(self):return self.ctx.sources

    def transform(self,yaw,pitch):
        return mathematical_transform(self.center,yaw,pitch)+interp(self.frame_residual,yaw,pitch)

    def upper(self,name,yaw,pitch):
        c=interp(self.controls[name],yaw,pitch)
        my=self.transform(yaw,0);mt=self.transform(yaw,pitch)
        local_frame=np.linalg.inv(my)@mt
        c[4:]=self.end_canonical[name]@local_frame[:3,:3].T+local_frame[:3,3]+interp(self.end_residual[name],yaw,pitch)
        lower=self.ctx.f.candidate(name,yaw)['control']
        start=lower[-1];incoming=BSpline(self.ctx.f.knots,lower,3).derivative()(1.)
        finish=c[0]@my[:3,:3].T+my[:3,3]
        source_direction=my[:3,:3]@(c[1]-c[0]);L=float(np.linalg.norm(finish-start))
        stub=np.array([[start,start+unit(incoming)*L/3,finish-unit(source_direction)*L/3,finish]])
        end=c[-1]@my[:3,:3].T+my[:3,3]
        raw=np.array([start,finish,end])
        pre=dict(control=c,matrix=my,cubic=stub,raw=raw,incoming=incoming,
                 outgoing=my[:3,:3]@(c[-1]-c[-2]),required_radius=MINIMUM_RADIUS[name])
        actual,info=candidate(pre,self.targets[name]-self.ctx.f.targets[name],np.array([0.,0.,1.]),.5)
        if actual is not None:
            info['full_numeric_reference_mm']=self.ctx.f.targets[name]+info['upper_Gauss64_length_mm']
            info['target_full_numeric_reference_mm']=self.targets[name]
            info['single_stub_length_mm']=L
            info['matrix_residual_operator_norm']=float(np.linalg.svd(interp(self.frame_residual,yaw,pitch)[:3],compute_uv=False)[0])
        return actual,info

    def unchanged(self):self.ctx.unchanged()
