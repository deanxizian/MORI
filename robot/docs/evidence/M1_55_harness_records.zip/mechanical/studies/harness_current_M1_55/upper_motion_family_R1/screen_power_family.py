"""Pilot/key-grid mathematics for the continuous power/CC family."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from power_family import PowerFamily,NAMES,cubic_lengths,sha

HERE=Path(__file__).resolve().parent
PILOT=[(0.,0.),(-60.,-20.),(60.,25.),(-55.,-17.5),(-45.,-2.5),(-5.,2.5),
       (5.,-17.5),(15.,22.5),(35.,7.5),(55.,-7.5),(0.,.1),(0.,-.1)]


def main():
    started=time.time();family=PowerFamily();rows=[];failures=[];arrays={}
    mode='half_grid' if '--half-grid' in sys.argv else 'key_grid' if '--key-grid' in sys.argv else 'pilot'
    poses=(PILOT if mode=='pilot' else [(float(y),float(p)) for y in range(-60,61,10) for p in range(-20,26,5)] if mode=='key_grid'
           else [(float(y),float(p)) for y in range(-60,61,5) for p in np.arange(-20,25.01,2.5)])
    for yaw,pitch in poses:
        for name in NAMES:
            c,info=family.upper(name,yaw,pitch)
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,**info)
            rows.append(row)
            if c is None:failures.append(row)
            else:
                key=f'{name}_y{yaw:g}_p{pitch:g}'
                arrays[key+'_controls']=c;arrays[key+'_lengths']=cubic_lengths(c)
        print('CONTINUOUS_POWER_FAMILY_POSE',yaw,pitch,len(rows),len(failures),flush=True)
        if failures:break
    family.ctx.record([Path(__file__)]);family.unchanged()
    np.savez_compressed(HERE/f'{mode}_curves.npz',**arrays)
    out=dict(status='PASS' if not failures and len(rows)==3*len(poses) else 'BLOCKED',
        scope='Continuous family construction tested at finite power/CC samples only; not continuous native/bending proof',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=family.sources,
        planned_poses=poses,checked_curve_poses=len(rows),rows=rows,failures=failures,
        family_shape_interpolation='Quintic C2 residual interpolation in yaw frame; endpoints follow head frame plus retained numerical residual',
        root_direction=[0,0,1],second_control_weight=.5,targets=family.targets,
        arrays_sha256=sha(HERE/f'{mode}_curves.npz'),elapsed_s=time.time()-started,
        global_root_branch='NOT_TESTED',continuous_all_angle_bending='NOT_TESTED',
        native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        actual_material_endpoints_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/f'{mode}_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_POWER_FAMILY_TERMINAL',out['status'],len(rows),len(failures),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
