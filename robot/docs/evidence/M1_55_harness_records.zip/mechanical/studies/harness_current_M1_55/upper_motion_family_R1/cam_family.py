"""Analytic line/arc CAM references evaluated between the retained key poses.

Recompute the existing return height to match complete numeric length, with
the R3 body/neck family unchanged. Frames continuously reproduce the current
key transforms; all real ports, solids and selected materials stay untouched.
"""
from pathlib import Path
import math
import sys
import numpy as np

from power_family import PowerFamily
from piecewise_geometry import Builder,BSpline,unit,radius_bound,MINIMUM_RADIUS,sha
from inspect_complete_numeric_lengths import upper_length
from match_bundle import cubic_lengths
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'upper_length_match_R1'))
from match_cam import shape_check

HERE=Path(__file__).resolve().parent
NAMES=[f'CAM_{p}' for p in range(1,5)]


class CAMFamily:
    def __init__(self,carrier=None,reserve=0.):
        self.carrier=carrier or PowerFamily();self.ctx=self.carrier.ctx;self.reserve=reserve
        import json
        path=HERE.parent/'complete_known_upper_review_R1/verification.json'
        d=json.loads(path.read_text());assert d['status']=='PASS'
        summaries={r['wire']:r for r in d['summaries']}
        self.targets={n:(summaries[n]['final_numeric_min_mm']+summaries[n]['final_numeric_max_mm'])/2+reserve for n in NAMES}
        self.tail_builders={};self.anchors={}
        for pin in range(1,5):
            self.anchors[pin]=np.array(self.ctx.loop[pin,0,0]['anchor_mm'])
            assert all(np.linalg.norm(np.array(m['anchor_mm'])-self.anchors[pin])<1e-7 for (p,y,t),m in self.ctx.loop.items() if p==pin)
            tail=self.ctx.cam[f'pin{pin}'];start,end=tail[[0,-1]];j=pin-1;r=7.5+j
            s=self.ctx.tail_spec;right,top_z,under,R=s['right'],s['top'],s['under'],s['return_radius']
            x=right+r;y=end[1]+2*R;c3=np.array([right,end[1],end[2]-r]);a3=c3+[r,0,0]
            upper=Builder()
            points=[start,[start[0],start[1],210.-1.3*j],[start[0],-40.-1.3*j,210.-1.3*j],
                    [start[0],-40.-1.3*j,240.],[start[0],y,top_z+j],[x,y,top_z+j],[x,y,under]]
            upper.rounded(points,7.5);upper.arc([x,end[1]+R,under],[0,1,0],[0,0,-1],R,0,math.pi)
            upper.line(upper.end,a3);upper.arc(c3,[1,0,0],[0,0,1],r,0,math.pi/2);upper.line(upper.end,end)
            self.tail_builders[pin]=upper
        self.ctx.record([Path(__file__),path])

    @property
    def sources(self):return self.ctx.sources

    def construct(self,pin,yaw,pitch,height):
        name=f'CAM_{pin}';f=self.ctx.f;result=Builder()
        lower_control=f.candidate(name,yaw)['control'];start=lower_control[-1]
        incoming=BSpline(f.knots,lower_control,3).derivative()(1.)
        my=self.carrier.transform(yaw,0);mp=self.carrier.transform(0,pitch);mt=self.carrier.transform(yaw,pitch)
        spec=self.ctx.fan[pin];fan_start=np.array(spec['start_mm'])
        finish=fan_start@my[:3,:3].T+my[:3,3];delta=finish-start
        if abs(delta[2])>1e-8:
            L=float(np.linalg.norm(delta));outgoing=my[:3,:3]@np.array([0.,0.,1.])
            c=np.array([start,start+unit(incoming)*L/3,finish-unit(outgoing)*L/3,finish])
            result.add(c,L,'neck_Hermite')
            local_start=fan_start
        else:
            assert np.linalg.norm(delta)<1e-5
            inverse=np.linalg.inv(my);local_start=start@inverse[:3,:3].T+inverse[:3,3]
        local=Builder();first=local_start+[0,0,spec['lead_mm']]
        local.line(local_start,first);anchor=self.anchors[pin]
        local.shift(first,anchor[:2],spec['radius_mm']);local.line(local.end,anchor)
        a=anchor;first=a+[0,0,self.ctx.loop_spec['lead_mm']];local.line(a,first)
        tail=self.ctx.cam[f'pin{pin}'];endpoint=tail[0]-[0,0,15.]
        b=endpoint@mp[:3,:3].T+mp[:3,3];angle=math.radians(pitch);s,c=math.sin(angle),math.cos(angle)
        sign=1. if pitch>=0 else -1.;tangent=np.array([0.,s,-c]);terminal=self.ctx.loop_spec['terminal_straight_mm']
        d=b-terminal*tangent;lower=d-[0,sign*7.5*(1-c),-7.5*abs(s)]
        local.shift(first,[b[0],lower[1]+14.],7.)
        top=local.end+[0,0,height];local.line(local.end,top)
        local.arc(top+[0,-7.,0],[0,1,0],[0,0,1],7.,0,math.pi)
        return_straight=float(local.end[2]-lower[2]);local.line(local.end,lower)
        local.arc(lower+[0,sign*7.5,0],[0,-sign,0],[0,0,-1],7.5,0,abs(angle))
        result.append(local,my)
        upper=self.tail_builders[pin]
        first_ctrl=np.asarray(upper.controls[0])@mt[:3,:3].T+mt[:3,3]
        correction=float(np.linalg.norm(result.end-first_ctrl[0]));assert correction<1e-5
        last=result.controls[-1];last[3]=first_ctrl[0]
        last[2]=last[3]-unit(first_ctrl[1]-first_ctrl[0])*np.linalg.norm(last[3]-last[2])
        result.append(upper,mt)
        first=result.controls[0];span=np.linalg.norm(first[1]-first[0]);first[0]=start;first[1]=start+unit(incoming)*span
        outgoing=mt[:3,:3]@np.array([-1.,0.,0.])
        expected=tail[-1]@mt[:3,:3].T+mt[:3,3];last=result.controls[-1];span=np.linalg.norm(last[-1]-last[-2])
        last[-1]=expected;last[-2]=expected-unit(outgoing)*span
        return np.array(result.controls),np.array(result.lengths),dict(incoming=incoming,outgoing=outgoing,
            return_straight_mm=return_straight,source_seam_correction_mm=correction)

    def upper(self,name,yaw,pitch):
        pin=int(name.split('_')[-1]);body=self.ctx.f.targets[name]
        baseline=1.;c,L,info=self.construct(pin,yaw,pitch,baseline)
        rate=2*float(np.linalg.norm(self.carrier.transform(yaw,0)[:3,:3]@np.array([0.,0.,1.])))
        height=baseline+(self.targets[name]-body-upper_length(c,64))/rate
        if height<.5:
            return None,dict(status='BLOCKED',stage='return_height',height_mm=float(height),minimum_height_mm=.5,
                target_full_numeric_reference_mm=self.targets[name],additional_numeric_reserve_mm=self.reserve)
        for _ in range(3):
            c,L,details=self.construct(pin,yaw,pitch,height)
            actual=body+upper_length(c,64);residual=actual-self.targets[name]
            if abs(residual)<1e-8:break
            height-=residual/rate
        bend=radius_bound(c);joins=shape_check(c,details['incoming'],details['outgoing'])
        ok=(height>=.5 and details['return_straight_mm']>=.5 and abs(residual)<1e-8 and
            bend['radius_lower_mm']>=MINIMUM_RADIUS[name] and joins['internal_position_error_mm']<1e-10 and
            joins['internal_tangent_unit_error']<1e-8 and joins['end_tangent_unit_error']<1e-8)
        row=dict(status='PASS' if ok else 'BLOCKED',stage='curve_math',height_mm=float(height),
            minimum_height_mm=.5,target_full_numeric_reference_mm=self.targets[name],
            full_numeric_reference_mm=actual,length_residual_mm=residual,
            additional_numeric_reserve_mm=self.reserve,continuous_bending=bend,
            required_reference_radius_mm=MINIMUM_RADIUS[name],**joins,
            return_straight_mm=details['return_straight_mm'],source_seam_correction_mm=details['source_seam_correction_mm'],
            supplier_cut_length=None)
        return c if ok else None,row

    def unchanged(self):self.carrier.unchanged()
