"""Audit completed finite workers and publish their exact remaining boundaries."""
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import datetime
import hashlib
import itertools
import json
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
PROJECT = HERE.parents[3]
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    paths = [HERE / 'half_grid_inspection.json', HERE / 'cam_half_grid_inspection.json',
             HERE / 'half_grid_worker_0_geometry.json', HERE / 'half_grid_worker_1_geometry.json']
    power, cam, *workers = [read(p) for p in paths]
    sources = {}
    for receipt in [power, cam, *workers]:
        assert receipt['status'] == 'PASS' and not receipt['failures']
        for path, digest in receipt['sources'].items():
            assert path not in sources or sources[path] == digest
            sources[path] = digest
    assert all(sha(p) == h for p, h in sources.items())
    poses = power['planned_poses']
    expected_poses = set(itertools.product(range(-60, 61, 5), [i / 2 for i in range(-40, 51, 5)]))
    assert len(poses) == 475 and {tuple(p) for p in poses} == expected_poses
    assert {tuple(p) for p in cam['planned_poses']} == expected_poses
    for receipt, arrays, count in [(power, 'half_grid_curves.npz', 1425),
                                    (cam, 'cam_half_grid_curves.npz', 1900)]:
        assert receipt['checked_curve_poses'] == len(receipt['rows']) == count
        assert sha(HERE / arrays) == receipt['arrays_sha256']
    math_rows = power['rows'] + cam['rows']
    math_keys = {(r['wire'], r['yaw_deg'], r['pitch_deg']) for r in math_rows}
    names = {r['wire'] for r in math_rows}
    assert len(names) == 7 and len(math_keys) == 3325
    assert math_keys == {(n, y, p) for n in names for y, p in expected_poses}
    summaries = []
    for name in sorted(names):
        rows = [r for r in math_rows if r['wire'] == name]
        lengths = [r['full_numeric_reference_mm'] for r in rows]
        assert all(r['status'] == 'PASS' and abs(r['length_residual_mm']) < 1e-7 for r in rows)
        assert all(r['continuous_bending']['radius_lower_mm'] >= r['required_reference_radius_mm'] for r in rows)
        summaries.append(dict(wire=name, curve_poses=len(rows),
                              numeric_length_range_mm=max(lengths)-min(lengths),
                              minimum_cubic_radius_lower_mm=min(r['continuous_bending']['radius_lower_mm'] for r in rows),
                              supplier_cut_length=None))
    counts = Counter()
    per_pose = Counter()
    keys = set()
    for index, worker in enumerate(workers):
        assert worker['worker'] == index and worker['workers'] == 2
        assert worker['planned_poses'] == poses[index::2]
        assert worker['counts'] == worker['expected_counts']
        assert len(worker['rows']) == sum(worker['counts'].values()) == 140 * len(worker['planned_poses'])
        for row in worker['rows']:
            assert row['status'] == 'PASS' and not row.get('hits')
            pose = (row['yaw_deg'], row['pitch_deg'])
            key = (*pose, row['kind'], row.get('wire'), tuple(row.get('wires', [])), row.get('group'))
            assert key not in keys
            keys.add(key)
            counts[row['kind']] += 1
            per_pose[pose] += 1
    assert set(per_pose) == expected_poses and set(per_pose.values()) == {140}
    expected_counts = dict(native=9975, conditional_USB=3325, upper_peer=9975,
                           other_prefix=36575, self=3325, own_join=3325)
    assert dict(counts) == expected_counts and len(keys) == 66500
    short_path = PARENT / 'cam_tail_simplification_R1/zero_review.json'
    short = read(short_path)
    assert short['status'] == 'BLOCKED' and len(short['failures']) == 4
    assert len(short['geometry_checks']) == 86
    assert all(r['kind'] == 'conditional_USB' for r in short['failures'])
    assert all(sha(p) == h for p, h in short['sources'].items())
    baseline = read(PROJECT / 'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {n: h for n, h in baseline['protected_hardware'].items()
                 if '__pycache__' not in n and Path(n).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT / n) == h for n, h in protected.items())
    main_path = PROJECT / 'mechanical/mori_v1_2.blend'
    video_path = PROJECT / 'mechanical/animation/MORI_assembly.mp4'
    assert sha(main_path) == '3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video_path) == '9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT, text=True).strip()
    assert head == 'a719272b305f6e17fa19bf4687a6826003f16c2b'
    logs = ['screen_half_grid.log', 'screen_cam_half_grid.log',
            'inspect_half_grid_worker_0.log', 'inspect_half_grid_worker_1.log']
    actual_logs = [p for p in HERE.glob('*.log') if p.name in logs]
    # Source receipts, including terminal reports, are the authority for results.
    for log in actual_logs:
        assert 'Traceback (most recent call last)' not in log.read_text()
    files = paths + [short_path, Path(__file__), HERE / 'half_grid_curves.npz', HERE / 'cam_half_grid_curves.npz'] + actual_logs
    out = dict(status='PASS', scope='Independent finite report identity, coverage and preservation audit; not new BVH or all-angle proof',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               input_hashes={str(p): sha(p) for p in files}, sources=sources,
               finite_poses=475, known_references=7, curve_math_checks=3325,
               unique_geometry_checks=66500, counts=expected_counts, summaries=summaries,
               shorter_CAM_candidate='BLOCKED', shorter_CAM_failure_scope='Four conditional USB allocation clashes at zero pose; unadopted',
               remaining_work_packages=4, remaining_missing_upper=['P_J9_1', 'P_J9_2', 'P_J9_3', 'SPK_reservation_3', 'SPK_reservation_6'],
               all_angle_native_clearance='NOT_TESTED', all_angle_peer_clearance='NOT_TESTED',
               exact_CAM_cubic_family_continuity='NOT_TESTED - angle-dependent arc subdivision count',
               actual_material_and_cut_lengths='BLOCKED', full_harness='BLOCKED',
               main_sha256=sha(main_path), video_sha256=sha(video_path), git_head=head,
               protected_hardware_files=len(protected), main_changed=False, animation_changed=False,
               hardware_changed=False, manufacturing_release=False,
               audit_command=[sys.executable, str(Path(__file__))], audit_cwd=str(PROJECT),
               Python=sys.version.split()[0], Blender='5.2.2 LTS d13f752e3b9c')
    (HERE / 'verification.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    text = '''# 已知上段中间姿态复核：未采用

7条已知上段参考在475个组合姿态（偏航5°、俯仰2.5°步长）下，
3325条曲线的整段三次曲率、切向接续和公共数值长度检查通过。
两个独立分区检查当前201件实体、假定USB插头、21组上段配对、
其他前段、远端自接近和自身接续，共66500项通过。
verify_half_grid.py核对两分区没有重复或漏姿态、候选数组和源文件完全对应。
它没有重跑BVH，不把离散样本当作全角度证明。

更短的CAM固定尾段候选在零位与假定USB插头空间冲突，4条失败保留。
其余零位检查通过不构成完整路线通过。失败候选没有采用。

仍剩四类工作：完整上段与运动；实际材料、分段线长和余量；
配对端接与应力释放；带线装入、拆装和闭壳，然后经确认同步主模型及动画。
3条头舵机总线、2条喇叭参考缺实际上段端点；CAM供电源端待正式硬件交接。
喇叭150mm是从壳体出口到已有插头末端的用户测量，不是裸线裁线长。
SC-0090-C001配件和微雪FPC/FFC按用户决定到货复核。

路线仍为PLACEHOLDER / ASSUMED。当前主模型M1.55、动画M1.55-A1、
hardware/及HEAD保持；manufacturing_release=false。
'''
    (HERE / 'README.md').write_text(text)
    page = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 线束进度与卡点</title>
<style>body{max-width:940px;margin:32px auto;padding:0 20px 60px;font:16px/1.75 system-ui;color:#243841;background:#f6f8f9}a{color:#146885}td,th{padding:12px;border-bottom:1px solid #d9e1e5;text-align:left}table{width:100%;border-collapse:collapse;background:white}.notice{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}</style>
<h1>M1.55 · 线束进度与卡点</h1><p>2026-10-09 · <strong>已知参考的有限姿态检查PASS；完整线束BLOCKED，尚未采用。</strong></p>
<p>7条已知上段在475个组合姿态完成3,325条曲线检查；当前201件原生实体、假定USB插头、跨线及远端自接近检查共66,500项通过。偏航步长5°，俯仰步长2.5°；这些结果仅覆盖样本，完整角度之间仍待复核。</p>
<p class="notice">更短的CAM固定尾线候选在零位与USB插头预留空间冲突，4条失败保留。原候选的475姿态通过结果与这版失败分别记录，均没有进入主模型。长度为数值参考，不能发给供应商直接裁线。</p>
<table><tr><th>剩余工作</th><th>当前卡点／可继续内容</th></tr>
<tr><td>1. 完整上段与运动</td><td>7条已知上段已加密检查；3条头舵机总线和2条喇叭参考缺真实端点。可继续相邻姿态与尾线优化。</td></tr>
<tr><td>2. 实际材料与线长</td><td>厂配尾线、混合材料分段和最终端点未齐，不能冻结裁线图；现有公共数值长度已匹配。</td></tr>
<tr><td>3. 端接与固定</td><td>CAM供电源端待硬件正式交接，喇叭插头规格待核对；完成配对后继续夹持和应力释放。</td></tr>
<tr><td>4. 带线装配与闭壳</td><td>需在完整路线与固定方案确定后，复核穿装、头身连接、拆装和闭壳，经确认同步主模型及视频。</td></tr></table>
<p>SC-0090-C001舵盘／花键／锁紧、微雪FPC／FFC按用户决定到货复核。PA12配合、公差、强度和线束寿命需要试打／实物；目前不用再确认新的结构方案。</p>
<p><a href="verification.json">本轮独立汇总</a> · <a href="half_grid_worker_0_geometry.json">分区0原始检查</a> · <a href="half_grid_worker_1_geometry.json">分区1原始检查</a> · <a href="half_grid_inspection.json">电源／CC曲线</a> · <a href="cam_half_grid_inspection.json">CAM曲线</a> · <a href="../cam_tail_simplification_R1/zero_review.json">短尾线失败记录</a> · <a href="../missing_upper_interface_review_R1/README.md">缺失端点来源核对</a> · <a href="README.md">复现与边界</a></p>
<p><a href="../index.html">线束总览</a> · <a href="../../../../docs/CURRENT_STATUS.md">当前状态</a> · <a href="../../../mori_v1_2.blend">M1.55主模型</a> · <a href="../../../animation/index.html">M1.55-A1装配视频</a></p>
<p>PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></html>'''
    (HERE / 'index.html').write_text(page)
    links = []
    for link in re.findall(r'(?:href|src)="([^"]+)"', page):
        parsed = urlsplit(link)
        if parsed.scheme or not parsed.path:
            continue
        target = (HERE / parsed.path).resolve()
        assert target.is_file() and target.is_relative_to(PROJECT)
        url = 'http://127.0.0.1:58202/' + str(target.relative_to(PROJECT))
        with urlopen(Request(url, method='HEAD'), timeout=10) as response:
            assert response.status == 200
        links.append(str(target.relative_to(PROJECT)))
    published = [HERE / n for n in ['verification.json', 'README.md', 'index.html', 'verify_half_grid.py']]
    (HERE / 'publication_verification.json').write_text(json.dumps(dict(status='PASS',
        scope='Local files, source identity and HTTP links only', files={p.name: sha(p) for p in published},
        checked_links=links, full_harness='BLOCKED', manufacturing_release=False), ensure_ascii=False, indent=2) + '\n')
    print('UPPER_HALF_GRID_VERIFIED', len(expected_poses), len(math_rows), len(keys), len(links), flush=True)


if __name__ == '__main__':
    main()
