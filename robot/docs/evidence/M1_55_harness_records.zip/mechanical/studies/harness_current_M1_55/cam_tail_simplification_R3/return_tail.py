"""Retain the USB-clearing lower return, reduce only the fixed-head upper detour."""
from pathlib import Path
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from cam_family import CAMFamily,Builder,upper_length
from piecewise_geometry import unit


class LowerTopFamily(CAMFamily):
    def __init__(self,carrier=None,top=245.):
        super().__init__(carrier=carrier)
        self.spec=dict(top_z_base_mm=top,first_rear_height_mm=240.,
                       right_x_mm=self.ctx.tail_spec['right'],under_z_mm=self.ctx.tail_spec['under'],
                       return_radius_mm=self.ctx.tail_spec['return_radius'])
        self.tail_changes=[]
        for pin in range(1,5):
            tail=self.ctx.cam[f'pin{pin}'];start,end=tail[[0,-1]];j=pin-1;r=7.5+j
            right=self.spec['right_x_mm'];under=self.spec['under_z_mm'];R=self.spec['return_radius_mm']
            x=right+r;y=end[1]+2*R;c3=np.array([right,end[1],end[2]-r]);a3=c3+[r,0,0]
            candidate=Builder()
            points=[start,[start[0],start[1],210.-1.3*j],[start[0],-40.-1.3*j,210.-1.3*j],
                    [start[0],-40.-1.3*j,240.],[start[0],y,top+j],[x,y,top+j],[x,y,under]]
            candidate.rounded(points,7.5)
            candidate.arc([x,end[1]+R,under],[0,1,0],[0,0,-1],R,0,math.pi)
            candidate.line(candidate.end,a3)
            candidate.arc(c3,[1,0,0],[0,0,1],r,0,math.pi/2)
            candidate.line(candidate.end,end)
            old=self.tail_builders[pin]
            old_length=upper_length(np.array(old.controls),64);new_length=upper_length(np.array(candidate.controls),64)
            assert np.linalg.norm(candidate.controls[0][0]-start)<1e-10 and np.linalg.norm(candidate.end-end)<1e-10
            assert np.linalg.norm(unit(candidate.controls[0][1]-candidate.controls[0][0])-[0,0,-1])<1e-10
            assert np.linalg.norm(unit(candidate.controls[-1][-1]-candidate.controls[-1][-2])-[-1,0,0])<1e-10
            self.tail_builders[pin]=candidate;self.targets[f'CAM_{pin}']-=old_length-new_length
            self.tail_changes.append(dict(wire=f'CAM_{pin}',old_fixed_tail_numeric_mm=old_length,
                new_fixed_tail_numeric_mm=new_length,saving_mm=old_length-new_length,
                source_start_mm=start.tolist(),source_end_mm=end.tolist(),waypoints_mm=np.array(points).tolist(),
                supplier_cut_length=None))
        self.ctx.record([Path(__file__)])
