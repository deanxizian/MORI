"""Unadopted PH-side reroute, preserving J5 datums and a yaw-fixed splice reserve.

Only wires move in this study. No shortening of manufacturer hardware, print
changes, gap relaxation, or substitution of the factory SH tail is performed.
"""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *
from bounded_curve_checks import pair_threshold
from curve_self_partition import self_clear

RADIUS=.565
ERROR=.0006
def smooth(t):
    t=np.clip(t,0,1);return t*t*t*(10-15*t+6*t*t)
def window(z,a,b,c,d):
    return smooth((z-a)/(b-a))*(1-smooth((z-c)/(d-c)))
def prefix(p,z=200.):
    i=int(np.flatnonzero((p[:-1,2]<z)&(p[1:,2]>=z))[-1])
    t=(z-p[i,2])/(p[i+1,2]-p[i,2]);return clean(np.vstack([p[:i+1],p[i]+t*(p[i+1]-p[i])]))
def reroute(p,pin,inset,down,fan):
    p=np.array(p,copy=True);r=np.linalg.norm(p[:,:2],axis=1)
    inner=smooth((r-10.8)/.8)*(1-smooth((r-15)/3))*window(p[:,2],142.,144.,148.,155.)*inset
    p[:,:2]*=((r-inner)/r)[:,None]
    # Route the PH bundle below the former shared loop plane, then recover
    # through the existing neck. Preserve the actual J5 departure datum.
    p[:,2]-=window(p[:,2],136.,141.,148.,158.)*down
    p[:,0]+=(pin-2.5)*fan*window(p[:,2],132.,137.,141.,145.)
    return p
def sampled_radius(p):
    a=p[1:-1]-p[:-2];b=p[2:]-p[1:-1];c=p[2:]-p[:-2]
    cross=2*np.linalg.norm(np.cross(a,b),axis=1);prod=np.linalg.norm(a,axis=1)*np.linalg.norm(b,axis=1)*np.linalg.norm(c,axis=1)
    valid=cross>1e-13
    values=np.full(len(cross),np.inf);values[valid]=prod[valid]/cross[valid]
    i=int(np.argmin(values));return dict(radius_mm=float(values[i]),point_mm=p[i+1].tolist(),method='Three-point sampled radius only; not a continuous curvature proof')
def main():
    start=time.time();ctx=Context();attempts=[];accepted=None
    poses=[(0,0)]+[(y,p) for y in [-60,0,60] for p in [-20,0,25] if (y,p)!=(0,0)]
    variants=[(.25,1.,.2),(.35,1.4,.5),(.25,2.,.7)]
    for inset,down,fan in variants:
        name=f'i{inset:g}_d{down:g}_f{fan:g}';folder=HERE/'body_relayout_R3'/name;folder.mkdir(parents=True,exist_ok=True)
        rows=[];curves={};meta=[]
        for yaw,pitch in poses:
            paths={};packs={}
            for pin in range(1,5):
                key=f'CAM_{pin}_y{yaw}_p{pitch}';old=ctx.old[key][:ctx.joins[key]+1]
                base=prefix(old);new=reroute(base,pin,inset,down,fan)
                assert np.array_equal(new[0],base[0]) and np.array_equal(new[-1],base[-1])
                paths[pin]=new;packs[pin]=prepared(new,RADIUS,ERROR)
                curves[f'CAM_{pin}_y{yaw}_p{pitch}']=new
                meta.append(dict(pin=pin,yaw_deg=yaw,pitch_deg=pitch,length_mm=length(new),length_change_mm=length(new)-length(base),
                    proposed_splice_reference_mm=new[-1].tolist(),sampled_bend=sampled_radius(new)))
            others={n:d for n,d in ctx.refs(yaw,pitch).items() if not n.startswith('CAM_')}
            for pin,new in paths.items():
                tests=[]
                for group,targets in ctx.groups.items():
                    inverse=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,pitch if group=='pitch' else 0)))
                    bad,near=clear(transform_points(new,inverse),RADIUS,targets,error=ERROR)
                    tests.append(dict(test='native',group=group,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near))
                tests.append(dict(test='self',**self_clear(packs[pin])))
                for other in range(1,pin):tests.append(dict(test='PH_peer',other_pin=other,**pair_threshold(packs[pin],packs[other])))
                for n,d in others.items():tests.append(dict(test='retained_reference',other=n,**pair_threshold(packs[pin],d)))
                bad=[r for r in tests if r['status']!='PASS']
                rows.append(dict(pin=pin,yaw_deg=yaw,pitch_deg=pitch,status='BLOCKED' if bad else 'PASS',tests=tests))
            if any(r['status']!='PASS' for r in rows):break
        np.savez_compressed(folder/'curves.npz',**curves)
        result=dict(candidate=name,inset_mm=inset,lower_outer_loop_mm=down,fan_per_pin_mm=fan,
            status='PASS' if len(rows)==36 and all(r['status']=='PASS' for r in rows) else 'BLOCKED',
            checked_prefixes=len(rows),rows=rows,path_metadata=meta,
            length_compensation='NOT_TESTED',continuous_curvature='NOT_TESTED',material_dynamic_life='NOT_TESTED',
            actual_splices='BLOCKED',factory_SH_tail='BLOCKED',full_harness='BLOCKED')
        (folder/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');attempts.append(dict(candidate=name,status=result['status'],checked_prefixes=len(rows),first_failure=next((r for r in rows if r['status']!='PASS'),None)))
        print('BODY_RELAYOUT',name,result['status'],str(attempts[-1]['first_failure'])[:430],flush=True)
        if result['status']=='PASS':accepted=name;break
    ctx.record([Path(__file__),HERE/'materials/retrieval.json',HERE/'materials/Tensility_30_02600.pdf',HERE/'materials/JST_PH.pdf'])
    ctx.unchanged()
    (HERE/'body_relayout_R3/review.json').write_text(json.dumps(dict(status='PASS' if accepted else 'BLOCKED',revision=P['revision'],
         scope='Nine static-pose screens of PH-side AWG28 capacity prefixes to an unselected yaw-fixed splice reference at Z200; current native solids, mutual gaps, self contact and seven retained reference wires',
         sources=ctx.sources,OD_capacity_mm=2*RADIUS,required_nominal_gap_mm=.3,planned_poses=poses,
         attempts=attempts,accepted=accepted,formal_wire_and_terminals_unchanged=True,
         factory_SH_tail_and_splices='BLOCKED',constant_material_length='NOT_TESTED',continuous_material_bend='NOT_TESTED',
         main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
main()
