"""Saved M1.55 geometry and unchanged historical conductor references.

Old M1.54 PASS reports are not recertified. Every reference array retains its
receipt; new tests must check actual M1.55 solids and specify their own scope.
"""
from pathlib import Path
import functools, hashlib, json, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROJECT = ROOT.parent
OLD = Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49')
PREVIOUS = ROOT/'studies/harness_current_M1_54'
sys.path[:0] = [str(ROOT/'scripts'), str(PREVIOUS/'cc_full_reference')]
from common import bpy, np, manifold, P, PREFIX, Vector, COLS, load_collections, assembled, parts
from validate import Solid, rigidtr
from review_geometry_fingerprint import record
from route_context import RouteContext, prepared, clear, transform_points, clean, length
from mathutils.bvhtree import BVHTree

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class Context:
    refs = RouteContext.refs

    def __init__(self):
        assert Path(bpy.data.filepath).resolve() == ROOT/'mori_v1_2.blend'
        assert P['revision'] == 'V1.2-M1.55' and P['reaction_clamp_entry']['approved']
        self.sources = {}
        paths = [PROJECT/p for p in ['mechanical/mori_v1_2.blend', 'config/geometry.json',
                 'contracts/mechanical_interfaces.json', 'contracts/components.json',
                 'mechanical/reports/build_manifest.json', 'mechanical/reports/reaction_clamp_entry_validation.json',
                 'mechanical/scripts/common.py', 'mechanical/scripts/validate.py',
                 'mechanical/scripts/validate_reaction_clamp_entry.py',
                 'mechanical/scripts/review_geometry_fingerprint.py']]
        self.record(paths+[Path(__file__), PREVIOUS/'cc_full_reference/route_context.py',
                            PREVIOUS/'cam_upper_reroute/current_context.py'])
        current = json.loads(paths[5].read_text())
        assert current['status']=='PASS' and current['source_blend_sha256']==sha(paths[0])
        baseline_path=PROJECT/P['reaction_clamp_entry']['baseline']
        baseline=json.loads(baseline_path.read_text())
        self.record([baseline_path, PROJECT/P['reaction_clamp_entry']['approval']])
        bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly']
        load_collections()
        for name in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:
            COLS[name].hide_viewport=False
        assembled();bpy.context.view_layer.update()
        self.ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts()
                 if o.type=='MESH' and o.get('group') not in ['dock','coupon']}
        assert set(self.ss)==set(baseline['parts']) and len(self.ss)==201
        changed=[]
        for name,s in self.ss.items():
            actual=record(s.v,s.f.tolist())
            assert np.array_equal(np.asarray(s.o.matrix_world),baseline['parts'][name]['matrix_world'])
            if actual['exact_sha256']!=baseline['parts'][name]['geometry']['exact_sha256']:
                changed.append(name)
            if s.o.get('validation_solid_source'):
                self.record([PROJECT/s.o['validation_solid_source']])
        assert changed==['Pitch_Yoke'],changed
        assert current['scope_readback']['approved_mesh_difference_mm3']==0
        assert current['scope_readback']['changed_ids']==changed
        display=bpy.data.objects[PREFIX+'Display_PCB']
        proxy=bpy.data.objects[display['validation_proxy']]
        assert np.max(abs(np.asarray(display.matrix_world)-np.asarray(proxy.matrix_world)))<1e-5
        self.targets={n:dict(m=s.m,lo=s.lo,hi=s.hi,tree=s.bvh()) for n,s in self.ss.items()}
        self.groups={g:{n:t for n,t in self.targets.items()
                     if (self.ss[n].group if self.ss[n].group in ['yaw','pitch'] else 'body')==g}
                     for g in ['body','yaw','pitch']}

        # Retained arrays are unadopted planning references; validate exact file
        # identities against the last receipt without accepting its old geometry.
        receipt_path=PREVIOUS/'proxy_evaluation_fix/revalidation.json'
        receipt=json.loads(receipt_path.read_text())
        refpaths=[OLD/'remaining_routes/cam_side_fans/c6_join/candidate_curves.npz',
                  ROOT/'studies/harness_current_M1_53/power_yaw_compensation/mixed/candidate_curves.npz',
                  PREVIOUS/'usb_power_routes/separated_candidates.npz',
                  PREVIOUS/'cc_neck_capacity/neck_inset_candidate.npz',
                  PREVIOUS/'usb_complete_reference/final_tails.npz',
                  PREVIOUS/'usb_complete_reference/join_final_review.json',
                  PREVIOUS/'usb_compact_angle/conditional_profiles.npz']
        assert all(sha(p)==receipt['sources'][str(p)] for p in refpaths)
        self.old,self.mixed,self.upper,self.neck,self.cam=[np.load(p) for p in refpaths[:5]]
        self.joins={r['key']:r['index'] for r in json.loads(refpaths[5].read_text())['joins']}
        self.record(refpaths+[receipt_path, OLD/'curve_clearance.py', OLD/'bounded_curve_checks.py', OLD/'curve_self_partition.py'])
        profile=np.load(refpaths[6]);v,f=profile['wide_up_vertices_mm'],profile['wide_up_triangles']
        self.usb={'USB_CONDITIONAL_ALLOCATION':dict(m=manifold.Manifold(manifold.Mesh64(v,f)),lo=v.min(0),hi=v.max(0),
                  tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True))}
        self.transition=dict(status='PASS',current_revision=P['revision'],evaluated_native_parts=201,
                    changed_native_parts=changed,unchanged_native_parts=200,hardware_transforms_unchanged=True,
                    approved_mesh_difference_mm3=0.,historical_reference_arrays_unchanged=True,
                    inherited_route_PASS=False,actual_harness_material='BLOCKED',main_changed=False,
                    hardware_changed=False,manufacturing_release=False)

    def record(self,paths):
        for p in paths:self.sources[str(p)]=sha(p)

    def unchanged(self):
        assert all(sha(p)==h for p,h in self.sources.items())

if __name__=='__main__':
    ctx=Context();ctx.unchanged()
    (HERE/'context_receipt.json').write_text(json.dumps(dict(ctx.transition,sources=ctx.sources),ensure_ascii=False,indent=2)+'\n')
    ports=[]
    for name in ['Plug_motion_J5','MCU_Carrier','CAM_Mainboard','Pitch_Yoke','Body_Front','Speaker','Display_Frame']:
        if name not in ctx.ss:continue
        s=ctx.ss[name]
        ports.append(dict(id=name,lo_mm=s.lo.tolist(),hi_mm=s.hi.tolist(),world_matrix=np.asarray(s.o.matrix_world).tolist(),
                          category=s.o.get('category'),data_status=s.o.get('data_status')))
    (HERE/'current_datums.json').write_text(json.dumps(dict(revision=P['revision'],ports=ports),ensure_ascii=False,indent=2)+'\n')
    print('M1_55_HARNESS_CONTEXT_PASS',len(ctx.ss),'native parts; historical PASS not inherited',flush=True)
