"""Repair continuous-radius witnesses without changing current rigid geometry.

Original all_yaws results are retained. R2 adds per-knot curvature/speed
constraints, then uses independent polynomial certificates as a stopping
condition. Optimizer success is never used as the geometry result.
"""
from pathlib import Path
import sys,json,time,shutil
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from all_yaws import *
from inspect_candidate import continuous_radius
HERE=Path(__file__).resolve().parent

class RefinedProblem(WorstPitchProblem):
    def __init__(self,*args,extra=None,**kwargs):
        super().__init__(*args,**kwargs)
        self.dense={};self.dense_cache=None
        for name,it in self.items.items():
            edges=np.unique(it['knot'])
            ts=np.unique(np.r_[np.concatenate([np.linspace(a,b,33) for a,b in zip(edges[:-1],edges[1:])]),(extra or {}).get(name,[])])
            self.dense[name]=(basis(it['knot'],ts,1),basis(it['knot'],ts,2))

    def evaluate(self,x):
        if self.dense_cache is not None and np.array_equal(x,self.dense_cache[0]):return self.dense_cache[1:]
        r,j,stats=super().evaluate(x);controls=self.unpack(x);values=[];rr=[];cc=[];vv=[];offset=0;rad=[];speeds=[]
        def block(value,name,matrix,gradient):
            nonlocal offset
            values.append(value);rows,cols=np.nonzero((abs(matrix)>1e-15)&np.any(gradient!=0,axis=1)[:,None])
            axes=np.tile(np.arange(3),len(rows))
            rr.append(offset+np.repeat(rows,3));cc.append(self.names.index(name)*self.free*3+3*np.repeat(cols,3)+axes)
            vv.append(np.repeat(matrix[rows,cols],3)*gradient[rows].ravel());offset+=len(value)
        for name in self.names:
            d,a=self.dense[name];v=d@controls[name];acc=a@controls[name]
            k,speed,gv,ga=curvature(v,acc);pen=np.maximum(k-1/OPT_RADIUS,0)
            # Two contributions to the same curvature residual rows.
            block(2000.*pen,name,d[:,2:-2],2000.*gv*(pen>0)[:,None])
            offset-=len(pen);values.pop()
            block(2000.*pen,name,a[:,2:-2],2000.*ga*(pen>0)[:,None])
            pen=np.maximum(.5-speed,0)
            block(50.*pen,name,d[:,2:-2],-50.*v/np.maximum(speed[:,None],1e-9)*(pen>0)[:,None])
            rad.append(1/max(float(k.max()),1e-18));speeds.append(float(speed.min()))
        add=coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(offset,self.nvars)).tocsr()
        result=np.r_[r,np.concatenate(values)];jac=vstack([j,add],format='csr')
        stats=dict(stats,dense_knot_minimum_sampled_radius_mm=min(rad),dense_knot_minimum_speed=min(speeds))
        self.dense_cache=(x.copy(),result,jac,stats)
        return result,jac,stats

    def callback(self,x):
        self.iters+=1
        if self.iters%10==0:
            r,j,s=self.evaluate(x)
            print('RADIUS_REFINEMENT',self.pose[0],self.iters,float(r@r/2),{k:v for k,v in s.items() if k!='reference_length_deltas_mm'},flush=True)

def main():
    start=time.time();ctx=Context();original=HERE/'all_yaws';out=HERE/'all_yaws_R2';out.mkdir(exist_ok=True)
    oldreceipt=HERE/'all_yaws_optimization.json';receipt=json.loads(oldreceipt.read_text())
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    ctx.record([Path(__file__),HERE/'all_yaws.py',HERE/'pose_screen.py',HERE/'solve.py',HERE/'inspect_candidate.py',oldreceipt,HERE/'all_yaws_inspection.json'])
    targets=receipt['reference_prefix_lengths_mm'];results=[]
    for yaw in YAWS:
        old=original/f'y{yaw}';folder=out/f'y{yaw}';folder.mkdir(exist_ok=True)
        originalreport=json.loads((old/'inspection.json').read_text());meta=json.loads((old/'optimization.json').read_text())
        data=np.load(old/'candidate.npz');ctx.record([old/'inspection.json',old/'optimization.json',old/'candidate.npz'])
        stages=[];newmeta=dict(meta)
        if originalreport['status']=='PASS':
            shutil.copyfile(old/'candidate.npz',folder/'candidate.npz')
            newmeta.update(sources=dict(ctx.sources),reused_original_certified_candidate=True,original_inspection=str(old/'inspection.json'))
        else:
            raws,radii=raw_inputs(ctx,yaw,0)
            items={name:dict(fit(raw),control=data[name+'_controls'],knot=data[name+'_knots'],radius=radii[name]) for name,raw in raws.items()}
            x=np.concatenate([it['control'][2:-2].ravel() for it in items.values()]);lo=x-8;hi=x+8;extra={name:[] for name in items}
            for iteration in range(3):
                problem=RefinedProblem(ctx,items,420,yaw,0,targets,extra=extra);first=problem.evaluate(x)[2]
                sol=least_squares(lambda z:problem.evaluate(z)[0],x,jac=lambda z:problem.evaluate(z)[1],bounds=(lo,hi),method='trf',
                     tr_solver='lsmr',tr_options=dict(maxiter=250),max_nfev=70,ftol=1e-9,xtol=1e-9,gtol=1e-5,callback=problem.callback)
                x=sol.x;controls=problem.unpack(x);last=problem.evaluate(x)[2];bends={}
                for name,c in controls.items():
                    bends[name]=continuous_radius(BSpline(items[name]['knot'],c,3))[0]
                    for f in bends[name]['failures']:
                        if 'parameter_mm' in f:extra[name].append(f['parameter_mm'])
                        else:extra[name].extend(f['parameter_range_mm'])
                stages.append(dict(iteration=iteration,initial=first,final=last,solver_success=bool(sol.success),solver_message=sol.message,
                                   nfev=int(sol.nfev),cost=float(sol.cost),continuous_radius=bends))
                print('RADIUS_ROUND_TERMINAL',yaw,iteration,{name:b['status'] for name,b in bends.items()},flush=True)
                if all(b['status']=='PASS' for b in bends.values()):break
            arrays={name+'_controls':c for name,c in controls.items()};arrays.update({name+'_knots':items[name]['knot'] for name in items})
            np.savez_compressed(folder/'candidate.npz',**arrays)
            newmeta.update(sources=dict(ctx.sources),reused_original_certified_candidate=False,original_inspection=str(old/'inspection.json'),stages=stages)
            for name,c in controls.items():
                newmeta['wires'][name].update(final_Gauss32_length_mm=integral_length(c,items[name]['knot'],32),final_Gauss64_length_mm=integral_length(c,items[name]['knot'],64))
        newmeta.update(status='PASS',scope='Refinement execution only; native and peer certification must be repeated on the stored R2 curves',
                       main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False)
        (folder/'optimization.json').write_text(json.dumps(newmeta,ensure_ascii=False,indent=2)+'\n')
        results.append(dict(yaw_deg=yaw,pitches_deg=PITCHES,reused_original_candidate=newmeta['reused_original_certified_candidate'],
                            candidate=str((folder/'candidate.npz').relative_to(HERE)),refinement_rounds=len(stages)))
    ctx.unchanged()
    result=dict(status='PASS',scope='Execution of per-knot continuous-radius repair; independent 130-pose inspection remains required',revision=P['revision'],
                sources=ctx.sources,yaws=YAWS,pitches=PITCHES,results=results,wire_count=12,reference_prefix_lengths_mm=targets,
                main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'all_yaws_R2_optimization.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('R2_REFINEMENT_EXECUTION_TERMINAL',time.time()-start,flush=True)
if __name__=='__main__':main()
