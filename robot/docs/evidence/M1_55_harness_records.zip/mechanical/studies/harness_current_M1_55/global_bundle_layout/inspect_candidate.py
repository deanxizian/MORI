"""Independent dense native/peer checks and continuous cubic radius bounds.

This covers twelve zero-pose body/neck capacity prefixes only. It does not
approve actual mixed-material tails, source pins, restraints or assembly.
"""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parent)]
from solve import BSpline,SCIPY,REQUIRED_RADIUS
from context import *
from polyline_pair_distance import exact_pair,algorithm_checks
from bounded_curve_checks import pair_threshold
from curve_self_partition import self_clear
HERE=Path(__file__).resolve().parent

def split(c):
    a=(c[:-1]+c[1:])/2;b=(a[:-1]+a[1:])/2;d=(b[0]+b[1])/2
    return np.array([c[0],a[0],b[0],d]),np.array([d,b[1],a[2],c[3]])
def radius_bound(c):
    d=3*np.diff(c,axis=0);a=2*np.diff(d,axis=0);jerk=a[1]-a[0]
    middle=.25*d[0]+.5*d[1]+.25*d[2];acceleration=.5*(a[0]+a[1]);max_a=float(np.linalg.norm(a,axis=1).max())
    speed_lower=float(np.linalg.norm(middle)-.5*max_a-1e-9)
    speed_upper=float(np.linalg.norm(middle)+.5*max_a)
    upper=float(np.linalg.norm(np.cross(middle,acceleration))+.5*speed_upper*np.linalg.norm(jerk)+1e-11)
    sample_cross=float(np.linalg.norm(np.cross(middle,acceleration)))
    sampled=float(np.linalg.norm(middle)**3/sample_cross) if sample_cross>1e-18 else None
    return (max(0.,speed_lower)**3/upper),speed_lower,sampled
def continuous_radius(spl):
    knots=np.unique(spl.t);accepted=[];failures=[];controls=[];evaluated=0;minimum=float('inf')
    for a,b in zip(knots[:-1],knots[1:]):
        if b<=a:continue
        h=b-a;p=spl([a,b]);d=spl.derivative()([a,b])
        c=np.array([p[0],p[0]+h*d[0]/3,p[1]-h*d[1]/3,p[1]])
        for u in [.2,.5,.8]:
            q=(1-u)**3*c[0]+3*(1-u)**2*u*c[1]+3*(1-u)*u*u*c[2]+u**3*c[3]
            assert np.max(abs(q-spl(a+u*h)))<1e-9
        controls.append(c)
        todo=[(c,float(a),float(b),0)]
        while todo:
            c,lo,hi,depth=todo.pop();evaluated+=1;bound,speed,sampled=radius_bound(c)
            if sampled is not None and sampled<REQUIRED_RADIUS-1e-8:
                failures.append(dict(parameter_mm=(lo+hi)/2,radius_mm=sampled,type='analytic_point_below_requirement'));continue
            if bound>=REQUIRED_RADIUS and speed>0:
                minimum=min(minimum,bound);accepted.append([lo,hi,bound]);continue
            if depth>=16:
                failures.append(dict(parameter_range_mm=[lo,hi],bound_mm=bound,type='bound_not_certified'));continue
            l,r=split(c);mid=(lo+hi)/2
            todo.extend([(r,mid,hi,depth+1),(l,lo,mid,depth+1)])
    return dict(status='BLOCKED' if failures else 'PASS',cubic_spans=len(controls),evaluated_cells=evaluated,
                accepted_cells=len(accepted),radius_lower_mm=minimum if np.isfinite(minimum) else None,
                failures=failures,requirement_mm=REQUIRED_RADIUS,scope='Entire stored zero-pose B-spline; fixed-polynomial interval bound, no dynamic-life rating'),np.asarray(controls)

def main():
    start=time.time();ctx=Context();input_path=HERE/'input_receipt.json';inputs=json.loads(input_path.read_text())
    assert all(sha(p)==h for p,h in inputs['sources'].items())
    filename=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'candidate_300.npz'
    source=HERE/filename;data=np.load(source);rows=[];paths={};packs={};polynomials={}
    for name,meta in inputs['wires'].items():
        c=data[name+'_controls'];knot=data[name+'_knots'];spl=BSpline(knot,c,3)
        assert np.max(abs(spl(knot[0])-meta['reference_start_mm']))<1e-8
        assert np.max(abs(spl(knot[-1])-meta['reference_end_mm']))<1e-8
        bending,controls=continuous_radius(spl);polynomials[name]=controls
        edges=np.unique(knot);max_acc=float(np.linalg.norm(spl.derivative(2)(edges),axis=1).max())
        max_step=min(.04,np.sqrt(8*.00025/max(max_acc,1e-12)))
        count=int(np.ceil((edges[-1]-edges[0])/max_step))+1
        t=np.linspace(edges[0],edges[-1],count);p=spl(t)
        error=max_acc*((t[-1]-t[0])/(len(t)-1))**2/8+1e-9
        radius=float(meta['radius_mm']);bad,nearest=clear(p,radius,ctx.targets,error=error)
        pack=prepared(p,radius,error);own=self_clear(pack)
        paths[name]=p;packs[name]=pack
        rows.append(dict(wire=name,status='PASS' if not bad and own['status']=='PASS' and bending['status']=='PASS' else 'BLOCKED',
                         samples=len(p),radius_mm=radius,chord_error_bound_mm=error,sampled_length_mm=length(p),
                         native_status='PASS' if not bad else 'BLOCKED',native_hits=bad,nearest_native=nearest,
                         remote_self=own,continuous_radius=bending))
        print('INDEPENDENT_PREFIX',name,rows[-1]['status'],'native',not bad,'bend',bending['status'],'points',len(p),flush=True)
    peers=[]
    for a,b in itertools.combinations(packs,2):
        fast=pair_threshold(packs[a],packs[b]);row=dict(wires=[a,b],**fast)
        if fast['status']!='PASS':
            d=exact_pair(paths[a],paths[b]);gap=d['centreline_distance_mm']-packs[a]['radius']-packs[b]['radius']
            lower=gap-packs[a]['error']-packs[b]['error']-.0001
            row.update(status='PASS' if lower>=.3 else 'BLOCKED',gap_lower_bound_mm=lower,
                       nominal_polyline_surface_gap_mm=gap,method='Exhaustive finite-polyline minimum minus both proven chord deviations',
                       independent_minimum=d,initial_conservative_screen=fast)
        peers.append(row)
    np.savez_compressed(HERE/(Path(filename).stem+'_dense.npz'),**paths)
    np.savez_compressed(HERE/(Path(filename).stem+'_cubics.npz'),**polynomials)
    ctx.record([Path(__file__),HERE/'solve.py',HERE.parent/'polyline_pair_distance.py',source,input_path]);ctx.unchanged()
    status='PASS' if all(r['status']=='PASS' for r in rows+peers) else 'BLOCKED'
    result=dict(status=status,scope='Twelve whole body/neck capacity prefixes in zero pose; not full mixed-material harness or assembly',
        revision=P['revision'],sources=ctx.sources,wire_count=len(rows),native_parts=len(ctx.ss),poses=[[0,0]],
        rows=rows,peer_pairs=peers,reference_endpoints_fixed=True,required_gap_mm=.3,
        continuous_radius_requirement_mm=REQUIRED_RADIUS,algorithm_checks=algorithm_checks(),
        untouched_upper_tails='NOT_TESTED',other_head_poses='NOT_TESTED',constant_material_length='NOT_TESTED',
        actual_CC_source='BLOCKED',factory_SH_tail_and_splices='BLOCKED',restraints='BLOCKED',wired_assembly='BLOCKED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    target=HERE/('inspection_'+Path(filename).stem+'.json');target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('INDEPENDENT_JOINT_PREFIX_TERMINAL',status,'native failures',sum(r['native_status']!='PASS' for r in rows),
          'bend failures',sum(r['continuous_radius']['status']!='PASS' for r in rows),'peer failures',sum(r['status']!='PASS' for r in peers),flush=True)
if __name__=='__main__':main()
