"""Exact saved inspection readback, including native geometry and wire radii."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from context import *
HERE=Path(__file__).resolve().parent
ctx=Context();manifest_path=HERE/'render_manifest.json';manifest=json.loads(manifest_path.read_text())
assert manifest['status']=='PASS' and all(sha(p)==h for p,h in manifest['sources'].items())
inspection=HERE/manifest['inspection_file'];assert sha(inspection)==manifest['inspection_sha256']
def mesh_record(o):
    vertices=np.asarray([v.co[:] for v in o.data.vertices],dtype=float);o.data.calc_loop_triangles()
    triangles=np.asarray([f.vertices[:] for f in o.data.loop_triangles],dtype=int)
    return dict(geometry=record(vertices,triangles.tolist())['exact_sha256'],matrix=np.asarray(o.matrix_world).tolist())
native_expected={name:mesh_record(s.o) for name,s in ctx.ss.items()}
arrayspath=HERE/'all_yaws_R3/zero_pose_dense.npz';data=np.load(arrayspath)
paths={name:data[name].copy() for name in data.files}
ctx.record([Path(__file__),manifest_path,inspection,arrayspath]);ctx.unchanged();sources=dict(ctx.sources)
bpy.ops.wm.open_mainfile(filepath=str(inspection));bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for name in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:COLS[name].hide_viewport=False
assembled();bpy.context.view_layer.update()
native={o.name.removeprefix(PREFIX):o for o in parts() if o.type=='MESH' and o.get('group') not in ['dock','coupon']}
assert set(native)==set(native_expected)
for name,o in native.items():assert mesh_record(o)==native_expected[name],name
owner=manifest['review_owner'];rows=[]
for name in manifest['copied_native_parts']:
    o=bpy.data.objects[owner+'_'+name];assert mesh_record(o)==native_expected[name],name
    assert o['review_owner']==owner and not o['export_candidate']
for meta in manifest['wires']:
    name=meta['id'];o=bpy.data.objects[owner+'_'+name];curve=o.data;p=paths[name]
    assert o['review_owner']==owner and o['category']=='PLACEHOLDER' and o['data_status']=='ASSUMED'
    assert not o['export_candidate'] and not o['manufacturing_release'] and not o['material_selected']
    assert len(curve.splines)==1 and curve.splines[0].type=='POLY'
    actual=np.asarray([v.co[:3] for v in curve.splines[0].points],dtype=float)
    expected=np.asarray(p,dtype=np.float32).astype(float)
    assert np.array_equal(actual,expected),name
    assert curve.bevel_depth==float(np.float32(meta['radius_mm'])),name
    error=float(abs(actual-p).max());assert error<.0001,(name,error)
    rows.append(dict(wire=name,status='PASS',points=len(actual),exact_float32_points_and_radius=True,maximum_quantization_error_mm=error))
assert all(sha(p)==h for p,h in sources.items())
result=dict(status='PASS',scope='Saved inspection representation only; main native geometry preserved',sources=sources,revision=P['revision'],
            preserved_native_parts=len(native),copied_native_parts=manifest['copied_native_parts'],wires=rows,
            main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False)
(HERE/'saved_readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('JOINT_PREFIX_SAVED_READBACK_PASS',len(native),len(rows),flush=True)
