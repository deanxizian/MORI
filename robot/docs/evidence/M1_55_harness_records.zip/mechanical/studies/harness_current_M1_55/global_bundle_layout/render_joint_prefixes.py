"""Save an editable, explicitly unadopted prefix inspection with native CAD."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parent)]
from context import *
HERE=Path(__file__).resolve().parent
ctx=Context();digest=sha(ROOT/'mori_v1_2.blend');reportpath=HERE/'all_yaws_R3_inspection.json';report=json.loads(reportpath.read_text())
assert report['status']=='PASS' and all(sha(p)==h for p,h in report['sources'].items())
curvespath=HERE/'all_yaws_R3/zero_pose_dense.npz';paths=np.load(curvespath)
meta=json.loads((HERE/'all_yaws_R3/y0/optimization.json').read_text());owner='M155_JOINT_PREFIX_REVIEW'
assert not any(o.get('review_owner')==owner for o in bpy.data.objects)
scene=bpy.data.scenes.new('MORI_M1_55_JOINT_PREFIXES_UNADOPTED');bpy.context.window.scene=scene
scene['source_revision']=P['revision'];scene['main_source_sha256']=digest;scene['review_owner']=owner
scene['scope']='12 capacity prefixes to an unselected Z200 reference plane; not full wiring'
scene['candidate_status']='PASS';scene['full_harness']='BLOCKED';scene['manufacturing_release']=False
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001;scene.unit_settings.length_unit='MILLIMETERS'
scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1400;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
scene.world=bpy.data.worlds.new(owner+'_WORLD');scene.world.color=(.08,.105,.13)
collection=bpy.data.collections.new(owner);scene.collection.children.link(collection);collection['review_owner']=owner
shown=[]
for n in ['Load_Frame','Yaw_Base','Pitch_Yoke','MCU_Carrier','MCU_Motion','Power_Module','Yaw_Reaction_Link','Yaw_Anti_Lift_Keeper',
          'Yaw_Reaction_Clamp','Plug_motion_J5','Head_Yaw_Bearing','Head_Yaw_Servo']:
    if n not in ctx.ss:continue
    original=ctx.ss[n].o;o=original.copy();o.data=original.data.copy();o.parent=None;o.matrix_world=original.matrix_world.copy()
    o.name=owner+'_'+n;o.hide_render=False;o['review_owner']=owner;o['mori_owner']=owner;o['source_object']=original.name
    o['export_candidate']=False;collection.objects.link(o);shown.append(n)
wire_rows=[]
for i,(name,points) in enumerate((n,paths[n]) for n in meta['wires']):
    radius=meta['wires'][name]['radius_mm'];c=bpy.data.curves.new(owner+'_'+name,'CURVE');c.dimensions='3D';c.resolution_u=1
    c.bevel_depth=radius;c.bevel_resolution=3;s=c.splines.new('POLY');s.points.add(len(points)-1)
    s.points.foreach_set('co',np.c_[points,np.ones(len(points))].ravel())
    m=bpy.data.materials.new(owner+'_'+name+'_MAT');m.diffuse_color=(1.,.36+.025*(i%8),.035,1);c.materials.append(m)
    o=bpy.data.objects.new(owner+'_'+name,c);collection.objects.link(o)
    for k,v in dict(review_owner=owner,category='PLACEHOLDER',data_status='ASSUMED',role='routing_reference',export_candidate=False,
                    manufacturing_release=False,full_harness='BLOCKED',reference_end='UNSELECTED_Z200_SEAM',material_selected=False).items():o[k]=v
    o['source_points']=str(curvespath.relative_to(PROJECT));o['source_radius_mm']=radius
    o['model_fidelity']='Capacity prefix only; no selected terminal, splice, clamp or upper tail'
    if name.startswith('CAM_'):
        o['unselected_capacity_wire']='Tensility 30-02600';o['maximum_OD_capacity_mm']=1.13;o['OD_field_evidence']='VENDOR_DOCUMENTED'
    wire_rows.append(dict(id=name,points=len(points),radius_mm=radius,category='PLACEHOLDER',data_status='ASSUMED'))
camera_data=bpy.data.cameras.new(owner+'_CAMERA');camera=bpy.data.objects.new(camera_data.name,camera_data);scene.collection.objects.link(camera)
camera_data.type='ORTHO';camera_data.clip_start=.1;camera_data.clip_end=1200;scene.camera=camera
views=[('joint_prefix_overview',(158,-211,260),(0,-11,165),150),('joint_prefix_detail',(64,-92,189),(0,-11,157),83)]
files=[]
for name,loc,target,scale in views:
    camera.location=loc;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera_data.ortho_scale=scale
    scene.render.filepath=str(HERE/(name+'.png'));bpy.ops.render.render(write_still=True)
    files.append(dict(file=name+'.png',sha256=sha(HERE/(name+'.png'))))
camera.location=views[0][1];camera.rotation_euler=(Vector(views[0][2])-camera.location).to_track_quat('-Z','Y').to_euler();camera_data.ortho_scale=views[0][3]
ctx.record([Path(__file__),reportpath,curvespath,HERE/'all_yaws_R3/y0/optimization.json']);ctx.unchanged()
dest=HERE/'M1_55_joint_prefixes_UNADOPTED.blend';bpy.ops.wm.save_as_mainfile(filepath=str(dest),compress=True)
assert sha(ROOT/'mori_v1_2.blend')==digest
result=dict(status='PASS',scope='Editable scoped prefix inspection only; native main is preserved',sources=ctx.sources,revision=P['revision'],
            source_blend_sha256=digest,review_scene=scene.name,review_owner=owner,copied_native_parts=shown,wires=wire_rows,
            inspection_file=dest.name,inspection_sha256=sha(dest),files=files,geometry_proof=reportpath.name,
            full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False)
(HERE/'render_manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('JOINT_PREFIX_INSPECTION_RENDERED',len(shown),len(wire_rows),flush=True)
