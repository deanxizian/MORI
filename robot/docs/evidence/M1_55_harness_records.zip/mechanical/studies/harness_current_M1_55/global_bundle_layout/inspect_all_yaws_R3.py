# R3 invocation of the retained independent validator; original result files are untouched.
"""Independently certify stored prefixes at the complete 13x10 pose grid."""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from inspect_candidate import *
from pose_screen import integral_length
HERE=Path(__file__).resolve().parent
YAWS=list(range(-60,61,10));PITCHES=list(range(-20,26,5))

def main():
    started=time.time();ctx=Context();receipt_path=HERE/'all_yaws_R3_optimization.json';receipt=json.loads(receipt_path.read_text())
    assert receipt['status']=='PASS' and receipt['yaws']==YAWS and receipt['pitches']==PITCHES
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    yaw_reports=[];pose_reports=[];arrays_zero={}
    ctx.record([Path(__file__),HERE/'inspect_candidate.py',HERE/'pose_screen.py',HERE/'solve.py',receipt_path,
                HERE.parent/'polyline_pair_distance.py'])
    for yaw in YAWS:
        folder=HERE/'all_yaws_R3'/f'y{yaw}';source=folder/'candidate.npz';meta_path=folder/'optimization.json'
        data=np.load(source);meta=json.loads(meta_path.read_text());ctx.record([source,meta_path])
        assert meta['yaw_deg']==yaw and meta['pitches_deg']==PITCHES
        paths={};packs={};rows=[]
        for name,it in meta['wires'].items():
            c=data[name+'_controls'];knot=data[name+'_knots'];spl=BSpline(knot,c,3)
            assert np.max(abs(spl(knot[0])-it['reference_start_mm']))<1e-8
            assert np.max(abs(spl(knot[-1])-it['reference_end_mm']))<1e-8
            bend,controls=continuous_radius(spl);edges=np.unique(knot)
            acc=float(np.linalg.norm(spl.derivative(2)(edges),axis=1).max())
            step=min(.04,np.sqrt(8*.00025/max(acc,1e-12)));count=int(np.ceil((edges[-1]-edges[0])/step))+1
            t=np.linspace(edges[0],edges[-1],count);p=spl(t);error=acc*((t[-1]-t[0])/(count-1))**2/8+1e-9
            radius=float(it['radius_mm']);pack=prepared(p,radius,error);own=self_clear(pack)
            L64=integral_length(c,knot,64);L128=integral_length(c,knot,128)
            length_delta=L128-it['reference_length_target_mm'];quadrature_delta=abs(L128-L64)
            length_status='PASS' if abs(length_delta)<1e-4 and quadrature_delta<1e-6 else 'BLOCKED'
            rows.append(dict(wire=name,status='PASS' if bend['status']==own['status']==length_status=='PASS' else 'BLOCKED',
              samples=count,chord_error_bound_mm=error,radius_mm=radius,continuous_radius=bend,remote_self=own,
              reference_prefix_length_status=length_status,Gauss128_length_mm=L128,Gauss64_to128_difference_mm=quadrature_delta,
              reference_length_error_mm=length_delta,reference_start_mm=p[0].tolist(),reference_end_mm=p[-1].tolist()))
            paths[name]=p;packs[name]=pack
        peers=[]
        for a,b in itertools.combinations(packs,2):
            fast=pair_threshold(packs[a],packs[b]);pair=dict(wires=[a,b],**fast)
            if fast['status']!='PASS':
                exact=exact_pair(paths[a],paths[b]);gap=exact['centreline_distance_mm']-packs[a]['radius']-packs[b]['radius']
                lower=gap-packs[a]['error']-packs[b]['error']-.0001
                pair.update(status='PASS' if lower>=.3 else 'BLOCKED',gap_lower_bound_mm=lower,
                   nominal_polyline_surface_gap_mm=gap,method='Exhaustive polyline minimum minus both proven chord deviations',
                   minimum=exact,initial_conservative_screen=fast)
            peers.append(pair)
        fixed=[]
        for group in ['body','yaw']:
            tr=np.eye(4) if group=='body' else np.asarray(rigidtr(yaw,0))
            for name,p in paths.items():
                bad,near=clear(transform_points(p,np.linalg.inv(tr)),packs[name]['radius'],ctx.groups[group],error=packs[name]['error']+.0001)
                fixed.append(dict(wire=name,group=group,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near,
                    coordinates='Zero-pose native group coordinates; inverse current rigid transform'))
        for pitch in PITCHES:
            tr=np.asarray(rigidtr(yaw,pitch));pitchrows=[]
            for name,p in paths.items():
                bad,near=clear(transform_points(p,np.linalg.inv(tr)),packs[name]['radius'],ctx.groups['pitch'],error=packs[name]['error']+.0001)
                pitchrows.append(dict(wire=name,group='pitch',status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near,
                  coordinates='Zero-pose pitch group coordinates; inverse current yaw/pitch transform'))
            status='PASS' if all(r['status']=='PASS' for r in rows+peers+fixed+pitchrows) else 'BLOCKED'
            pose_reports.append(dict(yaw_deg=yaw,pitch_deg=pitch,status=status,wire_count=len(paths),
               reused_same_yaw_prefix_proofs=True,native_pitch=pitchrows))
        ystatus='PASS' if all(r['status']=='PASS' for r in rows+peers+fixed) and all(r['status']=='PASS' for r in pose_reports if r['yaw_deg']==yaw) else 'BLOCKED'
        result=dict(yaw_deg=yaw,status=ystatus,rows=rows,peer_pairs=peers,native_fixed_and_yaw=fixed,
            poses=[r for r in pose_reports if r['yaw_deg']==yaw],scope='Same stored body prefix under all ten pitch poses; no upper-tail or real terminations included')
        (folder/'inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        if yaw==0:arrays_zero=paths
        yaw_reports.append(dict(yaw_deg=yaw,status=ystatus,inspection=str((folder/'inspection.json').relative_to(HERE)),
             minimum_certified_radius_mm=min(r['continuous_radius']['radius_lower_mm'] or 0 for r in rows),
             minimum_peer_gap_lower_mm=min(r['gap_lower_bound_mm'] for r in peers),
             maximum_reference_prefix_length_error_mm=max(abs(r['reference_length_error_mm']) for r in rows)))
        print('INDEPENDENT_YAW_PREFIX',yaw,ystatus,yaw_reports[-1],flush=True)
    assert len(yaw_reports)==13 and len(pose_reports)==130
    np.savez_compressed(HERE/'all_yaws_R3/zero_pose_dense.npz',**arrays_zero)
    ctx.unchanged()
    status='PASS' if all(r['status']=='PASS' for r in pose_reports) else 'BLOCKED'
    result=dict(status=status,scope='Twelve body/neck capacity prefixes, entire stored curves, thirteen yaws and ten pitches each; not full mixed-material harness or wired assembly',
      revision=P['revision'],sources=ctx.sources,yaw_reports=yaw_reports,poses=pose_reports,native_parts=201,
      checked_wire_pose_instances=1560,peer_pairs_per_yaw=66,required_gap_mm=.3,continuous_radius_requirement_mm=REQUIRED_RADIUS,
      reference_prefix_length_tolerance_mm=1e-4,actual_CC_source='BLOCKED',factory_SH_tails_and_splices='BLOCKED',
      untouched_upper_tails='NOT_TESTED',between_pose_continuity='NOT_TESTED',physical_dynamic_life='NOT_TESTED',
      restraints='BLOCKED',wired_assembly='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
      manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'all_yaws_R3_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('THIRTEEN_YAWS_R3_INDEPENDENT_CHECK_TERMINAL',status,time.time()-started,flush=True)
if __name__=='__main__':main()
