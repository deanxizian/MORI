"""Compare new prefixes to retained unselected upper references.

These are capacity-allocation comparisons, not selected factory tail or
splice geometry. Historical native or material PASS values are not inherited.
"""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from inspect_all_yaws_R2 import *
from pose_screen import raw_inputs
HERE=Path(__file__).resolve().parent

def upper_tail(points,seam):
    # Factory-tail reference can cross Z200 again after pitch rotation. Locate
    # the corresponding prefix endpoint on the original directed polyline,
    # rather than discarding part of that tail at its last height crossing.
    u=np.diff(points,axis=0)
    t=np.clip(np.sum((seam-points[:-1])*u,axis=1)/np.maximum(np.sum(u*u,axis=1),1e-18),0,1)
    projected=points[:-1]+t[:,None]*u;distance=np.linalg.norm(projected-seam,axis=1)
    ids=np.flatnonzero(distance<1e-7);assert len(ids),(float(distance.min()),seam.tolist())
    i=int(ids[0]);tail=clean(np.vstack([projected[i],points[i+1:]]))
    while len(tail)>1 and np.linalg.norm(tail[1]-tail[0])<1e-9:tail=np.vstack([tail[0],tail[2:]])
    return tail

def main():
    start=time.time();ctx=Context();proof=HERE/'all_yaws_R3_inspection.json';receipt=json.loads(proof.read_text())
    assert receipt['status']=='PASS' and all(sha(p)==h for p,h in receipt['sources'].items())
    base=ROOT/'studies/harness_current_M1_54';bodypath=base/'cc_power_bundle/body_candidate.npz'
    neckpath=base/'cc_thin_reference/adaptive_between_candidate.npz';uppath=base/'cc_power_bundle/fixed_length_candidate.npz'
    body=np.load(bodypath)['CC_body'];necks=np.load(neckpath);uppers=np.load(uppath)
    ctx.record([Path(__file__),HERE/'inspect_all_yaws_R2.py',proof,bodypath,neckpath,uppath])
    summaries=[];failures=[];zero_arrays={};checked=0;missing_upper=set()
    for yaw in YAWS:
        folder=HERE/'all_yaws_R3'/f'y{yaw}';data=np.load(folder/'candidate.npz');meta=json.loads((folder/'optimization.json').read_text())
        ctx.record([folder/'candidate.npz',folder/'optimization.json',folder/'inspection.json'])
        prefixes={};cpacks={};tangents={}
        for name,it in meta['wires'].items():
            spl=BSpline(data[name+'_knots'],data[name+'_controls'],3);end=float(data[name+'_knots'][-1])
            t=np.linspace(0,end,int(np.ceil(end/.025))+1);p=spl(t)
            max_a=float(np.linalg.norm(spl.derivative(2)(np.unique(spl.t)),axis=1).max());error=max_a*(t[1]-t[0])**2/8+1e-9
            prefixes[name]=p;cpacks[name]=prepared(p,it['radius_mm'],error);tangents[name]=spl.derivative()(end)
        for pitch in PITCHES:
            refs=ctx.refs(yaw,pitch);tails={name:dict(p=upper_tail(r['p'],prefixes[name][-1]),radius=r['radius'],error=r['error']) for name,r in refs.items()}
            neck=necks[f'CC_y{yaw}'];up=uppers[f'CC_y{yaw}_p{pitch}']
            assert np.linalg.norm(body[-1]-neck[0])<1e-8 and np.linalg.norm(neck[-1]-up[0])<1e-8
            cc=clean(np.vstack([body,neck[1:],up[1:]]));tails['CC_allocation']=dict(p=upper_tail(cc,prefixes['CC_allocation'][-1]),radius=.3683,error=.0006)
            rows=[];joins=[]
            for name,tail in tails.items():
                assert np.linalg.norm(prefixes[name][-1]-tail['p'][0])<1e-5,(yaw,pitch,name)
                if len(tail['p'])<2:
                    angle=None;missing_upper.add(name)
                else:
                    v=tail['p'][1]-tail['p'][0];a=tangents[name]
                    angle=float(np.degrees(np.arccos(np.clip(a@v/np.linalg.norm(a)/np.linalg.norm(v),-1,1))))
                joins.append(dict(wire=name,endpoint_error_mm=float(np.linalg.norm(prefixes[name][-1]-tail['p'][0])),
                                  nominal_tangent_angle_deg=angle,upper_radius_mm=tail['radius'],
                                  stored_upper_segment_available=len(tail['p'])>=2,
                                  physical_splice='BLOCKED',upper_continuous_curvature='NOT_TESTED'))
            for name,pack in cpacks.items():
                for other,tail in tails.items():
                    if name==other:continue # own material join requires a full mixed-radius self audit
                    if len(tail['p'])<2:continue # reference stops at Z200; no invented upper segment
                    otherpack=prepared(tail['p'],tail['radius'],tail['error']);fast=pair_threshold(pack,otherpack)
                    row=dict(prefix=name,upper=other,**fast);checked+=1
                    if fast['status']!='PASS':
                        exact=exact_pair(prefixes[name],tail['p']);gap=exact['centreline_distance_mm']-pack['radius']-tail['radius']
                        lower=gap-pack['error']-tail['error']-.0001
                        row.update(status='PASS' if lower>=.3 else 'BLOCKED',gap_lower_bound_mm=lower,
                                   nominal_polyline_surface_gap_mm=gap,minimum=exact,initial_conservative_screen=fast)
                        if row['status']!='PASS':failures.append(dict(yaw_deg=yaw,pitch_deg=pitch,**row))
                    rows.append(row)
            summaries.append(dict(yaw_deg=yaw,pitch_deg=pitch,status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
                                  directed_prefix_to_other_upper_checks=len(rows),minimum_gap_lower_mm=min(r['gap_lower_bound_mm'] for r in rows),
                                  joins=joins,failed_pairs=[r for r in rows if r['status']!='PASS']))
            if yaw==pitch==0:zero_arrays={**{name+'_prefix':p for name,p in prefixes.items()},**{name+'_upper':r['p'] for name,r in tails.items()}}
        print('UPPER_REFERENCE_SEAM_YAW',yaw,len([r for r in summaries[-10:] if r['status']!='PASS']),flush=True)
    np.savez_compressed(HERE/'upper_seam_zero_pose.npz',**zero_arrays);ctx.unchanged()
    status='PASS' if not failures else 'BLOCKED'
    result=dict(status=status,scope='New capacity prefixes against other retained upper allocation tails in 130 static poses only',
                sources=ctx.sources,revision=P['revision'],poses=summaries,confirmed_failed_pairs=failures,directed_pair_checks=checked,
                missing_upper_reference_segments=sorted(missing_upper),complete_upper_coverage='BLOCKED' if missing_upper else 'PASS',
                required_gap_mm=.3,all_reference_joins_identical=True,old_native_PASS_inherited=False,
                upper_native_clearance='NOT_TESTED',full_mixed_radius_self='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
                material_splices='BLOCKED',restraints='BLOCKED',between_pose_continuity='NOT_TESTED',full_harness='BLOCKED',
                main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'upper_seam_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('UPPER_REFERENCE_SEAM_TERMINAL',status,checked,'checks',len(failures),'confirmed failed pairs',time.time()-start,flush=True)
if __name__=='__main__':main()
