"""Joint zero-pose capacity layout; optimizer convergence is NOT fit proof.

Twelve unadopted reference conductors move together. Native geometry and all
reference endpoints remain fixed. H06 keeps AWG28/PH002 plus factory SH tail;
the thick PH-side endpoint remains an unselected splice allocation. CC source
and other unselected terminations remain allocations, not actual pin models.
"""
from pathlib import Path
import sys,json,time,itertools,hashlib
HERE=Path(__file__).resolve().parent
SCIPY=Path('/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
sys.path[:0]=[str(HERE.parent),str(SCIPY)]
from context import *
HERE=Path(__file__).resolve().parent # the imported context has its own study directory
import scipy
from scipy.interpolate import BSpline
from scipy.spatial import cKDTree
from scipy.optimize import least_squares
from scipy.sparse import coo_matrix

NCV=48
REQUIRED_RADIUS=6.865
OPT_RADIUS=7.25
OPT_GAP=.42

def prefix(p,z=200.):
    hits=np.flatnonzero((p[:-1,2]<z)&(p[1:,2]>=z))
    assert len(hits)>0
    i=int(hits[-1]);t=(z-p[i,2])/(p[i+1,2]-p[i,2])
    return clean(np.vstack([p[:i+1],p[i]+t*(p[i+1]-p[i])]))

def basis(knot,ts,derivative=0):
    spl=BSpline(knot,np.eye(NCV),3)
    if derivative:spl=spl.derivative(derivative)
    return spl(ts)

def fit(raw):
    s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(raw,axis=0),axis=1))];L=s[-1]
    knot=np.r_[np.zeros(4),np.linspace(0,L,NCV-2)[1:-1],np.full(4,L)]
    assert len(knot)==NCV+4
    t=np.linspace(0,L,1600);p=np.c_[*[np.interp(t,s,raw[:,i]) for i in range(3)]]
    b=basis(knot,t);c=np.zeros((NCV,3))
    u=raw[1]-raw[0];u/=np.linalg.norm(u);v=raw[-1]-raw[-2];v/=np.linalg.norm(v)
    h=L/(NCV-3)
    c[0]=raw[0];c[1]=raw[0]+u*h/3;c[-1]=raw[-1];c[-2]=raw[-1]-v*h/3
    fixed=[0,1,NCV-2,NCV-1];free=np.arange(2,NCV-2)
    c[free]=np.linalg.lstsq(b[:,free],p-b[:,fixed]@c[fixed],rcond=None)[0]
    return dict(knot=knot,control=c,target_length=float(L),raw=raw,
                initial_fit_sample_error_mm=float(np.max(np.linalg.norm(b@c-p,axis=1))))

def curvature(v,a):
    speed=np.linalg.norm(v,axis=1);cross=np.cross(v,a);cn=np.linalg.norm(cross,axis=1)
    ss=np.maximum(speed,1e-9);safe=np.maximum(cn,1e-12)
    k=cn/ss**3
    gv=np.cross(a,cross)/safe[:,None]/ss[:,None]**3-3*k[:,None]*v/ss[:,None]**2
    ga=np.cross(cross,v)/safe[:,None]/ss[:,None]**3
    return k,speed,gv,ga

def algorithm_checks():
    v=np.array([[1.2,.4,.2]]);a=np.array([[.3,.5,-.1]])
    k,s,gv,ga=curvature(v,a);maximum=0.
    for which,g in [('v',gv),('a',ga)]:
        for axis in range(3):
            dv=np.zeros_like(v);da=np.zeros_like(a)
            (dv if which=='v' else da)[0,axis]=1e-5
            numerical=(curvature(v+dv,a+da)[0][0]-curvature(v-dv,a-da)[0][0])/2e-5
            maximum=max(maximum,abs(numerical-g[0,axis]))
    assert maximum<1e-8,maximum
    return dict(status='PASS',scope='Analytic curvature gradient versus central differences only',
                max_absolute_error=maximum,finite_difference_step=1e-5)

class Problem:
    def __init__(self,ctx,items,n):
        self.ctx=ctx;self.items=items;self.names=list(items);self.n=n;self.free=NCV-4
        self.nvars=len(items)*self.free*3;self.ts={};self.B={};self.D={};self.A={};self.reference={}
        for name,it in items.items():
            t=np.linspace(0,it['knot'][-1],n);self.ts[name]=t
            self.B[name]=basis(it['knot'],t);self.D[name]=basis(it['knot'],t,1);self.A[name]=basis(it['knot'],t,2)
            self.reference[name]=self.B[name]@it['control']
        self.last=None;self.calls=0;self.iters=0;self.started=time.time()

    def unpack(self,x):
        result={}
        for i,name in enumerate(self.names):
            c=self.items[name]['control'].copy();c[2:-2]=x[i*self.free*3:(i+1)*self.free*3].reshape(-1,3)
            result[name]=c
        return result

    @staticmethod
    def inside(t,p):
        # A nearest TRIANGLE normal is not the signed-distance pseudonormal
        # at a concave edge. Confirm negative search signs using ray parity.
        # This remains a search field: final checks use solid containment.
        length=float(np.linalg.norm(t['hi']-t['lo']))+2.
        results=[]
        for raw in [[1.,.371,.529],[.219,1.,.613]]:
            direction=Vector(raw).normalized();origin=Vector(p);remaining=length;hits=0
            for _ in range(64):
                location,normal,index,distance=t['tree'].ray_cast(origin,direction,remaining)
                if location is None:break
                hits+=1;travel=float(distance)+.0001
                origin=location+direction*.0001;remaining-=travel
                if remaining<=0:break
            else:
                raise RuntimeError('Ray parity exceeded 64 hits; search field cannot classify this solid')
            results.append(hits%2==1)
        if results[0]!=results[1]:
            probe=manifold.Manifold.sphere(.005,12).translate(p.tolist())
            return (probe^t['m']).volume()>probe.volume()/2
        return results[0]

    def native(self,p,radii):
        limit=radii+OPT_GAP
        distance=np.full(len(p),1e6);gradient=np.zeros_like(p)
        for name,t in self.ctx.targets.items():
            ids=np.flatnonzero(np.all(p>=t['lo']-limit[:,None],axis=1)&np.all(p<=t['hi']+limit[:,None],axis=1))
            for i in ids:
                nearest,normal,index,dist=t['tree'].find_nearest(Vector(p[i]))
                delta=p[i]-np.asarray(nearest)
                negative_hint=delta@np.asarray(normal)<0
                # Check parity where the old field could report penetration
                # or at any close surface. Far exterior unsigned distances
                # need no active gradient in this approximate search field.
                check_inside=(negative_hint or float(np.linalg.norm(delta))<limit[i]) and np.all(p[i]>=t['lo']) and np.all(p[i]<=t['hi'])
                sign=-1. if check_inside and self.inside(t,p[i]) else 1.
                signed=sign*float(np.linalg.norm(delta))
                if signed<distance[i]:
                    distance[i]=signed
                    gradient[i]=sign*delta/max(float(np.linalg.norm(delta)),1e-9)
        return distance,gradient

    def evaluate(self,x):
        if self.last is not None and np.array_equal(x,self.last[0]):return self.last[1:]
        c=self.unpack(x);paths={name:self.B[name]@c[name] for name in self.names}
        residual=[];rr=[];cc=[];vv=[];offset=0;stats={};self.calls+=1
        def block(values,terms):
            nonlocal offset
            values=np.asarray(values,dtype=float).ravel();residual.append(values)
            for name,w,g in terms:
                g=np.asarray(g);mask=np.any(g!=0,axis=1)
                rows,cols=np.nonzero((abs(w)>1e-15)&mask[:,None])
                if not len(rows):continue
                axis=np.tile(np.arange(3),len(rows))
                rr.append(offset+np.repeat(rows,3))
                cc.append(self.names.index(name)*self.free*3+np.repeat(cols,3)*3+axis)
                vv.append(np.repeat(w[rows,cols],3)*g[rows].ravel())
            offset+=len(values)
        allpoints=np.vstack([paths[name] for name in self.names])
        rad=np.concatenate([np.full(self.n,self.items[name]['radius']) for name in self.names])
        dist,grad=self.native(allpoints,rad)
        stats['minimum_sampled_native_gap_mm']=float(np.min(dist-rad))
        for i,name in enumerate(self.names):
            sl=slice(i*self.n,(i+1)*self.n);pen=np.maximum(rad[sl]+OPT_GAP-dist[sl],0)
            g=-20.*grad[sl]*(pen>0)[:,None]
            block(20.*pen,[(name,self.B[name][:,2:-2],g)])
        bend=[];speedvalues=[]
        for name in self.names:
            v=self.D[name]@c[name];a=self.A[name]@c[name]
            k,speed,gv,ga=curvature(v,a);pen=np.maximum(k-1/OPT_RADIUS,0)
            block(300.*pen,[(name,self.D[name][:,2:-2],300.*gv*(pen>0)[:,None]),
                             (name,self.A[name][:,2:-2],300.*ga*(pen>0)[:,None])])
            pen_speed=np.maximum(.5-speed,0)
            block(10.*pen_speed,[(name,self.D[name][:,2:-2],-10.*v/np.maximum(speed[:,None],1e-9)*(pen_speed>0)[:,None])])
            bend.append(float(np.max(k)));speedvalues.append(float(speed.min()))
        stats['minimum_sampled_radius_mm']=1/max(bend) if max(bend)>0 else None
        stats['minimum_sampled_speed']=min(speedvalues)
        pairmin=[]
        for left,right in itertools.combinations(self.names,2):
            p,q=paths[left],paths[right];tree=cKDTree(q);_,nearest=tree.query(p)
            options=[]
            for j in [np.clip(nearest-1,0,len(q)-2),np.clip(nearest,0,len(q)-2)]:
                u=q[j+1]-q[j];t=np.clip(np.sum((p-q[j])*u,axis=1)/np.maximum(np.sum(u*u,axis=1),1e-18),0,1)
                delta=p-(q[j]+t[:,None]*u);d=np.linalg.norm(delta,axis=1)
                options.append((d,delta,j,t))
            choose=options[1][0]<options[0][0]
            d=np.where(choose,options[1][0],options[0][0]);delta=np.where(choose[:,None],options[1][1],options[0][1])
            j=np.where(choose,options[1][2],options[0][2]);t=np.where(choose,options[1][3],options[0][3])
            gap=d-self.items[left]['radius']-self.items[right]['radius'];pairmin.append(float(gap.min()))
            pen=np.maximum(OPT_GAP-gap,0);g=-20.*delta/np.maximum(d[:,None],1e-9)*(pen>0)[:,None]
            w=(1-t)[:,None]*self.B[right][j,2:-2]+t[:,None]*self.B[right][j+1,2:-2]
            block(20.*pen,[(left,self.B[left][:,2:-2],g),(right,w,-g)])
        stats['minimum_sampled_peer_gap_mm']=min(pairmin)
        selfmin=[]
        for name in self.names:
            p=paths[name];s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
            delta=p[:,None,:]-p[None,:,:];d=np.linalg.norm(delta,axis=2)
            eligible=abs(s[:,None]-s[None,:])>5.
            masked=np.where(eligible,d,np.inf);j=np.argmin(masked,axis=1)
            delta=p-p[j];distance=masked[np.arange(len(p)),j];gap=distance-2*self.items[name]['radius']
            selfmin.append(float(gap.min()));pen=np.maximum(OPT_GAP-gap,0)
            g=-20.*delta/np.maximum(distance[:,None],1e-9)*(pen>0)[:,None]
            block(20.*pen,[(name,self.B[name][:,2:-2],g),(name,self.B[name][j,2:-2],-g)])
            # Small reference/length penalties choose a nearby topology. They
            # do not certify actual total cut length or force hardware to move.
            delta=p-self.reference[name]
            for axis in range(3):
                g=np.zeros_like(p);g[:,axis]=.01
                block(.01*delta[:,axis],[(name,self.B[name][:,2:-2],g)])
            seg=np.diff(p,axis=0);seglen=np.linalg.norm(seg,axis=1);L=float(seglen.sum())
            Lgrad=np.diff(self.B[name][:,2:-2],axis=0).T@(seg/np.maximum(seglen[:,None],1e-9))
            residual.append(np.array([.01*(L-self.items[name]['target_length'])]))
            nz=np.nonzero(abs(Lgrad.ravel())>1e-15)[0]
            rr.append(np.full(len(nz),offset));cc.append(self.names.index(name)*self.free*3+nz);vv.append(.01*Lgrad.ravel()[nz]);offset+=1
        stats['minimum_sampled_remote_self_gap_mm']=min(selfmin)
        r=np.concatenate(residual);assert len(r)==offset and np.isfinite(r).all()
        jac=coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(offset,self.nvars)).tocsr()
        self.last=(x.copy(),r,jac,stats)
        return r,jac,stats

    def callback(self,x):
        self.iters+=1;r,j,stats=self.evaluate(x)
        if self.iters%5==0:
            print('JOINT_ITERATION',self.n,self.iters,'cost',float(r@r/2),stats,'seconds',round(time.time()-self.started,2),flush=True)
            arrays={name+'_controls':c for name,c in self.unpack(x).items()}
            arrays.update({name+'_knots':self.items[name]['knot'] for name in self.names})
            np.savez_compressed(HERE/'checkpoint.npz',**arrays)
            (HERE/'progress.json').write_text(json.dumps(dict(status='BLOCKED',scope='Live optimizer checkpoint; not independently validated',
                 samples_per_wire=self.n,iteration=self.iters,cost=float(r@r/2),stats=stats,
                 main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False),indent=2)+'\n')

def main():
    started=time.time();ctx=Context();checks=algorithm_checks();raws={};radii={}
    for name,d in ctx.refs(0,0).items():
        raw=d['p']
        if name.startswith('CAM_'):raw=ctx.old[f'{name}_y0_p0'][:ctx.joins[f'{name}_y0_p0']+1]
        raws[name]=prefix(raw);radii[name]=.565 if name.startswith('CAM_') else float(d['radius'])
    ccbase=ROOT/'studies/harness_current_M1_54/cc_power_bundle'
    body=np.load(ccbase/'body_candidate.npz')['CC_body']
    ccpath=ccbase.parent/'cc_thin_reference/adaptive_between_candidate.npz'
    neck=np.load(ccpath)['CC_y0']
    assert np.linalg.norm(body[-1]-neck[0])<1e-8
    # The separately stored cubic certificate covers only Z144..174. The
    # original neck reference continues to Z206; do not bridge that interval
    # with an invented straight segment or omit it from the layout inputs.
    raws['CC_allocation']=prefix(clean(np.vstack([body,neck[1:]])));radii['CC_allocation']=.3683
    assert len(raws)==12
    items={name:dict(fit(raw),radius=radii[name]) for name,raw in raws.items()}
    ctx.record([Path(__file__),ccbase/'body_candidate.npz',ccpath,
                HERE.parent/'materials/source_facts.json',HERE.parent/'materials/Tensility_30_02600.pdf'])
    baseline={name:dict(reference_start_mm=raw[0].tolist(),reference_end_mm=raw[-1].tolist(),radius_mm=radii[name],
          target_reference_length_mm=items[name]['target_length'],initial_fit_sample_error_mm=items[name]['initial_fit_sample_error_mm'],
          endpoint_evidence='ASSUMED_REFERENCE_DATUM; J5 read-only native reference, CC source not selected',material_selected=False)
          for name,raw in raws.items()}
    (HERE/'input_receipt.json').write_text(json.dumps(dict(status='PASS',scope='Current source receipt and optimization inputs only',sources=ctx.sources,
         revision=P['revision'],native_parts=len(ctx.ss),wires=baseline,SciPy=scipy.__version__,NumPy=np.__version__,
         controls_per_wire=NCV,required_radius_mm=REQUIRED_RADIUS,optimization_radius_mm=OPT_RADIUS,
         formal_H06_AWG28_PH002_unchanged=True,splices_and_factory_SH_tail='BLOCKED',main_changed=False,hardware_changed=False,
         manufacturing_release=False,algorithm_checks=checks),ensure_ascii=False,indent=2)+'\n')
    x=np.concatenate([it['control'][2:-2].ravel() for it in items.values()]);lower=x-15.;upper=x+15.;stages=[]
    np.savez_compressed(HERE/'baseline_prefixes.npz',**raws)
    for n,maxeval in [(160,70),(300,70)]:
        problem=Problem(ctx,items,n);initial=problem.evaluate(x)[2]
        print('JOINT_START',n,initial,flush=True)
        sol=least_squares(lambda a:problem.evaluate(a)[0],x,jac=lambda a:problem.evaluate(a)[1],bounds=(lower,upper),
                         method='trf',tr_solver='lsmr',tr_options=dict(maxiter=150),max_nfev=maxeval,
                         ftol=1e-7,xtol=1e-7,gtol=1e-5,callback=problem.callback,verbose=0)
        x=sol.x;final=problem.evaluate(x)[2]
        stages.append(dict(samples_per_wire=n,initial=initial,final=final,solver_success=bool(sol.success),
                           solver_status=int(sol.status),message=sol.message,nfev=int(sol.nfev),cost=float(sol.cost)))
        ctrl=problem.unpack(x)
        arrays={name+'_controls':v for name,v in ctrl.items()};arrays.update({name+'_knots':items[name]['knot'] for name in items})
        np.savez_compressed(HERE/f'candidate_{n}.npz',**arrays)
        print('JOINT_STAGE_FINISHED',n,final,sol.message,flush=True)
    ctx.unchanged()
    (HERE/'optimization.json').write_text(json.dumps(dict(status='PASS',scope='Optimizer execution only; independent dense/continuous checks required',
        sources=ctx.sources,revision=P['revision'],wire_count=12,native_parts=len(ctx.ss),stages=stages,
        candidate_file='candidate_300.npz',reference_endpoints_fixed=True,main_changed=False,hardware_changed=False,
        factory_SH_tail='BLOCKED',CC_source='BLOCKED',continuous_curvature='NOT_TESTED',
        constant_material_length='NOT_TESTED',wired_assembly='BLOCKED',full_harness='BLOCKED',
        manufacturing_release=False,elapsed_s=time.time()-started),ensure_ascii=False,indent=2)+'\n')
    print('JOINT_ZERO_POSE_SOLVER_TERMINAL',time.time()-started,flush=True)

if __name__=='__main__':main()
