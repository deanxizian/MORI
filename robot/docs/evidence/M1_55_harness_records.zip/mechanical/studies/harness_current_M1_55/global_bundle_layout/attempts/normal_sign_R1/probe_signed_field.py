"""Check suspicious optimizer signs against actual solid intersection."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from solve import *
HERE=Path(__file__).resolve().parent
ctx=Context();saved=np.load(HERE/'baseline_prefixes.npz');rows=[]
for name in saved.files:
    p=saved[name];s=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(p,axis=0),axis=1))]
    sample=np.c_[*[np.interp(np.linspace(0,s[-1],160),s,p[:,i]) for i in range(3)]]
    radius=.565 if name.startswith('CAM_') else (.3683 if name=='CC_allocation' else ctx.refs(0,0)[name]['radius'])
    worst=None
    for obj,t in ctx.targets.items():
        ids=np.flatnonzero(np.all(sample>=t['lo']-(radius+.42),axis=1)&np.all(sample<=t['hi']+(radius+.42),axis=1))
        for i in ids:
            nearest,normal,index,d=t['tree'].find_nearest(Vector(sample[i]));delta=sample[i]-np.asarray(nearest)
            signed=(-1. if delta@np.asarray(normal)<0 else 1.)*float(np.linalg.norm(delta))
            if worst is None or signed<worst['estimated_signed_distance_mm']:
                worst=dict(wire=name,object=obj,sample_index=int(i),point_mm=sample[i].tolist(),nearest_mm=list(nearest),
                           face_normal=list(normal),estimated_signed_distance_mm=signed)
    point=worst['point_mm'];probe=manifold.Manifold.sphere(.005,12).translate(point)
    fraction=(probe^ctx.targets[worst['object']]['m']).volume()/probe.volume()
    worst['actual_probe_intersection_fraction']=fraction
    worst['inside_probe']=fraction>.5
    worst['sign_agrees_with_probe']=(worst['estimated_signed_distance_mm']<0)==(fraction>.5)
    rows.append(worst);print('SIGNED_FIELD_PROBE',name,worst['object'],round(worst['estimated_signed_distance_mm'],4),fraction,flush=True)
ctx.record([Path(__file__),HERE/'solve.py',HERE/'baseline_prefixes.npz']);ctx.unchanged()
(HERE/'signed_field_probe.json').write_text(json.dumps(dict(status='PASS',scope='Diagnostic signs and actual 0.005mm solid-probe intersections only; not route clearance',
    sources=ctx.sources,rows=rows,search_field_sign_failures=sum(not r['sign_agrees_with_probe'] for r in rows),
    main_changed=False,hardware_changed=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
