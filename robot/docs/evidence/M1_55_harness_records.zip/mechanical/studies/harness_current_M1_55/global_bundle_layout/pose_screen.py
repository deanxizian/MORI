"""Joint capacity layout at eight combined-motion corner/edge poses.

Reference endpoints and rigid geometry follow the current project's motion
convention. A common reference prefix length is an allocation, not a supplier
cut dimension. Full mixed-material tails and physical restraints stay open.
"""
from pathlib import Path
import sys,json,time,types
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from solve import *
from scipy.sparse import vstack
HERE=Path(__file__).resolve().parent

def length_quadrature(knot,order=32):
    edges=np.unique(knot);u,w=np.polynomial.legendre.leggauss(order)
    t=np.concatenate([(a+b)/2+(b-a)*u/2 for a,b in zip(edges[:-1],edges[1:])])
    weights=np.concatenate([(b-a)*w/2 for a,b in zip(edges[:-1],edges[1:])])
    return basis(knot,t,1),weights
def integral_length(c,knot,order=32):
    d,w=length_quadrature(knot,order);v=d@c
    return float(w@np.linalg.norm(v,axis=1))
def raw_inputs(ctx,yaw,pitch):
    raws={};radii={}
    for name,d in ctx.refs(yaw,pitch).items():
        raw=d['p']
        if name.startswith('CAM_'):raw=ctx.old[f'{name}_y{yaw}_p{pitch}'][:ctx.joins[f'{name}_y{yaw}_p{pitch}']+1]
        raws[name]=prefix(raw);radii[name]=.565 if name.startswith('CAM_') else float(d['radius'])
    ccbase=ROOT/'studies/harness_current_M1_54/cc_power_bundle'
    body=np.load(ccbase/'body_candidate.npz')['CC_body']
    neck=np.load(ccbase.parent/'cc_thin_reference/adaptive_between_candidate.npz')[f'CC_y{yaw}']
    assert np.linalg.norm(body[-1]-neck[0])<1e-8
    raws['CC_allocation']=prefix(clean(np.vstack([body,neck[1:]])));radii['CC_allocation']=.3683
    return raws,radii

class PoseProblem(Problem):
    def __init__(self,ctx,items,n,yaw,pitch,targets):
        super().__init__(ctx,items,n)
        self.realctx=ctx;self.pose=(yaw,pitch);self.length_targets=targets;self.extra_cache=None
        self.transforms={g:np.eye(4) if g=='body' else np.asarray(rigidtr(yaw,pitch if g=='pitch' else 0))
                         for g in ctx.groups}
        self.length_matrices={name:length_quadrature(it['knot']) for name,it in items.items()}

    def native(self,p,radii):
        distance=np.full(len(p),1e6);gradient=np.zeros_like(p)
        try:
            for group,targets in self.realctx.groups.items():
                tr=self.transforms[group];inverse=np.linalg.inv(tr)
                local=transform_points(p,inverse)
                self.ctx=types.SimpleNamespace(targets=targets)
                d,g=Problem.native(self,local,radii)
                use=d<distance;distance[use]=d[use];gradient[use]=(g@tr[:3,:3].T)[use]
        finally:self.ctx=self.realctx
        return distance,gradient

    def evaluate(self,x):
        if self.extra_cache is not None and np.array_equal(x,self.extra_cache[0]):return self.extra_cache[1:]
        r,j,stats=Problem.evaluate(self,x);c=self.unpack(x);values=[];rr=[];cc=[];vv=[];deltas={}
        for i,name in enumerate(self.names):
            d,w=self.length_matrices[name];v=d@c[name];speed=np.linalg.norm(v,axis=1)
            actual=float(w@speed);delta=actual-self.length_targets[name];deltas[name]=delta
            values.append(20.*delta)
            grad=d[:,2:-2].T@((w/np.maximum(speed,1e-9))[:,None]*v)
            nz=np.flatnonzero(abs(grad.ravel())>1e-15)
            rr.append(np.full(len(nz),i));cc.append(i*self.free*3+nz);vv.append(20.*grad.ravel()[nz])
        add=coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(len(self.names),self.nvars)).tocsr()
        result=np.r_[r,values];jac=vstack([j,add],format='csr')
        stats=dict(stats,maximum_reference_length_error_mm=max(abs(v) for v in deltas.values()),reference_length_deltas_mm=deltas)
        self.extra_cache=(x.copy(),result,jac,stats)
        return result,jac,stats

    def callback(self,x):
        self.iters+=1;r,j,stats=self.evaluate(x)
        if self.iters%10==0:
            print('POSE_ITERATION',self.pose,self.n,self.iters,float(r@r/2),{k:v for k,v in stats.items() if k!='reference_length_deltas_mm'},flush=True)

def main():
    start=time.time();ctx=Context();base_inputs=HERE/'input_receipt.json';inputs=json.loads(base_inputs.read_text())
    zero=np.load(HERE/'candidate_300.npz');baseline=np.load(HERE/'baseline_prefixes.npz')
    targets={name:integral_length(zero[name+'_controls'],zero[name+'_knots'],64) for name in inputs['wires']}
    initialfit={name:fit(baseline[name]) for name in inputs['wires']}
    poses=[(-60,-20),(-60,0),(-60,25),(0,-20),(0,25),(60,-20),(60,0),(60,25)]
    out=HERE/'poses';out.mkdir(exist_ok=True);results=[]
    ctx.record([Path(__file__),HERE/'solve.py',HERE/'candidate_300.npz',HERE/'baseline_prefixes.npz',base_inputs,
                ROOT/'studies/harness_current_M1_54/cc_power_bundle/body_candidate.npz',
                ROOT/'studies/harness_current_M1_54/cc_thin_reference/adaptive_between_candidate.npz'])
    for yaw,pitch in poses:
        folder=out/f'y{yaw}_p{pitch}';folder.mkdir(exist_ok=True)
        raws,radii=raw_inputs(ctx,yaw,pitch);items={}
        for name,raw in raws.items():
            own=fit(raw);control=zero[name+'_controls']+own['control']-initialfit[name]['control']
            control[[0,1,-2,-1]]=own['control'][[0,1,-2,-1]]
            items[name]=dict(own,control=control,radius=radii[name])
        x=np.concatenate([it['control'][2:-2].ravel() for it in items.values()]);lo=x-18;hi=x+18;stages=[]
        for n,maxeval in [(180,70),(340,70)]:
            problem=PoseProblem(ctx,items,n,yaw,pitch,targets);first=problem.evaluate(x)[2]
            sol=least_squares(lambda z:problem.evaluate(z)[0],x,jac=lambda z:problem.evaluate(z)[1],bounds=(lo,hi),method='trf',
                             tr_solver='lsmr',tr_options=dict(maxiter=200),max_nfev=maxeval,ftol=1e-8,xtol=1e-8,gtol=1e-5,
                             callback=problem.callback,verbose=0)
            x=sol.x;last=problem.evaluate(x)[2]
            stages.append(dict(samples_per_wire=n,initial=first,final=last,nfev=int(sol.nfev),cost=float(sol.cost),
                               solver_success=bool(sol.success),solver_message=sol.message))
        controls=problem.unpack(x);arrays={name+'_controls':c for name,c in controls.items()}
        arrays.update({name+'_knots':items[name]['knot'] for name in items})
        np.savez_compressed(folder/'candidate.npz',**arrays)
        receipt=dict(status='PASS',scope='Optimizer execution only; not independent motion/fit proof',sources=ctx.sources,
          revision=P['revision'],yaw_deg=yaw,pitch_deg=pitch,wires={name:dict(reference_start_mm=raws[name][0].tolist(),
          reference_end_mm=raws[name][-1].tolist(),radius_mm=radii[name],reference_length_target_mm=targets[name],
          final_Gauss32_length_mm=integral_length(controls[name],items[name]['knot'],32),
          final_Gauss64_length_mm=integral_length(controls[name],items[name]['knot'],64),endpoint_evidence='ASSUMED_REFERENCE_DATUM') for name in items},
          stages=stages,reference_endpoints_fixed=True,actual_CC_source='BLOCKED',factory_SH_tails='BLOCKED',
          main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False)
        (folder/'optimization.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
        results.append(dict(yaw_deg=yaw,pitch_deg=pitch,final=last,candidate=str((folder/'candidate.npz').relative_to(HERE))))
        print('POSE_SOLVER_TERMINAL',yaw,pitch,{k:v for k,v in last.items() if k!='reference_length_deltas_mm'},flush=True)
    ctx.unchanged()
    (HERE/'pose_optimization.json').write_text(json.dumps(dict(status='PASS',scope='Eight posed capacity-prefix optimizer runs only; independent checks and between-pose behavior unresolved',
         revision=P['revision'],sources=ctx.sources,poses=results,wire_count=12,reference_prefix_lengths_mm=targets,
         main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
    print('EIGHT_POSE_SOLVER_EXECUTION_TERMINAL',time.time()-start,flush=True)
if __name__=='__main__':main()
