# M1.55 共同排线前段 R3（未采用）

12条身体/颈部容量前段，130个静态组合姿态通过当前原生实体、线间距、
整段连续弯曲及数值参考长度检查。前段到原路线Z200参考点；不是实际接头设计。
最小实体间隙下界 0.347622 mm。主模型与原生硬件保持。

原生201件、8个展示副本、12条曲线保存回读通过。独立检查文件：
`M1_55_joint_prefixes_UNADOPTED.blend`；所有橙色线路为 PLACEHOLDER / ASSUMED。
正式H06保持AWG28/PH002/PHR-4及厂配SH尾线，不替换终端，也未定裁线长度。

可用上段的跨线接续检查已执行 10,010 次，结果 PASS；0 个确认未通过配对。没有上段线段的保留参考：P_J9_1, P_J9_2, P_J9_3, SPK_reservation_3, SPK_reservation_6。
尚未验证完整上段实体/转弯、自线接续、任意中间姿态、实际材料长度、夹持和带线装配。
实发SCS0009舵盘与微雪FPC/FFC按用户要求到货核对。manufacturing_release=false。

## 复现

Blender 5.2.2 LTS d13f752e3b9c；内置Python3.13.13/NumPy2.3.4；
SciPy1.16.2独立装在 `/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313`，
未写入Blender.app或原项目运行时。安装实际命令与日志在 commands.json。

从当前工作树根目录，以如下前缀运行各脚本（完整顺序/日志见commands.json）：

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend --python mechanical/studies/harness_current_M1_55/global_bundle_layout/solve.py
```

执行 solve → inspect_candidate → pose_screen → all_yaws → inspect_all_yaws →
all_yaws_refined → inspect_all_yaws_R2 → polish_reference_length → inspect_all_yaws_R3。
几何PASS来自最后独立检查，不来自优化器success。R1、R2和搜索场失败保留。
最后执行check_upper_seams、render_joint_prefixes、verify_joint_saved，直接查看图像，
再运行本publisher与verify_delivery；不能据此下制造单。
