"""Verify final research hashes, main/hardware preservation and local links."""
from pathlib import Path
import datetime,hashlib,json,re
from urllib.parse import urlsplit,unquote
from urllib.request import Request,urlopen
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3];ROOT=PROJECT/'mechanical'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
delivery=read(HERE/'delivery.json');assert delivery['status']=='PASS' and delivery['full_harness']=='BLOCKED'
assert delivery['prefix_geometry']=='PASS' and delivery['prefix_static_poses']==130
assert sha(ROOT/'mori_v1_2.blend')==delivery['source_blend_sha256']
assert all((HERE/p).is_file() and sha(HERE/p)==h for p,h in delivery['files'].items())
for name in ['all_yaws_R3_inspection.json','render_manifest.json','saved_readback.json','upper_seam_inspection.json']:
    r=read(HERE/name);assert r['status']=='PASS'
    assert all(sha(p)==h for p,h in r['sources'].items())
visual=read(HERE/'visual_review.json');render=read(HERE/'render_manifest.json')
assert visual['status']=='PASS' and visual['files']==render['files']
assert all(sha(HERE/r['file'])==r['sha256'] for r in visual['files'])
baseline=read(ROOT/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in baseline['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
assert all((PROJECT/n).is_file() and sha(PROJECT/n)==h for n,h in protected.items())
links=[]
for link in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(link)
    if parsed.scheme or not parsed.path:continue
    target=(HERE/unquote(parsed.path)).resolve();assert target.is_file() and target.is_relative_to(PROJECT),link
    url='http://127.0.0.1:58202/'+str(target.relative_to(PROJECT))
    with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
    links.append(str(target.relative_to(PROJECT)))
result=dict(status='PASS',scope='Research publication, hash and preservation verification only',
 recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',delivery_sha256=sha(HERE/'delivery.json'),
 checked_delivery_files=len(delivery['files']),checked_local_links=links,protected_hardware_files=len(protected),
 current_main_unchanged=True,main_source_sha256=delivery['source_blend_sha256'],hardware_unchanged=True,
 final_images_directly_reviewed=True,full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('JOINT_PREFIX_PUBLICATION_VERIFIED',len(delivery['files']),len(links),len(protected),flush=True)
