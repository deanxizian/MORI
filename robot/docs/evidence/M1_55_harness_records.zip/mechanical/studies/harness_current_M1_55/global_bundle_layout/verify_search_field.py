"""Compare ray parity with actual native solid probes at representative points."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from solve import *
HERE=Path(__file__).resolve().parent
ctx=Context();old=HERE/'attempts/normal_sign_R1/signed_field_probe.json';report=json.loads(old.read_text())
points=[(r['object'],np.array(r['point_mm']),'previous_suspicious_reference') for r in report['rows']]
for name in ['Head_Rear','Yaw_Base','Yaw_Reaction_Link','Pitch_Yoke','Load_Frame','MCU_Carrier','Power_Module']:
    s=ctx.ss[name];tri=s.v[s.f.astype(int)];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
    areas=np.linalg.norm(cross,axis=1);i=int(np.argmax(areas));normal=cross[i]/areas[i];center=tri[i].mean(0)
    for sign in [-1,1]:points.append((name,center+sign*.05*normal,'largest_face_offset_'+str(sign)))
rows=[]
for name,point,kind in points:
    t=ctx.targets[name];parity=Problem.inside(t,point)
    probe=manifold.Manifold.sphere(.005,12).translate(point.tolist())
    fraction=(probe^t['m']).volume()/probe.volume();inside=fraction>.5
    assert abs(fraction-.5)>.1,(name,point,fraction)
    rows.append(dict(object=name,point_mm=point.tolist(),case=kind,ray_parity_inside=bool(parity),
                     solid_probe_inside=inside,probe_volume_fraction=fraction,status='PASS' if parity==inside else 'FAIL'))
assert all(r['status']=='PASS' for r in rows),[r for r in rows if r['status']!='PASS']
ctx.record([Path(__file__),HERE/'solve.py',old]);ctx.unchanged()
(HERE/'search_field_check.json').write_text(json.dumps(dict(status='PASS',scope='Twenty-six representative point classifications, not full signed-distance or route qualification',
    sources=ctx.sources,points=len(rows),rows=rows,probe_radius_mm=.005,
    earlier_false_signed_distance_cases=report['search_field_sign_failures'],native_parts_unchanged=201,
    main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('RAY_PARITY_VS_NATIVE_PROBE_PASS',len(rows),'points',flush=True)
