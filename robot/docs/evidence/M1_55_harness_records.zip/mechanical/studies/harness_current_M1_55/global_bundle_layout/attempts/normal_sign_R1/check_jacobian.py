"""Check the sparse optimizer derivative on a synthetic two-curve case.

This tests curvature, peer, reference and length residuals with an analytic
plane field. It does not test real native geometry or qualify any route.
"""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from solve import np,fit,Problem,algorithm_checks,scipy

t=np.linspace(0,1.85*np.pi,1200)
p=np.c_[6*np.cos(t),6*np.sin(t),150.+.31*t]
q=p+[.21,.13,.87]
items={'test_a':dict(fit(p),radius=.565),'test_b':dict(fit(q),radius=.565)}
class Dummy:
    targets={}
problem=Problem(Dummy(),items,16)
def plane_field(points,radii):
    gradient=np.zeros_like(points);gradient[:,2]=1
    return points[:,2]-150.6,gradient
problem.native=plane_field
x=np.concatenate([row['control'][2:-2].ravel() for row in items.values()])
values,jac,stats=problem.evaluate(x);analytic=jac.toarray();maximum=0.;relative=0.
for i in range(len(x)):
    shift=np.zeros_like(x);shift[i]=1e-5
    numerical=(problem.evaluate(x+shift)[0]-problem.evaluate(x-shift)[0])/2e-5
    delta=abs(numerical-analytic[:,i]);maximum=max(maximum,float(delta.max()))
    relative=max(relative,float(np.max(delta/np.maximum(1.,abs(numerical)))))
assert relative<2e-6,(relative,maximum)
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),HERE/'solve.py']}
(HERE/'jacobian_check.json').write_text(json.dumps(dict(status='PASS',scope='Synthetic two-curve sparse derivative only; not native geometry or route fit',
    sources=sources,SciPy=scipy.__version__,variables=len(x),residuals=len(values),central_difference_step=1e-5,
    maximum_absolute_difference=maximum,maximum_scaled_difference=relative,curvature_check=algorithm_checks(),
    native_field='Synthetic analytic plane',main_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')
print('JOINT_SPARSE_JACOBIAN_PASS',len(x),len(values),maximum,relative,flush=True)
