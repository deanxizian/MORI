"""One common-length prefix layout per yaw, constrained by all ten pitches."""
from pathlib import Path
import sys,json,time,types
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from pose_screen import *
HERE=Path(__file__).resolve().parent
PITCHES=list(range(-20,26,5))
YAWS=list(range(-60,61,10))

class WorstPitchProblem(PoseProblem):
    def native(self,p,radii):
        distance=np.full(len(p),1e6);gradient=np.zeros_like(p)
        groups=[('body',0),('yaw',0)]+[('pitch',pitch) for pitch in PITCHES]
        try:
            for group,pitch in groups:
                targets=self.realctx.groups[group]
                tr=np.eye(4) if group=='body' else np.asarray(rigidtr(self.pose[0],pitch if group=='pitch' else 0))
                local=transform_points(p,np.linalg.inv(tr));self.ctx=types.SimpleNamespace(targets=targets)
                d,g=Problem.native(self,local,radii);use=d<distance
                distance[use]=d[use];gradient[use]=(g@tr[:3,:3].T)[use]
        finally:self.ctx=self.realctx
        return distance,gradient

def main():
    start=time.time();ctx=Context();zero=np.load(HERE/'candidate_300.npz');baseline=np.load(HERE/'baseline_prefixes.npz')
    inputs=json.loads((HERE/'input_receipt.json').read_text())
    targets={name:integral_length(zero[name+'_controls'],zero[name+'_knots'],64) for name in inputs['wires']}
    initialfit={name:fit(baseline[name]) for name in inputs['wires']}
    out=HERE/'all_yaws';out.mkdir(exist_ok=True);results=[]
    ctx.record([Path(__file__),HERE/'pose_screen.py',HERE/'solve.py',HERE/'candidate_300.npz',HERE/'baseline_prefixes.npz',HERE/'input_receipt.json',
        ROOT/'studies/harness_current_M1_54/cc_power_bundle/body_candidate.npz',ROOT/'studies/harness_current_M1_54/cc_thin_reference/adaptive_between_candidate.npz'])
    for yaw in YAWS:
        folder=out/f'y{yaw}';folder.mkdir(exist_ok=True)
        raws,radii=raw_inputs(ctx,yaw,0)
        for pitch in PITCHES:
            compared,_=raw_inputs(ctx,yaw,pitch)
            assert all(np.array_equal(compared[name],raw) for name,raw in raws.items()),(yaw,pitch,'body-prefix reference depends on pitch')
        items={}
        for name,raw in raws.items():
            own=fit(raw);control=zero[name+'_controls']+own['control']-initialfit[name]['control']
            control[[0,1,-2,-1]]=own['control'][[0,1,-2,-1]]
            items[name]=dict(own,control=control,radius=radii[name])
        x=np.concatenate([it['control'][2:-2].ravel() for it in items.values()]);lo=x-18;hi=x+18;stages=[]
        for n,maxeval in [(220,70),(420,70)]:
            problem=WorstPitchProblem(ctx,items,n,yaw,0,targets);first=problem.evaluate(x)[2]
            sol=least_squares(lambda z:problem.evaluate(z)[0],x,jac=lambda z:problem.evaluate(z)[1],bounds=(lo,hi),method='trf',
                 tr_solver='lsmr',tr_options=dict(maxiter=200),max_nfev=maxeval,ftol=1e-8,xtol=1e-8,gtol=1e-5,callback=problem.callback)
            x=sol.x;last=problem.evaluate(x)[2]
            stages.append(dict(samples_per_wire=n,initial=first,final=last,nfev=int(sol.nfev),cost=float(sol.cost),
                          solver_success=bool(sol.success),solver_message=sol.message))
        controls=problem.unpack(x);arrays={name+'_controls':c for name,c in controls.items()}
        arrays.update({name+'_knots':items[name]['knot'] for name in items})
        np.savez_compressed(folder/'candidate.npz',**arrays)
        receipt=dict(status='PASS',scope='Optimizer execution against all ten pitch allocations only; independent checks required',sources=ctx.sources,
            revision=P['revision'],yaw_deg=yaw,pitches_deg=PITCHES,body_prefixes_yaw_only_verified=True,
            wires={name:dict(reference_start_mm=raws[name][0].tolist(),reference_end_mm=raws[name][-1].tolist(),radius_mm=radii[name],
               reference_length_target_mm=targets[name],final_Gauss32_length_mm=integral_length(controls[name],items[name]['knot'],32),
               final_Gauss64_length_mm=integral_length(controls[name],items[name]['knot'],64),endpoint_evidence='ASSUMED_REFERENCE_DATUM') for name in items},
            stages=stages,reference_endpoints_fixed=True,actual_CC_source='BLOCKED',factory_SH_tails='BLOCKED',
            main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False)
        (folder/'optimization.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
        results.append(dict(yaw_deg=yaw,pitches_deg=PITCHES,final=last,candidate=str((folder/'candidate.npz').relative_to(HERE))))
        print('ALL_PITCHES_YAW_TERMINAL',yaw,{k:v for k,v in last.items() if k!='reference_length_deltas_mm'},flush=True)
    ctx.unchanged()
    (HERE/'all_yaws_optimization.json').write_text(json.dumps(dict(status='PASS',scope='Thirteen joint prefix layouts optimized against130 static poses, not independent fit proof or a between-pose physical family',
      revision=P['revision'],sources=ctx.sources,yaws=YAWS,pitches=PITCHES,results=results,wire_count=12,
      reference_prefix_lengths_mm=targets,main_changed=False,hardware_changed=False,full_harness='BLOCKED',
      manufacturing_release=False,elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
    print('THIRTEEN_YAWS_SOLVER_EXECUTION_TERMINAL',time.time()-start,flush=True)
if __name__=='__main__':main()
