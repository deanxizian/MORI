"""Publish the latest scoped capacity evidence and preserved failed attempts."""
from pathlib import Path
import datetime,hashlib,html,json
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3];ROOT=PROJECT/'mechanical'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
proof=read(HERE/'all_yaws_R3_inspection.json');render=read(HERE/'render_manifest.json');saved=read(HERE/'saved_readback.json')
visual=read(HERE/'visual_review.json');upper=read(HERE/'upper_seam_inspection.json')
assert proof['status']==render['status']==saved['status']==visual['status']=='PASS'
digest=sha(ROOT/'mori_v1_2.blend');assert render['source_blend_sha256']==digest
assert all(sha(p)==h for r in [proof,render,saved,upper] for p,h in r['sources'].items())
assert render['files']==visual['files'] and all(sha(HERE/r['file'])==r['sha256'] for r in visual['files'])
assert len(proof['poses'])==130 and proof['checked_wire_pose_instances']==1560 and saved['preserved_native_parts']==201
yaws=[];native=[]
for row in proof['yaw_reports']:
    report=read(HERE/row['inspection']);assert report['status']=='PASS'
    yaws.append(row)
    for item in report['native_fixed_and_yaw']+[i for pose in report['poses'] for i in pose['native_pitch']]:
        if item['nearest']:native.append(item['nearest']['gap_lower_bound_mm'])
minimum_native=min(native);max_length=max(r['maximum_reference_prefix_length_error_mm'] for r in yaws)
minimum_bend=min(r['minimum_certified_radius_mm'] for r in yaws)
old=read(HERE/'all_yaws_inspection.json');r2=read(HERE/'all_yaws_R2_inspection.json')
old_failed=sum(r['status']!='PASS' for r in old['yaw_reports']);r2_failed=sum(r['status']!='PASS' for r in r2['yaw_reports'])
missing=', '.join(upper['missing_upper_reference_segments']) or '无'
failures=upper['confirmed_failed_pairs']
upper_text=(f'可用上段的跨线接续检查已执行 {upper["directed_pair_checks"]:,} 次，结果 {upper["status"]}；'
            f'{len(failures)} 个确认未通过配对。没有上段线段的保留参考：{missing}。')
table=''.join(f'<tr><td>{r["yaw_deg"]}°</td><td>−20°～+25° / 10档</td><td>12</td><td>PASS</td><td><a href="{r["inspection"]}">逐项原始报告</a></td></tr>' for r in yaws)
page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 共同排线前段 R3</title>
<style>body{{max-width:1120px;margin:38px auto;padding:0 20px 70px;font:16px/1.75 system-ui;color:#253944;background:#f5f8fa}}a{{color:#146b87}}img{{width:100%;height:auto}}figure{{margin:28px 0}}table{{border-collapse:collapse;width:100%;background:white}}td,th{{text-align:left;padding:10px;border-bottom:1px solid #d9e1e5}}.notice{{padding:18px;background:#fff1d5;border-left:4px solid #bd7f26}}.pass{{color:#196547}}code{{font-size:.9em}}.scroll{{overflow:auto}}</style>
<h1>M1.55 · 共同排线前段 R3</h1><p><strong class="pass">前段的130个静态组合姿态：PASS</strong> · 完整线束：BLOCKED · 尚未采用到主模型</p>
<p class="notice">橙色是12条未定料的容量参考，只到原路线的 Z200 参考接续位置。真实端子、接头、固定夹持和完整上段没有因此定型。这里的长度一致是数值参考，不是厂家裁线尺寸，也不是随动寿命或带线装配放行。</p>
<p><a href="M1_55_joint_prefixes_UNADOPTED.blend">可编辑 Blender 检查模型</a> · <a href="../../../mori_v1_2.blend">M1.55 主模型</a> · <a href="../../reaction_clamp_R2_adoption/index.html">R2 已采用记录</a> · <a href="../index.html">早期失败候选与线材来源</a></p>
<h2>本轮完成</h2><p>共同调整身体余量圈和颈部前段，接口参考点、201件原生实体及硬件位姿保持。13档偏航（−60°～+60°、每10°）分别检查10档俯仰（−20°～+25°、每5°），覆盖1,560个线条/姿态实例。每档偏航另检查66个线间配对、每条整段连续三次曲线的转弯和远端自接近。</p>
<div class="scroll"><table><tr><th>项目</th><th>本轮证据</th><th>适用边界</th></tr>
<tr><td>对原生实体的表面间隙下界</td><td>最小 {minimum_native:.4f} mm；目标≥0.3 mm</td><td>包含整段曲线的离散偏差、步长和数值预留；独立实体检查，不继承优化器判定</td></tr>
<tr><td>线间距 / 远端自接近</td><td>所有前段通过0.3 mm目标</td><td>仅本次容量半径，不包含实际压接/保护套/夹持件</td></tr>
<tr><td>连续弯曲半径</td><td>整段区间下界≥{proof["continuous_radius_requirement_mm"]:.3f} mm</td><td>保守容量目标来自未选定的线材参考；未证明反复运动寿命</td></tr>
<tr><td>前段参考长度</td><td>各姿态与同一数值目标的差值&lt;0.0001 mm</td><td>不等于完整混合线材的材料坐标或实际裁线公差</td></tr>
<tr><td>保存文件回读</td><td>201件原生件、{len(saved["copied_native_parts"])}件展示副本、12条曲线：PASS</td><td>逐点/逐半径核对精确float32表示，主模型未修改</td></tr></table></div>
<figure><img src="joint_prefix_overview.png" alt="M1.55原生结构与12条橙色未采用前段参考"><figcaption>当前主体、PCB和开放颈部。为看清路线，只显示8件原生结构副本；独立几何检查包含当前全部201件实体。头部顶部和身体底部在近景之外。</figcaption></figure>
<figure><img src="joint_prefix_detail.png" alt="身体余量圈与颈部入口局部"><figcaption>零位的共同排线容量候选。原生实体没有移动、缩放或为线路增开孔；橙色线材尚未选定，也没有实际夹持约束。</figcaption></figure>
<h2>130个姿态覆盖</h2><div class="scroll"><table><tr><th>偏航</th><th>俯仰</th><th>线条</th><th>本轮范围</th><th>证据</th></tr>{table}</table></div>
<p><a href="all_yaws_R3_inspection.json">完整独立报告</a> · <a href="saved_readback.json">保存回读</a> · <a href="visual_review.json">图像检查范围</a></p>
<h2>上段接续正在闭合</h2><p>{html.escape(upper_text)}</p>
<p>原相机尾线参考会在部分俯仰姿态再次穿过Z200，已改为沿原有有向路线定位对应连接点，保留后续整条尾线；没有按最后一次高度交点截掉它。缺失上段保持缺失，不以直线补齐。现有上段参考仍需重新完成实体、连续转弯、同线接续与材料长度检查。</p>
<p><a href="upper_seam_inspection.json">接续检查、缺失上段及未通过配对</a></p>
<h2>已保留的失败与修正</h2><p>旧的24个独立四芯变体仍按零位失败保存。新共同排线的初始零位整段候选通过，但加上全偏航的公共长度约束后，R1有{old_failed}档偏航的连续转弯未通过。R2修正短促弯折后仍有{r2_failed}档的数值长度误差过大；R3继续修正，重新对存盘曲线执行全部130个姿态检查才得到当前前段PASS。</p>
<p>搜索阶段的最近三角面法线曾把凹边附近外部点误判为内部；保留失败结果，并用真实实体探针定位。搜索场只是求解辅助，最终间隙用原生实体独立检查。上段脚本的初次异常日志也保留，没有把Blender进程退出0当成检查通过。</p>
<p><a href="attempts/normal_sign_R1/archive_receipt.json">搜索误判保留记录</a> · <a href="search_field_check.json">26个代表点实体对照</a> · <a href="refined_derivative_check.json">新增约束导数复核</a> · <a href="all_yaws_inspection.json">R1未通过报告</a> · <a href="all_yaws_R2_inspection.json">R2未通过报告</a></p>
<h2>仍未完成</h2><ul><li>完整上段、PH与厂配SH尾线的实际接续、真实端子/插头、固定点、应力释放及逐根穿线。</li><li>姿态之间的连续随动、完整混合线材材料长度、后装供电线、带线装入与闭壳。</li><li>喇叭已有150mm原线及插头；配对件仍等针数/针距/标记。SCS0009实发舵盘与微雪FPC/FFC按用户决定到货后核对。</li><li>PA12开放处强度、压接与插合、动态寿命和电气验证。</li></ul>
<p>正式H06保持AWG28、PH002/PHR-4和厂配SH尾线。未改为PH004/AWG30，没有供应商发送、采购、提交或推送。</p>
<p><a href="README.md">复现与边界</a> · <a href="commands.json">实际命令/日志</a> · <a href="delivery.json">本页交付哈希</a> · <a href="../../../index.html?revision=V1.2-M1.55">机械主页</a></p><p>PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
(HERE/'index.html').write_text(page)
(HERE/'README.md').write_text(f'''# M1.55 共同排线前段 R3（未采用）

12条身体/颈部容量前段，130个静态组合姿态通过当前原生实体、线间距、
整段连续弯曲及数值参考长度检查。前段到原路线Z200参考点；不是实际接头设计。
最小实体间隙下界 {minimum_native:.6f} mm。主模型与原生硬件保持。

原生201件、8个展示副本、12条曲线保存回读通过。独立检查文件：
`M1_55_joint_prefixes_UNADOPTED.blend`；所有橙色线路为 PLACEHOLDER / ASSUMED。
正式H06保持AWG28/PH002/PHR-4及厂配SH尾线，不替换终端，也未定裁线长度。

{upper_text}
尚未验证完整上段实体/转弯、自线接续、任意中间姿态、实际材料长度、夹持和带线装配。
实发SCS0009舵盘与微雪FPC/FFC按用户要求到货核对。manufacturing_release=false。

## 复现

Blender 5.2.2 LTS d13f752e3b9c；内置Python3.13.13/NumPy2.3.4；
SciPy1.16.2独立装在 `/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313`，
未写入Blender.app或原项目运行时。安装实际命令与日志在 commands.json。

从当前工作树根目录，以如下前缀运行各脚本（完整顺序/日志见commands.json）：

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend --python mechanical/studies/harness_current_M1_55/global_bundle_layout/solve.py
```

执行 solve → inspect_candidate → pose_screen → all_yaws → inspect_all_yaws →
all_yaws_refined → inspect_all_yaws_R2 → polish_reference_length → inspect_all_yaws_R3。
几何PASS来自最后独立检查，不来自优化器success。R1、R2和搜索场失败保留。
最后执行check_upper_seams、render_joint_prefixes、verify_joint_saved，直接查看图像，
再运行本publisher与verify_delivery；不能据此下制造单。
''')
names=['solve','check_jacobian','probe_signed_field','verify_search_field','inspect_candidate_300','pose_screen',
       'all_yaws','inspect_all_yaws','all_yaws_refined','check_refined_derivative','inspect_all_yaws_R2',
       'polish_reference_length','inspect_all_yaws_R3','check_upper_seams','render_joint_prefixes','verify_joint_saved']
rows=[]
for name in names:
    script='inspect_candidate.py' if name=='inspect_candidate_300' else name+'.py';log=HERE/(name+'.log')
    assert log.is_file() and 'Traceback (most recent call last)' not in log.read_text(),name
    rows.append(dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','mechanical/mori_v1_2.blend','--python',str((HERE/script).relative_to(PROJECT))],
                     cwd=str(PROJECT),log=log.name,log_sha256=sha(log),execution='PASS',scope='Command execution only; each report retains its own fit scope'))
commands=dict(status='PASS',Blender='5.2.2 LTS d13f752e3b9c',Python='3.13.13',NumPy='2.3.4',SciPy='1.16.2',commands=rows,
 dependency_install_command=['/Users/dean/.local/bin/uv','pip','install','--python','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',
 '--target','/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313','--no-deps','--only-binary',':all:','--index-url','https://pypi.org/simple','scipy==1.16.2'],
 dependency_install_log='dependency_install.log',failed_initial_logs=[p.name for p in sorted(HERE.glob('*failure.log'))],
 old_bad_search_archive='attempts/normal_sign_R1/archive_receipt.json',main_changed=False,hardware_changed=False)
(HERE/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
files=[p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.blend1'
       and p.name not in ['delivery.json','publication_verification.json','publish_joint_study.log','verify_delivery.log']]
delivery=dict(status='PASS',scope='Scoped research publication only, not full harness or physical qualification',
 published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',source_blend_sha256=digest,
 prefix_geometry='PASS',prefix_static_poses=130,wire_pose_instances=1560,native_parts=201,minimum_native_gap_lower_mm=minimum_native,
 maximum_reference_prefix_length_error_mm=max_length,minimum_certified_bend_radius_mm=minimum_bend,
 upper_reference_seam_status=upper['status'],missing_upper_references=upper['missing_upper_reference_segments'],
 actual_material_selected=False,main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False,
 files={str(p.relative_to(HERE)):sha(p) for p in sorted(files)})
(HERE/'delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
print('JOINT_PREFIX_RESEARCH_PUBLISHED',len(files),minimum_native,upper['status'],flush=True)
