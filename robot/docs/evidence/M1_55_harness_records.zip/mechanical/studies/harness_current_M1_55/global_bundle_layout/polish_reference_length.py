"""Preserve R2 results and polish its zero-yaw allocation length residual."""
from pathlib import Path
import sys,json,time,shutil
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from all_yaws_refined import *
HERE=Path(__file__).resolve().parent

class LengthPolishProblem(RefinedProblem):
    def evaluate(self,x):
        if getattr(self,'polish_cache',None) is not None and np.array_equal(x,self.polish_cache[0]):return self.polish_cache[1:]
        r,j,s=super().evaluate(x);controls=self.unpack(x);values=[];rr=[];cc=[];vv=[]
        for i,name in enumerate(self.names):
            d,w=self.length_matrices[name];v=d@controls[name];speed=np.linalg.norm(v,axis=1)
            delta=float(w@speed)-self.length_targets[name];values.append(1000.*delta)
            grad=d[:,2:-2].T@((w/np.maximum(speed,1e-9))[:,None]*v)
            nz=np.flatnonzero(abs(grad.ravel())>1e-15)
            rr.append(np.full(len(nz),i));cc.append(i*self.free*3+nz);vv.append(1000.*grad.ravel()[nz])
        add=coo_matrix((np.concatenate(vv),(np.concatenate(rr),np.concatenate(cc))),shape=(len(self.names),self.nvars)).tocsr()
        result=np.r_[r,values];jac=vstack([j,add],format='csr');self.polish_cache=(x.copy(),result,jac,s)
        return result,jac,s

def main():
    start=time.time();ctx=Context();old=HERE/'all_yaws_R2';out=HERE/'all_yaws_R3';out.mkdir(exist_ok=True)
    rp=HERE/'all_yaws_R2_optimization.json';receipt=json.loads(rp.read_text())
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    ctx.record([Path(__file__),rp,HERE/'all_yaws_refined.py',HERE/'all_yaws.py',HERE/'pose_screen.py',HERE/'solve.py',HERE/'inspect_candidate.py'])
    results=[];targets=receipt['reference_prefix_lengths_mm']
    for yaw in YAWS:
        before=old/f'y{yaw}';folder=out/f'y{yaw}';folder.mkdir(exist_ok=True)
        ctx.record([before/'candidate.npz',before/'optimization.json'])
        meta=json.loads((before/'optimization.json').read_text());newmeta=dict(meta)
        stages=[]
        if yaw!=0:
            shutil.copyfile(before/'candidate.npz',folder/'candidate.npz')
        else:
            data=np.load(before/'candidate.npz');raws,radii=raw_inputs(ctx,0,0)
            items={name:dict(fit(raw),control=data[name+'_controls'],knot=data[name+'_knots'],radius=radii[name]) for name,raw in raws.items()}
            x=np.concatenate([it['control'][2:-2].ravel() for it in items.values()]);lo=x-2.;hi=x+2.
            problem=LengthPolishProblem(ctx,items,420,0,0,targets);first=problem.evaluate(x)[2]
            sol=least_squares(lambda z:problem.evaluate(z)[0],x,jac=lambda z:problem.evaluate(z)[1],bounds=(lo,hi),method='trf',tr_solver='lsmr',
                  tr_options=dict(maxiter=300),max_nfev=100,ftol=1e-9,xtol=1e-9,gtol=1e-5,callback=problem.callback)
            controls=problem.unpack(sol.x);last=problem.evaluate(sol.x)[2]
            stages.append(dict(initial=first,final=last,nfev=int(sol.nfev),cost=float(sol.cost),solver_success=bool(sol.success),solver_message=sol.message))
            arrays={name+'_controls':c for name,c in controls.items()};arrays.update({name+'_knots':items[name]['knot'] for name in items})
            np.savez_compressed(folder/'candidate.npz',**arrays)
            for name,c in controls.items():newmeta['wires'][name].update(final_Gauss32_length_mm=integral_length(c,items[name]['knot'],32),final_Gauss64_length_mm=integral_length(c,items[name]['knot'],64))
            print('ZERO_PREFIX_LENGTH_POLISH_TERMINAL',{k:v for k,v in last.items() if k!='reference_length_deltas_mm'},flush=True)
        newmeta.update(status='PASS',sources=dict(ctx.sources),scope='Reference-length polish execution only; independent native/peer/radius inspection must follow',
                       reused_R2_candidate=yaw!=0,R3_polish_stages=stages,main_changed=False,hardware_changed=False,full_harness='BLOCKED')
        (folder/'optimization.json').write_text(json.dumps(newmeta,ensure_ascii=False,indent=2)+'\n')
        results.append(dict(yaw_deg=yaw,pitches_deg=PITCHES,candidate=str((folder/'candidate.npz').relative_to(HERE)),reused_R2_candidate=yaw!=0))
    ctx.unchanged()
    result=dict(status='PASS',scope='Execution only; independent 130-pose geometry certification remains required',sources=ctx.sources,
                revision=P['revision'],yaws=YAWS,pitches=PITCHES,results=results,wire_count=12,reference_prefix_lengths_mm=targets,
                main_changed=False,hardware_changed=False,full_harness='BLOCKED',manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'all_yaws_R3_optimization.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('R3_LENGTH_POLISH_EXECUTION_TERMINAL',time.time()-start,flush=True)
if __name__=='__main__':main()
