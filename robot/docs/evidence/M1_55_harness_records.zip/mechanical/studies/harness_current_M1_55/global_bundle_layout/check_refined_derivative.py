"""Directional finite-difference check for added dense-knot residuals."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from all_yaws_refined import *
HERE=Path(__file__).resolve().parent
t=np.linspace(0,1.85*np.pi,1200)
p=np.c_[6*np.cos(t),6*np.sin(t),150.+.31*t];q=p+[.21,.13,.87]
items={'test_a':dict(fit(p),radius=.565),'test_b':dict(fit(q),radius=.565)}
class Dummy:
    targets={};groups={}
targets={name:integral_length(row['control'],row['knot'],64) for name,row in items.items()}
problem=RefinedProblem(Dummy(),items,16,0,0,targets)
def plane(points,radii):
    g=np.zeros_like(points);g[:,2]=1
    return points[:,2]-150.6,g
problem.native=plane
x=np.concatenate([row['control'][2:-2].ravel() for row in items.values()])
r,j,s=problem.evaluate(x);rng=np.random.default_rng(123456);rows=[]
for trial in range(10):
    direction=rng.normal(size=len(x));direction/=np.linalg.norm(direction)
    step=1e-5
    numeric=(problem.evaluate(x+step*direction)[0]-problem.evaluate(x-step*direction)[0])/(2*step)
    expected=j@direction;delta=abs(numeric-expected)
    maximum=float(delta.max());scaled=float((delta/np.maximum(1.,abs(numeric))).max())
    assert scaled<3e-6,(trial,maximum,scaled)
    rows.append(dict(trial=trial,maximum_absolute_error=maximum,maximum_scaled_error=scaled))
paths=[Path(__file__),HERE/'all_yaws_refined.py',HERE/'solve.py',HERE/'pose_screen.py',HERE/'all_yaws.py']
out=dict(status='PASS',scope='Ten synthetic analytic-plane derivative directions; not native geometry or route qualification',
         variables=len(x),residuals=len(r),step=step,rows=rows,sources={str(p):sha(p) for p in paths},main_changed=False,hardware_changed=False)
(HERE/'refined_derivative_check.json').write_text(json.dumps(out,indent=2)+'\n')
print('REFINED_SPARSE_DERIVATIVE_PASS',len(x),len(r),max(row['maximum_scaled_error'] for row in rows),flush=True)
