from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *
from native_electronics import board_transform

ctx=Context();data=json.loads((PROJECT/P['native_electronics']['boards']['motion']['mesh']).read_text())
r,t=board_transform('motion',data)
j=next(c for c in data['components'] if c['reference']=='J5')
v=np.vstack([np.array(s['vertices_mm'])@r.T+t for s in j['solids']])
inventory=json.loads((PROJECT/P['native_electronics']['inventory']).read_text())
fp=next(c for c in inventory['boards']['motion']['footprints'] if c['reference']=='J5')
all_names=[dict(name=o.name,role=o.get('role'),group=o.get('group'),type=o.type) for o in bpy.context.scene.objects if 'J5' in o.name]
reference=ctx.refs(0,0)
ctx.unchanged()
result=dict(revision=P['revision'],J5=dict(value=j['value'],lo_mm=v.min(0).tolist(),hi_mm=v.max(0).tolist(),
             board_rotation=r.tolist(),board_translation_mm=t.tolist(),native_footprint={k:v for k,v in fp.items() if k not in ['pads','models']}),
            scene_related=all_names,reference_curves={n:dict(point_count=len(d['p']),lo_mm=d['p'].min(0).tolist(),hi_mm=d['p'].max(0).tolist()) for n,d in reference.items()},sources=ctx.sources)
(HERE/'port_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('M1_55_PORT_INSPECTION',json.dumps(result['J5'],ensure_ascii=False),flush=True)
