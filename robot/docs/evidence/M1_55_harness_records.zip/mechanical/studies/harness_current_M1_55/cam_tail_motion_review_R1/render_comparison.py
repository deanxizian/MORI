"""Render exact zero-pose source cubics in separate editable inspection scenes."""
from pathlib import Path
import math
import json
import sys

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT));from context import Context,np,bpy,Vector,sha,ROOT,PROJECT,P


def points(c):
    chunks=[]
    for i,q in enumerate(c):
        count=max(1,math.ceil(np.linalg.norm(np.diff(q,axis=0),axis=1).sum()/.2))
        t=np.linspace(0,1,count+1);u=1-t
        v=u[:,None]**3*q[0]+3*(u*u*t)[:,None]*q[1]+3*(u*t*t)[:,None]*q[2]+t[:,None]**3*q[3]
        chunks.append(v if i==0 else v[1:])
    return np.concatenate(chunks)


def main():
    ctx=Context();digest=sha(ROOT/'mori_v1_2.blend');owner='M155_CAM_TAIL_COMPARISON_R1'
    zero_path=PARENT/'cam_tail_simplification_R4/zero_review.json';zero=json.loads(zero_path.read_text())
    assert zero['status']=='PASS' and all(sha(p)==h for p,h in zero['sources'].items())
    candidate_path=zero_path.parent/'zero_curves.npz';assert sha(candidate_path)==zero['arrays_sha256']
    original_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    original_receipt=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
    original_report=json.loads(original_receipt.read_text());assert sha(original_path)==original_report['arrays_sha256']
    original=np.load(original_path);candidate=np.load(candidate_path)
    assert not any(o.get('review_owner')==owner for o in bpy.data.objects)
    shown_names=['Pitch_Cradle','Pitch_Yoke','Display_Frame','Yaw_Reaction_Link','Yaw_Reaction_Clamp',
                 'Yaw_Anti_Lift_Keeper','Yaw_Base','Head_Yaw_Bearing','Head_Yaw_Servo','Head_Pitch_Servo',
                 'CAM_Mainboard','CAM_Mic_L','CAM_Mic_R','Camera_Module','LCD_Module']
    views=[('rear',(-140,-160,295),(0,-12,235),132),('front',(110,165,294),(0,-12,235),132)]
    files=[];scenes=[]
    profile_path=ROOT/'studies/harness_current_M1_54/usb_compact_angle/conditional_profiles.npz'
    profile=np.load(profile_path);shown=[]
    for label,arrays,source in [('original',original,original_path),('candidate',candidate,candidate_path)]:
        scene=bpy.data.scenes.new(owner+'_'+label.upper());bpy.context.window.scene=scene
        for k,v in dict(review_owner=owner,source_revision=P['revision'],main_source_sha256=digest,
                        candidate_status='ZERO_POSE_ONLY',full_harness='BLOCKED',manufacturing_release=False,
                        scope='Four complete upper capacity references at zero; shells omitted for inspection').items():scene[k]=v
        scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001;scene.unit_settings.length_unit='MILLIMETERS'
        scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1300;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
        scene.render.image_settings.file_format='PNG';scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
        scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
        scene.world=bpy.data.worlds.new(owner+'_'+label+'_WORLD');scene.world.color=(.07,.09,.12)
        collection=bpy.data.collections.new(owner+'_'+label);scene.collection.children.link(collection);collection['review_owner']=owner
        for name in shown_names:
            if name not in ctx.ss:continue
            source_object=ctx.ss[name].o;o=source_object.copy();o.data=source_object.data.copy();o.parent=None;o.matrix_world=source_object.matrix_world.copy()
            o.name=owner+'_'+label+'_'+name;o.hide_render=False;o['review_owner']=owner;o['mori_owner']=owner;o['source_object']=source_object.name
            o['export_candidate']=False;collection.objects.link(o)
            if name not in shown:shown.append(name)
        for pin in range(1,5):
            name=f'CAM_{pin}';key=f'{name}_y0_p0_controls' if label=='original' else name+'_controls'
            xyz=points(arrays[key]);c=bpy.data.curves.new(owner+'_'+label+'_'+name,'CURVE');c.dimensions='3D';c.resolution_u=1
            c.bevel_depth=.3302;c.bevel_resolution=3;s=c.splines.new('POLY');s.points.add(len(xyz)-1)
            s.points.foreach_set('co',np.c_[xyz,np.ones(len(xyz))].ravel())
            material=bpy.data.materials.new(owner+'_'+label+'_'+name+'_MAT');material.diffuse_color=(1.,.38+.07*(pin-1),.035,1);c.materials.append(material)
            o=bpy.data.objects.new(owner+'_'+label+'_'+name,c);collection.objects.link(o)
            for k,v in dict(review_owner=owner,category='PLACEHOLDER',data_status='ASSUMED',role='upper_routing_reference',
                            actual_endpoints_verified=False,material_selected=False,export_candidate=False,
                            full_harness='BLOCKED',manufacturing_release=False,source_arrays=str(source.relative_to(PROJECT)),
                            source_key=key,visual_sample_step_mm=.2).items():o[k]=v
        mesh=bpy.data.meshes.new(owner+'_'+label+'_USB_ALLOCATION')
        mesh.from_pydata(profile['wide_up_vertices_mm'].tolist(),[],profile['wide_up_triangles'].tolist());mesh.update()
        usb=bpy.data.objects.new(mesh.name,mesh);collection.objects.link(usb)
        material=bpy.data.materials.new(mesh.name+'_MAT');material.diffuse_color=(.95,.6,.12,1);mesh.materials.append(material)
        for k,v in dict(review_owner=owner,category='PLACEHOLDER',data_status='ASSUMED',
                        role='conditional_USB_allocation',export_candidate=False,manufacturing_release=False).items():usb[k]=v
        data=bpy.data.cameras.new(owner+'_'+label+'_CAMERA');camera=bpy.data.objects.new(data.name,data);scene.collection.objects.link(camera)
        data.type='ORTHO';data.clip_start=.1;data.clip_end=1200;scene.camera=camera
        for view,location,target,scale in views:
            camera.location=location;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();data.ortho_scale=scale
            output=HERE/(label+'_'+view+'.png');scene.render.filepath=str(output);bpy.ops.render.render(write_still=True)
            files.append(dict(file=output.name,sha256=sha(output),candidate=label,view=view))
        scenes.append(scene.name)
    ctx.record([Path(__file__),zero_path,candidate_path,original_path,original_receipt,profile_path]);ctx.unchanged()
    destination=HERE/'M1_55_CAM_tail_comparison_UNADOPTED.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(destination),compress=True)
    assert sha(ROOT/'mori_v1_2.blend')==digest
    receipt=dict(status='PASS',scope='Four zero-pose upper reference comparison only; not assembly or actual wiring qualification',
                 sources=ctx.sources,source_blend_sha256=digest,review_owner=owner,scenes=scenes,
                 copied_native_parts=shown,files=files,inspection_file=destination.name,inspection_sha256=sha(destination),
                 zero_geometry_receipt=str(zero_path),full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'render_manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print('CAM_TAIL_COMPARISON_RENDERED',len(shown),len(files),flush=True)


if __name__=='__main__':main()
