"""Check selected shorter fixed tails with the unchanged R3 prefixes at 475 poses."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_motion_family_R1'))
from power_family import PowerFamily,sha
from cam_family import CAMFamily,upper_length
from piecewise_geometry import unit


def main():
    started=time.time();variant=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--variant=')),'R4')
    assert variant in ['R3','R4']
    source=PARENT/f'cam_tail_simplification_{variant}/zero_review.json';d=json.loads(source.read_text())
    assert d['status']=='PASS' and d['selected']['status']=='PASS'
    assert all(sha(p)==h for p,h in d['sources'].items())
    carrier=PowerFamily();before=CAMFamily(carrier);parameters=d['selected']['candidate_parameters']
    if variant=='R3':
        sys.path.insert(0,str(PARENT/'cam_tail_simplification_R3'))
        from return_tail import LowerTopFamily
        family=LowerTopFamily(carrier,top=parameters['top_z_base_mm'])
        class_source=PARENT/'cam_tail_simplification_R3/return_tail.py'
    else:
        sys.path.insert(0,str(PARENT/'cam_tail_simplification_R4'))
        from diverted_tail import DivertedFamily
        family=DivertedFamily(carrier,top=parameters['top_z_base_mm'],outward=parameters['outward_x_mm'],
                              return_radius=parameters['return_radius_mm'])
        class_source=PARENT/'cam_tail_simplification_R4/diverted_tail.py'
    assert family.spec==parameters
    original_path=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
    original=json.loads(original_path.read_text());assert original['status']=='PASS'
    assert all(sha(p)==h for p,h in original['sources'].items())
    original_rows={(r['wire'],r['yaw_deg'],r['pitch_deg']):r for r in original['rows']}
    poses=original['planned_poses'];assert len(poses)==475
    arrays={};rows=[];failures=[]
    for yaw,pitch in poses:
        for pin in range(1,5):
            name=f'CAM_{pin}';c,info=family.upper(name,yaw,pitch)
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,**info)
            if c is not None:
                start=carrier.ctx.f.candidate(name,yaw)['control'][-1]
                end=carrier.ctx.cam[f'pin{pin}'][-1]
                mt=carrier.transform(yaw,pitch);end=end@mt[:3,:3].T+mt[:3,3]
                assert np.linalg.norm(c[0,0]-start)<1e-10 and np.linalg.norm(c[-1,-1]-end)<1e-10
                old=original_rows[name,yaw,pitch]
                height_difference=info['height_mm']-old['height_mm']
                row['service_loop_height_difference_from_previous_mm']=height_difference
                row['service_loop_construction_unchanged']=True
                row['reference_endpoints_unchanged']=True
                arrays[f'{name}_y{yaw:g}_p{pitch:g}_controls']=c
            else:failures.append(row)
            rows.append(row)
        print('SHORT_CAM_MOTION_MATH',yaw,pitch,len(rows),len(failures),flush=True)
        if failures:break
    carrier.ctx.record([Path(__file__),source,original_path,class_source])
    carrier.ctx.sources.update(d['sources']);carrier.ctx.sources.update(original['sources']);carrier.unchanged()
    np.savez_compressed(HERE/'curves.npz',**arrays)
    out=dict(status='PASS' if not failures and len(rows)==1900 else 'BLOCKED',
        scope='475 finite poses of selected shorter CAM reference; cubic curves, endpoints, loop and numeric common length only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=carrier.sources,
        selected_variant=variant,selected_zero_review=str(source),parameters=family.spec,tail_changes=family.tail_changes,
        planned_poses=poses,checked_curve_poses=len(rows),rows=rows,failures=failures,
        arrays_sha256=sha(HERE/'curves.npz'),elapsed_s=time.time()-started,
        native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',all_angle_clearance='NOT_TESTED',
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',main_changed=False,
        animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'curve_math.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('SHORT_CAM_MOTION_MATH_TERMINAL',out['status'],len(rows),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
