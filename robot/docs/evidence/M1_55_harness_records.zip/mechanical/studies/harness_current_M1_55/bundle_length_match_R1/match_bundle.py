"""Numeric length candidates for the retained power/CC upper primitives.

This study changes only two interior controls of each unadopted degree-five
reference. The current R3 prefixes, ends and their directions stay fixed.
No real port, print, selected material or supplier cut length is changed.
"""
from pathlib import Path
import datetime
import itertools
import json
import math
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path.insert(0,str(PARENT/'upper_smooth_review_R2'))
from piecewise_geometry import PiecewiseContext,Builder,fit,pieces,radius_bound,unit,MINIMUM_RADIUS,sha
from inspect_complete_numeric_lengths import upper_length
sys.path.insert(0,str(PARENT/'upper_length_match_R1'))
from match_cam import shape_check

NAMES=['P_J18_2','CC_allocation']
PIECE_COUNT=128
EDGES=np.linspace(0.,1.,PIECE_COUNT+1)


def basis(t,degree):
    t=np.asarray(t)
    return np.stack([math.comb(degree,j)*(1-t)**(degree-j)*t**j for j in range(degree+1)],axis=-1)


def convert(control):
    # Endpoint and derivative Hermite conversion on fixed parameter intervals.
    # Every resulting cubic is curvature-checked independently of degree five.
    p=basis(EDGES,5)@control
    v=basis(EDGES,4)@(5*np.diff(control,axis=0))
    h=1/(3*PIECE_COUNT)
    return np.stack([p[:-1],p[:-1]+h*v[:-1],p[1:]-h*v[1:],p[1:]],axis=1)


def cubic_lengths(c,order=64):
    q,w=np.polynomial.legendre.leggauss(order);t=(q+1)/2
    d=3*np.diff(c,axis=1)
    v=(1-t)[None,:,None]**2*d[:,None,0]+2*(t*(1-t))[None,:,None]*d[:,None,1]+t[None,:,None]**2*d[:,None,2]
    return np.linalg.norm(v,axis=-1)@(w/2)


def roots(control,target,direction,weight):
    q,w=np.polynomial.legendre.leggauss(96);t=(q+1)/2;w=w/2
    displacement=np.zeros((6,3));displacement[2]=direction;displacement[3]=weight*direction
    B=basis(t,4);base=B@(5*np.diff(control,axis=0));move=B@(5*np.diff(displacement,axis=0))
    def value(amplitude):
        v=base+amplitude*move;s=np.linalg.norm(v,axis=1)
        return float(w@s),float(w@(np.sum(v*move,axis=1)/s))
    found=[];original=value(0)[0]
    if abs(original-target)<1e-10:found.append(0.)
    for sign in [1.,-1.]:
        last=0.;flast=original-target
        for distance in [1.,2.,4.,8.,12.,18.]:
            a=sign*distance;fa=value(a)[0]-target
            if flast*fa<=0 and abs(flast)>1e-10:
                lo,hi=sorted([last,a]);flo=value(lo)[0]-target
                for _ in range(48):
                    m=(lo+hi)/2;fm=value(m)[0]-target
                    if flo*fm<=0:hi=m
                    else:lo,flo=m,fm
                found.append((lo+hi)/2);break
            last,flast=a,fa
    return found,displacement,value


def stub(ctx,name,yaw,pitch,raw):
    code='CC' if name=='CC_allocation' else name
    control=np.array(ctx.upper_meta[code,yaw,pitch]['controls_yaw_local_mm'],float)
    assert control.shape==(6,3)
    my=np.asarray(ctx.tr['transforms'][f'y{yaw}_p0'])
    junction=control[0]@my[:3,:3].T+my[:3,3]
    index=int(np.argmin(np.linalg.norm(raw-junction,axis=1)))
    assert index>0 and np.linalg.norm(raw[index]-junction)<1e-5
    incoming,outgoing=ctx.tangents(name,yaw,pitch)
    source_direction=my[:3,:3]@(control[1]-control[0])
    spl,details=fit(raw[:index+1],incoming,source_direction,.5)
    c=pieces(spl);assert details['deviation']['max_deviation_mm']<=.001
    # Preserve raw coordinates and tangent directions after endpoint evaluation.
    c[0,0]=raw[0];c[-1,-1]=raw[index]
    return dict(control=control,matrix=my,cubic=c,index=index,details=details,
                incoming=incoming,outgoing=outgoing,raw=raw)


def candidate(pre,target,direction,weight):
    original=pre['control'];prefix=pre['cubic'];my=pre['matrix'];raw=pre['raw']
    stub_length=upper_length(prefix,64)
    amplitudes,displacement,value=roots(original,target-stub_length,direction,weight)
    if not amplitudes:return None,dict(status='BLOCKED',stage='root_range',tested_limit_mm=18.)
    attempts=[]
    for initial in sorted(amplitudes,key=abs):
        amplitude=initial
        for _ in range(4):
            control=original+amplitude*displacement
            polynomial=convert(control);polynomial=polynomial@my[:3,:3].T+my[:3,3]
            seam=prefix[-1,-1]-polynomial[0,0]
            end=raw[-1]-polynomial[-1,-1]
            assert max(np.linalg.norm(seam),np.linalg.norm(end))<1e-5
            polynomial[0,:2]+=seam;polynomial[-1,-2:]+=end
            c=np.concatenate([prefix,polynomial])
            actual=upper_length(c,64);residual=actual-target
            if abs(residual)<1e-8:break
            derivative=value(amplitude)[1]
            if abs(derivative)<.005:break
            amplitude-=residual/derivative
        coarse=radius_bound(c,depth=4)
        bend=radius_bound(c,depth=7) if coarse['radius_lower_mm']>=pre['required_radius'] else coarse
        joins=shape_check(c,pre['incoming'],pre['outgoing'])
        exact=np.array_equal(c[0,0],raw[0]) and np.array_equal(c[-1,-1],raw[-1])
        ok=(abs(residual)<1e-8 and abs(amplitude)<=18.00001 and bend['radius_lower_mm']>=pre['required_radius'] and
            joins['internal_tangent_unit_error']<1e-8 and joins['internal_position_error_mm']<1e-10 and
            joins['end_tangent_unit_error']<1e-8 and exact)
        info=dict(status='PASS' if ok else 'BLOCKED',stage='curve_math',amplitude_mm=float(amplitude),
            root_initial_mm=float(initial),root_branches_found=amplitudes,length_residual_mm=float(residual),
            continuous_bending=bend,required_reference_radius_mm=pre['required_radius'],
            source_end_controls_unchanged=bool(np.array_equal(control[[0,1,-2,-1]],original[[0,1,-2,-1]])),
            endpoints_exact=exact,**joins,upper_Gauss64_length_mm=actual,
            upper_Gauss32_64_difference_mm=abs(upper_length(c,32)-actual),
            source_roundoff_correction_mm=[float(np.linalg.norm(seam)),float(np.linalg.norm(end))],
            degree_five_controls_yaw_local_mm=control.tolist(),supplier_cut_length=None)
        attempts.append(info)
        if ok:return c,info
    return None,dict(status='BLOCKED',stage='curve_math',root_attempts=attempts)


def main():
    started=time.time();ctx=PiecewiseContext()
    inventory_path=PARENT/'upper_smooth_review_R2/numeric_length_inventory.json'
    cam_path=PARENT/'upper_length_match_R1/all_poses_length_match.json'
    inventory=json.loads(inventory_path.read_text());cam=json.loads(cam_path.read_text())
    assert inventory['status']==cam['status']=='PASS'
    assert all(sha(p)==h for r in [inventory,cam] for p,h in r['sources'].items())
    source=PARENT/'upper_length_match_R1/all_poses_curves.npz';assert sha(source)==cam['arrays_sha256']
    old=np.load(source);arrays={k:old[k] for k in old.files}
    summaries={r['wire']:r for r in inventory['summaries']}
    first=[(0,0),(0,-20),(0,25),(-60,-20),(60,-20),(-60,25),(60,25),(-60,0),(60,0)]
    planned=first+[(y,p) for y in range(-60,61,10) for p in range(-20,26,5) if (y,p) not in first]
    cache={}
    def get(name,yaw,pitch):
        key=name,yaw,pitch
        if key not in cache:
            cache[key]=stub(ctx,name,yaw,pitch,ctx.upper(yaw,pitch)[name])
            cache[key]['required_radius']=MINIMUM_RADIUS[name]
        return cache[key]
    ctx.record([Path(__file__),inventory_path,cam_path,source,PARENT/'upper_length_match_R1/match_cam.py'])
    directions=[np.array(d,float) for d in [[0,0,1],[1,0,0],[1,0,1],[1,0,-1],[0,1,0]]]
    directions=[d/np.linalg.norm(d) for d in directions]
    trials=[];selected=None;selected_arrays=None
    for fraction,direction,weight in itertools.product([.5,0.,1.],directions,[.5,1.,1.5]):
        targets={n:summaries[n]['full_reference_min_mm']+fraction*summaries[n]['full_reference_range_mm'] for n in NAMES}
        rows=[];new={};failure=None
        poses=first if '--pilot' in sys.argv else planned
        for yaw,pitch in poses:
            for name in NAMES:
                body=ctx.f.targets[name];pre=get(name,yaw,pitch)
                c,info=candidate(pre,targets[name]-body,direction,weight)
                row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,body_neck_Gauss64_length_mm=body,
                         target_full_reference_length_mm=targets[name],**info)
                rows.append(row)
                if c is None:failure=row;break
                key=f'{name}_y{yaw}_p{pitch}'
                new[key+'_controls']=c;new[key+'_lengths']=cubic_lengths(c)
            if failure:break
            if (yaw,pitch)==first[-1] or len(rows)%40==0:
                print('BUNDLE_REFERENCE_LENGTH_PROGRESS',len(trials),yaw,pitch,len(rows),flush=True)
        trial=dict(index=len(trials),status='PASS' if not failure else 'BLOCKED',
                   spec=dict(target_fraction=fraction,direction=direction.tolist(),second_control_weight=weight),
                   target_full_reference_lengths_mm=targets,checked_curve_poses=len(rows),first_failure=failure)
        trials.append(trial)
        print('BUNDLE_REFERENCE_LENGTH_TRIAL',trial['index'],trial['status'],len(rows),
              failure and (failure['wire'],failure['yaw_deg'],failure['pitch_deg'],failure['stage']),flush=True)
        if not failure:
            selected=dict(spec=trial['spec'],rows=rows,targets=targets,planned_poses=poses);selected_arrays=new;break
    ctx.unchanged();suffix='pilot' if '--pilot' in sys.argv else 'all_poses'
    if selected_arrays:
        arrays.update(selected_arrays);np.savez_compressed(HERE/f'{suffix}_curves.npz',**arrays)
    out=dict(status='PASS' if selected else 'BLOCKED',scope='Two power/CC numeric lengths and cubic curvature at finite poses only; fresh geometry not yet tested',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,trials=trials,selected=selected,
        arrays_sha256=sha(HERE/f'{suffix}_curves.npz') if selected else None,elapsed_s=time.time()-started,
        unchanged_upper_families=['CAM_1','CAM_2','CAM_3','CAM_4','P_J18_1'],changed_upper_families=NAMES,
        native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',actual_arc_self_and_join='NOT_TESTED',
        between_pose_motion='NOT_TESTED',actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/f'{suffix}_length_match.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('BUNDLE_REFERENCE_LENGTH_TERMINAL',out['status'],len(trials),out['elapsed_s'],flush=True)


if __name__=='__main__':main()
