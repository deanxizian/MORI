"""Independently replay bridge-entry failures and resolve the early peer hit."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]
sys.path[:0]=[str(PARENT),str(PARENT/'upper_length_match_R1'),str(PROJECT/'mechanical/scripts/vendor')]
from polyline_pair_distance import exact_pair,algorithm_checks
from sample_geometry import sample
import manifold3d as manifold
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    started=time.time()
    report_path=HERE/'sequence_review.json';report=read(report_path)
    assert report['status']=='BLOCKED' and len(report['prior_native_ids'])==83
    assert len(report['moving_bridge_native_ids'])==6 and len(report['actor_readback'])==85
    assert all(sha(p)==h for p,h in report['sources'].items())
    manifest_path=PROJECT/'mechanical/animation/manifest.json';manifest=read(manifest_path)
    current=PARENT/'terminal_install_review_R1'
    receipt=read(current/'current_native_receipt.json');native_path=current/'current_native_parts.npz';native=np.load(native_path)
    assert sha(native_path)==receipt['output_sha256'] and receipt['native_part_count']==201
    ids={r['id'] for r in receipt['native_parts']}
    assert set(report['prior_native_ids'])=={n for n in ids if manifest['part_stages'][n]<=7}
    assert set(report['moving_bridge_native_ids'])=={n for n in ids if manifest['part_stages'][n]==8}
    assert all(max(r['moving_matrix_error_mm'],r['fixed_matrix_error_mm'])<.00005 for r in report['actor_readback'])
    prior=PARENT/'moving_bundle_entry_review_R1';bundle=read(prior/'bundle_receipt.json');array_path=prior/'bundle_zero.npz';arrays=np.load(array_path)
    assert sha(array_path)==bundle['arrays_sha256'] and bundle['prefix_sections']==12 and bundle['upper_sections']==7
    metadata={r['key']:r for r in bundle['rows']}
    parts={}
    for n in report['moving_bridge_native_ids']:
        m=manifold.Manifold(manifold.Mesh64(native[n+'__vertices_mm'],native[n+'__triangles'].astype(np.uint64)))
        assert m.status()==manifold.Error.NoError
        parts[n]=m
    verified=[]
    for path in report['bridge_paths']:
        assert path['status']=='BLOCKED' and len(path['rows'])==19
        for row in path['rows']:
            assert row['status']=='BLOCKED'
            failure=next(r['first_failure'] for r in row['path_results'] if r['first_failure'])
            segment=path['segments'][failure['path_segment']]
            a=np.array(segment['start_translation_mm']);b=np.array(segment['end_translation_mm'])
            offset=a+(b-a)*failure['midpoint']
            assert np.max(abs(offset-np.array(failure['bridge_translation_mm'])))<1e-12
            witness=failure['nearest'];n=witness['object'];local=np.array(witness['point_mm']);world=local+offset
            key=row['key'];controls=arrays[key+'__controls_mm']
            samples=sample(controls,max_step=.03)['points']
            assert np.max(abs(samples-arrays[key+'__points_mm']))<1e-10
            replay_error=float(np.linalg.norm(samples-world,axis=1).min())
            assert replay_error<1e-9
            assert row['radius_capacity_mm']==metadata[key]['radius_capacity_mm']
            probe=manifold.Manifold.sphere(row['radius_capacity_mm'],32).translate(world.tolist())
            target=parts[n].translate(offset.tolist())
            overlap=float((probe^target).volume());gap=float(probe.min_gap(target,.5))
            assert overlap>1e-5 or gap<.3-1e-5,(path['id'],key,overlap,gap)
            verified.append(dict(path=path['id'],key=key,wire=row['wire'],section=row['role'],
                moving_native=n,bridge_translation_mm=offset.tolist(),point_world_mm=world.tolist(),
                exact_sample_replay_error_mm=replay_error,inscribed_capacity_sphere_radius_mm=row['radius_capacity_mm'],
                overlap_mm3=overlap,sphere_to_moving_native_gap_mm=gap,
                classification='Actual capacity intersection' if overlap>1e-5 else 'Planning0.3mm gap violation'))
    assert len(verified)==38

    # The finite early connection has a conservative threshold hit at the
    # maximum lift. Exact segment-pair distance resolves this without moving
    # any wire or shrinking its capacity radius.
    early_path=HERE/'early_connection_arrays.npz';early=np.load(early_path)
    assert sha(early_path)==report['early_arrays_sha256']
    diagnostics=[];resolved=[]
    for case in report['early_connection_cases']:
        lift=case['lift_mm'];pairs=[]
        for row in case['pair_rows']:
            if row['status']=='PASS':
                pairs.append(dict(a=row['a'],b=row['b'],status='PASS',basis='Unchanged conservative complete-sample/chord certificate'))
                continue
            def curve(key):
                n=metadata[key]['wire']
                if key.endswith('__prefix') and n.startswith('CAM_'):
                    c=early[f'early_lift_{lift:.9f}_{n}__controls_mm']
                else:c=arrays[key+'__controls_mm']
                return sample(c,max_step=.03)
            left,right=curve(row['a']),curve(row['b'])
            minimum=exact_pair(left['points'],right['points'])
            radii=metadata[row['a']]['radius_capacity_mm']+metadata[row['b']]['radius_capacity_mm']
            surface=minimum['centreline_distance_mm']-radii
            lower=float(surface-left['error']-right['error']-.0001)
            upper=float(surface+left['error']+right['error'])
            diagnostic=dict(a=row['a'],b=row['b'],lift_mm=lift,status='PASS' if lower>=.3 else 'BLOCKED',
                polyline_surface_gap_mm=float(surface),gap_lower_bound_mm=lower,gap_upper_bound_mm=upper,
                true_capacity_gap_violation=upper<.3,initial_threshold_hit=row,exact_minimum=minimum)
            diagnostics.append(diagnostic);pairs.append(diagnostic)
        assert len(pairs)==62
        resolved.append(dict(lift_mm=lift,status='PASS' if all(w['status']=='PASS' for w in case['wire_rows'])
            and all(p['status']=='PASS' for p in pairs) else 'BLOCKED',native_parts=83,pair_checks=62,pairs=pairs))
    baseline_path=PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json';baseline=read(baseline_path)
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    sources={**report['sources'],**{str(p):sha(p) for p in [Path(__file__),report_path,manifest_path,
        current/'current_native_receipt.json',native_path,prior/'bundle_receipt.json',array_path,
        early_path,PARENT/'polyline_pair_distance.py',PARENT/'upper_length_match_R1/sample_geometry.py',baseline_path]}}
    assert all(sha(p)==h for p,h in sources.items())
    result=dict(status='PASS',scope='38 independent bridge-capacity failures and exact early-peer diagnostics; failed sequence remains unadopted',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        bridge_witnesses=verified,verified_bridge_witnesses=38,
        capacity_intersections=sum(r['overlap_mm3']>1e-5 for r in verified),
        planning_gap_only_violations=sum(r['overlap_mm3']<=1e-5 for r in verified),
        early_pair_diagnostics=diagnostics,early_positions_after_exact_peer_check=resolved,
        polyline_algorithm_check=algorithm_checks(),actual_mating='BLOCKED',full_wired_assembly='BLOCKED',
        protected_hardware_files=846,main_changed=False,animation_changed=False,hardware_changed=False,
        assembly_order_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'witness_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('BODY_FIRST_WITNESSES_VERIFIED',38,result['capacity_intersections'],result['planning_gap_only_violations'],
          'early',[(r['lift_mm'],r['status']) for r in resolved],846,flush=True)


if __name__=='__main__':main()
