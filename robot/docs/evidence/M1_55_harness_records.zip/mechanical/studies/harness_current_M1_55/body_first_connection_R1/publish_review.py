"""Publish the early-connection and bridge-entry sequence limits."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote,unquote,urlsplit
import datetime
import hashlib
import json
import sys
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):self.links.extend(v for k,v in attrs if k in ['href','src'])


def main():
    sequence=read(HERE/'sequence_review.json')
    audit=read(HERE/'witness_verification.json')
    handling=read(HERE/'handling_source.json')
    assert sequence['status']=='BLOCKED' and audit['status']==handling['status']=='PASS'
    assert audit['verified_bridge_witnesses']==38 and audit['capacity_intersections']==36
    assert audit['planning_gap_only_violations']==2 and len(sequence['actor_readback'])==85
    assert len(sequence['prior_native_ids'])==83 and len(sequence['moving_bridge_native_ids'])==6
    assert all(p['status']=='BLOCKED' and len(p['rows'])==19 for p in sequence['bridge_paths'])
    assert [r['status'] for r in audit['early_positions_after_exact_peer_check']]==['PASS','PASS','BLOCKED']
    diagnostic=audit['early_pair_diagnostics'][0]
    assert diagnostic['a']=='CAM_1__prefix' and diagnostic['b']=='CAM_3__prefix'
    assert diagnostic['true_capacity_gap_violation']
    sources={}
    for r in [sequence,audit,handling]:
        assert all(sha(p)==h for p,h in r['sources'].items())
        for p,h in r['sources'].items():
            assert p not in sources or sources[p]==h
            sources[p]=h
    for p in [Path(__file__),*[HERE/n for n in ['sequence_review.json','witness_verification.json','handling_source.json']]]:
        sources[str(p)]=sha(p)
    blender='/Applications/Blender.app/Contents/MacOS/Blender'
    primary='/Users/dean/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
    commands=[]
    for name in ['check_sequence','verify_witnesses','record_handling']:
        command=[primary,str(HERE/(name+'.py'))] if name=='record_handling' else [blender,'-b','--factory-startup',
            '--python-exit-code','1','--python',str(HERE/(name+'.py'))]
        commands.append(dict(command=command,log=name+'.log',exit_code=0))
    logs=[(HERE/c['log']).read_text() for c in commands]
    assert 'BODY_FIRST_CONNECTION_TERMINAL BLOCKED 3 2' in logs[0]
    assert 'BODY_FIRST_WITNESSES_VERIFIED 38 36 2' in logs[1]
    assert 'JST_GENERAL_HANDLING_RECORDED 14 2 PH_SPECIFIC_METHOD_BLOCKED' in logs[2]
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',cwd=str(PROJECT),commands=commands,
        versions=dict(blender='5.2.2 LTS',python='3.13.13',numpy='2.3.4',scipy='1.16.2',manifold3d='3.5.3'),
        source_reader_versions=handling['versions'],full_wired_assembly='BLOCKED',main_changed=False,
        animation_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 先接身体端与承重桥装入比较</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1050px;margin:32px auto;padding:0 22px;color:#27343b}}table{{width:100%;border-collapse:collapse;margin:20px 0}}td,th{{padding:9px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}</style>
<h1>提前接身体端，仍不能直接预铺原姿态线束后落座</h1>
<p class="scope">独立候选，未采用。19个参考分段＝12身体前段＋全部7可用上段；5个完整上段仍缺失。PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED。真实自由端、实际端子／夹持、分步软线整理与完整带线装配仍BLOCKED。</p>
<p>本轮使用主模型M1.55及其现有装配动画。身体电子装到第7阶段后，83件原生刚体均保留。第8阶段承重桥的6件预装分总成来自保存的演员父子关系；85个实际帧／矩阵回读核对了三段移动及两段停留，没有用旧模型或临时删除阻挡零件。</p>
<table><thead><tr><th>阶段／候选</th><th>实际范围</th><th>结果</th></tr></thead><tbody>
<tr><td>桥未装时插合身体CAM四芯</td><td>83件已有刚体；4根前段、其他8前段及7上段；三个有限抬起量</td><td>零位／中途通过；最高容量框抬起量处CAM1／CAM3规划净距下界{diagnostic['gap_lower_bound_mm']:.6f}mm，低于0.3mm目标。线材／真实插深仍未知，未缩线径或改目标。</td></tr>
<tr><td>预铺19参考／现有桥装入路径</td><td>保持Y−14mm，Z144→18mm；向前Y−14→0；最后Z18→0，两次停留也核对</td><td>19参考均出现净距失败。相交位置重新构建，并用6件当前原生实体复现。</td></tr>
<tr><td>预铺19参考／直落比较</td><td>显式候选Y0、Z144→0mm；未写入现有动画</td><td>19参考同样出现净距失败；改变下放方向本身没有闭合这个预铺方案。</td></tr>
<tr><td>独立证据</td><td>两条路线，共38处；每处核对当前实体、桥平移和真实曲线取样点</td><td>36处容量管／移动实体相交，2处不足0.3mm规划净距。是容量参考反例，不是实物测量或其他所有装法的不可行证明。</td></tr>
<tr><td>仍需完成</td><td>分步穿入／临时整理、真实自由端与保护、夹持及整束闭壳</td><td>NOT_TESTED／BLOCKED；没有把数学Z200切点当成已知裸端子或完整临时线束。</td></tr>
</tbody></table>
<p>两个方案都没有找到可采用的完整入座路径。后续需围绕骨架先装、导线分步穿入和最终端接继续；完整线束仍有4组未完成工作，主Blender／视频和846个硬件工程源保持。</p>
<h2>新补充的厂家处理要求</h2>
<p>JST通用手册要求保留操作余量，通常握住塑壳插拔；狭窄处的例外仍需支撑连接器、均匀受力，具体产品说明优先。线材／端子与压接工具也需匹配。<a href="https://www.jst-mfg.com/product/pdf/eng/handling_e.pdf">JST官方手册，p3／4／7</a>。</p>
<p>已查看余量与插拔示意两页。手册没有确认“空塑壳先插在J5，再从后方逐针装端子”这个PH专用方案；这只是资料边界，未据此宣称禁止，也未将其作为已验证装法。PH具体内腔／插深、实际线材／压接和夹持外形仍待确认。</p>
<p><a href="sequence_review.json">当前阶段与路线检查</a> · <a href="witness_verification.json">38处复现及精确互线距离</a> · <a href="handling_source.json">厂家要求与未确认方法</a> · <a href="commands.json">实际命令</a> · <a href="../phr4_mating_capacity_R1/index.html">上轮身体插合诊断</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# Early body connection and fixed-bridge entry

Current M1.55 saved animation stage7 yields83 installed native solids. Six
bridge parts are rigid children of Fixed_Bridge. Their saved path and two
pauses are read back at85 poses, preserving all source transforms.
CAM held-bend service probe before bridge: zero and halfway clear, highest
outside-capacity-box lift fails CAM1/CAM3 gap. Exact finite-polyline minimum
minus both cubic errors gives0.298153mm lower /0.298322mm upper, so the
planning0.3mm criterion genuinely fails; geometry/radii/criteria unchanged.

All19 existing curve sections are retained:12 body prefixes and7 available
uppers. They have unqualified temporary free ends, with5 complete uppers
missing. Both current Y-14/down144-to18/forward14/down18 bridge path and
unadopted straight-drop comparison fail19 sections. Independent38 witnesses
are36 capacity-sphere/native intersections and2 planning-gap violations.
No claim that other temporary soft shapes or sequences are impossible.

Public general JST handling guide recorded and p3/4 diagrams reviewed.
Provide slack, prefer housing grip, and match wire/terminal/application
tooling; product-specific guidance takes precedence. The general manual
does not qualify inserting contacts into an already-mated empty PH housing.
No invented product-specific confirmation or claimed prohibition.

True free terminals, wire/protection/grip and temporary reshaping/final
closure remain unresolved. Four full-harness groups remain. Main geometry,
video, assembly order and846 hardware files are unchanged; no release.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
        and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_review.log']}
    delivery=dict(status='PASS',scope='Publication of rejected early-body/rigid-prelaid sequence and source handling boundaries',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        early_body_mating_capacity='BLOCKED',prelaid_reference_bridge_entry='BLOCKED',
        saved_bridge_actor_pose_readbacks=85,prior_native_parts=83,moving_bridge_native_parts=6,
        reference_sections=19,prefix_sections=12,upper_sections=7,verified_bridge_witnesses=38,
        capacity_intersections=36,planning_gap_only_violations=2,
        general_JST_handling_source='PASS',already_mated_empty_housing_contact_insertion='BLOCKED',
        full_harness='BLOCKED',remaining_work_packages=4,protected_hardware_files=846,
        main_changed=False,animation_changed=False,hardware_changed=False,assembly_order_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items()) and all(sha(HERE/p)==h for p,h in files.items())
    parser=Links();parser.feed((HERE/'index.html').read_text());targets=[HERE/'index.html']
    for link in parser.links:
        u=urlsplit(link)
        if not u.scheme and u.path:targets.append((HERE/unquote(u.path)).resolve())
    served=[]
    for p in dict.fromkeys(targets):
        relative=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(relative),timeout=10) as response:
            assert response.status==200 and response.read()==p.read_bytes()
        served.append(dict(path=relative,sha256=sha(p)))
    (HERE/'publication_verification.json').write_text(json.dumps(dict(status='PASS',delivery_sha256=sha(HERE/'delivery.json'),
        verified_files=len(files),served_links=len(served),served=served,full_harness='BLOCKED',main_changed=False,
        animation_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')
    print('BODY_FIRST_SEQUENCE_PUBLISHED',len(files),len(served),38,36,2,846,flush=True)


if __name__=='__main__':main()
