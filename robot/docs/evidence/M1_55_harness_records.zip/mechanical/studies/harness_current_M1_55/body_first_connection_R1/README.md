# Early body connection and fixed-bridge entry

Current M1.55 saved animation stage7 yields83 installed native solids. Six
bridge parts are rigid children of Fixed_Bridge. Their saved path and two
pauses are read back at85 poses, preserving all source transforms.
CAM held-bend service probe before bridge: zero and halfway clear, highest
outside-capacity-box lift fails CAM1/CAM3 gap. Exact finite-polyline minimum
minus both cubic errors gives0.298153mm lower /0.298322mm upper, so the
planning0.3mm criterion genuinely fails; geometry/radii/criteria unchanged.

All19 existing curve sections are retained:12 body prefixes and7 available
uppers. They have unqualified temporary free ends, with5 complete uppers
missing. Both current Y-14/down144-to18/forward14/down18 bridge path and
unadopted straight-drop comparison fail19 sections. Independent38 witnesses
are36 capacity-sphere/native intersections and2 planning-gap violations.
No claim that other temporary soft shapes or sequences are impossible.

Public general JST handling guide recorded and p3/4 diagrams reviewed.
Provide slack, prefer housing grip, and match wire/terminal/application
tooling; product-specific guidance takes precedence. The general manual
does not qualify inserting contacts into an already-mated empty PH housing.
No invented product-specific confirmation or claimed prohibition.

True free terminals, wire/protection/grip and temporary reshaping/final
closure remain unresolved. Four full-harness groups remain. Main geometry,
video, assembly order and846 hardware files are unchanged; no release.
