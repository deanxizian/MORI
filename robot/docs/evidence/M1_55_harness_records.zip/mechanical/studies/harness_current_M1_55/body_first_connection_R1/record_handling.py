"""Public general JST handling guidance; no PH-specific method invented."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import urllib.request
import pypdf
import pypdfium2

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    target=HERE/'sources/JST_handling_e.pdf'
    target.parent.mkdir(parents=True,exist_ok=True)
    url='https://www.jst-mfg.com/product/pdf/eng/handling_e.pdf'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MORI engineering source review'}),timeout=25) as response:
        raw=response.read();final=response.url;status=response.status
    assert status==200 and raw.startswith(b'%PDF')
    target.write_bytes(raw)
    reader=pypdf.PdfReader(target)
    assert len(reader.pages)==14
    extracted={str(i+1):reader.pages[i].extract_text() for i in [2,3,5,6]}
    assert 'holding the body' in extracted['4'] and '15 degrees' in extracted['4']
    assert 'appropriate slack' in extracted['3']
    assert 'wire to be used' in extracted['7']
    # Render the two pages with the relevant handling diagrams. Product-
    # specific insertion/cavity geometry is not extracted from these figures.
    doc=pypdfium2.PdfDocument(str(target));rendered=[]
    for index,name in [(2,'JST_slack_guidance.png'),(3,'JST_mating_guidance.png')]:
        page=doc[index];bitmap=page.render(scale=1.3)
        image=HERE/name;bitmap.to_pil().save(image)
        rendered.append(dict(page=index+1,file=name,sha256=sha(image)))
        bitmap.close();page.close()
    doc.close()
    (HERE/'handling_pages_text.json').write_text(json.dumps(extracted,indent=2)+'\n')
    facts=dict(status='PASS',scope='General public connector-handling rules only; no PH-specific insertion method qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_url=url,final_url=final,http_status=status,PDF_pages=14,PDF_sha256=sha(target),
        sources={str(p):sha(p) for p in [Path(__file__),target]},
        versions=dict(python=sys.version,pypdf=pypdf.__version__,PDFium=pypdfium2.PYPDFIUM_INFO.version),
        documented_general_rules=[
            dict(page=3,rule='Provide adequate handling slack so connector joints do not carry abnormal harness loads.'),
            dict(page=4,rule='In principle mate/unmate by holding the housing; the constrained-access alternative supports the connector and loads all wires evenly, within15deg unless product-specific instructions govern.'),
            dict(page=7,rule='Check the chosen wire against the terminal and use the relevant product/application tooling instructions.')],
        record_interpretation='Grip and strain relief are necessary remaining checks; a geometric capacity PASS does not demonstrate these handling requirements.',
        seated_empty_housing_contact_insertion='BLOCKED: this general manual does not document or qualify that PH-specific alternative',
        PH_specific_cavity_and_stroke='BLOCKED',actual_wire_and_crimp='BLOCKED',
        customer_form_submitted=False,supplier_contacted=False,rendered=rendered,
        full_wired_assembly='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'handling_source.json').write_text(json.dumps(facts,indent=2)+'\n')
    print('JST_GENERAL_HANDLING_RECORDED',len(reader.pages),len(rendered),'PH_SPECIFIC_METHOD_BLOCKED',flush=True)


if __name__=='__main__':main()
