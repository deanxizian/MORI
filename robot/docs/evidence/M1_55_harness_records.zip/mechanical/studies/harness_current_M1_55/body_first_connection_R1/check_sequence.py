"""Early body-connection capacity and subsequent fixed-bridge entry.

Unadopted sequence investigation. The exact saved bridge path is replayed;
an explicit straight-drop comparison is not put into the main animation.
Twelve body prefixes and all seven available uppers are retained. Their
ends are existing capacity datums, not qualified temporary free contacts.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]
PREVIOUS=PARENT/'phr4_mating_capacity_R1'
sys.path[:0]=[str(PREVIOUS),str(PARENT/'upper_length_match_R1'),
             str(PARENT/'upper_smooth_review_R2'),str(PARENT)]
from screen_held_bend import HeldBendFamily
from check_service_positions import own_join
from sample_geometry import sample
from piecewise_geometry import pieces
from context import clear,manifold,BVHTree,prepared,bpy
from bounded_curve_checks import pair_threshold
from curve_self_partition import self_clear
from selected_family import BSpline
from assembly_animation import AP,SCENE_NAME,curves
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def descendant(actor,root):
    while actor is not None:
        if actor==root:return True
        actor=actor.parent
    return False


def main():
    started=time.time()
    current=PARENT/'terminal_install_review_R1'
    receipt_path=current/'current_native_receipt.json';native_path=current/'current_native_parts.npz'
    receipt=read(receipt_path);native=np.load(native_path)
    assert receipt['status']=='PASS' and receipt['native_part_count']==201
    assert sha(native_path)==receipt['output_sha256']
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    manifest_path=PROJECT/'mechanical/animation/manifest.json';manifest=read(manifest_path)
    assert manifest['source_blend_sha256']==sha(PROJECT/'mechanical/mori_v1_2.blend')
    ids={r['id'] for r in receipt['native_parts']}
    fixed_ids=sorted(n for n in ids if manifest['part_stages'][n]<=7)
    moving_ids=sorted(n for n in ids if manifest['part_stages'][n]==8)
    assert len(fixed_ids)==83 and len(moving_ids)==6
    assert set(moving_ids)=={'Yaw_Base','Yaw_Bearing','Yaw_Base_-1_Nut','Yaw_Base_1_Nut',
                            'Yaw_Keeper_Insert_0','Yaw_Keeper_Insert_1'}
    targets={}
    for n in fixed_ids+moving_ids:
        v=native[n+'__vertices_mm'];f=native[n+'__triangles']
        solid=manifold.Manifold(manifold.Mesh64(v,f.astype(np.uint64)))
        assert solid.status()==manifold.Error.NoError
        targets[n]=dict(m=solid,lo=v.min(0),hi=v.max(0),tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True))
    fixed={n:targets[n] for n in fixed_ids};moving={n:targets[n] for n in moving_ids}
    bundle_path=PARENT/'moving_bundle_entry_review_R1/bundle_receipt.json'
    bundle=read(bundle_path);bundle_arrays=bundle_path.parent/'bundle_zero.npz';arrays=np.load(bundle_arrays)
    assert bundle['status']=='PASS' and sha(bundle_arrays)==bundle['arrays_sha256']
    assert all(sha(p)==h for p,h in bundle['sources'].items())
    stored={}
    for row in bundle['rows']:
        controls=arrays[row['key']+'__controls_mm'];sampled=sample(controls,max_step=.03)
        assert np.max(abs(sampled['points']-arrays[row['key']+'__points_mm']))<1e-10
        stored[row['key']]=dict(meta=row,controls=controls,sampled=sampled,
            pack=prepared(sampled['points'],row['radius_capacity_mm'],sampled['error']))
    assert len(stored)==19

    # Early mating of CAM body ends is tested with precisely the prior-stage
    # 83 native parts, never by an arbitrary blocker-removal list.
    housing_path=PREVIOUS/'housing_capacity.json';housing=read(housing_path)
    assert housing['status']=='PASS' and all(sha(p)==h for p,h in housing['sources'].items())
    held_path=PREVIOUS/'held_bend_screen.json';held=read(held_path)
    variant=next(r for r in held['rows'] if r['hold_parameter']==.10 and r['fade_end_parameter']==.40)
    assert variant['status']=='PASS' and all(sha(p)==h for p,h in held['sources'].items())
    family=HeldBendFamily(.10,.40);cam_names=family.names
    retained={k:v for k,v in stored.items() if not (v['meta']['role']=='prefix' and v['meta']['wire'] in cam_names)}
    own={n:retained[n+'__upper'] for n in cam_names}
    service=[];outputs={}
    for lift in [0.,housing['release_lift_mm']/2,housing['release_lift_mm']]:
        packs={};wire_rows=[];pairs=[]
        for n in cam_names:
            it=family.candidate(n,lift);spline=BSpline(family.f.knots,it['control'],3)
            controls=pieces(spline);geometry=sample(controls,max_step=.03)
            pack=prepared(geometry['points'],family.f.radii[n],geometry['error'])
            prior=next(c for c in variant['cases'] if c['wire']==n and c['lift_mm']==lift)
            prior_controls=np.load(PREVIOUS/'held_bend_0.10_0.40.npz')[n+f'__lift_{lift:.9f}__controls']
            assert np.max(abs(prior_controls-it['control']))<1e-10
            assert prior['continuous_curve_bend']['status']=='PASS'
            hits,near=clear(geometry['points'],pack['radius'],fixed,error=geometry['error'],gap=.3)
            remote=self_clear(pack);join=own_join(geometry,own[n]['sampled'],pack['radius'],own[n]['pack']['radius'])
            packs[n]=pack
            wire_rows.append(dict(wire=n,status='PASS' if not hits and remote['status']==join['status']=='PASS' else 'BLOCKED',
                native_hits=hits,nearest_native=near,remote_self=remote,own_join=join,
                continuous_curve_bend=prior['continuous_curve_bend'],numeric_length_residual_mm=it['residual_mm'],
                curve_bend_source='Exact control-array readback of previous held-bend preflight; no continuous-lift claim'))
            outputs[f'early_lift_{lift:.9f}_{n}__controls_mm']=controls
            outputs[f'early_lift_{lift:.9f}_{n}__points_mm']=geometry['points']
        import itertools
        for a,b in itertools.combinations(cam_names,2):pairs.append(dict(a=a+'__prefix',b=b+'__prefix',**pair_threshold(packs[a],packs[b])))
        for n in cam_names:
            for key,item in retained.items():
                if key==n+'__upper':continue
                pairs.append(dict(a=n+'__prefix',b=key,**pair_threshold(packs[n],item['pack'])))
        assert len(pairs)==62
        case=dict(lift_mm=lift,status='PASS' if all(r['status']=='PASS' for r in wire_rows+pairs) else 'BLOCKED',
            native_prior_parts=83,wire_rows=wire_rows,pair_rows=pairs,
            head_end_status='Existing Z200 capacity cut and upper reference fixed, no free-contact qualification')
        service.append(case)
        print('EARLY_BODY_CONNECTION',lift,case['status'],flush=True)
        if case['status']!='PASS':break
    family.f.unchanged()

    # Read actual saved source FCurves and actor membership. In the saved
    # bridge bench each native part is a rigid child of Fixed_Bridge.
    animation_path=PROJECT/'mechanical/mori_assembly_animation.blend'
    bpy.ops.wm.open_mainfile(filepath=str(animation_path))
    scene=bpy.data.scenes[SCENE_NAME];bpy.context.window.scene=scene
    root=bpy.data.objects[AP+'Fixed_Bridge']
    actors={o.name.removeprefix(AP):o for o in scene.objects if o.get('presentation_actor')}
    assert root.parent is None and np.max(abs(np.asarray(root.rotation_euler)))<1e-10
    assert all(descendant(actors[n],root) for n in moving_ids)
    assert not any(descendant(actors[n],root) for n in fixed_ids)
    assert np.array_equal(np.asarray(root.scale),np.ones(3))
    stage8=next(s for s in manifest['stages'] if s['index']==8)
    stage9=next(s for s in manifest['stages'] if s['index']==9)
    waypoints=[(stage8['start']+12,[0.,-14.,144.]),
               (stage8['start']+104,[0.,-14.,18.]),
               (stage8['start']+110,[0.,-14.,18.]),
               (stage8['end'],[0.,0.,18.]),
               (stage9['start']+8,[0.,0.,18.]),
               (stage9['start']+36,[0.,0.,0.])]
    channels={fc.array_index:fc for fc in curves(root) if fc.data_path=='location'}
    assert set(channels)=={0,1,2}
    saved_segments=[];readback=[]
    matrices={r['id']:np.array(r['matrix_world']) for r in receipt['native_parts']}
    for (left,a),(right,b) in zip(waypoints[:-1],waypoints[1:]):
        for axis in range(3):
            keys={int(k.co[0]):k for k in channels[axis].keyframe_points}
            assert left in keys and right in keys
            assert keys[left].interpolation=='LINEAR'
            assert not any(left<k<right for k in keys)
            assert max(abs(keys[left].co[1]-a[axis]),abs(keys[right].co[1]-b[axis]))<1e-5
        saved_segments.append(dict(frame_interval=[left,right],start_translation_mm=a,end_translation_mm=b))
        for u in np.linspace(0.,1.,17):
            frame=left+u*(right-left);scene.frame_set(int(frame),subframe=float(frame%1));bpy.context.view_layer.update()
            expected=np.eye(4);expected[:3,3]=(1-u)*np.array(a)+u*np.array(b)
            errors=[np.max(abs(np.array(actors[n].matrix_world)@np.linalg.inv(matrices[n])-expected)) for n in moving_ids]
            fixed_errors=[np.max(abs(np.array(actors[n].matrix_world)@np.linalg.inv(matrices[n])-np.eye(4))) for n in fixed_ids]
            assert max(errors+fixed_errors)<.00005
            readback.append(dict(frame=float(frame),moving_matrix_error_mm=float(max(errors)),
                                 fixed_matrix_error_mm=float(max(fixed_errors))))

    # Retain all available reference sections, not only the twelve prefixes
    # that would make a straight-drop candidate easier to certify.
    static=[]
    for key,item in stored.items():
        meta=item['meta'];hits,near=clear(item['sampled']['points'],meta['radius_capacity_mm'],fixed,error=item['sampled']['error'],gap=.3)
        static.append(dict(key=key,status='PASS' if not hits else 'BLOCKED',hits=hits,nearest=near))
    paths=[dict(id='saved_bridge_entry',source='Exact current saved actor FCurves',segments=saved_segments),
           dict(id='straight_vertical_candidate',source='Explicit unadopted path comparison, not saved animation',
                segments=[dict(start_translation_mm=[0.,0.,144.],end_translation_mm=[0.,0.,0.])])]
    runs=[]
    for path in paths:
        rows=[]
        for key,item in stored.items():
            radius=item['meta']['radius_capacity_mm'];geometry=item['sampled'];certificates=[];failure=None
            for si,seg in enumerate(path['segments']):
                a=np.array(seg['start_translation_mm']);b=np.array(seg['end_translation_mm']);todo=[(0.,1.,0)];passed=[]
                while todo:
                    left,right,depth=todo.pop();mid=(left+right)/2;offset=a+(b-a)*mid
                    motion=float(np.linalg.norm(b-a)*(right-left)/2)
                    hits,near=clear(geometry['points']-offset,radius,moving,error=geometry['error']+motion,gap=.3)
                    if not hits:
                        passed.append(dict(parameter_interval=[left,right],translation_radius_mm=motion,
                            gap_lower_bound_mm=near['gap_lower_bound_mm'] if near else None));continue
                    observed,witness=clear(geometry['points']-offset,radius,moving,error=geometry['error'],gap=.3)
                    upper=(witness['gap_lower_bound_mm']+witness['half_step_mm']+witness['chord_error_mm']+.0001) if witness else None
                    inside=any(h.get('inside') for h in observed)
                    if inside or (upper is not None and upper<.3) or depth>=13:
                        failure=dict(path_segment=si,parameter_interval=[left,right],midpoint=mid,
                            bridge_translation_mm=offset.tolist(),nearest=witness,hits=observed,
                            sampled_surface_clearance_upper_mm=upper,inside_native=inside,depth=depth);break
                    todo.extend([(mid,right,depth+1),(left,mid,depth+1)])
                certificates.append(dict(segment=si,status='PASS' if failure is None else 'BLOCKED',intervals=passed,first_failure=failure))
                if failure:break
                assert passed[0]['parameter_interval'][0]==0. and passed[-1]['parameter_interval'][1]==1.
                assert all(a['parameter_interval'][1]==b['parameter_interval'][0] for a,b in zip(passed[:-1],passed[1:]))
            row=dict(key=key,role=item['meta']['role'],wire=item['meta']['wire'],status='PASS' if failure is None else 'BLOCKED',
                path_results=certificates,radius_capacity_mm=radius)
            rows.append(row)
            print('PRELAID_BRIDGE_PATH',path['id'],key,row['status'],flush=True)
        runs.append(dict(**path,status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',rows=rows))

    baseline_path=PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json';baseline=read(baseline_path)
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    sources={**receipt['sources'],**bundle['sources'],**housing['sources'],**held['sources'],**family.f.sources,
        **{str(p):sha(p) for p in [Path(__file__),receipt_path,native_path,manifest_path,animation_path,
            PROJECT/'mechanical/scripts/assembly_animation.py',bundle_path,bundle_arrays,housing_path,held_path,
            PREVIOUS/'held_bend_0.10_0.40.npz',PREVIOUS/'screen_held_bend.py',PREVIOUS/'prepare_service_family.py',
            PREVIOUS/'check_service_positions.py',PARENT/'upper_length_match_R1/sample_geometry.py',
            PARENT/'upper_smooth_review_R1/smooth_geometry.py',PARENT/'context.py',baseline_path]}}
    assert all(sha(p)==h for p,h in sources.items())
    output_path=HERE/'early_connection_arrays.npz';np.savez_compressed(output_path,**outputs)
    report=dict(status='PASS' if len(service)==3 and all(c['status']=='PASS' for c in service) and
        all(c['status']=='PASS' for c in static) and any(r['status']=='PASS' for r in runs) else 'BLOCKED',
        scope='Unadopted early body-end connection and19 stationary references versus fixed-bridge entry; not full temporary wired assembly',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        native_source_count=201,prior_native_ids=fixed_ids,moving_bridge_native_ids=moving_ids,
        actor_readback=readback,early_connection_cases=service,early_arrays_sha256=sha(output_path),
        static_prior_native_checks=static,bridge_paths=runs,reference_sections=19,prefix_sections=12,available_upper_sections=7,
        missing_upper_references=bundle['missing_upper_references'],
        actual_temporary_free_ends='BLOCKED',actual_mating='BLOCKED',continuous_early_connection_motion='NOT_TESTED',
        actual_grip_and_soft_reshaping='NOT_TESTED',bridge_to_prior_rigid_revalidation='NOT_TESTED in this wire-only investigation',
        final_bolt_tools_with_wires='NOT_TESTED',full_wired_assembly='BLOCKED',protected_hardware_files=846,
        main_changed=False,animation_changed=False,hardware_changed=False,assembly_order_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'sequence_review.json').write_text(json.dumps(report,indent=2)+'\n')
    print('BODY_FIRST_CONNECTION_TERMINAL',report['status'],len(service),len(runs),round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
