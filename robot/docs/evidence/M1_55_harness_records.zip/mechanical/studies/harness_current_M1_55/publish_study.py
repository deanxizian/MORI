"""Publish scoped M1.55 harness research without adopting geometry."""
from pathlib import Path
import datetime,hashlib,html,json,re
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1];PROJECT=ROOT.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=sha(ROOT/'mori_v1_2.blend')
ctx=read(HERE/'context_receipt.json');facts=read(HERE/'materials/source_facts.json')
render=read(HERE/'render_manifest.json');saved=read(HERE/'saved_inspection_readback.json')
exact=read(HERE/'independent_pair_diagnostic.json')
assert ctx['status']==facts['status']==render['status']==saved['status']==exact['status']=='PASS'
assert render['source_blend_sha256']==digest
assert all(sha(p)==h for d in [ctx,saved,exact] for p,h in d['sources'].items())
assert facts['formal_definition']['changed'] is False
families=['body_relayout','body_relayout_R2','body_relayout_R3','body_relayout_R4','body_bundle_R5','body_bundle_R6']
variants=[];rows=[]
for family in families:
    report=read(HERE/family/'review.json')
    assert report['status']=='BLOCKED' and report['accepted'] is None
    assert all(sha(p)==h for p,h in report['sources'].items())
    count=sum(v['checked_prefixes'] for v in report['attempts'])
    rows.append(dict(family=family,status=report['status'],variants=len(report['attempts']),checked_prefixes=count,
                     actual_poses=[[0,0]],planned_poses=report['planned_poses']))
    for v in report['attempts']:
        detail=read(HERE/family/v['candidate']/'review.json')
        assert all(r['yaw_deg']==r['pitch_deg']==0 for r in detail['rows'])
        variants.append(dict(family=family,**v))
assert len(variants)==24 and sum(r['checked_prefixes'] for r in rows)==96
overlap=[r for r in exact['rows'] if r['polyline_surface_gap_mm']<0]
short=[r for r in exact['rows'] if r['status']=='BLOCKED' and r['polyline_surface_gap_mm']>=0]
passing=[r for r in exact['rows'] if r['status']=='PASS']
joint=read(HERE/'global_bundle_layout/delivery.json')
assert joint['status']=='PASS' and joint['source_blend_sha256']==digest and joint['prefix_geometry']=='PASS'
assert all(sha(HERE/'global_bundle_layout'/p)==h for p,h in joint['files'].items())
continuity=read(HERE/'prefix_continuity/delivery.json')
assert continuity['status']=='PASS' and continuity['source_blend_sha256']==digest
assert continuity['continuous_pitch_at_key_yaws']=='PASS' and continuity['continuous_yaw_family']=='PASS'
assert continuity['remaining_work_packages']==4
assert all(sha(HERE/'prefix_continuity'/p)==h for p,h in continuity['files'].items())
upper=read(HERE/'upper_reference_review_R1/delivery.json')
assert upper['status']=='PASS' and upper['source_blend_sha256']==digest
assert upper['upper_finite_native_clearance']=='PASS' and upper['full_harness']=='BLOCKED'
assert all(sha(HERE/'upper_reference_review_R1'/p)==h for p,h in upper['files'].items())
matched_upper=read(HERE/'upper_pairs_review_R2/delivery.json')
assert matched_upper['status']=='PASS' and matched_upper['source_blend_sha256']==digest
assert matched_upper['upper_finite_native_gap']==matched_upper['upper_finite_peer_gap']=='PASS'
assert matched_upper['full_harness']=='BLOCKED'
assert all(sha(HERE/'upper_pairs_review_R2'/p)==h for p,h in matched_upper['files'].items())
smooth_upper=read(HERE/'upper_smooth_review_R1/delivery.json')
assert smooth_upper['status']=='PASS' and smooth_upper['fit_status']=='BLOCKED'
assert smooth_upper['zero_pose_checked']==7 and smooth_upper['zero_pose_failed']==4
assert all(sha(HERE/'upper_smooth_review_R1'/p)==h for p,h in smooth_upper['files'].items())
piecewise_upper=read(HERE/'upper_smooth_review_R2/delivery.json')
assert piecewise_upper['status']=='PASS' and piecewise_upper['upper_whole_curvature_finite']=='PASS'
assert piecewise_upper['native_and_peer_gap_transfer_finite']=='PASS' and piecewise_upper['numeric_full_length_range']=='FAIL'
assert all(sha(HERE/'upper_smooth_review_R2'/p)==h for p,h in piecewise_upper['files'].items())
complete_upper=read(HERE/'complete_known_upper_review_R1/delivery.json')
assert complete_upper['status']=='PASS' and complete_upper['source_blend_sha256']==digest
assert complete_upper['numeric_known_full_length_range_finite']=='PASS' and complete_upper['known_upper_curve_poses']==910
assert complete_upper['full_harness']=='BLOCKED' and complete_upper['remaining_work_packages']==4
assert all(sha(HERE/'complete_known_upper_review_R1'/p)==h for p,h in complete_upper['files'].items())
table=''.join(f'<tr><td>{html.escape(r["family"])}</td><td>{r["variants"]}</td><td>{r["checked_prefixes"]}</td><td>零位；后续姿态未执行</td><td><a href="{r["family"]}/review.json">BLOCKED</a></td></tr>' for r in rows)
pairtable=''.join(f'<tr><td>CAM {r["pin"]} / {html.escape(r["other"])}</td><td>{r["polyline_surface_gap_mm"]:.4f} mm</td><td>{r["surface_gap_lower_mm"]:.4f} mm</td><td>{r["status"]}</td></tr>' for r in exact['rows'])
page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 线束材料与路线诊断</title>
<style>body{{max-width:1100px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}img{{width:100%;height:auto}}figure{{margin:28px 0}}table{{border-collapse:collapse;width:100%;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}.muted{{color:#586972}}.scroll{{overflow:auto}}code{{font-size:.9em}}</style>
<h1>M1.55 · 线束材料与路线诊断</h1><p>2026-10-10 · <strong>线束 BLOCKED / 未采用</strong>。批准的 R2 已应用到主模型；本页只记录后续独立研究。</p>
<p class="notice"><strong><a href="complete_known_upper_review_R1/index.html">最新：7条已知上段的长度补偿与有限间隙已核对</a></strong>。CAM四根重新匹配原余量圈；电源／CC调整原两个内部控制点，真实接口和打印件保持。130个有限姿态的整段曲率／切向接续、910个独立数值长度、2,730项最终一致数组配对及1,820项实际弧长远端自接近／自身接续通过。六条改动参考有2,340个新原生分组检查；P1实体间隙采用完全一致数组的R2偏差证明。5条缺失上段、中间角度、真实材料／端接／固定及带线装配仍未闭合；仍剩4类工作，候选未采用。</p>
<p class="notice"><strong>本轮：<a href="prefix_continuity/frame_family_R3/continuous_gaps_R1/index.html">R3参考前段连续几何已闭合</a></strong>。12条身体/颈部参考的全偏航转弯、公共数值长度根、全偏航/俯仰原生实体间隙、66组跨线与12条远端自接近通过。完整上段、真实材料/端接/夹持、实际线长和带线装配仍未闭合。<a href="prefix_continuity/index.html">剩余四项</a>持续更新，初版及R2加密失败记录保留为历史。没有新增打印件或修改主模型。</p>
<p class="notice"><strong>最新：<a href="global_bundle_layout/index.html">共同排线前段 R3</a>完成12条前段的130个组合姿态、连续弯曲和公共参考长度检查。</strong> 前段几何PASS；与现有上段参考的10,010次跨线间隙检查通过。仍有5条参考缺完整上段，完整材料长度、固定点、随动及带线装配未闭合。下方24个独立四芯失败变体保留为历史。</p>
<p class="notice"><strong><a href="upper_pairs_review_R2/index.html">本轮上段配套修正与复核</a>：纠正旧电源上段和后来CC参考混用造成的两侧净距不足，改用同组三线候选。</strong> 7条已知上段的130姿态跨线、远端参考折线和自身接续检查通过，新两根电源实体及全部前段复核通过。只调整未采用参考的假定出口各0.7mm，真实USB／PCB和主模型不动；完整连续曲率、真实端接、线长和带线闭壳仍未完成。原260条不足记录保留。</p>
<p class="notice"><strong><a href="upper_smooth_review_R2/index.html">此前上段分段曲率R2</a>：7条已知上段×130姿态，910个整段曲率和切向接续通过。</strong> 全部参考偏差≤0.0005mm，以新的偏差证明承接2,730个原生分组和2,730个上段配对检查。该版完整路线数值长度曾发现6条仍随姿态变化，CAM最多约8.49mm；已由上方长度补偿候选重匹配。旧差值记录保留，不能代表新候选。中间角度、缺失上段、材料／端接和带线装配仍未闭合。</p>
<p class="notice"><strong><a href="upper_smooth_review_R1/index.html">R1平滑拟合诊断（历史）</a>：4根CAM整段拟合在零位出现额外急弯。</strong> 后续R2已按原圆弧／直线分段解决有限姿态曲率，R1失败记录保留；不能把拟合失败当成原解析圆弧或主模型缺陷。研究均未采用，仍剩4类完整线束工作。</p>
<p class="notice"><strong><a href="upper_reference_review_R1/index.html">上一轮上段实体检查</a>：7条旧参考与当前201件实体的130个姿态间隙通过，共910条线路姿态、2,730次分组检查。</strong> CC零位Z200～206的小半径诊断已确认是细分折线三点算法的假象，原平滑曲线单独重构通过。两根旧电源上段已由上方配套候选替换；5条上段仍缺失，完整上段／线长／端接与应力释放／带线闭壳四类工作仍未完成。</p>
<p class="notice">R2 解决的是裸反力轴装入阻挡。完整线束仍有间隙、转弯、材料长度及带线装配问题，不能据此裁线或下制造单。主模型和原生硬件保持；下图橙色线是未选定的容量候选。</p>
<p><a href="../reaction_clamp_R2_adoption/index.html">R2 已采用及装配检查</a> · <a href="../../mori_v1_2.blend">当前主模型</a> · <a href="../../animation/index.html">M1.55-A1 装配视频</a> · <a href="harness_M1_55_UNADOPTED_inspection.blend">独立线束检查 Blender</a> · <a href="README.md">命令与边界</a></p>
<h2>正式交付形态保持</h2><p>CAM H06 身体端仍是 AWG28、SPH-002T-P0.5S（PH002）及 PHR-4；CAM 端保留厂配 SH 尾线。用户已接受厂家压接、身体端四个端子暂不装塑壳，装机穿线后逐个入壳。没有换成 PH004、AWG30 或自行假定厂配尾线尺寸。</p>
<p>身体 J5 的真实 PCB 型号、孔位和变换已只读核对。新增粗线测试只到候选的 Z200 接续区域；那是未选定的参考位置，不是确定的接头、夹持件或实际裁线尺寸。粗线与厂配 SH 尾线必须分开建模。</p>
<h2>厂商资料与未选定材料</h2><div class="scroll"><table><tr><th>候选</th><th>查到的资料</th><th>边界</th></tr>
<tr><td>Tensility 30-02600</td><td>AWG28，7×0.127 mm 镀锡铜；外径 1.05±0.08 mm。最大外径 1.13 mm 用于本次容量检查。<a href="materials/Tensility_30_02600.pdf">厂商图纸</a> · <a href="https://www.tensility.com/products/30-02600">厂商页面</a></td><td>线径和绝缘外径在 PH002 目录范围内；不能直接压到 SH。页面的 R6.3 未说明内侧/中心线基准，也没有头部反复运动寿命认证。若按内侧保守换算，中心线目标为 R6.865，此为推算。尚未选定、询价或验证压接。</td></tr>
<tr><td>SAB 3346 .. 28</td><td>AWG28/7，最大外径 0.93 mm。<a href="materials/SAB_single_conductors.pdf">厂商目录</a></td><td>未给最小外径，无法完整核对 PH002 的 0.8 mm 下限。目录弯曲值明确只用于一次安装弯折，不能用于反复头动。</td></tr>
<tr><td>JST PH</td><td>PH002：AWG30–24、绝缘外径 0.8–1.5 mm；PH004：AWG32–28、0.5–0.9 mm。<a href="materials/JST_PH.pdf">厂商目录</a></td><td>仅核对目录字段，PH004 未采用。完整压接外形、保护套、插合和供货工艺仍待确认。</td></tr></table></div>
<p class="muted">资料字段是 VENDOR_DOCUMENTED，未选定的线材与路线是 PLACEHOLDER / ASSUMED。没有库存、价格、压接或动态寿命放行。<a href="materials/source_facts.json">来源字段与哈希</a> · <a href="materials/retrieval.json">实际下载记录</a> · <a href="materials/render_receipt.json">PDF 渲染记录</a></p>
<h2>早期失败候选 CAD 对照</h2><figure><img src="body_neck_overview.png" alt="当前M1.55结构和未采用橙色四芯线容量候选"><figcaption>原生结构来自当前保存模型。橙色为四根 OD1.13 容量候选，灰色为七根保留参考线；没有完整 SH 尾线、压接或接续实体。显示的是 R4 的 i0.25_d1_f0.6 失败候选，用于定位。最新候选见上方共同排线R3链接。</figcaption></figure>
<figure><img src="body_neck_detail.png" alt="身体余量圈与下颈局部未通过路线"><figcaption>身体余量圈与下颈局部。不是已经完成的整束设计；后续两种并排拓扑也未通过。<a href="saved_inspection_readback.json">保存回读</a>核对了 201 件原生网格/变换、8 件复制结构和 11 条显示曲线的 float32 点位及半径。</figcaption></figure>
<h2>已执行到什么程度</h2><p>24 个未采用变体，共 96 个四芯前段的零位检查。每个变体原计划 9 个静态姿态，但都因零位未通过而停止，因此没有全姿态或完整带线装配 PASS。弯曲数字只是三点采样诊断，不能当作连续曲率或动态寿命证明。</p>
<div class="scroll"><table><tr><th>研究族</th><th>变体</th><th>前段检查</th><th>实际姿态</th><th>结果</th></tr>{table}</table></div>
<h2>保守检查与真实相交分开记录</h2><p>对展示候选的 11 个零位失败配对，另外枚举全部可能更近的线段对，并在双精度下求有限折线的最小距离。7 个具有解析答案的算法例子通过。{len(overlap)} 个配对出现线材包络相交，{len(short)} 个配对仍低于 0.3 mm 目标；{len(passing)} 个原保守失败配对通过更细复核。这里只覆盖这些配对，不覆盖真实平滑线、压接、材料或运动。</p>
<div class="scroll"><table><tr><th>配对</th><th>折线包络名义间隙</th><th>含参考误差的下界</th><th>配对结果</th></tr>{pairtable}</table></div>
<p><a href="independent_pair_diagnostic.json">精细配对报告与坐标</a> · <a href="formal_body_wire_screen.json">初始较粗线检查</a>（保留历史全前段假设，不等于最终混合线束） · <a href="port_inspection.json">原生 J5 接口记录</a> · <a href="context_receipt.json">当前模型接收边界</a></p>
<h2>接下来仍要完成</h2><ol><li>共同排线前段已通过静态几何检查，继续完成缺失上段、两端接续及完整连续转弯；不能把前段PASS作为整束PASS。</li><li>按实际端接、固定/滑移位置完成恒定材料长度、应力释放、逐根穿线、后装供电线及带线闭壳。</li><li>喇叭原线已确认是从壳体到已有插头末端 150 mm；针数、针距或插头标记正在等用户补充，用于选择真实配对件。未假定插头型号。</li><li>SC-0090-C001 实发舵盘及微雪完整 FPC/FFC 按用户决定到货后复核；开放颈壁 PA12 强度、插合及动态线束寿命仍需实物验证。</li></ol>
<p><a href="delivery.json">本页交付哈希</a> · <a href="commands.json">实际计算命令与失败重试</a> · <a href="render_manifest.json">渲染范围</a> · <a href="../../index.html?revision=V1.2-M1.55">当前机械主页</a></p><p>PROTOTYPE / UNVALIDATED · full_wired_assembly=BLOCKED · manufacturing_release=false</p></html>'''
motion=read(HERE/'upper_motion_family_R1/verification.json')
motion_pub=read(HERE/'upper_motion_family_R1/publication_verification.json')
assert motion['status']==motion_pub['status']=='PASS'
assert motion['finite_poses']==475 and motion['curve_math_checks']==3325 and motion['unique_geometry_checks']==66500
assert motion['main_sha256']==digest and motion['full_harness']=='BLOCKED'
assert all(sha(p)==h for p,h in motion['sources'].items())
assert all(sha(p)==h for p,h in motion['input_hashes'].items())
assert all(sha(HERE/'upper_motion_family_R1'/p)==h for p,h in motion_pub['files'].items())
motion_notice='<p class="notice"><strong><a href="upper_motion_family_R1/index.html">最新进度与卡点：7条已知上段在475个组合姿态复核通过</a></strong>。3,325条曲线检查和66,500项当前实体、假定USB、跨线／自接近检查通过，离散样本不是全角度证明。更短CAM尾线候选在零位与USB预留空间冲突，未采用；五条缺失上段、实际材料／端接／固定、完整带线装配仍未完成，剩4类工作。主模型及动画保持。</p>\n'
first_notice=page.index('<p class="notice"')
page=page[:first_notice]+motion_notice+page[first_notice:]
station_material=read(HERE/'restraint_station_review_R1/delivery.json')
assert station_material['status']=='PASS' and station_material['station_checks']==3800
assert station_material['actual_harness']=='BLOCKED' and not station_material['manufacturing_release']
assert all(sha(p)==h for p,h in station_material['sources'].items())
assert all(sha(HERE/'restraint_station_review_R1'/p)==h for p,h in station_material['files'].items())
station_notice='<p class="notice"><strong><a href="restraint_station_review_R1/index.html">当前CAM固定位置与实际线径复核</a></strong>：475姿态／3,800个材料位置检查完成，补偿后不再套用旧8.0–8.5mm滑移数值。正式兼容AWG28候选最大线径的身体／颈部25偏航样本及三个头部俯仰样本共1,550项检查通过；粗线不能直接沿用头内细线排布。真实分段接续、夹持与带线闭壳仍待完成，旧固定座未采用，参考长度未放行裁线。</p>\n'
assert station_material['body_material_motion_status']=='PASS' and station_material['body_material_motion_checks']==1550
page=page.replace(motion_notice,motion_notice+station_notice)
body_path=HERE/'body_restraint_review_R1/delivery.json'
body_restraint=read(body_path)
assert body_restraint['status']=='PASS' and body_restraint['actual_harness']=='BLOCKED'
assert body_restraint['body_curve_checks']==100 and body_restraint['body_native_pair_checks']==3650
assert body_restraint['body_fixture_checks']==600 and body_restraint['feature_checks']==552
assert all(sha(p)==h for p,h in body_restraint['sources'].items())
assert all(sha(body_path.parent/p)==h for p,h in body_restraint['files'].items())
body_notice='<p class="notice"><strong><a href="body_restraint_review_R1/index.html">CAM身体端固定候选与装桥顺序</a></strong>：一体短座与一根扎带，无新增打印件或螺钉。新4根的全偏航数值长度／转弯、当前201件实体全偏航／俯仰、38跨线／4远端自身，以及12前段对新固定结构的全偏航检查通过。<a href="body_restraint_review_R1/tie_access_review_R1/index.html">两端先不连接、平直放开、桥外剪尾，再装桥</a>：3个工具方向的连续包络进入、4根CAM×2种准备装桥和新增座／扎带路径通过；保留83件此前刚体，86对象／祖先变换通道另检。实际端子／钳口／穿扣／夹持、柔性整理、其他线路及完整闭壳仍待完成。主模型和视频未采用；完整目标仍剩4类工作。</p>\n'
page=page.replace(station_notice,station_notice+body_notice)
upper_math_path=HERE/'upper_continuity_review_R1/delivery.json'
upper_math=read(upper_math_path)
upper_math_verified=read(upper_math_path.parent/'publication_verification.json')
assert upper_math['status']==upper_math_verified['status']=='PASS' and upper_math['full_harness']=='BLOCKED'
assert upper_math['continuous_power_root_and_bending']=='PASS' and upper_math['accepted_rectangles']==18095
assert upper_math['continuous_native_clearance']=='PASS' and upper_math['native_angular_rectangles']==19068
assert upper_math['continuous_peer_clearance']==upper_math['continuous_CAM_math']=='PASS'
assert upper_math['power_peer_unordered_pairs']==3
assert upper_math['CAM_positive_length_rectangles']==2592 and upper_math['CAM_saved_curve_readbacks']==1900
assert upper_math['CAM_continuous_native_clearance']==upper_math['CAM_continuous_peer_clearance']=='PASS'
assert upper_math['CAM_peer_unordered_pairs']==6 and upper_math['CAM_power_cross_pairs']=='PASS'
assert upper_math['CAM_power_cross_unordered_pairs']==12 and upper_math['known_upper_unordered_pairs']==21
assert upper_math['CAM_native_source_math_rectangles']==2592 and upper_math['known_upper_native_references']==7
assert upper_math['CAM_fixed_tail_remote_self']=='PASS' and upper_math['CAM_fixed_tail_self_parameter_cells']==64000
assert upper_math['CAM_continuous_upper_remote_self']=='PASS' and upper_math['CAM_moving_lower_self']=='PASS'
assert upper_math['power_continuous_remote_self']==upper_math['known_upper_continuous_remote_self']=='PASS'
assert upper_math['known_upper_remote_self_references']==7
assert upper_math['known_continuous_own_prefix']==upper_math['known_continuous_other_prefix']=='PASS'
assert upper_math['prefix_upper_comparisons']==84 and upper_math['own_prefix_pairs']==7 and upper_math['other_prefix_pairs']==77
assert upper_math_verified['delivery_sha256']==sha(upper_math_path)
assert all(sha(p)==h for p,h in upper_math['sources'].items())
assert all(sha(upper_math_path.parent/p)==h for p,h in upper_math['files'].items())
upper_math_notice=(
    '<p class="notice"><strong><a href="upper_continuity_review_R1/index.html">最新已知线路连续检查</a></strong>：'
    '7条已知上段的全名义偏航／俯仰长度、弯折、201件模型实体间隙、全部21组互线及全部非局部自身通过。'
    '<a href="upper_continuity_review_R1/prefix_upper_join_review_R1/index.html">与12条身体前段的84组接续／跨线</a>'
    '随后完整通过，含7组自身接续、77组其他前段；'
    f"{upper_math['prefix_upper_angular_rectangles']:,}个角度区间／{upper_math['prefix_upper_parameter_rectangles']:,}个必要二维参数区间独立核对，原0.3mm目标保持。"
    '五条缺实际端点线路、真实材料／粗细线接续／裁线、配对端子／应力释放及带线闭壳仍未完成，剩4类工作。'
    '主模型与视频未采用。</p>\n')
page=page.replace(body_notice,body_notice+upper_math_notice)
terminal_path=HERE/'material_terminal_review_R1/delivery.json'
terminal_preflight=read(terminal_path)
terminal_verified=read(terminal_path.parent/'publication_verification.json')
assert terminal_preflight['status']==terminal_verified['status']=='PASS'
assert terminal_verified['delivery_sha256']==sha(terminal_path)
assert terminal_preflight['formal_pin_rows']==4 and terminal_preflight['PDF_sources']==3
assert terminal_preflight['actual_material_and_connection_qualification']=='BLOCKED'
assert not terminal_preflight['formal_H06_changed'] and not terminal_preflight['wire_selected']
assert all(sha(p)==h for p,h in terminal_preflight['sources'].items())
assert all(sha(terminal_path.parent/p)==h for p,h in terminal_preflight['files'].items())
terminal_notice=('<p class="notice"><strong><a href="material_terminal_review_R1/index.html">H06端子、线材与制作要求预筛</a></strong>：'
                 '原厂PH／SH端子范围、候选线材字段及四针针序已独立核对；现行PH002／AWG28＋厂配尾线保持。'
                 '整条细AWG28／PH004只是未采用方向，线径公差、弯折、实际CAM配对及压接尚未闭合。'
                 '<a href="material_terminal_review_R1/supplier_requirements_DRAFT.md">制作资料准备稿</a>和逐针表已备好，实际裁线保持空白。'
                 '喇叭插头参数待用户到公司后补充，150mm线长已记录。完整目标仍剩4类工作，主模型／视频保持。</p>\n')
page=page.replace(upper_math_notice,upper_math_notice+terminal_notice)
entry_path=HERE/'terminal_install_review_R1/delivery.json'
entry_review=read(entry_path)
entry_verified=read(entry_path.parent/'publication_verification.json')
assert entry_review['status']==entry_verified['status']=='PASS'
assert entry_verified['delivery_sha256']==sha(entry_path)
assert entry_review['bare_contact_continuous_native_clearance']=='PASS'
assert entry_review['closed_intervals']==6090 and entry_review['current_native_parts_at_stage']==197
assert entry_review['full_harness']=='BLOCKED' and not entry_review['gentler_candidates_adopted']
assert all(sha(p)==h for p,h in entry_review['sources'].items())
assert all(sha(entry_path.parent/p)==h for p,h in entry_review['files'].items())
entry_notice=('<p class="notice"><strong><a href="terminal_install_review_R1/index.html">当前裸端子容量装入与改缓路径诊断</a></strong>：'
              '原单端子轨迹已对M1.55装入阶段197件原生实体重查，两种包络共6,090个闭运动区间通过；'
              '保护容量包络的最小下界约0.396mm，原0.3mm目标保持。另有384个区间内部姿态独立回读。'
              '98个改缓搜索未取得通过，均未采用；失败不证明其他路径不可行，也不代表主模型故障。'
              '真实压接、附着导线弯折、四根逐根穿入／其他线路及闭壳仍未完成；'
              'Daburn技术询问待对外发信授权。完整目标仍剩4类工作，主模型／视频保持。</p>\n')
page=page.replace(terminal_notice,terminal_notice+entry_notice)
prelaid_path=HERE/'staged_prefix_entry_review_R1/delivery.json'
prelaid=read(prelaid_path)
prelaid_verified=read(prelaid_path.parent/'publication_verification.json')
assert prelaid['status']==prelaid_verified['status']=='PASS'
assert prelaid_verified['delivery_sha256']==sha(prelaid_path)
assert prelaid['prelaid_prefix_entry']=='BLOCKED' and prelaid['collision_witnesses']==12
assert prelaid['moving_native_parts']==21 and prelaid['stationary_prior_native_parts']==102
assert all(sha(p)==h for p,h in prelaid['sources'].items())
assert all(sha(prelaid_path.parent/p)==h for p,h in prelaid['files'].items())
prelaid_notice='''<p class="notice"><strong><a href="staged_prefix_entry_review_R1/index.html">装配准备诊断：最终前段不能直接预铺后下放驱动座</a></strong>。回读实际动画的21件驱动座分总成和102件此前固定实体；12条R3身体／颈部容量前段保持最终原形时，下放到Z32mm全部与Pitch_Yoke相交，12处独立探针复现。该准备方式BLOCKED／未采用，临时自由端与柔性整理仍需设计；Z200只是数学切点，不是实际线端。主模型、顺序和视频保持。</p>'''
page=page.replace(entry_notice,entry_notice+prelaid_notice)
moving_path=HERE/'moving_bundle_entry_review_R1/delivery.json'
moving_bundle=read(moving_path)
moving_verified=read(moving_path.parent/'publication_verification.json')
assert moving_bundle['status']==moving_verified['status']=='PASS'
assert moving_verified['delivery_sha256']==sha(moving_path)
assert moving_bundle['moving_bundle_entry']=='BLOCKED' and moving_bundle['reference_sections']==19
assert moving_bundle['prefix_sections']==12 and moving_bundle['available_upper_sections']==7
assert moving_bundle['independently_replayed_collisions']==10
assert all(sha(p)==h for p,h in moving_bundle['sources'].items())
assert all(sha(moving_path.parent/p)==h for p,h in moving_bundle['files'].items())
phr4_path=HERE/'phr4_source_review_R1/delivery.json'
phr4=read(phr4_path)
phr4_verified=read(phr4_path.parent/'publication_verification.json')
assert phr4['status']==phr4_verified['status']=='PASS'
assert phr4_verified['delivery_sha256']==sha(phr4_path)
assert phr4['documented_numeric_fields']==9 and phr4['actual_mating']=='BLOCKED'
assert not phr4['CAD_data_received'] and not phr4['customer_form_submitted']
assert all(sha(p)==h for p,h in phr4['sources'].items())
assert all(sha(phr4_path.parent/p)==h for p,h in phr4['files'].items())
phr4_capacity_path=HERE/'phr4_mating_capacity_R1/delivery.json'
phr4_capacity=read(phr4_capacity_path)
phr4_capacity_verified=read(phr4_capacity_path.parent/'publication_verification.json')
assert phr4_capacity['status']==phr4_capacity_verified['status']=='PASS'
assert phr4_capacity_verified['delivery_sha256']==sha(phr4_capacity_path)
assert phr4_capacity['conditional_external_box_capacity']=='PASS' and phr4_capacity['fixed_head_service_probes']=='BLOCKED'
assert phr4_capacity['independently_replayed_service_witnesses']==20
assert phr4_capacity['capacity_intersections']==18 and phr4_capacity['planning_gap_only_violations']==2
assert phr4_capacity['actual_mating']=='BLOCKED' and phr4_capacity['remaining_work_packages']==4
assert all(sha(p)==h for p,h in phr4_capacity['sources'].items())
assert all(sha(phr4_capacity_path.parent/p)==h for p,h in phr4_capacity['files'].items())
body_first_path=HERE/'body_first_connection_R1/delivery.json'
body_first=read(body_first_path)
body_first_verified=read(body_first_path.parent/'publication_verification.json')
assert body_first['status']==body_first_verified['status']=='PASS'
assert body_first_verified['delivery_sha256']==sha(body_first_path)
assert body_first['early_body_mating_capacity']==body_first['prelaid_reference_bridge_entry']=='BLOCKED'
assert body_first['reference_sections']==19 and body_first['verified_bridge_witnesses']==38
assert body_first['capacity_intersections']==36 and body_first['planning_gap_only_violations']==2
assert body_first['saved_bridge_actor_pose_readbacks']==85 and body_first['prior_native_parts']==83
assert body_first['already_mated_empty_housing_contact_insertion']=='BLOCKED' and not body_first['assembly_order_changed']
assert all(sha(p)==h for p,h in body_first['sources'].items())
assert all(sha(body_first_path.parent/p)==h for p,h in body_first['files'].items())
moving_notice='''<p class="notice"><strong><a href="moving_bundle_entry_review_R1/index.html">松线束整体随驱动座下放：当前失败准备</a></strong>。12条身体前段和7条可用上段均参与，19个分段共同平移；10条身体前段在下放途中与固定Yaw_Base相交，10处独立复现。两条喇叭预留前段及7上段在此路径范围内通过，不能据此放行整束。候选未采用，实际自由端／临时整理／分步穿线／闭壳仍待完成。</p>'''
phr4_notice='''<p class="notice"><strong><a href="phr4_source_review_R1/index.html">PHR-4公开资料与详细CAD边界</a></strong>。配对对象是运动P5R7的J5；公开目录两页、9个数值字段已核对，外形9.8×4.5×6.85mm。详细CAD需登记后邮件领取，尚未取得或提交个人／公司资料；内腔、线口／插深／压接和实际插合仍BLOCKED，未新增完整壳体到主模型。</p>'''
phr4_capacity_notice='''<p class="notice"><strong><a href="phr4_mating_capacity_R1/index.html">身体插头外形容量与带线插合诊断</a></strong>。假定基准的外形框整段平移及246项实体容量检查通过；这不是内腔／端子插合。短段提线7种均弯曲不足；第一处弯整体随动5种通过有限弯曲预检，但均在中途与固定Yaw_Base净距冲突。20处独立复现：18处容量管相交、2处低于0.3mm规划净距。主模型／视频未改；临时整理／分步穿线和整束闭壳继续未完成。</p>'''
body_first_notice='''<p class="notice"><strong><a href="body_first_connection_R1/index.html">先接身体端，再装桥的比较</a></strong>。83件此前刚体保留；提前插合最高抬起量处CAM1／CAM3规划净距不足。预铺全部19参考时，原桥路径与直落候选各19处失败，38处独立复现（36相交／2净距不足）；6件桥分总成和85个真实演员姿态核对。厂家通用处理要求已补入，但没有PH“已插空壳再装端子”的专用方法确认。两候选未采用，仍需分步穿线／临时整理与整束闭壳。</p>'''
page=page.replace(prelaid_notice,prelaid_notice+moving_notice+phr4_notice+phr4_capacity_notice+body_first_notice)
(HERE/'index.html').write_text(page)
(HERE/'README.md').write_text('''# M1.55 线束研究：未采用

R2 已采用；本目录只记录后续独立线束研究，不改变主模型或硬件。
当前汇总在 [检查页](index.html)。路线与线材仍是 PLACEHOLDER / ASSUMED，
厂商外径/线规等字段单独标注 VENDOR_DOCUMENTED。

正式 H06 保持 PH 侧 AWG28＋厂配 SH 尾线，PH002/PHR-4 保持。
工厂压接、身体端暂不装壳已获用户确认。并未确认材料型号或最终裁线图。

24 个路线变体都在零位失败，共96个四芯前段检查；规划的后续姿态未执行。
独立折线诊断区分相交、正间隙不足及保守下界不足。有限失败不能证明没有其他路线。
R4 检查 Blender 只是失败位置的可编辑展示，未加入主模型。

最新共同排线前段R3与这24个失败变体分开记录：[当前检查](global_bundle_layout/index.html)。
12条前段的130个静态组合姿态、连续转弯和公共参考长度通过，现有上段的
10,010次跨线间隙比较通过；5条参考缺完整上段。完整线束与带线装配仍BLOCKED。
没有把未采用候选或原始研究自动应用到主模型。

最新[已知上段长度补偿](complete_known_upper_review_R1/index.html)完成CAM四根、
电源／CC两根的130姿态补偿与新间隙检查。独立汇总910个数值长度，按最终一致
数组替换旧配对得到2730项，补完P1实际弧长自接近／接续后共1820项通过。
旧R2的8.49mm长度差保留为历史。5条缺失上段、中间角度、真实材料／端接／固定
和带线装配仍未完成；当前模型和视频未采用候选，仍剩4类工作。

历史[上段平滑拟合诊断R1](upper_smooth_review_R1/index.html)完成7条已知上段的零位检查。
2根电源及CC通过，4根CAM拟合未通过；未运行其余129姿态或新曲线间隙。
失败属于新拟合，不能据此把原解析圆弧或主模型判断为缺陷。仍剩4类完整线束工作。

最新[上段分段曲率R2](upper_smooth_review_R2/index.html)完成7条×130姿态的整段曲率与切向接续，
910次通过。70条进一步精化、840条按完全一致数组保留；新偏差界承接2730个原生分组
及2730个上段配对检查，原BVH／配对没有重跑。完整参考数值长度另检发现6条仍变化，
CAM最多约8.49mm，需要重匹配原上段补偿。真实弧长自接近、中间角度、材料／端接、
缺失5条上段和带线装配仍未闭合。没有改变主模型或动画。

本轮[连续运动与剩余四项](prefix_continuity/index.html)记录13档偏航下的完整
连续俯仰PASS，以及初版−55°偏航过渡族的3个实际转弯失败点。
四个未完成工作包与真实端接依赖分开列出，未按比例宣称整束完成。
最新R3完成12条参考的全偏航转弯界与公共数值参考长度连续根，25档独立
实体/跨线/连续俯仰检查通过。continuous_gaps_R1随后独立完成全偏航/俯仰实体间隙、
66组跨线与12条远端自接近。完整上段、真实材料/端接/夹持、实际线长和带线装配仍未闭合。

本轮[上段有限检查](upper_reference_review_R1/index.html)完成7条参考的130姿态实体间隙，
共910条线路姿态、2,730次分组检查。CC零位Z200..206的三点小半径属于细分折线
诊断假象，原平滑曲线单独重构。没有扩为完整上段或全角度PASS，仍剩四类工作。

最新[上段配套R2](upper_pairs_review_R2/index.html)修正旧电源上段与后来CC候选混用：
两根假定出口各向外0.7mm，不移动真实USB／PCB。2,730个上段配对、910个远端
参考折线及910个自身接续通过；新电源780个原生分组检查（含一行同折线精化）、
312个接续段／前段配对与260个凸包分离界通过。原260条不足记录保留，完整线束仍BLOCKED。

## 实际运行方式

在当前工作树根目录运行（每个脚本读取同一 M1.55 保存源）：

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend --python mechanical/studies/harness_current_M1_55/context.py
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend --python mechanical/studies/harness_current_M1_55/inspect_ports.py
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend --python mechanical/studies/harness_current_M1_55/screen_formal_body_wire.py
```

同样的命令前缀分别执行 screen_body_relayout.py、screen_body_relayout_R2.py、
screen_body_relayout_R3.py、screen_body_relayout_R4.py、screen_body_bundle_R5.py、
screen_body_bundle_R6.py、independent_pair_diagnostic.py、render_review.py
和 verify_saved_inspection.py。每项有对应 `.log`；完整命令见 commands.json。

Blender 无 SciPy，首次精细诊断失败，后来改用可用的 KDTree；
另一次 JSON 写入因 NumPy float32 失败，原日志保留；成功报告才作为证据。
保存回读首次使用固定 1e-5 mm 误差失败：Blender 实际存 float32，
后续改为逐点、逐半径匹配精确的 float32 表示，同时记录真实量化误差。
这没有移动曲线或放宽原 0.3 mm 净距目标。
JST PDF 首次 Poppler 渲染缺字，保留记录，改用 PDFium 并目视核对相同原文件。

打印件、主模型和正式物料均未采用这里的候选。完整长度补偿、端接、动态寿命
和带线装配仍 BLOCKED / NOT_TESTED，manufacturing_release=false。
''')
(HERE/'README.md').write_text((HERE/'README.md').read_text()+'''\n最新[CAM身体端固定研究](body_restraint_review_R1/index.html)建立一体短座与一根扎带候选，
无新增打印件或螺钉。100条有限曲线、3650项实体／配对、600项线与固定结构、552项固定结构检查通过。
后续已补四根新身体段全偏航数值长度／转弯、当前201实体全偏航／俯仰、38跨线／4远端自身，
以及12前段与新座／带身／扣头的全偏航检查。新版扎带补带根／回穿／余尾；未剪长尾碰托板／电源板。
两端先不连接、平直放开，桥外剪尾再装桥：3个工具方向、4根CAM×2种准备及新增结构路径通过。
保留83件此前刚体，86对象／祖先完整变换通道另检；实际端子／手部／穿扣／夹持及完整闭壳仍未完成。
仅是独立原型；实际装入、工具操作、夹持和完整带线装配未闭合，主模型／视频未采用。
J5原生针号图已补齐，不替代PHR-4腔体识别或实际导通。完整目标仍剩4类工作。\n''')
(HERE/'README.md').write_text((HERE/'README.md').read_text()+'''\n最新[电源／CC上段连续检查](upper_continuity_review_R1/index.html)完成3条上部参考的全偏航／俯仰长度根与弯折。
18,095个二维角度区间及独立覆盖检查通过；1,425条原保存曲线、18条非网格构造另检，原端点逐位保持。
三条与当前201实体的全名义偏航／俯仰间隙另经19,068个二维区间检查通过；独立覆盖及完整参数区间核对通过。
三组电源／CC全范围互线间隙随后通过，父区间交集与细分覆盖独立核对。
四条[CAM新名义数学参考](upper_continuity_review_R1/cam_math_review_R1/index.html)完成全范围长度／弯折，
48个身体接续偏航区间、2,592个长度二维区间及1,900条保存曲线回读通过。
一致名义框架与80位构造不等于原浮点数组逐位一致，新CAM间隙不能继承旧有限结果。
新CAM随后独立完成当前201模型的全范围实体间隙，2,592个父区间及必要细分覆盖核对通过，包含零角度退化槽。
四条头内固定尾线的非局部自身检查随后PASS，64,000个闭参数区间与源核对完成。
四条完整CAM上段的非局部自身检查随后独立通过，包含48个扇出偏航区间、2,592个活动二维角度区间及固定尾线的互斥完整组合。
四条CAM上段的6组内部互线随后完成全偏航／俯仰和完整曲线参数检查，三类组合的完整／互斥分类独立核对通过。
与电源／CC的12组跨组配对随后通过；1,562个角度区间和必要组合5,985个二维参数区间独立核对。
7条已知上段全部21组互线组合无重复、无遗漏，原0.3mm目标保持。
电源／CC完整自身随后通过；418个角度区间、39,687个二维参数区间独立核对，与CAM合并后7条已知上段全部非局部自身齐全。
身体前段与七条已知上段的84组名义接续／跨线随后完整通过：
7组同线自身接续、77组其他前段，9,072个角度区间／4,185个参数区间独立核对，
两侧分别使用源线径参考、原0.3mm目标保持。
五条缺真实端点线路，以及实际材料／粗细线接续／裁线、端接／完整带线装配仍未闭合。
这不放行实际裁线或制造；当前主模型、视频保持，完整目标仍剩4类工作。\n''')
(HERE/'README.md').write_text((HERE/'README.md').read_text()+'''\n[H06材料与端接预筛](material_terminal_review_R1/index.html)已完成原厂字段、
四针针序及条件线径区间核对。现行PH002／AWG28＋厂配尾线保持；
PH004整条细线未采用，实际线材／压接／CAM配对／裁线仍BLOCKED。
[制作资料准备稿](material_terminal_review_R1/supplier_requirements_DRAFT.md)不放行制造。
SP3040插头参数待用户到公司后补充，已确认150mm线长保持。\n''')
(HERE/'README.md').write_text((HERE/'README.md').read_text()+'''\n[当前裸端子容量装入](terminal_install_review_R1/index.html)新增对M1.55阶段197件
实体的完整检查：原单端子轨迹两种包络共6,090个闭运动区间PASS，
384个内部姿态独立回读；不是实际压接、附着导线或四根带线装配资格。
98个改缓搜索未采用，不能据此判定无其他路线或主模型故障。
Daburn技术资料询问稿NOT_SENT，等待明确发信授权。\n''')
command_rows=[]
scripts=['context.py','inspect_ports.py','screen_formal_body_wire.py','screen_body_relayout.py',
         'screen_body_relayout_R2.py','screen_body_relayout_R3.py','screen_body_relayout_R4.py',
         'screen_body_bundle_R5.py','screen_body_bundle_R6.py','independent_pair_diagnostic.py',
         'render_review.py','verify_saved_inspection.py']
for name in scripts:
    log=HERE/(Path(name).stem+'.log');assert log.is_file()
    assert 'Traceback (most recent call last)' not in log.read_text()
    command_rows.append(dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','mechanical/mori_v1_2.blend',
                                     '--python',str((HERE/name).relative_to(PROJECT))],cwd=str(PROJECT),
                             log=str(log.relative_to(PROJECT)),log_sha256=sha(log),
                             scope='Execution and reports only; failed geometry candidates are retained as BLOCKED'))
commands=dict(status='PASS',revision='V1.2-M1.55',Blender='5.2.2 LTS d13f752e3b9c',
    commands=command_rows,publish_command=['/Users/dean/.cache/codex-runtimes/mori-cad/bin/python',str(Path(__file__))],
    initial_attempt_logs=['independent_pair_diagnostic_initial.log','independent_pair_diagnostic_json_failure.log',
                          'render_review_initial.log','verify_saved_inspection_initial.log'],
    source_download_receipt='materials/retrieval.json',PDF_render_receipt='materials/render_receipt.json',
    main_changed=False,hardware_changed=False,manufacturing_release=False)
(HERE/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
files=[p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.blend1'
       and p.name not in ['delivery.json','publication_verification.json','publish_study.log','verify_publication.log']]
receipt=dict(status='PASS',scope='Research publication only; old isolated variants BLOCKED, current joint prefixes scoped PASS; full harness BLOCKED',
    published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',
    source_blend_sha256=digest,unchanged_current_native_parts=201,variant_families=rows,
    variant_count=24,zero_pose_prefix_checks=96,actual_poses=[[0,0]],full_harness='BLOCKED',
    joint_prefix_geometry='PASS',joint_prefix_static_poses=130,joint_prefix_delivery_sha256=sha(HERE/'global_bundle_layout/delivery.json'),
    continuity_delivery_sha256=sha(HERE/'prefix_continuity/delivery.json'),
    upper_reference_delivery_sha256=sha(HERE/'upper_reference_review_R1/delivery.json'),
    upper_finite_native_clearance='PASS',upper_available_references=7,upper_static_poses=130,
    matched_upper_delivery_sha256=sha(HERE/'upper_pairs_review_R2/delivery.json'),
    matched_upper_finite_native_gap='PASS',matched_upper_finite_peer_gap='PASS',
    matched_upper_known_references=7,matched_upper_reference_checks=4550,
    matched_upper_scope='Finite reference checks; local smooth tube, interpose motion and real endpoints unresolved',
    continuous_pitch_at_key_yaws='PASS',continuous_yaw_family='PASS',remaining_work_packages=4,
    continuous_yaw_family_scope='Unadopted body/neck capacity prefixes only; full harness BLOCKED',
    continuous_bend_across_yaw='PASS',continuous_numerical_reference_length_root='PASS',
    continuous_native_gap_across_yaw='PASS',continuous_peer_gap_across_yaw='PASS',continuous_remote_self_across_yaw='PASS',
    complete_known_upper_delivery_sha256=sha(HERE/'complete_known_upper_review_R1/delivery.json'),
    numeric_known_full_length_range_finite='PASS',known_upper_curve_poses=910,
    final_unique_upper_peer_checks=2730,actual_arc_self_and_own_join_checks=1820,
    upper_motion_verification_sha256=sha(HERE/'upper_motion_family_R1/verification.json'),
    upper_motion_sampled_native_and_peer_gap='PASS',upper_motion_sampled_poses=475,
    upper_motion_curve_math_checks=3325,upper_motion_unique_geometry_checks=66500,
    station_material_delivery_sha256=sha(HERE/'restraint_station_review_R1/delivery.json'),
    station_material_checks=3800,body_material_motion_finite_checks=1550,
    body_restraint_delivery_sha256=sha(body_path),body_restraint_curve_checks=100,
    body_restraint_native_pair_checks=3650,body_restraint_fixture_checks=600,body_restraint_feature_checks=552,
    upper_power_math_delivery_sha256=sha(upper_math_path),upper_power_continuous_length_and_bending='PASS',
    upper_power_math_known_references=3,upper_power_math_accepted_rectangles=18095,
    upper_power_continuous_native_gap='PASS',upper_power_native_angular_rectangles=19068,
    upper_power_native_motion_scope='Ideal nominal rotations; actual USB geometry and all-angle Float32 helper rounding unqualified',
    upper_power_continuous_peer_gap='PASS',upper_power_peer_angular_rectangles=upper_math['power_peer_angular_rectangles'],
    upper_power_peer_source_intersections=upper_math['power_peer_source_intersections'],
    CAM_tiny_angle_origin_diagnostic='PASS',upper_CAM_continuous_math='PASS',
    upper_CAM_math_scope=upper_math['CAM_math_scope'],upper_CAM_positive_length_rectangles=2592,
    upper_CAM_saved_curve_readbacks=1900,upper_CAM_continuous_native_gap='PASS',
    upper_CAM_native_angular_rectangles=upper_math['CAM_native_angular_rectangles'],
    upper_CAM_native_source_math_rectangles=2592,known_upper_native_references=7,
    upper_CAM_continuous_peer_gap='PASS',upper_CAM_peer_unordered_pairs=6,
    upper_CAM_power_cross_pairs='PASS',upper_CAM_power_cross_unordered_pairs=12,
    known_upper_continuous_mutual='PASS',known_upper_unordered_pairs=21,
    upper_power_continuous_remote_self='PASS',upper_power_self_angular_rectangles=418,
    known_upper_continuous_remote_self='PASS',known_upper_remote_self_references=7,
    known_continuous_own_prefix='PASS',known_continuous_other_prefix='PASS',
    prefix_upper_comparisons=84,own_prefix_pairs=7,other_prefix_pairs=77,
    prefix_upper_angular_rectangles=upper_math['prefix_upper_angular_rectangles'],
    prefix_upper_parameter_rectangles=upper_math['prefix_upper_parameter_rectangles'],
    upper_CAM_fixed_tail_remote_self='PASS',upper_CAM_fixed_tail_self_parameter_cells=64000,
    upper_CAM_moving_lower_self='PASS',upper_CAM_continuous_upper_remote_self='PASS',
    upper_CAM_self_mixed_angular_rectangles=2592,
    unpublished_research_directories=[],
    actual_material_splice_and_restraint='BLOCKED',
    terminal_material_preflight_delivery_sha256=sha(terminal_path),terminal_range_preflight='PASS',
    formal_H06_changed=False,actual_material_and_connection_qualification='BLOCKED',
    speaker_connector_information='BLOCKED: user will provide after reaching office',
    bare_contact_entry_delivery_sha256=sha(entry_path),bare_contact_continuous_native_clearance='PASS',
    bare_contact_closed_intervals=6090,bare_contact_current_native_parts_at_stage=197,
    bare_contact_interior_pose_checks=384,actual_attached_wire_entry='NOT_TESTED',
    prelaid_prefix_entry_delivery_sha256=sha(prelaid_path),prelaid_prefix_entry='BLOCKED',
    prelaid_prefix_verified_collision_witnesses=12,temporary_full_harness_entry='NOT_TESTED',
    moving_bundle_entry_delivery_sha256=sha(moving_path),moving_bundle_entry='BLOCKED',
    moving_bundle_reference_sections=19,moving_bundle_replayed_collisions=10,
    PHR4_source_delivery_sha256=sha(phr4_path),PHR4_public_documented_numeric_fields=9,
    PHR4_detailed_CAD_received=False,PHR4_actual_mating='BLOCKED',
    PHR4_capacity_delivery_sha256=sha(phr4_capacity_path),PHR4_conditional_external_box_capacity='PASS',
    PHR4_fixed_head_service_probes='BLOCKED',PHR4_replayed_service_witnesses=20,
    PHR4_service_capacity_intersections=18,PHR4_service_planning_gap_only_violations=2,
    body_first_sequence_delivery_sha256=sha(body_first_path),body_first_early_connection='BLOCKED',
    prelaid_reference_bridge_entry='BLOCKED',body_first_reference_sections=19,
    body_first_verified_bridge_witnesses=38,body_first_bridge_capacity_intersections=36,
    body_first_bridge_planning_gap_only_violations=2,body_first_bridge_actor_readbacks=85,
    general_JST_handling_requirements='PASS',already_mated_empty_housing_contact_insertion='BLOCKED',
    wire_supplier_technical_inquiry='NOT_SENT: explicit user authorization pending',
    main_changed=False,hardware_changed=False,material_selected=False,manufacturing_release=False,
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(files)})
assert sha(ROOT/'mori_v1_2.blend')==digest
(HERE/'delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('M1_55_HARNESS_RESEARCH_PUBLISHED',len(files),'files; 24 unadopted variants; current main unchanged',flush=True)
