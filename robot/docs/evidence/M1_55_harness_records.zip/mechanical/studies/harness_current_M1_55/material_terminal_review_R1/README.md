# H06 terminal and material preflight

Read-only electrical pin-map receipt and manufacturer-field comparison.
The formal PH002/AWG28 plus factory SH tail remains unchanged.

PH002 OD0.8..1.5 and catalogue SH0.4..0.8 intersect only at0.8.
With the current head-reference maximum OD0.6604, that uniform-wire
interval is empty. PH0040.5..0.9 gives a possible0.5..0.6604 interval.
This does not prove the actual CAM mating connector or crimps.

Daburn2420/28:AWG28,65/46,FEP,nominal OD0.559mm only.
Maximum/minimum OD and numeric bend radius remain null, so actual
route/crimp qualification stays BLOCKED. Alpha2842/7 maximum OD0.7366
exceeds the current head-reference allocation. Neither is selected.

Supplier worksheet preserves all four formal same-number pin mappings
and the reference-only Gauss64 lengths. All actual cuts/splices/terminal
outlines, colours and actual CAM part numbers remain null or blank.
No supplier contact, order, hardware/main/animation change or release.
