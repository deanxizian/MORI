"""Publish source-backed H06 preparation, keeping all actual interfaces blocked."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import datetime
import hashlib
import importlib.metadata
import json
import sys
import urllib.request

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        self.links.extend(value for key, value in attrs if key in ['href', 'src'])


def main():
    audit = read(HERE / 'preflight_verification.json')
    data = read(HERE / 'preflight.json')
    assert audit['status'] == data['status'] == 'PASS'
    assert audit['pin_rows'] == 4 and audit['PDF_sources'] == 3
    assert audit['actual_material_and_connection_qualification'] == data['full_harness'] == 'BLOCKED'
    assert not data['PH004_adopted'] and not data['wire_selected']
    assert not any(data[k] for k in ['main_changed', 'hardware_changed', 'animation_changed', 'manufacturing_release'])
    sources = dict(audit['sources'])
    sources[str(HERE / 'preflight_verification.json')] = sha(HERE / 'preflight_verification.json')
    sources[str(Path(__file__))] = sha(Path(__file__))
    assert all(sha(p) == h for p, h in sources.items())
    logs = ['fetch_sources.log', 'inspect_sources.log', 'build_preflight.log', 'verify_preflight.log']
    assert all('Traceback (most recent call last)' not in (HERE / n).read_text() for n in logs)
    commands = dict(
        status='PASS', python=sys.executable, version=sys.version,
        packages={n: importlib.metadata.version(n) for n in ['pypdf', 'pypdfium2']},
        commands=[dict(script=s, log=l, exit_code=0) for s, l in zip(
            ['fetch_sources.py', 'inspect_sources.py', 'build_preflight.py', 'verify_preflight.py'], logs)],
        publication_command=[sys.executable, str(Path(__file__))],
        PDF_review='Source bytes unchanged; completed relevant page field review only',
        full_harness='BLOCKED', manufacturing_release=False)
    (HERE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    protected = read(PROJECT / 'mechanical/input_assets/M1_55_reaction_entry_baseline.json')['protected_hardware']
    protected = {p: h for p, h in protected.items() if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT / p) == h for p, h in protected.items())
    assert sha(PROJECT / 'mechanical/mori_v1_2.blend') == '3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT / 'mechanical/animation/MORI_assembly.mp4') == '9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    files = {str(p.relative_to(HERE)): sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in
             ['delivery.json', 'publication_verification.json', 'publish_review.log']}
    delivery = dict(
        status='PASS', scope='Published source and conditional preflight only; no material, crimp or routing qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=sources, files=files,
        formal_pin_rows=4, PDF_sources=3, reviewed_source_images=3, terminal_range_preflight='PASS',
        actual_material_and_connection_qualification='BLOCKED', actual_supplier_cut_lengths='BLOCKED',
        full_harness='BLOCKED', formal_H06_changed=False, PH004_adopted=False, wire_selected=False,
        protected_hardware_files=846, main_changed=False, hardware_changed=False, animation_changed=False,
        manufacturing_release=False)
    (HERE / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
    assert all(sha(p) == h for p, h in sources.items())
    assert all(sha(HERE / p) == h for p, h in files.items())
    parser = Links()
    parser.feed((HERE / 'index.html').read_text())
    targets = [HERE / 'index.html']
    for link in parser.links:
        parsed = urlsplit(link)
        if not parsed.scheme and parsed.path:
            targets.append((HERE / unquote(parsed.path)).resolve())
    served = []
    for p in dict.fromkeys(targets):
        relative = p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/' + relative, timeout=10) as response:
            assert response.status == 200 and response.read() == p.read_bytes(), relative
        served.append(dict(path=relative, sha256=sha(p)))
    receipt = dict(
        status='PASS', scope='Retained source and served byte verification only',
        delivery_sha256=sha(HERE / 'delivery.json'), verified_files=len(files), verified_sources=len(sources),
        served_links=len(served), served=served, protected_hardware_files=846,
        full_harness='BLOCKED', main_changed=False, hardware_changed=False, animation_changed=False,
        manufacturing_release=False)
    (HERE / 'publication_verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('H06_PREFLIGHT_PUBLICATION_VERIFIED', len(files), len(served), len(protected), flush=True)


if __name__ == '__main__':
    main()
