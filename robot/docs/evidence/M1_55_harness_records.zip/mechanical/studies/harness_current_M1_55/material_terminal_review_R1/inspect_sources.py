"""Extract and render complete relevant manufacturer pages for review."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent
POPLER = '/Users/dean/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    receipt = json.loads((HERE/'retrieval.json').read_text())
    assert receipt['status']=='PASS'
    assert all(sha(HERE/'sources'/r['file'])==r['sha256'] for r in receipt['rows'])
    outdir = HERE/'previews'
    outdir.mkdir(exist_ok=True)
    rows = []
    for name,page in [('JST_PH_current.pdf',2),('JST_SH_current.pdf',2),('Daburn_2420_RevD.pdf',1)]:
        source = HERE/'sources'/name
        reader = PdfReader(source)
        text = '\n\n'.join(f'PAGE {i+1}\n'+(p.extract_text() or '') for i,p in enumerate(reader.pages))
        (outdir/(source.stem+'.txt')).write_text(text)
        prefix = outdir/(source.stem+'_page')
        command = [POPLER,'-f',str(page),'-l',str(page),'-r','135','-png',str(source),str(prefix)]
        subprocess.run(command,check=True,capture_output=True,text=True,timeout=30)
        image = next(outdir.glob(source.stem+'_page-*.png'))
        rows.append(dict(file=name,pages=len(reader.pages),review_page=page,source_sha256=sha(source),
                         rendered_file=str(image.relative_to(HERE)),rendered_sha256=sha(image),command=command))
        print('MATERIAL_PDF_RENDER',name,page,len(reader.pages),image.name,flush=True)
    version = subprocess.run([POPLER,'-v'],capture_output=True,text=True,check=True)
    out = dict(status='PASS',scope='Extraction/rendering only; visual/source-field review follows',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               rows=rows,renderer_version=(version.stderr+version.stdout).strip(),
               script_sha256=sha(Path(__file__)),retrieval_sha256=sha(HERE/'retrieval.json'),visual_review='NOT_TESTED')
    (HERE/'render_receipt.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':
    main()
