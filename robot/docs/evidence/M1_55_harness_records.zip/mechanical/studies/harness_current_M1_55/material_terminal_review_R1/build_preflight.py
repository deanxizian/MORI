"""Prepare an unadopted H06 terminal/wire comparison and supplier worksheet.

Read the electrical pin map without changing it. Unknown material, crimp,
mate, length and purchase fields stay null/BLOCKED. Nominal diameter is
never substituted for a documented maximum or for physical qualification.
"""
from pathlib import Path
from decimal import Decimal
import csv
import datetime
import hashlib
import html
import json

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
PROJECT = HERE.parents[3]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def intersect(*intervals):
    lo = max(Decimal(str(q[0])) for q in intervals)
    hi = min(Decimal(str(q[1])) for q in intervals)
    return [float(lo),float(hi)] if lo<=hi else None


def main():
    fields_path = HERE/'source_field_review.json'
    facts = read(fields_path)
    assert facts['status']=='PASS' and all(sha(HERE/p)==h for p,h in facts['source_files'].items())
    formal_path = PROJECT/'hardware/v1_2/wiring_P5R7/03_逐针接线表.csv'
    with formal_path.open(encoding='utf-8-sig',newline='') as f:
        pins = [r for r in csv.DictReader(f) if r['线束']=='H06']
    assert len(pins)==4 and [r['起点针'] for r in pins]==['1','2','3','4']
    assert [r['起点信号'] for r in pins]==['CAM_RX','CAM_TX','CAM_3V3','GND']
    assert all(r['起点针']==r['终点针'] and r['起点信号']==r['终点信号'] for r in pins)
    assert all(r['起点口']=='J5' and r['终点口']=='J11' and r['线规建议']=='PH端AWG28；CAM端厂配SH尾线' for r in pins)
    join_path = PARENT/'upper_continuity_review_R1/prefix_upper_join_review_R1/join_verification.json'
    join_audit_path = join_path.with_name('join_coverage_verification.json')
    joins,audit = read(join_path),read(join_audit_path)
    assert joins['status']==audit['status']=='PASS' and audit['comparisons']==84
    assert all(sha(p)==h for p,h in audit['sources'].items())
    radii = {r['upper']:r['upper_radius_mm'] for r in joins['results'] if r['own_prefix'] and r['upper'].startswith('CAM_')}
    assert set(radii)=={'CAM_1','CAM_2','CAM_3','CAM_4'} and len(set(radii.values()))==1
    capacity_OD = 2*next(iter(radii.values()))
    assert capacity_OD==.6604
    body_path = PARENT/'prefix_continuity/frame_family_R3/continuous_bend_inspection.json'
    body = read(body_path)
    assert body['status']=='PASS' and body['required_radius_mm']==6.865
    assert all(sha(p)==h for p,h in body['sources'].items())
    cam_math_path = PARENT/'upper_continuity_review_R1/cam_math_review_R1/nominal_half_grid_verification.json'
    cam_math = read(cam_math_path)
    assert cam_math['status']=='PASS' and all(sha(p)==h for p,h in cam_math['sources'].items())
    targets = {}
    for name in radii:
        values = {r['target_full_numeric_reference_mm'] for r in cam_math['rows'] if r['wire']==name}
        assert len(values)==1
        targets[name] = next(iter(values))
    contact = facts['contacts']
    ph002 = contact['SPH-002T-P0.5S']['insulation_OD_range_mm']
    ph004 = contact['SPH-004T-P0.5S']['insulation_OD_range_mm']
    sh = contact['SSH-003T-P0.2-H']['insulation_OD_range_mm']
    formal_intersection = intersect(ph002,sh)
    retained = intersect(ph002,sh,[0.,capacity_OD])
    proposed = intersect(ph004,sh,[0.,capacity_OD])
    assert formal_intersection==[.8,.8] and retained is None and proposed==[.5,.6604]
    daburn = facts['Daburn_2420_28']
    assert all(daburn[k] is None for k in ['maximum_OD_mm','minimum_OD_mm','minimum_bend_radius_mm','dynamic_life_cycles'])
    nominal = daburn['nominal_OD_mm_document']
    assert proposed[0]<=nominal<=proposed[1]
    alpha = facts['Alpha_2842_7']
    alpha_OD = float((Decimal(str(alpha['nominal_OD_in']))+Decimal(str(alpha['OD_tolerance_in'])))*Decimal('25.4'))
    assert alpha_OD==.7366 and alpha_OD>capacity_OD
    rows = []
    for pin in pins:
        i = int(pin['起点针'])
        rows.append(dict(wire_id=f'H06-{i}',reference=f'CAM_{i}',start_module=pin['起点板'],
                         start_port=pin['起点口'],start_pin=i,end_module=pin['终点板'],
                         end_port=pin['终点口'],end_pin=int(pin['终点针']),signal=pin['起点信号'],
                         formal_wire_definition=pin['线规建议'],formal_body_terminal='SPH-002T-P0.5S',
                         formal_body_housing='PHR-4',numeric_capacity_reference_mm=targets[f'CAM_{i}'],
                         supplier_cut_length_mm=None,splice_position_mm=None,splice_maximum_outline_mm=None,
                         actual_CAM_housing_MPN=None,actual_CAM_contact_MPN=None,factory_tail_length_mm=None,
                         actual_wire_MPN=None,actual_wire_OD_range_mm=None,crimped_terminal_outline_mm=None,
                         protected_terminal_outline_mm=None,wire_colour=None,manufacturing_status='BLOCKED'))
    sources = {str(p):sha(p) for p in [Path(__file__),fields_path,HERE/'retrieval.json',formal_path,
                                     PROJECT/'contracts/components.json',join_path,join_audit_path,body_path,cam_math_path]}
    sources.update({str((HERE/p).resolve()):h for p,h in facts['source_files'].items()})
    constraints = dict(current_head_reference_maximum_OD_mm=capacity_OD,current_body_required_centreline_radius_mm=6.865,
                       PH002_SH_catalogue_OD_intersection_mm=formal_intersection,
                       PH002_SH_current_reference_OD_intersection_mm=retained,
                       PH004_SH_current_reference_OD_intersection_mm=proposed,
                       formal_uniform_wire_eligibility='FAIL',proposed_uniform_wire_range_eligibility='PASS',
                       actual_material_and_connection_qualification='BLOCKED')
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Source-backed terminal/wire range comparison and preparation only; not a selected harness or drawing release',
               sources=sources,constraints=constraints,H06_rows=rows,
               Daburn_2420_28_nominal_fields_eligibility='PASS',Daburn_2420_28_tolerance_and_bend_eligibility='BLOCKED',
               Alpha_2842_7_maximum_OD_mm=alpha_OD,Alpha_2842_7_current_capacity_eligibility='FAIL',
               current_formal_definition_retained=True,PH004_adopted=False,wire_selected=False,
               actual_CAM_mating='BLOCKED',terminal_feed_and_wired_closure='BLOCKED',
               actual_supplier_cut_lengths='BLOCKED',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'preflight.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    with (HERE/'supplier_worksheet.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['线号','起点','终点','信号','现行定义','数值容量参考mm_不可裁线','实际裁线mm','接续位置','真实CAM配对件','状态'])
        for r in rows:
            writer.writerow([r['wire_id'],f"{r['start_port']}.{r['start_pin']}",f"{r['end_module']} {r['end_port']}.{r['end_pin']}",
                             r['signal'],r['formal_wire_definition'],format(r['numeric_capacity_reference_mm'],'.6f'),
                             '','','','BLOCKED'])
    (HERE/'supplier_requirements_DRAFT.md').write_text('''# H06 制作资料准备稿

**DRAFT / BLOCKED，不可据此裁线、压接或下单。**

现行定义保持：身体端 PHR-4 / SPH-002T-P0.5S、AWG28；
CAM端使用实际匹配的厂配尾线。四条线按H06-1..4独立标识，
J5.1..4到CAM J11.1..4同号；RX/TX不再次交叉。
第3针CAM_3V3仅作U4 VCCB参考，不是CAM主供电。

用户已确认交付工序：厂家完成压接，身体端四个端子暂不入PHR-4，
穿线后再入壳。实际端子保护外形、装入、最终整理和闭壳尚待复核。

供应商／到货资料需要补齐：

- 实际CAM端壳体和端子料号、锁定片及针号视图，与原插座配对的依据。
- 原厂尾线实际长度、线规、最小／最大绝缘外径、允许弯折半径及其基准。
- 身体AWG28料号和批次；若保留接续，给出接续工艺及最大完整外形、
  刚性段长度、位置和应力释放。Z200数学分段点不是已指定接头。
- 压接后端子／保护件完整长宽高、线桶末端和第一可弯点。
  提供该具体线材、端子与工装组合的压接高度及拉力检验依据。
- 以已确认端接／固定位置计算裁线、剥线与工艺余量，逐针连续性检查。
- 报短长度供应、实际报价；整机预算约束未放宽。

另列未采用方向：整条细AWG28、身体端使用SPH-004T-P0.5S，
保留PHR-4与板端、针序，取消四处粗细线接续。当前资料仅支持
绝缘外径区间预筛；实际CAM配对、线径公差、弯折／压接及制造图均未闭合。
不允许通过加绝缘套、缩小线径模型或改变针距来冒充PH002合格压接。

supplier_worksheet.csv中的数值是未采用容量曲线的Gauss64参考长度，
不是物理裁线长度，也未指定粗细线分界。所有实际裁线字段保持空白。
''')
    table = ''.join(f"<tr><td>{r['wire_id']}</td><td>{r['signal']}</td><td>{r['numeric_capacity_reference_mm']:.3f}</td><td>待定</td></tr>" for r in rows)
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 H06端接与线材预筛</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:980px;margin:32px auto;padding:0 22px;color:#27343b}}table{{border-collapse:collapse;width:100%;margin:20px 0}}td,th{{padding:9px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}img{{max-width:100%;height:auto}}details{{margin:18px 0}}</style>
<h1>H06：现行混合尾线与整条细线候选</h1>
<p class="scope">PLACEHOLDER / ASSUMED · 未采用的材料与端接比较。现行AWG28／PH002＋厂配SH尾线保持。制造、完整穿线与闭壳BLOCKED。</p>
<table><thead><tr><th>端子</th><th>原厂线规范围</th><th>绝缘外径mm</th><th>当前关系</th></tr></thead><tbody>
<tr><td>SPH-002T-P0.5S</td><td>AWG30～24</td><td>0.8～1.5</td><td>正式PH端</td></tr>
<tr><td>SPH-004T-P0.5S</td><td>AWG32～28</td><td>0.5～0.9</td><td>替代方向，未采用</td></tr>
<tr><td>SSH-003T-P0.2-H</td><td>AWG32～28</td><td>0.4～0.8</td><td>原厂SH目录参考，实际CAM配对待核</td></tr></tbody></table>
<p>PH002与SH目录的线径交集仅0.8mm这一点；再纳入当前头内0.6604mm最大外径参考，交集为空。因此当前混合定义仍需接续。换PH004后，目录与现有容量区间的交集为0.5～0.6604mm，AWG28在双方范围内；这是端接方向预筛，未证明真实压接或配对。</p>
<h2>两种方向</h2><p><strong>A，保持正式定义：</strong>PH002＋身体AWG28，再接实际厂配SH尾线。接续位置、最大外形和真实尾线信息尚未确定。</p>
<p><strong>B，整条细AWG28候选：</strong>PH端改PH004，保留PHR-4塑壳、板端与针序，取消四处粗细接续。需要确认实际CAM壳体／端子，并提供完整线材公差、弯折和压接资料后才能复核采用。</p>
<p>Daburn2420/28为AWG28、65/46股裸铜、FEP，目录标称外径0.559mm，标称尺寸位于候选区间内；最大／最小外径、数值弯折半径和动态寿命未在所读资料中标注，保持未知。Alpha2842/7最大外径0.7366mm超过当前头内参考，不继承现有路线通过结果。候选均未选定，价格和短长度供应未核实。</p>
<p>当前CAM身体前段的全角度弯折要求为中心线R6.865mm。任何材料都须按厂家定义确认可用半径；不把“柔软”描述或标称线径视为资格。</p>
<h2>制作资料准备</h2><table><thead><tr><th>线号</th><th>信号</th><th>数值容量参考mm</th><th>实际裁线</th></tr></thead><tbody>{table}</tbody></table>
<p>表中数字不是裁线长。旧端子保护、逐根穿线与让位的容量结果不自动覆盖真实新线材或当前完整装配。头内粗细分界、端子保护、应力释放、逐针验证与闭壳仍需完成。</p>
<details><summary>已目视核对的原厂表格</summary><p>初次Poppler绘图缺失JST文字；保留诊断后使用PDFium重新渲染，源PDF未改变。</p><img src="previews/JST_PH_current_pdfium_page2.png" alt="JST PH第2页完整端子适用范围"><img src="previews/JST_SH_current_pdfium_page2.png" alt="JST SH第2页完整端子与塑壳表"><img src="previews/Daburn_2420_RevD_page-1.png" alt="Daburn2420修订D完整线材规格表"></details>
<p><a href="preflight.json">区间与未知字段</a> · <a href="supplier_requirements_DRAFT.md">供应商资料准备稿</a> · <a href="supplier_worksheet.csv">逐针准备表，不可裁线</a> · <a href="source_field_review.json">逐字段来源</a> · <a href="sources/JST_PH_current.pdf">JST PH原文</a> · <a href="sources/JST_SH_current.pdf">JST SH原文</a> · <a href="sources/Daburn_2420_RevD.pdf">Daburn原文</a> · <a href="../upper_continuity_review_R1/prefix_upper_join_review_R1/index.html">已知路线完整接续检查</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# H06 terminal and material preflight

Read-only electrical pin-map receipt and manufacturer-field comparison.
The formal PH002/AWG28 plus factory SH tail remains unchanged.

PH002 OD0.8..1.5 and catalogue SH0.4..0.8 intersect only at0.8.
With the current head-reference maximum OD0.6604, that uniform-wire
interval is empty. PH0040.5..0.9 gives a possible0.5..0.6604 interval.
This does not prove the actual CAM mating connector or crimps.

Daburn2420/28:AWG28,65/46,FEP,nominal OD0.559mm only.
Maximum/minimum OD and numeric bend radius remain null, so actual
route/crimp qualification stays BLOCKED. Alpha2842/7 maximum OD0.7366
exceeds the current head-reference allocation. Neither is selected.

Supplier worksheet preserves all four formal same-number pin mappings
and the reference-only Gauss64 lengths. All actual cuts/splices/terminal
outlines, colours and actual CAM part numbers remain null or blank.
No supplier contact, order, hardware/main/animation change or release.
''')
    print('H06_MATERIAL_PREFLIGHT_PASS',len(rows),formal_intersection,proposed,flush=True)


if __name__=='__main__':
    main()
