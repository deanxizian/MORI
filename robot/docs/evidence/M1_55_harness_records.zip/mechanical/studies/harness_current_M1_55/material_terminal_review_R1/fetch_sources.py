"""Retain public manufacturer source bytes; no supplier contact or ordering."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import urllib.request

HERE = Path(__file__).resolve().parent
URLS = {
    'JST_PH_current.pdf':'https://www.jst-mfg.com/product/pdf/eng/ePH.pdf',
    'JST_SH_current.pdf':'https://www.jst-mfg.com/product/pdf/eng/eSH.pdf',
    'Daburn_2420_RevD.pdf':'https://www.daburn.com/specs/2420_Spec_Sheet_04-29-2013.pdf',
    'Daburn_2420_product.html':'https://www.daburn.com/2420-Ultra-Flexible-Microminiature-FEP-Lead-Wire.aspx',
    'Alpha_2842_7_product.html':'https://www.alphawire.com/en/products/wire/hook-up-wire/premium/2842_7',
}


def fetch(item):
    name,url = item
    request = urllib.request.Request(url,headers={'User-Agent':'MORI engineering source review'})
    with urllib.request.urlopen(request,timeout=20) as response:
        data = response.read()
        final = response.url
        content_type = response.headers.get('Content-Type')
    if name.endswith('.pdf'):
        assert data.startswith(b'%PDF')
    path = HERE/'sources'/name
    path.write_bytes(data)
    return dict(file=name,url=url,final_url=final,content_type=content_type,
                sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),status='PASS')


def main():
    (HERE/'sources').mkdir(exist_ok=True)
    rows = []
    with ThreadPoolExecutor(max_workers=5) as pool:
        jobs = [(name,pool.submit(fetch,(name,url))) for name,url in URLS.items()]
        for name,job in jobs:
            try:
                row = job.result()
            except Exception as error:
                row = dict(file=name,url=URLS[name],status='BLOCKED',error=str(error))
            rows.append(row)
            print('MATERIAL_SOURCE',name,row['status'],row.get('bytes'),flush=True)
    out = dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               rows=rows,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               scope='Public manufacturer documents only; no availability/price or physical qualification')
    (HERE/'retrieval.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':
    main()
