"""Audit source provenance, formal pin mapping and unreleased supplier fields."""
from pathlib import Path
from decimal import Decimal
import csv
import datetime
import hashlib
import json
import pypdfium2 as pdfium

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    path = HERE/'preflight.json'
    data = read(path)
    assert data['status']=='PASS' and all(sha(p)==h for p,h in data['sources'].items())
    facts = read(HERE/'source_field_review.json')
    for row in facts['reviewed_images']:
        assert row['status']=='PASS' and sha(HERE/row['file'])==row['sha256']
    texts = {}
    for name in ['JST_PH_current.pdf','JST_SH_current.pdf','Daburn_2420_RevD.pdf']:
        with pdfium.PdfDocument(str(HERE/'sources'/name)) as doc:
            texts[name] = '\n'.join(doc[i].get_textpage().get_text_range() for i in range(len(doc)))
    ph,sh,daburn = [texts[n] for n in ['JST_PH_current.pdf','JST_SH_current.pdf','Daburn_2420_RevD.pdf']]
    assert all(s in ph for s in ['SPH-002T-P0.5S','SPH-004T-P0.5S','0.8 to 1.5','0.5 to 0.9'])
    assert all(s in sh for s in ['SSH-003T-P0.2-H','0.4 to 0.8'])
    assert all(s in daburn for s in ['2420/28','65/46','0.559','Nom. O.D.'])
    assert facts['Daburn_2420_28']['selected'] is False
    assert all(facts['Daburn_2420_28'][k] is None for k in [
        'maximum_OD_mm','minimum_OD_mm','minimum_bend_radius_mm','dynamic_life_cycles','supplier_quote_CNY'])
    # Rebuild the conditional intervals using source fields and integer
    # decimal arithmetic, without importing the preparation generator.
    c = facts['contacts']
    a,b,s = [c[n]['insulation_OD_range_mm'] for n in ['SPH-002T-P0.5S','SPH-004T-P0.5S','SSH-003T-P0.2-H']]
    cap = Decimal(str(data['constraints']['current_head_reference_maximum_OD_mm']))
    alo,ahi = max(Decimal(str(a[0])),Decimal(str(s[0]))),min(Decimal(str(a[1])),Decimal(str(s[1])))
    blo,bhi = max(Decimal(str(b[0])),Decimal(str(s[0]))),min(Decimal(str(b[1])),Decimal(str(s[1])),cap)
    assert alo==ahi==Decimal('.8') and cap<alo
    assert [float(blo),float(bhi)]==[.5,.6604] and cap==Decimal('.6604')
    assert data['constraints']['PH002_SH_current_reference_OD_intersection_mm'] is None
    assert data['Daburn_2420_28_tolerance_and_bend_eligibility']=='BLOCKED'
    assert data['Alpha_2842_7_current_capacity_eligibility']=='FAIL' and data['Alpha_2842_7_maximum_OD_mm']==.7366
    formal = PROJECT/'hardware/v1_2/wiring_P5R7/03_逐针接线表.csv'
    with formal.open(encoding='utf-8-sig',newline='') as f:
        original = [r for r in csv.DictReader(f) if r['线束']=='H06']
    rows = data['H06_rows']
    assert len(rows)==len(original)==4
    nulls = ['supplier_cut_length_mm','splice_position_mm','splice_maximum_outline_mm','actual_CAM_housing_MPN',
             'actual_CAM_contact_MPN','factory_tail_length_mm','actual_wire_MPN','actual_wire_OD_range_mm',
             'crimped_terminal_outline_mm','protected_terminal_outline_mm','wire_colour']
    for r,o in zip(rows,original):
        assert r['start_pin']==int(o['起点针'])==r['end_pin']==int(o['终点针'])
        assert r['signal']==o['起点信号']==o['终点信号'] and r['formal_wire_definition']==o['线规建议']
        assert r['formal_body_terminal']=='SPH-002T-P0.5S' and r['manufacturing_status']=='BLOCKED'
        assert all(r[k] is None for k in nulls)
    with (HERE/'supplier_worksheet.csv').open(encoding='utf-8-sig',newline='') as f:
        worksheet = list(csv.DictReader(f))
    assert len(worksheet)==4
    for r,o in zip(worksheet,original):
        assert r['信号']==o['起点信号'] and all(r[k]=='' for k in ['实际裁线mm','接续位置','真实CAM配对件'])
    assert data['current_formal_definition_retained'] and not data['PH004_adopted'] and not data['wire_selected']
    assert all(data[k]=='BLOCKED' for k in ['actual_CAM_mating','terminal_feed_and_wired_closure','actual_supplier_cut_lengths','full_harness'])
    assert all(not data[k] for k in ['main_changed','hardware_changed','animation_changed','manufacturing_release'])
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = data['sources'] | {str(p):sha(p) for p in [Path(__file__),path,HERE/'supplier_worksheet.csv',
                                                       HERE/'supplier_requirements_DRAFT.md',HERE/'index.html']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Manufacturer-source, conditional-range, pin-map and unreleased-field audit only',
               sources=sources,pin_rows=4,PDF_sources=3,reviewed_source_images=3,protected_hardware_files=846,
               actual_material_and_connection_qualification='BLOCKED',full_harness='BLOCKED',
               formal_H06_changed=False,main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'preflight_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('H06_MATERIAL_PREFLIGHT_VERIFIED',4,3,846,flush=True)


if __name__=='__main__':
    main()
