"""Read back the saved inspection against the current authoritative model."""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *

ctx=Context();manifest=json.loads((HERE/'render_manifest.json').read_text())
assert manifest['status']=='PASS'
source=sha(ROOT/'mori_v1_2.blend');inspection=HERE/manifest['inspection_file'];digest=sha(inspection)
assert source==manifest['source_blend_sha256'] and digest==manifest['inspection_sha256']
def mesh_record(o):
    v=np.asarray([v.co[:] for v in o.data.vertices],dtype=float)
    o.data.calc_loop_triangles();f=np.asarray([t.vertices[:] for t in o.data.loop_triangles],dtype=int)
    return dict(geometry=record(v,f.tolist())['exact_sha256'],matrix=np.asarray(o.matrix_world).tolist())
expected={n:mesh_record(s.o) for n,s in ctx.ss.items()}
refs={n:(d['p'].copy(),float(d['radius'])) for n,d in ctx.refs(0,0).items() if not n.startswith('CAM_')}
path=HERE/'body_relayout_R4'/manifest['unadopted_candidate']/'curves.npz'
curves=np.load(path);paths={pin:curves[f'CAM_{pin}_y0_p0'].copy() for pin in range(1,5)}
ctx.record([Path(__file__),HERE/'render_manifest.json',path,inspection]);sources=dict(ctx.sources)
ctx.unchanged()
bpy.ops.wm.open_mainfile(filepath=str(inspection))
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for n in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:COLS[n].hide_viewport=False
assembled();bpy.context.view_layer.update()
native={o.name.removeprefix(PREFIX):o for o in parts() if o.type=='MESH' and o.get('group') not in ['dock','coupon']}
assert set(native)==set(expected)
for n,o in native.items():assert mesh_record(o)==expected[n],n
copied=[]
for n in manifest['exact_saved_native_meshes']:
    o=bpy.data.objects['MORI_M155_REVIEW_'+n]
    assert mesh_record(o)==expected[n],n
    assert o['review_owner']=='M155_HARNESS_READONLY' and not o['export_candidate']
    copied.append(n)
wire_rows=[]
for label,p,radius in [(f'H06_BODY_{pin}',p,.565) for pin,p in paths.items()]+[(f'RETAINED_{n}',p,r) for n,(p,r) in refs.items()]:
    o=bpy.data.objects['MORI_M155_REVIEW_'+label];c=o.data
    assert o['category']=='PLACEHOLDER' and o['data_status']=='ASSUMED' and not o['export_candidate']
    assert len(c.splines)==1 and c.splines[0].type=='POLY'
    saved=np.asarray([v.co[:3] for v in c.splines[0].points],dtype=float)
    assert saved.shape==p.shape
    error=float(np.max(abs(saved-p)))
    # Blender stores curve points/radii in float32. Require their exact
    # expected float32 representation, not an arbitrary absolute tolerance.
    expected_points=np.asarray(p,dtype=np.float32).astype(float)
    assert np.array_equal(saved,expected_points),label
    assert c.bevel_depth==float(np.float32(radius)),(label,c.bevel_depth,radius)
    assert error<.0001,(label,error) # smaller than the separately reserved numerical gap margin
    wire_rows.append(dict(id=label,status='PASS',points=len(p),maximum_point_error_mm=error,
                          exact_float32_readback=True,radius_mm=float(c.bevel_depth)))
assert all(sha(p)==h for p,h in sources.items())
(HERE/'saved_inspection_readback.json').write_text(json.dumps(dict(status='PASS',revision=P['revision'],sources=sources,
    scope='Saved native geometry, copied part transforms and explicit polyline radii/points only; candidate route remains BLOCKED',
    authoritative_native_parts_unchanged=len(native),copied_native_parts=copied,wires=wire_rows,
    candidate_status=manifest['candidate_screen_status'],main_changed=False,hardware_changed=False,
    full_harness='BLOCKED',manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('SAVED_INSPECTION_READBACK_PASS',len(native),'native parts',len(wire_rows),'unadopted polylines',flush=True)
