"""Check the scope of the failed smooth-fit study and preserved inputs."""
from pathlib import Path
import datetime
import json
import math
import subprocess
import numpy as np

from smooth_geometry import SmoothContext,BSpline,MINIMUM_RADIUS,MAX_DEVIATION,radius_bound,sha

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2];PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())


def main():
    report=read(HERE/'zero_inspection.json');diagnosis=read(HERE/'zero_diagnosis.json')
    assert report['status']=='BLOCKED' and report['planned_poses']==[[0,0]]
    assert report['completed_curve_checks']==7 and len(report['failures'])==4
    failed={r['wire'] for r in report['failures']}
    assert failed=={f'CAM_{p}' for p in range(1,5)}
    for d in [report,diagnosis]:
        assert all(sha(p)==h for p,h in d['sources'].items())
    assert len(diagnosis['rows'])==16
    ctx=SmoothContext();ctx.record([Path(__file__),HERE/'zero_inspection.json',HERE/'zero_diagnosis.json'])
    raw=ctx.upper(0,0);arrays=np.load(HERE/'zero_curves.npz')
    assert sha(HERE/'zero_curves.npz')==report['arrays_sha256']
    accepted={r['wire'] for r in report['rows'] if r['status']=='PASS'}
    assert accepted=={'P_J18_1','P_J18_2','CC_allocation'}
    assert set(arrays.files)=={f'{n}_y0_p0_{s}' for n in accepted for s in ['knots','controls']}
    checked=[]
    for row in report['rows']:
        name=row['wire']
        for attempt in row['attempts']:
            condition=(attempt['deviation']['max_deviation_mm']<=MAX_DEVIATION and
                       attempt['continuous_bending']['radius_lower_mm']>=MINIMUM_RADIUS[name])
            assert (attempt['status']=='PASS')==condition
            assert max(attempt['tangent_unit_vector_errors'])<1e-10
            assert max(attempt['endpoint_evaluation_errors_mm'])<1e-10
        if name in failed:continue
        spl=BSpline(arrays[f'{name}_y0_p0_knots'],arrays[f'{name}_y0_p0_controls'],3)
        assert np.array_equal(spl.c[[0,-1]],raw[name][[0,-1]])
        direction=spl.derivative()(np.array([0.,1.]));direction/=np.linalg.norm(direction,axis=1)[:,None]
        expected=np.array(ctx.tangents(name,0,0));expected/=np.linalg.norm(expected,axis=1)[:,None]
        assert np.linalg.norm(direction-expected,axis=1).max()<1e-10
        bound=radius_bound(spl)
        assert bound['radius_lower_mm']==row['selected']['continuous_bending']['radius_lower_mm']
        checked.append(name)
    # These analytical examples check that the bound is conservative and
    # rejects zero-speed geometry; they do not qualify any physical cable.
    knot=np.r_[np.zeros(4),np.ones(4)]
    straight=BSpline(knot,np.array([[0,0,0],[0,0,1],[0,0,2],[0,0,3]],float),3)
    assert math.isinf(radius_bound(straight)['radius_lower_mm'])
    collapsed=BSpline(knot,np.zeros((4,3)),3)
    assert radius_bound(collapsed)['radius_lower_mm']==0 and not radius_bound(collapsed)['derivative_nonzero']
    R=7.;angle=.2
    p0=np.array([R,0,0]);p3=np.array([R*np.cos(angle),R*np.sin(angle),0])
    control=np.array([p0,p0+R*angle/3*np.array([0,1,0]),
                      p3-R*angle/3*np.array([-np.sin(angle),np.cos(angle),0]),p3])
    arc=BSpline(knot,control,3);lower=radius_bound(arc)['radius_lower_mm']
    t=np.linspace(0,1,10001);d=arc.derivative()(t);a=arc.derivative(2)(t)
    sampled=float((np.linalg.norm(d,axis=1)**3/np.linalg.norm(np.cross(d,a),axis=1)).min())
    assert 6.94<lower<=sampled
    baseline=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
    protected={n:h for n,h in baseline['protected_hardware'].items()
               if '__pycache__' not in Path(n).parts and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
    assert sha(MECHANICAL/'mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(MECHANICAL/'animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
    assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
    ctx.unchanged()
    out=dict(status='PASS',scope='Failed-fit result coverage, numerical examples and preserved source verification only',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
             fit_status='BLOCKED',zero_pose_curves_checked=7,accepted_zero_pose_curves=checked,
             failed_zero_pose_curves=sorted(failed),all_130_poses_attempted=False,
             numerical_examples=3,circular_Hermite_bound_mm=lower,circular_Hermite_sample_min_mm=sampled,
             initial_floating_endpoint_assertion='Retained in initial_attempt; exact endpoint controls with 1e-10 mm evaluation tolerance',
             protected_hardware_files=len(protected),main_changed=False,animation_changed=False,hardware_changed=False,
             Git_HEAD=head,new_commit_or_push=False,full_harness='BLOCKED',manufacturing_release=False)
    (HERE/'result_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('SMOOTH_FIT_RESULT_VERIFIED',7,'zero curves',4,'failed',len(protected),'protected hardware',flush=True)


if __name__=='__main__':main()
