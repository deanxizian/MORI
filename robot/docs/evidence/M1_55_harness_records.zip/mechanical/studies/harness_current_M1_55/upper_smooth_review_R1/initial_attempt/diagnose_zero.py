"""Locate the actual zero-pose fit limitations without changing a route."""
from pathlib import Path
import json
import time
import numpy as np

from smooth_geometry import SmoothContext,fit,sha

HERE=Path(__file__).resolve().parent


def main():
    start=time.time();ctx=SmoothContext();ctx.record([Path(__file__)])
    rows=[]
    for name,raw in ctx.upper(0,0).items():
        if not name.startswith('CAM_'):continue
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(raw,axis=0),axis=1))]
        lengths=np.diff(arc);directions=np.diff(raw,axis=0)/lengths[:,None]
        angles=np.arccos(np.clip(np.sum(directions[:-1]*directions[1:],axis=1),-1,1))
        circum=np.divide((lengths[:-1]+lengths[1:])/2,2*np.sin(angles/2),
                        out=np.full(len(angles),np.inf),where=angles>1e-10)
        worst=np.argsort(circum)[:10]
        raw_witnesses=[dict(index=int(i+1),arc_mm=float(arc[i+1]),point_mm=raw[i+1].tolist(),
                           angle_deg=float(np.degrees(angles[i])),adjacent_lengths_mm=lengths[i:i+2].tolist(),
                           three_point_radius_mm=float(circum[i])) for i in worst]
        for spacing in [4.,2.,1.,.5]:
            spl,details=fit(raw,*ctx.tangents(name,0,0),spacing)
            t=np.linspace(0,1,max(10000,12*len(spl.c)))
            d=spl.derivative(1)(t);a=spl.derivative(2)(t)
            cross=np.linalg.norm(np.cross(d,a),axis=1)
            radii=np.divide(np.linalg.norm(d,axis=1)**3,cross,out=np.full(len(t),np.inf),where=cross>1e-18)
            i=int(radii.argmin());u=float(t[i]);raw_t=arc/arc[-1]
            reference=np.array([np.interp(u,raw_t,raw[:,j]) for j in range(3)])
            row=dict(wire=name,spacing_mm=spacing,**details,
                     sampled_radius_min_mm=float(radii[i]),sampled_witness_t=u,
                     sampled_witness_arc_mm=float(u*arc[-1]),sampled_point_mm=spl(u).tolist(),
                     witness_reference_deviation_mm=float(np.linalg.norm(spl(u)-reference)),
                     raw_diagnostic_witnesses=raw_witnesses)
            rows.append(row)
            print('FIT_DIAGNOSTIC',name,spacing,'bound',details['continuous_bending']['radius_lower_mm'],
                  'sample',float(radii[i]),'deviation',details['deviation']['max_deviation_mm'],
                  'arc',float(u*arc[-1]),flush=True)
    ctx.unchanged()
    result=dict(status='PASS',scope='Read-only fit diagnosis, not geometry acceptance',sources=ctx.sources,
                rows=rows,elapsed_s=time.time()-start,main_changed=False,hardware_changed=False)
    (HERE/'zero_diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('FIT_DIAGNOSIS_TERMINAL',len(rows),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
