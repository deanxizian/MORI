"""Read back the published failure report and each local link."""
from pathlib import Path
import datetime
import hashlib
import json
import re
from urllib.parse import unquote,urlsplit
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
d=read(HERE/'delivery.json');result=read(HERE/'result_verification.json')
assert d['status']==result['status']=='PASS' and d['fit_status']=='BLOCKED'
assert all(sha(HERE/p)==h for p,h in d['files'].items())
assert all(sha(p)==h for p,h in result['sources'].items())
links=[]
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(value)
    if parsed.scheme or not parsed.path:continue
    p=(HERE/unquote(parsed.path)).resolve()
    assert p.is_file() and p.is_relative_to(PROJECT),(value,p)
    with urlopen(Request('http://127.0.0.1:58202/'+str(p.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:
        assert response.status==200
    links.append(str(p.relative_to(PROJECT)))
with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:
    assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
out=dict(status='PASS',scope='Blocked-fit reporting and publication only',
         recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checked_files=len(d['files']),
         checked_links=links,delivery_sha256=sha(HERE/'delivery.json'),script_sha256=sha(Path(__file__)),
         fit_status='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False)
(HERE/'publication_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('SMOOTH_FIT_PUBLICATION_VERIFIED',len(d['files']),'files',len(links),'links',flush=True)
