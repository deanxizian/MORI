"""Fit and certify complete known upper curves at requested stored poses."""
from pathlib import Path
import datetime
import json
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from smooth_geometry import SmoothContext,fit,NAMES,RADII,MINIMUM_RADIUS,MAX_DEVIATION,sha,np


def main():
    started=time.time();ctx=SmoothContext()
    zero='--zero' in sys.argv
    poses=[(0,0)] if zero else [(y,p) for y in range(-60,61,10) for p in range(-20,26,5)]
    rows=[];failed=[];arrays={}
    ctx.record([Path(__file__)])
    for yaw,pitch in poses:
        upper=ctx.upper(yaw,pitch)
        for name,raw in upper.items():
            incoming,outgoing=ctx.tangents(name,yaw,pitch)
            attempts=[];accepted=None
            for spacing in [2.,1.,.5]:
                spl,details=fit(raw,incoming,outgoing,spacing)
                status='PASS' if details['deviation']['max_deviation_mm']<=MAX_DEVIATION and details['continuous_bending']['radius_lower_mm']>=MINIMUM_RADIUS[name] else 'BLOCKED'
                attempts.append(dict(status=status,**details))
                if status=='PASS':
                    accepted=spl;break
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,status='PASS' if accepted is not None else 'BLOCKED',
                required_reference_radius_mm=MINIMUM_RADIUS[name],maximum_reference_deviation_mm=MAX_DEVIATION,
                radius_mm=RADII[name],attempts=attempts,selected=attempts[-1] if accepted is not None else None,
                geometric_tangent_join='PASS' if accepted is not None else 'NOT_TESTED',
                actual_material_join='BLOCKED',actual_cut_length=None)
            rows.append(row)
            if accepted is None:failed.append(row)
            else:
                key=f'{name}_y{yaw}_p{pitch}'
                arrays[key+'_knots']=accepted.t;arrays[key+'_controls']=accepted.c
            print('SMOOTH_UPPER_FIT',yaw,pitch,name,row['status'],attempts[-1]['deviation']['max_deviation_mm'],
                  attempts[-1]['continuous_bending']['radius_lower_mm'],flush=True)
        if failed:break
    ctx.unchanged()
    suffix='zero' if zero else 'all_poses'
    np.savez_compressed(HERE/f'{suffix}_curves.npz',**arrays)
    out=dict(status='PASS' if len(rows)==7*len(poses) and not failed else 'BLOCKED',
        scope='Complete known-upper cubic references with continuous curve-parameter bounds at specified stored poses only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        planned_poses=poses,completed_curve_checks=len(rows),rows=rows,failures=failed,
        maximum_reference_deviation_mm=MAX_DEVIATION,reference_radius_criteria_mm=MINIMUM_RADIUS,
        criteria_evidence='ASSUMED geometric references; not selected vendor cable bend limits',
        actual_mixed_material_length='BLOCKED',actual_endpoints_and_clamps='BLOCKED',
        current_native_clearance='NOT_TESTED',current_peer_clearance='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',complete_upper_tails='BLOCKED',
        wired_assembly_and_closure='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,
        manufacturing_release=False,arrays_sha256=sha(HERE/f'{suffix}_curves.npz'),elapsed_s=time.time()-started)
    (HERE/f'{suffix}_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('SMOOTH_UPPER_FIT_TERMINAL',suffix,out['status'],len(rows),len(failed),out['elapsed_s'],flush=True)


if __name__=='__main__':
    main()
