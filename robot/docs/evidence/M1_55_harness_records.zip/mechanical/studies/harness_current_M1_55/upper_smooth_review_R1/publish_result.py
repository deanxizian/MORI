"""Publish the blocked fit without substituting it for the retained routes."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    report=read(HERE/'zero_inspection.json');checked=read(HERE/'result_verification.json')
    assert checked['status']=='PASS' and checked['fit_status']==report['status']=='BLOCKED'
    assert all(sha(p)==h for p,h in checked['sources'].items())
    rows=''.join(f'<tr><td>{r["wire"]}</td><td>{r["status"]}</td><td>{r["attempts"][-1]["continuous_bending"]["radius_lower_mm"]:.6f}</td><td>{r["required_reference_radius_mm"]:.4f}</td><td>{r["attempts"][-1]["deviation"]["max_deviation_mm"]:.6f}</td></tr>' for r in report['rows'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 上段平滑拟合诊断</title>
<style>body{{max-width:1050px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}</style>
<h1>M1.55 · 上段平滑拟合诊断</h1><p>2026-10-09 · <strong>拟合候选 BLOCKED／未采用；结果范围核对 PASS。</strong></p>
<p class="notice">这是新生成的数值平滑候选，不是主模型或原路线的缺陷判定。7条已知上段在零位完成检查，3条通过、4条CAM拟合未通过。零位未通过后，没有运行其余129个姿态，也没有检查新曲线的实体间隙或跨线间隙。原配套R2有限姿态证据保留。</p>
<p><a href="../index.html">线束研究总览</a> · <a href="../upper_pairs_review_R2/index.html">原配套R2有限检查</a> · <a href="../../../../docs/CURRENT_STATUS.md">当前剩余清单</a> · <a href="../../../mori_v1_2.blend">当前主模型</a></p>
<h2>为何要补查</h2><p>R3前段末端切线来自最后一段参考折线。折线接续角不能直接证明它与解析上段完全平滑。这次用三次B样条拟合完整已知上段，保留端点控制点，并将前段真实样条的末端方向作为上段起始切线。拟合边界是几何切向连续，不代表已确定实际压接、接续和线材。</p>
<h2>零位结果</h2><p>下表为每条路线最后一组拟合的整段转弯下界与最大参考偏差。CAM的6.9342mm是历史容量研究的数值参考要求；电源／CC沿用5倍参考外径的假定规则。它们都不是选定原厂线材的动态弯折认证。最大参考偏差目标0.001mm仅用于本次数值近似，不是制造公差。</p>
<table><tr><th>参考导线</th><th>结果</th><th>曲率半径下界mm</th><th>数值参考要求mm</th><th>参考偏差上界mm</th></tr>{rows}</table>
<p>每个CAM拟合尝试2、1和0.5mm控制间距，均未同时满足转弯与偏差要求。另做4mm间距诊断也未解决。诊断发现拟合会产生比参考圆弧更急的弯，故不采用这些拟合；参考折线三点半径只用于定位，不据此证明原解析曲线的完整曲率。</p>
<h2>还剩四类工作</h2><ol><li>补齐完整上段：7条已知上段仍需平滑曲率和中间运动检查，3根舵机与2根喇叭参考缺完整上段。</li><li>完成整条材料与线长：两端、材料分界、可滑移段和固定位置确定后才能出实际裁线图。</li><li>落实接头与应力释放：CAM供电正式源端、完整USB尾线、喇叭插头和舵机实发尾线／配件仍需明确。</li><li>完成带线装配与闭壳，确认后同步主模型及动画。</li></ol>
<p>SC-0090-C001舵盘／锁紧配件与微雪FPC／FFC按用户决定到货核对。喇叭150mm包含已有插头，不能视为150mm自由可弯线长。主模型、动画、原生硬件、正式物料与Git HEAD保持，没有增加打印件或紧固件。</p>
<h2>原始记录</h2><p><a href="zero_inspection.json">7条零位检查</a> · <a href="zero_diagnosis.json">16组拟合诊断</a> · <a href="result_verification.json">范围／解析例子／来源核对</a> · <a href="initial_attempt/fit_zero.log">首次严格浮点断言日志</a> · <a href="commands.json">实际命令与错误修正</a> · <a href="README.md">复现与边界</a> · <a href="delivery.json">发布哈希</a></p>
<p>PROTOTYPE / UNVALIDATED · PLACEHOLDER / ASSUMED · full_harness=BLOCKED · manufacturing_release=false</p></html>''')
    (HERE/'README.md').write_text('''# M1.55 上段平滑拟合：未采用

7条已知参考的零位拟合：两根电源及CC通过，4根CAM未通过。
端点控制点完全不变；样条评价浮点误差另行检查<1e-10mm。
起始方向匹配R3前段末端样条方向，末端匹配现有上段参考方向。
曲率在每个样条区间递归拆分后的正权重控制凸包上给出保守界；
偏差在所有原折线顶点／样条结点之间以三次减一次控制凸包给出连续界。
范围仅为零位，未执行129个后续姿态、实体或跨线间隙复核。

CAM拟合额外出现急弯，不能据此把原圆弧参考或主模型判断为失败。
保留已发布配套R2的原始有限姿态证据；新拟合没有进入主模型或动画。
参考转弯半径与0.001mm近似偏差不是供应商材料资格或制造公差。

首次运行将样条浮点评价与端点做逐位相等比较，在CAM2处退出。
原脚本与日志保留initial_attempt；修正为端点控制点逐位相等、
评价误差<1e-10mm。另一次诊断字典重复spacing_mm报错，也保留。
成功运行结果才作为检查证据。命令见commands.json。

当前仍剩4类完整线束工作：上段、材料／线长、端接／应力释放、
带线装配／闭壳。型号SC-0090-C001与喇叭150mm含插头已记录，
未知接口没有替换为猜测的实际尺寸。没有采购、供应商消息或Git动作。
''')
    commands=[]
    runtime='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
    for script,args in [('diagnose_zero.py',[]),('fit_routes.py',['--zero']),('verify_result.py',[])]:
        log='fit_zero.log' if script=='fit_routes.py' else Path(script).with_suffix('.log').name
        assert 'Traceback (most recent call last)' not in (HERE/log).read_text()
        commands.append(dict(command=[runtime,str((HERE/script).relative_to(HERE.parents[3])),*args],
                             cwd=str(HERE.parents[3]),log=log,log_sha256=sha(HERE/log)))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,
        retained_initial_failures=['initial_attempt/fit_zero.log','initial_attempt/diagnose_zero.log'],
        original_source_and_main_preserved=True),ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_result.log','verify_publication.log']}
    (HERE/'delivery.json').write_text(json.dumps(dict(status='PASS',scope='Blocked-fit reporting only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),fit_status='BLOCKED',
        zero_pose_checked=7,zero_pose_failed=4,remaining_work_packages=4,files=files,
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,
        full_harness='BLOCKED',manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
    print('SMOOTH_FIT_DIAGNOSIS_PUBLISHED',len(files),'files',flush=True)


if __name__=='__main__':main()
