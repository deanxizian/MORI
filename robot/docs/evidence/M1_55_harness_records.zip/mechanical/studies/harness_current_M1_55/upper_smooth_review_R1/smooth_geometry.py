"""Tangent-matched cubic upper references, with continuous deviation bounds.

The fit preserves reference endpoints, actual hardware remains untouched.
These numerical curves are not selected cables or supplier cut dimensions.
"""
from pathlib import Path
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PAIR=HERE.parent/'upper_pairs_review_R2'
sys.path.insert(0,str(PAIR))
from matched_references import MatchedReferences,NAMES,RADII,FRAME,PREVIOUS,sha
from references import BSpline
from scipy.sparse.linalg import spsolve

# Geometric references only. The power/CC criteria retain the earlier 5xOD
# capacity convention. The CAM value is the historical reference criterion,
# not manufacturer-confirmed bend data for a selected factory SH tail.
MINIMUM_RADIUS={'P_J18_1':5.842,'P_J18_2':5.842,'CC_allocation':3.683,
                **{f'CAM_{p}':6.9342 for p in range(1,5)}}
MAX_DEVIATION=.001


def split_many(p):
    p=np.asarray(p);row=p.copy();left=[row[:,0]];right=[row[:,-1]]
    while row.shape[1]>1:
        row=(row[:,:-1]+row[:,1:])/2
        left.append(row[:,0]);right.append(row[:,-1])
    return np.concatenate([np.stack(left,axis=1),np.stack(right[::-1],axis=1)])


def pieces(spl,edges=None):
    edges=np.unique(spl.t) if edges is None else edges
    a,b=edges[:-1],edges[1:];h=(b-a)[:,None]/3
    p,q=spl(a),spl(b);d=spl.derivative(1)
    return np.stack([p,p+h*d(a),q-h*d(b),q],axis=1)


def radius_bound(spl,depth=7):
    ctrl=pieces(spl)
    for _ in range(depth):ctrl=split_many(ctrl)
    v=3*np.diff(ctrl,axis=1);a=2*np.diff(v,axis=1)
    lo,hi=v.min(1),v.max(1)
    nearest=np.where(lo>0,lo,np.where(hi<0,hi,0))
    speed=np.linalg.norm(nearest,axis=1)
    numerator=np.linalg.norm(np.cross(v[:,:,None,:],a[:,None,:,:]),axis=-1).max((1,2))
    R=np.divide(speed**3,numerator,out=np.full(len(ctrl),np.inf),where=numerator>1e-22)
    R[speed<=1e-12]=0
    return dict(radius_lower_mm=max(0.,float(R.min())-.0001),
                polynomial_cells=len(ctrl),derivative_nonzero=bool(np.all(speed>1e-12)),
                numeric_reserve_mm=.0001,scope='All curve parameters at one stored pose, not arbitrary angles or material life')


def deviation_bound(spl,raw,arc):
    # Include every original reference-polyline vertex and every B-spline
    # knot. Each resulting cell contains one cubic and one linear chord.
    edges=np.unique(np.r_[arc/arc[-1],spl.t])
    p=np.stack([np.interp(edges,arc/arc[-1],raw[:,j]) for j in range(3)],axis=1)
    cubics=pieces(spl,edges)
    a,b=p[:-1],p[1:]
    linear=np.stack([a,(2*a+b)/3,(a+2*b)/3,b],axis=1)
    maximum=float(np.linalg.norm(cubics-linear,axis=-1).max())+1e-8
    return dict(max_deviation_mm=maximum,polynomial_cells=len(cubics),
                method='Convex hull of exact cubic-minus-linear Bezier controls on every source vertex/knot interval')


def fit(raw,incoming,outgoing,spacing=2.):
    raw=np.asarray(raw,float)
    arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(raw,axis=0),axis=1))]
    assert np.all(np.diff(arc)>1e-10)
    length=arc[-1];count=max(16,int(math.ceil(length/spacing))+3)
    knots=np.r_[np.zeros(4),np.linspace(0,1,count-2)[1:-1],np.ones(4)]
    assert len(knots)==count+4
    samples=np.linspace(0,1,max(2200,12*count))
    target=np.stack([np.interp(samples,arc/length,raw[:,j]) for j in range(3)],axis=1)
    incoming=np.asarray(incoming);outgoing=np.asarray(outgoing)
    incoming=incoming/np.linalg.norm(incoming);outgoing=outgoing/np.linalg.norm(outgoing)
    c=np.zeros((count,3));h=length/(count-3)
    c[0]=raw[0];c[1]=raw[0]+incoming*h/3
    c[-1]=raw[-1];c[-2]=raw[-1]-outgoing*h/3
    fixed=[0,1,count-2,count-1];free=np.arange(2,count-2)
    B=BSpline.design_matrix(samples,knots,3).tocsr()
    A=B[:,free];rhs=target-B[:,fixed]@c[fixed]
    c[free]=spsolve((A.T@A).tocsc(),A.T@rhs)
    spl=BSpline(knots,c,3)
    dev=deviation_bound(spl,raw,arc);bend=radius_bound(spl)
    tangent=spl.derivative(1)([0,1]);tangent/=np.linalg.norm(tangent,axis=1)[:,None]
    errors=np.linalg.norm(tangent-np.stack([incoming,outgoing]),axis=1)
    assert errors.max()<1e-10
    endpoint_errors=np.linalg.norm(spl([0.,1.])-raw[[0,-1]],axis=1)
    assert np.array_equal(c[[0,-1]],raw[[0,-1]])
    assert endpoint_errors.max()<1e-10
    return spl,dict(spacing_mm=spacing,control_count=count,source_polyline_length_mm=float(length),
                    deviation=dev,continuous_bending=bend,
                    tangent_unit_vector_errors=errors.tolist(),
                    endpoints_unchanged=True,endpoint_evaluation_errors_mm=endpoint_errors.tolist(),actual_cut_length=None)


class SmoothContext(MatchedReferences):
    def __init__(self):
        super().__init__()
        path=PREVIOUS/'cc_power_bundle/length_review.json'
        import json
        meta=json.loads(path.read_text())
        self.upper_meta={(r['name'],r['yaw'],r['pitch']):r for r in meta['selected']['meta']}
        self.record([Path(__file__),path,
            Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49/cam_pitch_loop_geometry.py')])

    def tangents(self,name,yaw,pitch):
        c=self.f.candidate(name,yaw)['control']
        incoming=BSpline(self.f.knots,c,3).derivative()(1.)
        if name.startswith('CAM_'):
            mat=np.asarray(self.tr['transforms'][f'y{yaw}_p{pitch}'])
            outgoing=mat[:3,:3]@np.array([-1.,0.,0.])
        else:
            code='CC' if name=='CC_allocation' else name
            ctrl=np.asarray(self.upper_meta[code,yaw,pitch]['controls_yaw_local_mm'])
            mat=np.asarray(self.tr['transforms'][f'y{yaw}_p0'])
            outgoing=mat[:3,:3]@(ctrl[-1]-ctrl[-2])
        return incoming,outgoing
