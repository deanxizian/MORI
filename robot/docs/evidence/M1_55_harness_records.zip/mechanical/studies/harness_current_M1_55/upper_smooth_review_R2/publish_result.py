"""Publish finite curvature progress and the newly exposed length mismatch."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    names=['all_poses_exact_inspection.json','transfer_inspection.json','clearance_transfer.json',
           'geometry_verification.json','numeric_length_inventory.json']
    original,current,clearance,verified,lengths=[read(HERE/n) for n in names]
    assert all(r['status']=='PASS' for r in [original,current,clearance,verified,lengths])
    assert all(sha(p)==h for r in [original,current,clearance,verified,lengths] for p,h in r['sources'].items())
    assert original['checked_curve_poses']==current['checked_curve_poses']==910
    assert clearance['native_group_transfer_bounds']==clearance['upper_peer_transfer_bounds']==2730
    assert lengths['numeric_reference_range_status']=='FAIL'
    summary=[]
    for name in sorted({r['wire'] for r in current['rows']}):
        selected=[r for r in current['rows'] if r['wire']==name]
        L=next(r for r in lengths['summaries'] if r['wire']==name)
        summary.append(dict(wire=name,finite_poses=len(selected),
            radius_lower_mm=min(r['continuous_bending']['radius_lower_mm'] for r in selected),
            maximum_reference_deviation_mm=max(r['continuous_reference_deviation']['max_deviation_mm'] for r in selected),
            numeric_full_reference_range_mm=L['full_reference_range_mm'],numeric_length_status=L['numeric_reference_range_check']))
    rows=''.join(f'<tr><td>{r["wire"]}</td><td>{r["finite_poses"]}</td><td>{r["radius_lower_mm"]:.6f}</td><td>{r["maximum_reference_deviation_mm"]:.6f}</td><td>{r["numeric_full_reference_range_mm"]:.6f}</td><td>{r["numeric_length_status"]}</td></tr>' for r in summary)
    runtime='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13';commands=[]
    for script,args,log in [
        ('inspect_geometry.py',['--zero'],'inspect_zero.log'),
        ('inspect_geometry_exact_endpoints.py',['--zero'],'inspect_zero_exact.log'),
        ('inspect_geometry_exact_endpoints.py',[],'inspect_all_poses_exact.log'),
        ('refine_transfer_budget.py',[],'refine_transfer_budget.log'),
        ('prove_clearance_transfer.py',[],'prove_clearance_transfer.log'),
        ('verify_geometry.py',[],'verify_geometry.log'),
        ('inspect_complete_numeric_lengths.py',[],'inspect_complete_numeric_lengths.log')]:
        assert 'Traceback (most recent call last)' not in (HERE/log).read_text()
        commands.append(dict(command=[runtime,str((HERE/script).relative_to(PROJECT)),*args],cwd=str(PROJECT),
                             log=log,log_sha256=sha(HERE/log)))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,
        initial_construction_error='initial_rounded_attempt/inspect_zero.log: incorrectly required each end to use <49 percent of its segment; corrected to original neighbouring-corner fit checks',
        retained_initial_endpoint_result='zero_inspection.json: CC piece endpoint rounded5.7e-14mm; exact input endpoint retained in later report',
        retained_first_length_inventory='initial_length_inventory/source_archive_receipt.json; unreachable expression removed, numeric results unchanged'),ensure_ascii=False,indent=2)+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 上段分段曲率与完整长度核对</title>
<style>body{{max-width:1100px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}.scroll{{overflow:auto}}</style>
<h1>M1.55 · 上段分段曲率与完整长度核对</h1><p>2026-10-09 · <strong>7条已知上段：130有限姿态的整段曲率／切向接续PASS；完整线束BLOCKED／未采用。</strong></p>
<p class="notice">R1整段拟合在圆弧／直线的曲率变化处产生额外急弯。R2保留原构造分段，以短三次Hermite段表示圆弧，分别复核实际三次曲线的整段曲率、接续方向与参考偏差。未移动真实PCB、USB、端口或打印件；参考端点控制坐标完全保持。数值参考不是已选线材的弯折资格、实际尺寸精度或制造公差。</p>
<p><a href="../index.html">线束总览</a> · <a href="../upper_smooth_review_R1/index.html">R1失败拟合记录</a> · <a href="../upper_pairs_review_R2/index.html">配套原路线的有限间隙记录</a> · <a href="../../../../docs/CURRENT_STATUS.md">当前剩余清单</a> · <a href="../../../mori_v1_2.blend">主模型</a> · <a href="../../../animation/index.html">装配视频</a></p>
<h2>本轮完成</h2><p>7条×130姿态，共910个完整曲线参数检查通过。70条电源／CC曲线进一步拟合，最大连续参考偏差压到0.0005mm以内；840条按同一数组与来源保留。910条独立用单项式导数采样作保守性诊断，6个解析数值例子核对直线、偏差、分段端点导数速度和退化曲线。</p>
<p>通过新的偏差界证明，承接当前201件原生实体的2,730个分组检查和2,730个上段配对检查，保持原0.3mm目标。这里是新的三角不等式转移证明，原BVH和配对检查没有重跑。曲线偏差在原先已扣除的0.0006mm参考误差内；浮点变换的算子范数也计入。原折线远端自接近及自身接续的≤5mm排除不直接移用为新曲线的真实弧长证明。</p>
<h2>完整长度仍未闭合</h2><p class="notice">共同前段等长后，接上原上段，6条完整已知参考的数值长度仍随姿态变化；CAM最多约8.49mm，P_J18_2约7.08mm、CC约5.70mm。原上段包含针对旧前段的补偿，下一步需要重新匹配。P_J18_1的有限姿态数值长度变化很小，也没有因此变成实际材料或裁线资格。</p>
<div class="scroll"><table><tr><th>参考导线</th><th>姿态数</th><th>曲率半径下界mm</th><th>最大参考偏差mm</th><th>整条数值长度变化mm</th><th>历史0.01mm数值标准</th></tr>{rows}</table></div>
<p>转弯要求仅沿用现有容量研究：CAM6.9342mm、电源／CC5倍参考外径；不是厂配SH尾线的厂家动态标准。长度使用Gauss64积分，Gauss32／64差约{lengths['maximum_Gauss32_64_difference_mm']:.3g}mm仅为数值对照，没有完整积分误差证书，也不是实物线长。Z200材料分界仍是容量接续位置，未确定实际拼接／固定点。</p>
<h2>还要继续</h2><ol><li>重新匹配完整长度补偿，验证新曲线的自接近、接续局部及中间运动角度；补齐3根舵机与2根喇叭的上段参考。</li><li>确定实际材料、尾线、端接与固定／滑移点，才可形成供应商裁线图。</li><li>接收CAM供电正式源端，确认喇叭插头；舵盘／锁紧配件及微雪FPC／FFC按用户决定到货校准。</li><li>完成带线穿入、头身安装、拆壳与闭壳，确认后同步主模型和动画。</li></ol>
<p>没有新增打印件、紧固件、采购或供应商消息；没有新commit／push。M1.55主模型与M1.55-A1视频、846份原生硬件文件保持。</p>
<h2>原始证据</h2><p><a href="all_poses_exact_inspection.json">910个完整曲率检查</a> · <a href="transfer_inspection.json">70条精化与840条保留</a> · <a href="clearance_transfer.json">原生／跨线间隙转移证明</a> · <a href="geometry_verification.json">独立几何核对与解析例子</a> · <a href="numeric_length_inventory.json">910个整条数值长度</a> · <a href="zero_inspection.json">首次端点舍入记录</a> · <a href="commands.json">实际命令／日志</a> · <a href="README.md">复现边界</a> · <a href="delivery.json">发布哈希</a></p>
<p>PROTOTYPE / UNVALIDATED · 线路PLACEHOLDER / ASSUMED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# M1.55 上段分段曲率 R2：未采用

7条已知上段×130有限姿态：910个整段曲率、切向接续、端点控制坐标检查通过。
保留圆弧／直线分段；每个实际三次段给出速度与叉积凸包下界，不借名义R7放行。
偏差在所有源折线顶点／段边界间通过三次减一次控制凸包连续界核对。
R1整段拟合的4根CAM急弯记录保留；不是原解析圆弧或主模型的缺陷判定。

70条曲线进一步拟合，840条按精确数组保留，使全部参考偏差<=0.0005mm。
通过三角不等式的新证明承接当前201件实体的2730个分组和2730个上段配对结果，
没有重跑这些BVH／距离检查。实际偏差在此前0.0006mm扣减内；矩阵范数计入。
原保存折线的<=5mm局部排除没有当作新曲线实际弧长或局部管体资格。
6个解析数值例子及全部910条的独立单项式导数诊断核对算法和覆盖。

完整已知参考的Gauss64长度另外计算：6条仍随姿态变化，CAM最多约8.49mm、
P_J18_2约7.08mm、CC约5.70mm。原上段的旧前段补偿需重匹配。
Gauss32／64一致不证明真实材料恒长、端接、压接、弹性或裁线资格。
完整中间运动、真实弧长自接近、5条缺失上段、端接／固定和带线装配仍未闭合。

首次rounded误加49%约束，与原构造的首末段／相邻圆角检查不一致，日志及代码
保留initial_rounded_attempt。首次CC段转换仅有5.7e-14mm端点舍入，报告保留；
之后直接保留原端点控制坐标。首次长度脚本的不可达表达式删去，原代码／输出
保留initial_length_inventory并有来源映射；有效公式与结果没有改变。
实际命令、版本与日志见commands.json。没有修改主模型、动画或硬件，没有Git动作。
''')
    progress=dict(status='PASS',scope='Verified finite progress inventory only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources={str(HERE/n):sha(HERE/n) for n in names},
        finite_curve_poses=910,upper_whole_curvature_finite='PASS',upper_G1_join_finite='PASS',
        native_and_peer_gap_transfer_finite='PASS',native_group_bounds=2730,upper_peer_bounds=2730,
        numeric_full_length_range='FAIL',failed_full_reference_length_families=6,
        summaries=summary,remaining_work_packages=4,full_harness='BLOCKED',
        upper_between_pose_motion='NOT_TESTED',actual_material_and_termination='BLOCKED',wired_assembly='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_result.log','verify_publication.log']}
    (HERE/'delivery.json').write_text(json.dumps(dict(status='PASS',scope='Finite curvature and length-diagnostic publication only',
        files=files,upper_whole_curvature_finite='PASS',native_and_peer_gap_transfer_finite='PASS',
        numeric_full_length_range='FAIL',remaining_work_packages=4,full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
    print('PIECEWISE_UPPER_PUBLISHED',len(files),'files',flush=True)


if __name__=='__main__':main()
