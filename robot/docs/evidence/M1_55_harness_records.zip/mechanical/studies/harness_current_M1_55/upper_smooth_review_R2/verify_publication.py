"""Verify delivered evidence, historical source mappings and local links."""
from pathlib import Path
import datetime
import hashlib
import json
import re
from urllib.parse import unquote,urlsplit
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
d=read(HERE/'delivery.json');progress=read(HERE/'progress.json')
assert d['status']==progress['status']=='PASS' and d['numeric_full_length_range']=='FAIL'
assert all(sha(HERE/p)==h for p,h in d['files'].items())
assert all(sha(p)==h for p,h in progress['sources'].items())
geometry=read(HERE/'geometry_verification.json')
assert geometry['status']=='PASS' and geometry['complete_curve_parameter_checks']==910
assert all(sha(p)==h for p,h in geometry['sources'].items())
lengths=read(HERE/'numeric_length_inventory.json')
assert all(sha(p)==h for p,h in lengths['sources'].items())
archive=read(HERE/'initial_length_inventory/source_archive_receipt.json')
assert all(sha(r['archived_path'])==r['sha256'] for r in archive['files'].values())
links=[]
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(value)
    if parsed.scheme or not parsed.path:continue
    p=(HERE/unquote(parsed.path)).resolve()
    assert p.is_file() and p.is_relative_to(PROJECT),(value,p)
    with urlopen(Request('http://127.0.0.1:58202/'+str(p.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:
        assert response.status==200
    links.append(str(p.relative_to(PROJECT)))
with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:
    assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
out=dict(status='PASS',scope='Publication and verified result boundaries, not full harness',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checked_files=len(d['files']),checked_links=links,
    delivery_sha256=sha(HERE/'delivery.json'),script_sha256=sha(Path(__file__)),
    upper_whole_curvature_finite='PASS',numeric_full_length_range='FAIL',full_harness='BLOCKED',
    main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
(HERE/'publication_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PIECEWISE_UPPER_PUBLICATION_VERIFIED',len(d['files']),'files',len(links),'links',flush=True)
