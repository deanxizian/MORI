"""Refine only curves exceeding the existing clearance-error allowance.

The original seven-by130 curvature report remains unchanged. A tighter
reference-deviation target preserves those routes closely enough for a new
triangle-inequality transfer proof, rather than assuming inherited PASS.
"""
from pathlib import Path
import datetime
import json
import time
import numpy as np

from piecewise_geometry import PiecewiseContext,fit,pieces,radius_bound,deviation_bound,unit,MINIMUM_RADIUS,MAX_DEVIATION,sha

HERE=Path(__file__).resolve().parent
TARGET=.0005


def main():
    started=time.time();ctx=PiecewiseContext()
    path=HERE/'all_poses_exact_inspection.json';prior=json.loads(path.read_text())
    assert prior['status']=='PASS' and prior['checked_curve_poses']==910
    assert all(sha(p)==h for p,h in prior['sources'].items())
    source=HERE/'all_poses_exact_curves.npz'
    assert sha(source)==prior['arrays_sha256']
    old=np.load(source);arrays={k:old[k] for k in old.files};rows=[];changed=[];fails=[];cached={}
    ctx.record([Path(__file__),path,source])
    for before in prior['rows']:
        row=dict(before);name=row['wire'];yaw=row['yaw_deg'];pitch=row['pitch_deg']
        if row['continuous_reference_deviation']['max_deviation_mm']>TARGET:
            assert not name.startswith('CAM_')
            if (yaw,pitch) not in cached:cached[yaw,pitch]=ctx.upper(yaw,pitch)
            raw=cached[yaw,pitch][name];incoming,outgoing=ctx.tangents(name,yaw,pitch)
            attempts=[]
            for spacing in [1.,.5,.25]:
                spl,detail=fit(raw,incoming,outgoing,spacing);attempts.append(detail)
                if detail['deviation']['max_deviation_mm']<=TARGET and detail['continuous_bending']['radius_lower_mm']>=MINIMUM_RADIUS[name]:break
            c=pieces(spl);c[0,0]=raw[0];c[-1,-1]=raw[-1]
            lengths=np.diff(np.unique(spl.t))*detail['source_polyline_length_mm']
            bend=radius_bound(c);deviation=deviation_bound(c,lengths,raw)
            left=np.diff(c,axis=1)[:,-1];right=np.diff(c,axis=1)[:,0]
            left/=np.linalg.norm(left,axis=1)[:,None];right/=np.linalg.norm(right,axis=1)[:,None]
            internal=float(np.linalg.norm(left[:-1]-right[1:],axis=1).max())
            end=float(max(np.linalg.norm(right[0]-unit(incoming)),np.linalg.norm(left[-1]-unit(outgoing))))
            assert np.array_equal(c[0,0],raw[0]) and np.array_equal(c[-1,-1],raw[-1])
            assert np.linalg.norm(c[:-1,-1]-c[1:,0],axis=1).max()<1e-10
            ok=(bend['radius_lower_mm']>=MINIMUM_RADIUS[name] and deviation['max_deviation_mm']<=TARGET and internal<1e-8 and end<1e-8)
            row.update(status='PASS' if ok else 'BLOCKED',pieces=len(c),piece_kinds={'single_spline':len(c)},
                continuous_bending=bend,continuous_reference_deviation=deviation,internal_tangent_unit_error=internal,
                end_tangent_unit_error=end,details=dict(tighter_fit_attempts=attempts),
                numerical_reference_parameter_length_mm=float(lengths.sum()))
            key=f'{name}_y{yaw}_p{pitch}';arrays[key+'_controls']=c;arrays[key+'_lengths']=lengths
            changed.append(dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,before_max_deviation_mm=before['continuous_reference_deviation']['max_deviation_mm'],
                                after_max_deviation_mm=deviation['max_deviation_mm'],status=row['status']))
            print('TRANSFER_REFINEMENT',yaw,pitch,name,row['status'],deviation['max_deviation_mm'],flush=True)
        row['clearance_transfer_deviation_target_mm']=TARGET
        row['original_curve_acceptance_deviation_mm']=MAX_DEVIATION
        rows.append(row)
        if row['status']!='PASS' or row['continuous_reference_deviation']['max_deviation_mm']>TARGET:fails.append(row)
    ctx.unchanged();np.savez_compressed(HERE/'transfer_curves.npz',**arrays)
    out=dict(status='PASS' if not fails else 'BLOCKED',
        scope='Complete finite upper curvature with <=0.0005 mm stored-reference deviation; clearance transfer still separate',
        revision='V1.2-M1.55',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        rows=rows,failures=fails,checked_curve_poses=len(rows),refined_curve_poses=len(changed),
        unchanged_curve_poses_reused=len(rows)-len(changed),refinements=changed,
        original_continuous_reference_deviation_target_mm=MAX_DEVIATION,transfer_target_mm=TARGET,
        arrays_sha256=sha(HERE/'transfer_curves.npz'),elapsed_s=time.time()-started,
        current_native_clearance='NOT_TESTED',current_peer_clearance='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',actual_material_and_cut_length='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'transfer_inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('TRANSFER_REFINEMENT_TERMINAL',out['status'],len(changed),'refined',len(rows)-len(changed),'carried',out['elapsed_s'],flush=True)


if __name__=='__main__':main()
