"""C1 piecewise-cubic references following the retained line/arc construction.

Circle pieces use endpoint-tangent Hermite cubics; their actual cubic curvature
and deviation from the immutable references are checked, rather than inheriting
the nominal circle radius. No purchased geometry or physical end is moved.
"""
from pathlib import Path
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'upper_smooth_review_R1'))
from smooth_geometry import SmoothContext,BSpline,fit,pieces,split_many,MINIMUM_RADIUS,MAX_DEVIATION,RADII,sha
OLD=Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49')


def unit(v):
    v=np.asarray(v,float);length=np.linalg.norm(v)
    assert length>1e-12
    return v/length


class Builder:
    def __init__(self):self.controls=[];self.lengths=[];self.kinds=[]

    def add(self,c,length,kind):
        c=np.array(c,float);assert length>1e-10
        if self.controls:
            delta=self.controls[-1][-1]-c[0]
            assert np.linalg.norm(delta)<1e-5,(kind,delta)
            # Correct only source floating-point seam discrepancy, preserving
            # the first control displacement and hence incoming direction.
            c[:2]+=delta
        self.controls.append(c);self.lengths.append(float(length));self.kinds.append(kind)

    @property
    def end(self):return self.controls[-1][-1]

    def line(self,a,b):
        a=np.asarray(a,float);b=np.asarray(b,float);L=np.linalg.norm(b-a)
        if L>1e-9:self.add([a,(2*a+b)/3,(a+2*b)/3,b],L,'line')

    def arc(self,center,u,v,radius,start,end):
        center=np.asarray(center,float);u=np.asarray(u,float);v=np.asarray(v,float)
        if abs(end-start)<1e-10:return
        # Bound the resulting cubics separately, even though the source uses
        # circles. A C2 fit across curvature jumps caused the R1 overshoot.
        edges=np.linspace(start,end,math.ceil(abs(end-start)/.1)+1)
        for a,b in zip(edges[:-1],edges[1:]):
            point=lambda t:center+radius*(np.cos(t)*u+np.sin(t)*v)
            derivative=lambda t:radius*(-np.sin(t)*u+np.cos(t)*v)
            p,q=point(a),point(b);h=(b-a)/3
            self.add([p,p+h*derivative(a),q-h*derivative(b),q],radius*abs(b-a),'circle_Hermite')

    def shift(self,start,xy,radius):
        start=np.asarray(start,float);delta=np.r_[np.asarray(xy)-start[:2],0.]
        D=float(np.linalg.norm(delta))
        if D<1e-9:return start
        axis=delta/D;up=np.array([0.,0.,1.])
        angle=math.acos(1-D/(2*radius)) if D<2*radius else math.pi/2
        self.arc(start+radius*axis,-axis,up,radius,0,angle)
        middle=self.end.copy();self.line(middle,middle+max(0.,D-2*radius)*axis)
        middle=self.end.copy()
        self.arc(middle-radius*math.cos(angle)*axis+radius*math.sin(angle)*up,
                 axis,-up,radius,angle,0)
        return self.end.copy()

    def rounded(self,points,radius):
        points=np.array(points,float);cursor=points[0]
        distances=np.linalg.norm(np.diff(points,axis=0),axis=1)
        tangents=[]
        for a,b,c in zip(points,points[1:],points[2:]):
            angle=math.acos(float(np.clip(unit(b-a)@unit(c-b),-1,1)))
            tangents.append(radius*math.tan(angle/2))
        # Match the retained source's end and neighbouring-corner checks.
        # A first/last segment contains one corner, not two half-length cuts.
        assert distances[0]>=tangents[0] and distances[-1]>=tangents[-1]
        assert all(distances[i+1]>=tangents[i]+tangents[i+1]+.05 for i in range(len(tangents)-1))
        for a,b,c in zip(points,points[1:],points[2:]):
            incoming=unit(b-a);outgoing=unit(c-b)
            angle=math.acos(float(np.clip(incoming@outgoing,-1,1)))
            if angle<1e-10:
                self.line(cursor,b);cursor=b;continue
            tangent=radius*math.tan(angle/2)
            start=b-tangent*incoming;finish=b+tangent*outgoing
            normal=unit(outgoing-(incoming@outgoing)*incoming)
            self.line(cursor,start)
            self.arc(start+radius*normal,-normal,incoming,radius,0,angle)
            assert np.linalg.norm(self.end-finish)<1e-8
            cursor=finish
        self.line(cursor,points[-1])

    def append(self,other,matrix):
        matrix=np.asarray(matrix)
        for c,L,k in zip(other.controls,other.lengths,other.kinds):
            self.add(c@matrix[:3,:3].T+matrix[:3,3],L,k)


def radius_bound(ctrl,depth=7):
    ctrl=np.asarray(ctrl,float);original_count=len(ctrl)
    for _ in range(depth):ctrl=split_many(ctrl)
    v=3*np.diff(ctrl,axis=1);a=2*np.diff(v,axis=1)
    lo,hi=v.min(1),v.max(1)
    speed=np.linalg.norm(np.where(lo>0,lo,np.where(hi<0,hi,0)),axis=1)
    cross=np.linalg.norm(np.cross(v[:,:,None,:],a[:,None,:,:]),axis=-1).max((1,2))
    R=np.divide(speed**3,cross,out=np.full(len(ctrl),np.inf),where=cross>1e-22)
    R[speed<=1e-12]=0
    return dict(radius_lower_mm=max(0.,float(R.min())-.0001),cells=len(ctrl),worst_piece_index=int(np.argmin(R)%original_count),
                derivative_nonzero=bool(np.all(speed>1e-12)),numeric_reserve_mm=.0001)


def evaluate(ctrl,lengths,t,derivative=False,piece_indices=None):
    lengths=np.asarray(lengths);edges=np.r_[0.,np.cumsum(lengths)];edges/=edges[-1]
    t=np.asarray(t);i=np.clip(np.searchsorted(edges,t,side='right')-1,0,len(ctrl)-1) if piece_indices is None else piece_indices
    h=edges[i+1]-edges[i];u=(t-edges[i])/h;c=np.asarray(ctrl)[i]
    if derivative:
        d=3*np.diff(c,axis=1)
        value=(1-u)[:,None]**2*d[:,0]+2*(u*(1-u))[:,None]*d[:,1]+u[:,None]**2*d[:,2]
        return value/h[:,None]
    return ((1-u)**3)[:,None]*c[:,0]+(3*u*(1-u)**2)[:,None]*c[:,1]+(3*u*u*(1-u))[:,None]*c[:,2]+(u**3)[:,None]*c[:,3]


def deviation_bound(ctrl,lengths,raw):
    arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(raw,axis=0),axis=1))];arc/=arc[-1]
    edges=np.r_[0.,np.cumsum(lengths)];edges/=edges[-1]
    merged=np.unique(np.r_[arc,edges]);a,b=merged[:-1],merged[1:]
    indices=np.clip(np.searchsorted(edges,(a+b)/2,side='right')-1,0,len(ctrl)-1)
    p,q=evaluate(ctrl,lengths,a,piece_indices=indices),evaluate(ctrl,lengths,b,piece_indices=indices);h=(b-a)[:,None]/3
    cubics=np.stack([p,p+h*evaluate(ctrl,lengths,a,True,indices),q-h*evaluate(ctrl,lengths,b,True,indices),q],axis=1)
    r=np.stack([np.interp(merged,arc,raw[:,j]) for j in range(3)],axis=1)
    line=np.stack([r[:-1],(2*r[:-1]+r[1:])/3,(r[:-1]+2*r[1:])/3,r[1:]],axis=1)
    return dict(max_deviation_mm=float(np.linalg.norm(cubics-line,axis=-1).max())+1e-8,cells=len(a),
                scope='Continuous candidate-minus-stored-polyline bound with piecewise nominal-length parameter')


class PiecewiseContext(SmoothContext):
    def __init__(self):
        super().__init__()
        fan_path=OLD/'remaining_routes/cam_side_fans/fan_screen.json'
        loop_path=OLD/'remaining_routes/cam_side_following/loop_screen.json'
        fan=json.loads(fan_path.read_text());loop=json.loads(loop_path.read_text())
        self.fan={r['pin']:r for r in fan['selected']}
        selected=next(r for r in loop['results'] if r['status']=='PASS')
        self.loop={(r['pin'],r['yaw'],r['pitch_deg']):r for r in selected['metadata']}
        self.loop_spec=selected
        tail_root=HERE.parent.parent/'harness_current_M1_54/usb_complete_reference'
        tail_receipt=json.loads((tail_root/'final_tail_screen.json').read_text())
        assert sha(tail_root/'final_tails.npz')==tail_receipt['tails_sha256']
        self.tail_spec=tail_receipt['selected']['spec']
        # Historical PASS is not inherited. Only exact array/metadata receipts
        # and its construction formulas are read for new M1.55 checks.
        paths=[fan_path,loop_path,OLD/'upper_curve_geometry.py',OLD/'cam_side_service_geometry.py',
               OLD/'screen_cam_side_fans.py',OLD/'screen_cam_side_following.py',
               tail_root/'final_tails.npz',tail_root/'final_tail_screen.json',tail_root/'screen_final_tails.py',
               tail_root.parent/'cam_upper_reroute/screen_rear_detour.py']
        self.record(paths+[Path(__file__)])

    def cam_curve(self,pin,yaw,pitch,raw):
        result=Builder();name=f'CAM_{pin}';my=np.asarray(self.tr['transforms'][f'y{yaw}_p0'])
        mp=np.asarray(self.tr['transforms'][f'y0_p{pitch}']);mt=np.asarray(self.tr['transforms'][f'y{yaw}_p{pitch}'])
        spec=self.fan[pin];m=self.loop[pin,yaw,pitch];tail=self.cam[f'pin{pin}']
        fan_start=np.asarray(spec['start_mm']);expected=fan_start@my[:3,:3].T+my[:3,3]
        i=int(np.argmin(np.linalg.norm(raw-expected,axis=1)))
        assert np.linalg.norm(raw[i]-expected)<1e-5
        incoming,outgoing=self.tangents(name,yaw,pitch)
        if i:
            spl,details=fit(raw[:i+1],incoming,my[:3,:3]@np.array([0.,0.,1.]),.5)
            assert details['deviation']['max_deviation_mm']<MAX_DEVIATION
            edges=np.unique(spl.t);length=details['source_polyline_length_mm']
            for c,h in zip(pieces(spl),np.diff(edges)):result.add(c,h*length,'neck_fit')
        local=Builder();inverse=np.linalg.inv(my)
        start=raw[i]@inverse[:3,:3].T+inverse[:3,3];lead=spec['lead_mm']
        first=start+[0,0,lead];local.line(start,first)
        anchor=np.asarray(m['anchor_mm']);local.shift(first,anchor[:2],spec['radius_mm']);local.line(local.end,anchor)
        a=anchor;first=a+[0,0,self.loop_spec['lead_mm']];local.line(a,first)
        endpoint=tail[0]-[0,0,15.]
        b=endpoint@mp[:3,:3].T+mp[:3,3];angle=math.radians(pitch);s,c=math.sin(angle),math.cos(angle)
        sign=1. if pitch>=0 else -1.;tangent=np.array([0.,s,-c]);terminal=self.loop_spec['terminal_straight_mm']
        d=b-terminal*tangent;lower=d-[0,sign*7.5*(1-c),-7.5*abs(s)]
        local.shift(first,[b[0],lower[1]+14.],7.)
        top=local.end+[0,0,m['upper_lead_mm']];local.line(local.end,top)
        local.arc(top+[0,-7.,0],[0,1,0],[0,0,1],7.,0,math.pi)
        local.line(local.end,lower)
        local.arc(lower+[0,sign*7.5,0],[0,-sign,0],[0,0,-1],7.5,0,abs(angle))
        assert np.linalg.norm(local.end-d)<1e-5
        result.append(local,my)
        upper=Builder();start,end=tail[[0,-1]];j=pin-1;r=7.5+j
        right=self.tail_spec['right'];top_z=self.tail_spec['top'];under=self.tail_spec['under'];R=self.tail_spec['return_radius']
        x=right+r;y=end[1]+2*R;c3=np.array([right,end[1],end[2]-r]);a3=c3+[r,0,0]
        points=[start,[start[0],start[1],210.-1.3*j],[start[0],-40.-1.3*j,210.-1.3*j],
                [start[0],-40.-1.3*j,240.],[start[0],y,top_z+j],[x,y,top_z+j],[x,y,under]]
        upper.rounded(points,7.5)
        upper.arc([x,end[1]+R,under],[0,1,0],[0,0,-1],R,0,math.pi)
        upper.line(upper.end,a3);upper.arc(c3,[1,0,0],[0,0,1],r,0,math.pi/2);upper.line(upper.end,end)
        old_end=result.end.copy();first_ctrl=upper.controls[0]@mt[:3,:3].T+mt[:3,3]
        final_direction=unit(first_ctrl[1]-first_ctrl[0]);last=result.controls[-1]
        last[3]=first_ctrl[0];last[2]=last[3]-final_direction*np.linalg.norm(last[3]-last[2])
        assert np.linalg.norm(old_end-result.end)<1e-5
        result.append(upper,mt)
        # Preserve exact old endpoints and exact incoming/outgoing directions.
        first=result.controls[0];delta=raw[0]-first[0];first[0]=raw[0]
        first[1]=first[0]+unit(incoming)*np.linalg.norm(first[1]-first[0]+delta)
        last=result.controls[-1];delta=raw[-1]-last[-1];last[-1]=raw[-1]
        last[-2]=last[-1]-unit(outgoing)*np.linalg.norm(last[-1]-last[-2]-delta)
        return result,dict(neck_reference_index=i,source_floating_seam_correction_mm=float(np.linalg.norm(old_end-first_ctrl[0])),
                           tail_source_spec=dict(right=right,top=top_z,under=under,return_radius=R))
