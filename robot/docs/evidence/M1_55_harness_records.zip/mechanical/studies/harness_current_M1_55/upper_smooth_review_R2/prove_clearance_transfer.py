"""Transfer finite native/peer bounds through certified curve deviations.

This is a new triangle-inequality proof using prior exact-source clearance
records, not a new BVH replay and not an inheritance of whole-harness PASS.
Saved-polyline self exclusions cannot be transferred as actual arc exclusions.
"""
from pathlib import Path
import datetime
import itertools
import json
import numpy as np

from piecewise_geometry import PiecewiseContext,sha,RADII

HERE=Path(__file__).resolve().parent
PAIR=HERE.parent/'upper_pairs_review_R2'
read=lambda p:json.loads(Path(p).read_text())


def main():
    ctx=PiecewiseContext();current_path=HERE/'transfer_inspection.json';current=read(current_path)
    assert current['status']=='PASS' and current['checked_curve_poses']==910
    assert all(sha(p)==h for p,h in current['sources'].items())
    assert sha(HERE/'transfer_curves.npz')==current['arrays_sha256']
    paths=[PAIR/'result_verification.json',PAIR/'inspection.json',PAIR/'native_inspection.json',
           PAIR/'native_refinement.json',HERE.parent/'upper_reference_review_R1/inspection.json']
    checked,peer,power,refined,other=[read(p) for p in paths]
    assert checked['status']==peer['status']==refined['status']==other['status']=='PASS'
    assert checked['current_all_known_upper_native_group_checks']==2730
    assert all(sha(p)==h for d in [checked,peer,power,refined,other] for p,h in d['sources'].items())
    ctx.record(paths+[Path(__file__),current_path,HERE/'transfer_curves.npz'])
    assert power['required_gap_mm']==refined['required_gap_mm']==peer['required_gap_mm']==.3
    native_index={(r['yaw_deg'],r['pitch_deg'],r['wire'],r['group']):r for r in power['rows']}
    for r in refined['rows']:
        assert r['smooth_chord_error_allowance_mm']==.0006
        native_index[r['yaw_deg'],r['pitch_deg'],r['wire'],r['group']]=r
    for r in other['rows']:
        if r['wire'].startswith('P_J18'):continue
        assert r['radius_mm']==RADII[r['wire']] and r['chord_error_allowance_mm']==.0006
        for n in r['native']:native_index[r['yaw_deg'],r['pitch_deg'],r['wire'],n['group']]=n
    names=set(RADII);poses=list(itertools.product(range(-60,61,10),range(-20,26,5)))
    assert set(native_index)=={(y,p,n,g) for y,p in poses for n in names for g in ['body','yaw','pitch']}
    assert all(r['status']=='PASS' and not r['hits'] for r in native_index.values())
    # The current/reference error is a continuous corresponding-parameter
    # bound. Transform operator norms cover the float32 rotation matrices.
    deviations={(r['yaw_deg'],r['pitch_deg'],r['wire']):r['continuous_reference_deviation']['max_deviation_mm'] for r in current['rows']}
    native_rows=[];peer_rows=[]
    for yaw,pitch in poses:
        for name in names:
            deviation=deviations[yaw,pitch,name]
            for group in ['body','yaw','pitch']:
                matrix=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(ctx.tr['transforms'][f'y{yaw}_p{pitch if group=="pitch" else 0}']))
                norm=float(np.linalg.svd(matrix[:3,:3],compute_uv=False)[0]);required=norm*deviation
                assert required<.0006
                native_rows.append(dict(yaw_deg=yaw,pitch_deg=pitch,wire=name,group=group,status='PASS',
                    original_reference_allowance_mm=.0006,transformed_candidate_deviation_mm=required,
                    allowance_remaining_mm=.0006-required,linear_operator_norm=norm,required_gap_mm=.3,
                    method='Original polyline-to-native lower bound minus no more than its already reserved error allowance'))
    for r in peer['rows']:
        if r['kind']!='peer':continue
        assert r['status']=='PASS' and r['gap_lower_mm']>=.3
        yaw,pitch=r['yaw_deg'],r['pitch_deg'];a,b=r['wires']
        da,db=deviations[yaw,pitch,a],deviations[yaw,pitch,b]
        assert da<=.0006 and db<=.0006
        peer_rows.append(dict(yaw_deg=yaw,pitch_deg=pitch,wires=[a,b],status='PASS',
            original_allowance_mm_each=.0006,candidate_deviations_mm=[da,db],
            required_gap_mm=.3,method='Distance between candidate curves >= reference-polyline distance minus both continuous deviations'))
    assert len(native_rows)==len(peer_rows)==2730
    assert {(r['yaw_deg'],r['pitch_deg'],*r['wires']) for r in peer_rows}=={
        (y,p,a,b) for y,p in poses for a,b in itertools.combinations(list(RADII),2)}
    ctx.unchanged()
    out=dict(status='PASS',scope='New finite-pose deviation-transfer proof only; no new native BVH or segment-pair replay',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        revision='V1.2-M1.55',finite_poses=130,native_parts=201,
        native_group_transfer_bounds=len(native_rows),upper_peer_transfer_bounds=len(peer_rows),
        native_bounds=native_rows,peer_bounds=peer_rows,
        minimum_remaining_native_error_allowance_mm=min(r['allowance_remaining_mm'] for r in native_rows),
        native_geometry_sources_identical=True,original_reference_paths_identical=True,
        native_gap_finite='PASS',upper_peer_gap_finite='PASS',
        upper_remote_self_actual_arc='NOT_TESTED',upper_own_join_actual_arc='NOT_TESTED',
        local_smooth_tube='NOT_TESTED',upper_between_pose_motion='NOT_TESTED',
        actual_material_and_cut_length='BLOCKED',wired_assembly='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'clearance_transfer.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('UPPER_CLEARANCE_TRANSFER_TERMINAL',out['status'],len(native_rows),'native bounds',len(peer_rows),'peer bounds',flush=True)


if __name__=='__main__':main()
