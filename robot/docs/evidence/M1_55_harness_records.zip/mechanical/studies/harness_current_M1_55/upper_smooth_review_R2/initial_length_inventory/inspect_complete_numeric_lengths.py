"""Inventory full known reference lengths; never output supplier cut lengths."""
from pathlib import Path
import datetime
import json
import numpy as np

from piecewise_geometry import PiecewiseContext,sha

HERE=Path(__file__).resolve().parent


def upper_length(c,order):
    q,w=np.polynomial.legendre.leggauss(order);t=(q+1)/2
    velocity=3*np.diff(c,axis=1)
    v=(1-t)[None,:,None]**2*velocity[:,None,0]+2*(t*(1-t))[None,:,None]*velocity[:,None,1]+t[None,:,None]**2*velocity[:,None,2]
    return float(np.linalg.norm(v,axis=-1)@(w/2)).sum() if False else float((np.linalg.norm(v,axis=-1)@(w/2)).sum())


def main():
    ctx=PiecewiseContext();path=HERE/'transfer_inspection.json';source=HERE/'transfer_curves.npz'
    receipt=json.loads(path.read_text())
    assert receipt['status']=='PASS' and sha(source)==receipt['arrays_sha256']
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    arrays=np.load(source);rows=[];body={}
    for yaw in range(-60,61,10):
        for name in {r['wire'] for r in receipt['rows']}:
            control=ctx.f.candidate(name,yaw)['control']
            body[yaw,name]=float(ctx.f.weights@np.linalg.norm(ctx.f.Q@control,axis=1))
            assert abs(body[yaw,name]-ctx.f.targets[name])<1e-7
    for row in receipt['rows']:
        name=row['wire'];yaw=row['yaw_deg'];pitch=row['pitch_deg'];key=f'{name}_y{yaw}_p{pitch}'
        c=arrays[key+'_controls'];L64=upper_length(c,64);L32=upper_length(c,32)
        rows.append(dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,
                        body_neck_Gauss64_length_mm=body[yaw,name],upper_Gauss64_length_mm=L64,
                        full_known_reference_Gauss64_length_mm=body[yaw,name]+L64,
                        upper_Gauss32_64_difference_mm=abs(L64-L32),actual_material_cut_length_mm=None))
    summaries=[]
    for name in sorted({r['wire'] for r in rows}):
        selected=[r for r in rows if r['wire']==name];lengths=[r['full_known_reference_Gauss64_length_mm'] for r in selected]
        a=min(selected,key=lambda r:r['full_known_reference_Gauss64_length_mm'])
        b=max(selected,key=lambda r:r['full_known_reference_Gauss64_length_mm'])
        summaries.append(dict(wire=name,stored_poses=len(selected),body_neck_target_mm=ctx.f.targets[name],
            full_reference_min_mm=min(lengths),full_reference_max_mm=max(lengths),full_reference_range_mm=max(lengths)-min(lengths),
            minimum_at=[a['yaw_deg'],a['pitch_deg']],maximum_at=[b['yaw_deg'],b['pitch_deg']],
            historical_numeric_range_criterion_mm=.01,
            numeric_reference_range_check='PASS' if max(lengths)-min(lengths)<.01 else 'FAIL',
            real_wire_length_and_dynamic_compliance='BLOCKED'))
    ctx.record([Path(__file__),path,source]);ctx.unchanged()
    out=dict(status='PASS',scope='Verified numeric length inventory only; no material or supplier release',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        rows=rows,summaries=summaries,known_full_reference_pose_lengths=len(rows),
        numeric_reference_range_status='PASS' if all(r['numeric_reference_range_check']=='PASS' for r in summaries) else 'FAIL',
        historical_numeric_range_criterion_mm=.01,
        criterion_scope='Historical nominal path-length variation criterion, not vendor tolerance, elasticity or cut-length specification',
        maximum_Gauss32_64_difference_mm=max(r['upper_Gauss32_64_difference_mm'] for r in rows),
        quadrature_error_certificate='NOT_TESTED',upper_between_pose_motion='NOT_TESTED',
        physical_material_split_or_splice='BLOCKED',actual_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'numeric_length_inventory.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    for row in summaries:print('KNOWN_REFERENCE_LENGTH',row['wire'],row['numeric_reference_range_check'],row['full_reference_range_mm'],flush=True)
    print('KNOWN_REFERENCE_LENGTH_TERMINAL',out['numeric_reference_range_status'],len(rows),out['maximum_Gauss32_64_difference_mm'],flush=True)


if __name__=='__main__':main()
