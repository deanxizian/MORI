"""Independent polynomial diagnostics, coverage and exact endpoint checks."""
from pathlib import Path
import datetime
import itertools
import json
import math
import subprocess
import numpy as np

from piecewise_geometry import PiecewiseContext,Builder,radius_bound,deviation_bound,unit,MINIMUM_RADIUS,sha

HERE=Path(__file__).resolve().parent;MECHANICAL=HERE.parents[2];PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())


def sampled_radius(c):
    # Direct monomial derivatives, independent of Bezier bound helpers.
    a=np.asarray(c);u=np.linspace(0,1,33)[None,:,None]
    b=3*(a[:,1]-a[:,0]);q=3*(a[:,2]-2*a[:,1]+a[:,0]);d=a[:,3]-3*a[:,2]+3*a[:,1]-a[:,0]
    velocity=b[:,None]+2*q[:,None]*u+3*d[:,None]*u*u
    acceleration=2*q[:,None]+6*d[:,None]*u
    cross=np.linalg.norm(np.cross(velocity,acceleration),axis=-1)
    return float(np.divide(np.linalg.norm(velocity,axis=-1)**3,cross,
                           out=np.full_like(cross,np.inf),where=cross>1e-20).min())


def numerical_cases():
    checks=[]
    straight=np.array([[[0,0,0],[1/3,0,0],[2/3,0,0],[1,0,0]]],float)
    d=deviation_bound(straight,[1.],np.array([[0,0,0],[1,0,0]],float))
    assert abs(d['max_deviation_mm']-1e-8)<1e-12 and math.isinf(radius_bound(straight)['radius_lower_mm'])
    checks.append(dict(case='straight exact reference',status='PASS'))
    arch=straight.copy();arch[0,1:3,1]=.1
    d=deviation_bound(arch,[1.],np.array([[0,0,0],[1,0,0]],float))
    assert abs(d['max_deviation_mm']-(.1+1e-8))<1e-12
    checks.append(dict(case='known cubic convex-hull deviation',status='PASS',actual_max_mm=.075,bound_mm=d['max_deviation_mm']))
    second=straight.copy()*2;second[:,:,0]+=1
    pair=np.concatenate([straight,second]);raw=np.array([[0,0,0],[3,0,0]],float)
    d=deviation_bound(pair,[1.,.25],raw)
    assert abs(d['max_deviation_mm']-(1.4+1e-8))<1e-10
    checks.append(dict(case='unequal derivative speeds at C1 join',status='PASS',exact_corresponding_parameter_deviation_mm=1.4,bound_mm=d['max_deviation_mm']))
    d=deviation_bound(pair,[1.,2.],raw)
    assert abs(d['max_deviation_mm']-1e-8)<1e-12
    checks.append(dict(case='unequal piece lengths with uniform physical speed',status='PASS'))
    collapsed=radius_bound(np.zeros((1,4,3)))
    assert collapsed['radius_lower_mm']==0 and not collapsed['derivative_nonzero']
    checks.append(dict(case='zero-speed rejection',status='PASS'))
    builder=Builder();builder.arc([0,0,0],[1,0,0],[0,1,0],7.,0,.4)
    c=np.asarray(builder.controls);lower=radius_bound(c)['radius_lower_mm'];sample=sampled_radius(c)
    assert 6.94<lower<=sample
    checks.append(dict(case='circular Hermite actual cubic curvature',status='PASS',bound_mm=lower,independent_sample_min_mm=sample))
    return checks


def main():
    ctx=PiecewiseContext();path=HERE/'transfer_inspection.json';report=read(path)
    assert report['status']=='PASS' and report['checked_curve_poses']==910
    assert all(sha(p)==h for p,h in report['sources'].items())
    source=HERE/'transfer_curves.npz';assert sha(source)==report['arrays_sha256'];arrays=np.load(source)
    expected={(y,p,n) for y,p in itertools.product(range(-60,61,10),range(-20,26,5)) for n in MINIMUM_RADIUS}
    actual={(r['yaw_deg'],r['pitch_deg'],r['wire']) for r in report['rows']}
    assert actual==expected and len(report['rows'])==910
    assert set(arrays.files)=={f'{n}_y{y}_p{p}_{s}' for y,p,n in expected for s in ['controls','lengths']}
    bykey={(r['yaw_deg'],r['pitch_deg'],r['wire']):r for r in report['rows']}
    diagnostics=[]
    for yaw,pitch in itertools.product(range(-60,61,10),range(-20,26,5)):
        for name,raw in ctx.upper(yaw,pitch).items():
            row=bykey[yaw,pitch,name];key=f'{name}_y{yaw}_p{pitch}'
            c=arrays[key+'_controls'];lengths=arrays[key+'_lengths']
            assert np.array_equal(c[0,0],raw[0]) and np.array_equal(c[-1,-1],raw[-1])
            assert np.linalg.norm(c[:-1,-1]-c[1:,0],axis=1).max()<1e-10
            left=np.diff(c,axis=1)[:,-1];right=np.diff(c,axis=1)[:,0]
            left/=np.linalg.norm(left,axis=1)[:,None];right/=np.linalg.norm(right,axis=1)[:,None]
            incoming,outgoing=ctx.tangents(name,yaw,pitch)
            assert np.linalg.norm(left[:-1]-right[1:],axis=1).max()<1e-8
            assert max(np.linalg.norm(right[0]-unit(incoming)),np.linalg.norm(left[-1]-unit(outgoing)))<1e-8
            bend=radius_bound(c);dev=deviation_bound(c,lengths,raw);sample=sampled_radius(c)
            assert bend['radius_lower_mm']>=MINIMUM_RADIUS[name] and dev['max_deviation_mm']<=.0005
            assert abs(bend['radius_lower_mm']-row['continuous_bending']['radius_lower_mm'])<1e-9
            assert abs(dev['max_deviation_mm']-row['continuous_reference_deviation']['max_deviation_mm'])<1e-10
            assert bend['radius_lower_mm']<=sample+1e-7
            diagnostics.append(dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,status='PASS',
                                    certified_radius_lower_mm=bend['radius_lower_mm'],independent_sample_min_mm=sample,
                                    continuous_deviation_mm=dev['max_deviation_mm']))
    cases=numerical_cases()
    clearance=read(HERE/'clearance_transfer.json')
    assert clearance['status']=='PASS' and clearance['native_group_transfer_bounds']==clearance['upper_peer_transfer_bounds']==2730
    assert all(sha(p)==h for p,h in clearance['sources'].items())
    baseline=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
    protected={n:h for n,h in baseline['protected_hardware'].items() if '__pycache__' not in Path(n).parts and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
    assert sha(MECHANICAL/'mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(MECHANICAL/'animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
    assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
    ctx.record([Path(__file__),path,source,HERE/'clearance_transfer.json']);ctx.unchanged()
    out=dict(status='PASS',scope='Seven finite upper curves, numerical algorithms and source preservation only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=ctx.sources,
        finite_poses=130,complete_curve_parameter_checks=910,independent_polynomial_diagnostics=diagnostics,
        numerical_algorithm_cases=cases,protected_hardware_files=len(protected),Git_HEAD=head,
        native_gap_finite='PASS',peer_gap_finite='PASS',clearance_method='New deviation-transfer proof; existing native and peer tests not rerun',
        actual_material_and_cut_length='BLOCKED',upper_between_pose_motion='NOT_TESTED',
        actual_arc_remote_self_and_own_join='NOT_TESTED',local_smooth_tube='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,manufacturing_release=False)
    (HERE/'geometry_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('PIECEWISE_GEOMETRY_VERIFIED',910,'curve poses',len(cases),'numerical cases',len(protected),'protected hardware',flush=True)


if __name__=='__main__':main()
