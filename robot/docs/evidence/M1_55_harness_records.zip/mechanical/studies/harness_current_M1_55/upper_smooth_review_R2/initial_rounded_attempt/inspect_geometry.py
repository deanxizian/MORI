"""Certify all known upper cubic pieces before any clearance or adoption."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from piecewise_geometry import PiecewiseContext,Builder,fit,pieces,radius_bound,deviation_bound,unit,MINIMUM_RADIUS,MAX_DEVIATION,RADII,sha

HERE=Path(__file__).resolve().parent


def main():
    start=time.time();ctx=PiecewiseContext();ctx.record([Path(__file__)])
    zero='--zero' in sys.argv;poses=[(0,0)] if zero else [(y,p) for y in range(-60,61,10) for p in range(-20,26,5)]
    rows=[];failures=[];arrays={}
    for yaw,pitch in poses:
        for name,raw in ctx.upper(yaw,pitch).items():
            attempts=[]
            if name.startswith('CAM_'):
                builder,details=ctx.cam_curve(int(name.split('_')[-1]),yaw,pitch,raw)
            else:
                builder=None
                for spacing in [2.,1.,.5]:
                    spl,trial=fit(raw,*ctx.tangents(name,yaw,pitch),spacing)
                    attempts.append(trial)
                    if trial['deviation']['max_deviation_mm']<=MAX_DEVIATION and trial['continuous_bending']['radius_lower_mm']>=MINIMUM_RADIUS[name]:break
                builder=Builder();arc=trial['source_polyline_length_mm'];edges=np.unique(spl.t)
                for c,h in zip(pieces(spl),np.diff(edges)):builder.add(c,h*arc,'single_spline')
                details=dict(attempts=attempts)
            c=np.asarray(builder.controls);lengths=np.asarray(builder.lengths)
            bend=radius_bound(c);deviation=deviation_bound(c,lengths,raw)
            left=np.diff(c,axis=1)[:,-1];right=np.diff(c,axis=1)[:,0]
            left/=np.linalg.norm(left,axis=1)[:,None];right/=np.linalg.norm(right,axis=1)[:,None]
            tangent_error=float(np.linalg.norm(left[:-1]-right[1:],axis=1).max()) if len(c)>1 else 0.
            position_error=float(np.linalg.norm(c[:-1,-1]-c[1:,0],axis=1).max()) if len(c)>1 else 0.
            incoming,outgoing=ctx.tangents(name,yaw,pitch)
            end_error=float(max(np.linalg.norm(right[0]-unit(incoming)),np.linalg.norm(left[-1]-unit(outgoing))))
            endpoints_exact=np.array_equal(c[0,0],raw[0]) and np.array_equal(c[-1,-1],raw[-1])
            ok=(bend['radius_lower_mm']>=MINIMUM_RADIUS[name] and deviation['max_deviation_mm']<=MAX_DEVIATION and
                tangent_error<1e-8 and position_error<1e-10 and end_error<1e-8 and endpoints_exact)
            row=dict(wire=name,yaw_deg=yaw,pitch_deg=pitch,status='PASS' if ok else 'BLOCKED',
                     pieces=len(c),piece_kinds={k:builder.kinds.count(k) for k in set(builder.kinds)},
                     continuous_bending=bend,continuous_reference_deviation=deviation,
                     required_reference_radius_mm=MINIMUM_RADIUS[name],maximum_reference_deviation_mm=MAX_DEVIATION,
                     internal_tangent_unit_error=tangent_error,internal_position_error_mm=position_error,
                     end_tangent_unit_error=end_error,endpoints_exact=endpoints_exact,details=details,
                     numerical_reference_parameter_length_mm=float(lengths.sum()),supplier_cut_length=None)
            rows.append(row)
            if not ok:failures.append(row)
            key=f'{name}_y{yaw}_p{pitch}';arrays[key+'_controls']=c;arrays[key+'_lengths']=lengths
            print('PIECEWISE_UPPER',yaw,pitch,name,row['status'],'R',bend['radius_lower_mm'],
                  'dev',deviation['max_deviation_mm'],'G1',tangent_error,'end',end_error,flush=True)
        if failures:break
    ctx.unchanged();suffix='zero' if zero else 'all_poses'
    np.savez_compressed(HERE/f'{suffix}_curves.npz',**arrays)
    result=dict(status='PASS' if len(rows)==7*len(poses) and not failures else 'BLOCKED',
        scope='All curve parameters of seven known upper capacity references at specified finite poses only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),revision='V1.2-M1.55',
        sources=ctx.sources,planned_poses=poses,checked_curve_poses=len(rows),rows=rows,failures=failures,
        arrays_sha256=sha(HERE/f'{suffix}_curves.npz'),elapsed_s=time.time()-start,
        actual_endpoints_and_material='BLOCKED',actual_cut_lengths='BLOCKED',
        current_native_clearance='NOT_TESTED',current_peer_clearance='NOT_TESTED',
        upper_between_pose_motion='NOT_TESTED',full_harness='BLOCKED',manufacturing_release=False,
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False)
    (HERE/f'{suffix}_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('PIECEWISE_UPPER_TERMINAL',result['status'],len(rows),len(failures),result['elapsed_s'],flush=True)


if __name__=='__main__':main()
