"""Finite-segment clearance with spatially varying deformation envelopes.

World and yaw-frame bounds are each valid for the same actual segment pair;
the smaller sum may therefore be used per pair. Reference distances are
rotation invariant. KDTree pruning always includes segment half-lengths and
an explicit double-precision reserve; skipped pairs retain a proved gap.
"""
import numpy as np
from scipy.spatial import cKDTree
from motion_envelopes import BSpline

RESERVE=1e-8

def reference(curve,radius):
    p=curve['points'];u=np.diff(p,axis=0);length=np.linalg.norm(u,axis=1)
    assert np.min(length)>1e-10
    mid=(p[1:]+p[:-1])/2
    return dict(points=p,u=u,mid=mid,half=length/2,tree=cKDTree(mid),
                radius=radius,error=curve['chord_error_mm'])

def segment_motion(envelope):
    w=envelope['world_point_bound_mm'];y=envelope['yaw_point_bound_mm']
    return np.maximum(w[:-1],w[1:]),np.maximum(y[:-1],y[1:])

def distances(a,b,u,v):
    w=a-b
    A=np.einsum('ij,ij->i',u,u);B=np.einsum('ij,ij->i',v,v);C=np.einsum('ij,ij->i',u,v)
    D=np.einsum('ij,ij->i',u,w);E=np.einsum('ij,ij->i',v,w);det=A*B-C*C
    candidates=[]
    for s in [np.zeros(len(a)),np.ones(len(a))]:
        t=np.clip((C*s-D)/A,0,1);candidates.append((t,s,None))
    for t in [np.zeros(len(a)),np.ones(len(a))]:
        s=np.clip((E+C*t)/B,0,1);candidates.append((t,s,None))
    den=np.where(det>1e-24,det,1);t=(C*E-B*D)/den;s=(A*E-C*D)/den
    valid=(det>1e-24)&(t>=0)&(t<=1)&(s>=0)&(s<=1)
    candidates.append((t,s,valid));minimum=np.full(len(a),np.inf)
    best_t=np.zeros(len(a));best_s=np.zeros(len(a))
    for t,s,valid in candidates:
        delta=w+t[:,None]*u-s[:,None]*v;d=np.einsum('ij,ij->i',delta,delta)
        if valid is not None:d=np.where(valid,d,np.inf)
        use=d<minimum;minimum[use]=d[use];best_t[use]=t[use];best_s[use]=s[use]
    return np.sqrt(minimum),best_t,best_s

def pair_bound(a,b,aw,ay,bw,by,gap=.3,arc_upper=None):
    tube=a['radius']+b['radius']+a['error']+b['error']+RESERVE
    effective=np.minimum(aw+float(bw.max()),ay+float(by.max()))
    query_radius=tube+gap+effective+a['half']+float(b['half'].max())+RESERVE
    nearest=a['mid']*0 # allocate one scalar query result without shared state
    nearest=b['tree'].query(a['mid'],k=1)[0]
    possible=np.flatnonzero(nearest<=query_radius)
    if not len(possible):return dict(status='PASS',gap_lower_mm=gap,tested_segment_pairs=0,pruned_A_segments=len(aw))
    neighbours=b['tree'].query_ball_point(a['mid'][possible],query_radius[possible])
    counts=[len(row) for row in neighbours];ii=np.repeat(possible,counts)
    jj=np.concatenate([np.asarray(row,dtype=int) for row in neighbours]) if sum(counts) else np.empty(0,dtype=int)
    if arc_upper is not None:
        assert a is b and len(arc_upper)==len(a['points'])
        # Only omit pairs whose ENTIRE actual arc separation stays <=5mm.
        # The separately certified R6.865 curve bound covers this local tube.
        eligible=(jj>ii)&((arc_upper[jj+1]-arc_upper[ii]+RESERVE)>5.)
        ii,jj=ii[eligible],jj[eligible]
    lower=gap;tested=0;witness=None
    for start in range(0,len(ii),50000):
        ai,bi=ii[start:start+50000],jj[start:start+50000]
        midpoint_distance=np.linalg.norm(a['mid'][ai]-b['mid'][bi],axis=1)
        movement=np.minimum(aw[ai]+bw[bi],ay[ai]+by[bi])
        eligible=midpoint_distance-a['half'][ai]-b['half'][bi]<=tube+gap+movement+RESERVE
        ai,bi,movement=ai[eligible],bi[eligible],movement[eligible]
        if not len(ai):continue
        d,t,s=distances(a['points'][ai],b['points'][bi],a['u'][ai],b['u'][bi]);margin=d-tube-movement
        k=int(np.argmin(margin));tested+=len(ai)
        if margin[k]<lower:
            lower=float(margin[k]);witness=dict(segments=[int(ai[k]),int(bi[k])],
                reference_centreline_distance_mm=float(d[k]),combined_motion_bound_mm=float(movement[k]),
                reference_point_a_mm=(a['points'][ai[k]]+t[k]*a['u'][ai[k]]).tolist(),
                reference_point_b_mm=(b['points'][bi[k]]+s[k]*b['u'][bi[k]]).tolist())
        if lower<gap:
            return dict(status='BLOCKED',gap_lower_mm=lower,tested_segment_pairs=tested,witness=witness,
                        all_candidate_segment_pairs_tested=False)
    return dict(status='PASS',gap_lower_mm=lower,tested_segment_pairs=tested,
                pruned_A_segments=len(aw)-len(possible),all_candidate_segment_pairs_tested=True)

def arc_upper(envelopes,name,lo,hi,anchor):
    f=envelopes.f;mid=(lo+hi)/2;h=(hi-lo)/2;root=envelopes.root
    cert=root.certificate(name,lo,hi);assert cert['status']=='PASS'
    it=f.candidate(name,mid);c,cy,cyy,d,dy,dyy=it['base'];a0=it['amplitude_mm'];b=root.derivatives(name,lo,hi)
    coefficient=3/(f.knots[4:-1]-f.knots[1:-4]);V=np.zeros((47,48))
    for i,k in enumerate(coefficient):V[i,i]=-k;V[i,i+1]=k
    first=cy+a0*dy;second=b['C2']+abs(a0)*b['D2'];width=cert['amplitude_deviation_bound_mm']
    derivative_error=(h*np.linalg.norm(V@first,axis=1)+.5*h*h*(abs(V)@second)
        +width*(np.linalg.norm(V@d,axis=1)+h*(abs(V)@b['D1']))+RESERVE)
    reference_control=f.candidate(name,anchor)['control'];ref_velocity=V@reference_control
    maximum=np.linalg.norm(ref_velocity,axis=1)+np.linalg.norm(V@it['control']-ref_velocity,axis=1)+derivative_error
    integrated=BSpline(f.knots[1:-1],maximum,2).antiderivative()
    result=integrated(envelopes.t)-integrated(0.)
    assert np.all(np.diff(result)>0)
    return result

def algorithm_checks():
    tests=[('perpendicular_cross',[[-1,0,0],[1,0,0]],[[0,-1,0],[0,1,0]],0.),
           ('parallel_offset',[[0,0,0],[3,0,0]],[[1,1,0],[2,1,0]],1.),
           ('endpoint_minimum',[[0,0,0],[1,0,0]],[[2,1,0],[2,2,0]],np.sqrt(2)),
           ('skew',[[0,0,0],[3,0,0]],[[1,-1,3],[1,1,3]],3.),
           ('collinear_overlap',[[0,0,0],[3,0,0]],[[1,0,0],[4,0,0]],0.)]
    rows=[]
    for name,p,q,expected in tests:
        p,q=np.asarray(p,float),np.asarray(q,float)
        value=distances(p[:1],q[:1],np.diff(p,axis=0),np.diff(q,axis=0))[0][0]
        assert abs(value-expected)<1e-9,(name,value,expected)
        rows.append(dict(case=name,status='PASS',actual_mm=float(value),expected_mm=float(expected)))
    p=np.array([[0.,0.,0.],[3.,0.,0.]]);q=p+np.array([0.,1.,0.])
    a=reference(dict(points=p,chord_error_mm=0.),.1);b=reference(dict(points=q,chord_error_mm=0.),.1)
    zero=np.zeros(1);motion=np.full(1,.3)
    for name,aw,ay,bw,by,expected in [('zero',zero,zero,zero,zero,'PASS'),
        ('independent_motion',motion,motion,motion,motion,'BLOCKED'),('common_yaw_frame',motion,zero,motion,zero,'PASS')]:
        result=pair_bound(a,b,aw,ay,bw,by);assert result['status']==expected,(name,result)
        rows.append(dict(case=name,status='PASS',expected_result=expected,actual_result=result['status']))
    return rows
