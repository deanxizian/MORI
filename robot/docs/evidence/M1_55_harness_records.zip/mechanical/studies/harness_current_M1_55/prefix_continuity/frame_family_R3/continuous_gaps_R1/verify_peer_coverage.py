"""Verify every wire pair and self interval in the stored yaw proof."""
from pathlib import Path
import sys,json,itertools,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from selected_family import SelectedFamily,sha

def main():
    started=time.time();f=SelectedFamily();path=HERE/'peer_interval_inspection.json';p=json.loads(path.read_text())
    assert p['status']=='PASS' and p['wire_pairs_completed']==66 and p['remote_self_completed']==12
    assert p['required_gap_mm']==.3 and p['self_arc_eligibility_uses_all_yaw_upper_bounds'] is True
    assert all(sha(q)==h for q,h in p['sources'].items())
    expected=list(itertools.combinations(f.names,2))+[(n,n) for n in f.names]
    assert [tuple(r['wires']) for r in p['results']]==expected
    cells=0;minimum=float('inf')
    for result in p['results']:
        assert result['status']=='PASS' and result['accepted_yaw_cells']==len(result['intervals'])
        assert result['remote_self']==(result['wires'][0]==result['wires'][1])
        ordered=sorted(r['yaw_interval_deg'] for r in result['intervals'])
        assert ordered[0][0]==-60 and ordered[-1][1]==60
        assert all(a[0]<a[1] for a in ordered)
        assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(ordered[:-1],ordered[1:]))
        for row in result['intervals']:
            assert row['status']=='PASS' and row['gap_lower_mm']>=.3
            minimum=min(minimum,row['gap_lower_mm']);cells+=1
    f.unchanged();sources=dict(f.sources)
    for q in [path,Path(__file__)]:sources[str(q)]=sha(q)
    algorithm_path=HERE/'pair_algorithm_verification.json';alg=json.loads(algorithm_path.read_text())
    assert alg['status']=='PASS' and all(sha(q)==h for q,h in alg['sources'].items())
    sources[str(algorithm_path)]=sha(algorithm_path)
    report=dict(status='PASS',scope='Stored all-yaw pair/self coverage only; not physical wiring or complete upper routes',
       sources=sources,wire_pairs=66,self_wires=12,yaw_cells=cells,
       minimum_certified_gap_lower_mm=minimum,yaw_coverage_deg=[-60,60],
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,
       elapsed_s=time.time()-started)
    (HERE/'peer_coverage_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PEER_COVERAGE_PASS',cells,'yaw cells',minimum,flush=True)

if __name__=='__main__':main()
