"""All-yaw mutual and remote-self bounds for the twelve R3 capacity prefixes."""
from pathlib import Path
import sys,json,time,itertools
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parent)]
from motion_envelopes import Envelopes,SelectedFamily,sha
from pair_fields import reference,segment_motion,pair_bound,arc_upper,algorithm_checks
import numpy as np

def main():
    started=time.time();f=SelectedFamily();e=Envelopes(f,count=1501);tests=algorithm_checks()
    path=HERE.parent/'continuous_root_inspection.json';proof=json.loads(path.read_text())
    bending_path=HERE.parent/'continuous_bend_inspection.json';bend=json.loads(bending_path.read_text())
    assert proof['status']==bend['status']=='PASS'
    assert all(sha(p)==h for d in [proof,bend] for p,h in d['sources'].items())
    cached={};tested=0;results=[];failures=[];pairs=list(itertools.combinations(f.names,2))
    pairs.extend((name,name) for name in f.names)
    def get_reference(name,yaw):
        if (name,yaw) not in cached:cached[name,yaw]=reference(e.curve(name,yaw),f.radii[name])
        return cached[name,yaw]
    def compare(left,right,lo,hi,anchor):
        nonlocal tested
        a,b=get_reference(left,anchor),get_reference(right,anchor)
        ea=e.control_envelopes(left,lo,hi,anchor);eb=ea if left==right else e.control_envelopes(right,lo,hi,anchor)
        if ea is None or eb is None:return dict(status='BLOCKED',type='root_enclosure',gap_lower_mm=None)
        aw,ay=segment_motion(ea);bw,by=segment_motion(eb)
        arc=arc_upper(e,left,lo,hi,anchor) if left==right else None
        result=pair_bound(a,b,aw,ay,bw,by,arc_upper=arc);tested+=result['tested_segment_pairs']
        return dict(**result,anchor_yaw_deg=anchor,yaw_interval_deg=[lo,hi])
    for left,right in pairs:
        accepted=[];todo=[(r['yaw_interval_deg'][0],r['yaw_interval_deg'][1],0) for r in proof['certificates']]
        while todo:
            lo,hi,depth=todo.pop();mid=(lo+hi)/2;anchor=float(round(mid/5)*5)
            result=compare(left,right,lo,hi,anchor)
            if result['status']!='PASS':
                result=compare(left,right,lo,hi,mid);result['fresh_midpoint_reference']=True
            if result['status']=='PASS':accepted.append(result);continue
            if depth>=12:
                failures.append(dict(wires=[left,right],**result));break
            todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
        status='BLOCKED' if any(r['wires']==[left,right] for r in failures) else 'PASS'
        coverage=sorted(r['yaw_interval_deg'] for r in accepted)
        if status=='PASS':
            assert coverage[0][0]==-60 and coverage[-1][1]==60
            assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        row=dict(wires=[left,right],remote_self=left==right,status=status,accepted_yaw_cells=len(accepted),intervals=accepted)
        results.append(row)
        print('CONTINUOUS_PAIR',left,right,status,len(accepted),'segment_pairs',tested,'elapsed',time.time()-started,flush=True)
        if status!='PASS':break
    f.unchanged();sources=dict(f.sources)
    for p in [Path(__file__),HERE/'motion_envelopes.py',HERE/'pair_fields.py',path,bending_path,
              HERE.parent/'frame_motion_bounds.py',HERE.parent.parent/'root_direction_R2/root_motion_bounds.py']:sources[str(p)]=sha(p)
    status='PASS' if len(results)==78 and not failures else 'BLOCKED'
    report=dict(status=status,scope='All-yaw mutual and remote-self gaps for twelve R3 reference prefixes only; complete upper tails excluded',
       sources=sources,results=results,failures=failures,algorithm_checks=tests,required_gap_mm=.3,
       wire_pairs_completed=sum(not r['remote_self'] for r in results),remote_self_completed=sum(r['remote_self'] for r in results),
       yaw_coverage_deg=[-60,60],reference_curve_samples=len(e.t),finite_segment_comparisons=tested,
       self_local_arc_exclusion_mm=5.,self_arc_eligibility_uses_all_yaw_upper_bounds=True,
       local_self_exclusion_supported_by_continuous_radius_mm=6.865,
       full_harness='BLOCKED',upper_tails='BLOCKED',main_changed=False,hardware_changed=False,
       manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'peer_interval_inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PEER_TERMINAL',status,len(results),tested,time.time()-started,flush=True)

if __name__=='__main__':main()
