"""Check continuous-gap publication, local links and protected sources."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess
from urllib.parse import urlsplit,unquote
from urllib.request import Request,urlopen
HERE=Path(__file__).resolve().parent;MECHANICAL=HERE.parents[4];PROJECT=MECHANICAL.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
d=read(HERE/'delivery.json');assert d['status']=='PASS' and d['full_harness']=='BLOCKED'
assert all((HERE/n).is_file() and sha(HERE/n)==h for n,h in d['files'].items())
assert sha(MECHANICAL/'mori_v1_2.blend')==d['source_blend_sha256']
for name in ['native_interval_inspection.json','peer_interval_inspection.json','native_coverage_verification.json',
             'peer_coverage_verification.json','envelope_crosscheck.json','pair_algorithm_verification.json','progress.json']:
    p=read(HERE/name);assert p['status']=='PASS' and all(sha(q)==h for q,h in p['sources'].items())
base=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in base['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
assert all((PROJECT/n).is_file() and sha(PROJECT/n)==h for n,h in protected.items())
links=[]
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(value)
    if parsed.scheme or not parsed.path:continue
    target=(HERE/unquote(parsed.path)).resolve();assert target.is_file() and target.is_relative_to(PROJECT),(value,target)
    with urlopen(Request('http://127.0.0.1:58202/'+str(target.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:assert response.status==200
    links.append(str(target.relative_to(PROJECT)))
with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:
    assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
result=dict(status='PASS',scope='Publication and preservation only; full wiring remains incomplete',
   recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),delivery_sha256=sha(HERE/'delivery.json'),
   source_blend_sha256=d['source_blend_sha256'],checked_files=len(d['files']),checked_local_links=links,HTTP_HEAD='PASS',
   HTTP_page_content_sha256='PASS',
   protected_hardware_files=len(protected),protected_hardware_unchanged=True,Git_HEAD=head,
   main_changed=False,hardware_changed=False,new_commit_or_push=False,full_harness='BLOCKED',manufacturing_release=False,
   script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('CONTINUOUS_GAPS_PUBLICATION_VERIFIED',len(d['files']),'files',len(links),'links',len(protected),'protected hardware sources',flush=True)
