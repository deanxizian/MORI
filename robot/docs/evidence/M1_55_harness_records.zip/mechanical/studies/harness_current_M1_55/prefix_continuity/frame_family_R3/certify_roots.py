"""Certify a unique Gauss64 length root for every yaw within -60..+60."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from frame_motion_bounds import RootBounds,FamilyR2
from selected_family import sha
import numpy as np

def main():
    start=time.time();family=FamilyR2();bounds=RootBounds(family);rows=[];failed=[];checks=[]
    for ka in range(-60,60,10):
        todo=[(float(a),float(a+.5),0) for a in np.arange(ka,ka+10,.5)]
        while todo:
            lo,hi,depth=todo.pop();certificates=[bounds.certificate(n,lo,hi) for n in family.names]
            if any(r['status']!='PASS' for r in certificates):
                if depth<8:
                    mid=(lo+hi)/2;todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
                failed.append(dict(interval=[lo,hi],certificates=certificates));continue
            rows.append(dict(yaw_interval_deg=[lo,hi],certificates=certificates))
        print('CONTINUOUS_ROOT_KEY_INTERVAL',ka,ka+10,'accepted_cells',len(rows),'failures',len(failed),flush=True)
    # Independent sampled spot checks of the analytic derivative enclosures
    # and root brackets. These do not replace the all-interval construction.
    for record in rows[::max(1,len(rows)//24)]:
        lo,hi=record['yaw_interval_deg']
        for cert in record['certificates']:
            name=cert['wire'];b=bounds.derivatives(name,lo,hi);mid=(lo+hi)/2
            c0=family.candidate(name,mid)['control']
            for yaw in np.linspace(lo,hi,5):
                c,cy,cyy,d,dy,dyy=family.base(name,float(yaw))
                for field,value in [('C1',cy),('C2',cyy),('D1',dy),('D2',dyy),
                                    ('bC1',np.diff(cy,axis=0)),('bC2',np.diff(cyy,axis=0)),
                                    ('bD1',np.diff(dy,axis=0)),('bD2',np.diff(dyy,axis=0))]:
                    assert np.all(np.linalg.norm(value,axis=1)<=b[field]+1e-8),(name,yaw,field)
                it=family.candidate(name,float(yaw))
                assert abs(it['amplitude_mm']-cert['midpoint_amplitude_mm'])<=cert['amplitude_deviation_bound_mm']+1e-8
                assert np.all(np.linalg.norm(it['control']-c0,axis=1)<=np.array(cert['control_displacement_bound_mm'])+1e-8)
                checks.append(dict(wire=name,yaw_deg=float(yaw),interval=[lo,hi],status='PASS'))
    coverage=sorted(r['yaw_interval_deg'] for r in rows)
    assert not failed and coverage[0][0]==-60 and coverage[-1][1]==60
    assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
    family.unchanged();sources=dict(family.sources)
    for p in [Path(__file__),HERE/'frame_motion_bounds.py',HERE.parent/'root_direction_R2/root_motion_bounds.py']:sources[str(p)]=sha(p)
    report=dict(status='PASS',scope='All-yaw existence and uniqueness of the explicit Gauss64 numerical reference-length root',
       sources=sources,yaw_coverage_deg=[-60,60],wire_count=12,accepted_yaw_cells=len(rows),
       certificates=rows,spot_checks=len(checks),failed_intervals=failed,
       numerical_reserve=1e-9,actual_total_material_length='NOT_TESTED',native_clearance='NOT_TESTED',
       continuous_bend_across_yaw='NOT_TESTED',restraints='BLOCKED',full_harness='BLOCKED',
       main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'continuous_root_inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_ROOT_INSPECTION_PASS',len(rows),'cells',len(checks),'spot checks',time.time()-start,flush=True)

if __name__=='__main__':main()
