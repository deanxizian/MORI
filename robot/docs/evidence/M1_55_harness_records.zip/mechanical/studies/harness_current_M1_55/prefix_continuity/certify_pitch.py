"""Cover every pitch angle for each stored yaw-prefix layout.

The prefixes do not depend on pitch. Each actual native pitch-group vertex
is bounded by its maximum radius about the actual X pivot. Inflating the
required midpoint separation by the rigid displacement bound covers a whole
pitch interval, including surfaces missed by ordinary gap-only AABB culling.
Yaw interpolation, upper tails and physical harness properties are excluded.
"""
from pathlib import Path
import sys,json,time,math
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'global_bundle_layout'
sys.path[:0]=[str(BASE),str(HERE.parent)]
from inspect_candidate import *
from common import D
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'global_bundle_layout'
YAWS=list(range(-60,61,10))

def main():
    started=time.time();ctx=Context();proofpath=BASE/'all_yaws_R3_inspection.json';proof=json.loads(proofpath.read_text())
    assert proof['status']=='PASS' and all(sha(p)==h for p,h in proof['sources'].items())
    ctx.record([Path(__file__),proofpath,BASE/'inspect_candidate.py',BASE/'solve.py'])
    center=np.array([0.,0.,D['head_z']]);pitch_ids=list(ctx.groups['pitch'])
    radii={name:float(np.linalg.norm(ctx.ss[name].v[:,1:]-center[1:],axis=1).max()) for name in pitch_ids}
    maximum_radius=max(radii.values());reports=[];failures=[];checked=0
    for yaw in YAWS:
        folder=BASE/'all_yaws_R3'/f'y{yaw}';data=np.load(folder/'candidate.npz');meta=json.loads((folder/'optimization.json').read_text())
        ctx.record([folder/'candidate.npz',folder/'optimization.json',folder/'inspection.json'])
        paths={};errors={}
        for name,it in meta['wires'].items():
            spl=BSpline(data[name+'_knots'],data[name+'_controls'],3);edges=np.unique(spl.t)
            acc=float(np.linalg.norm(spl.derivative(2)(edges),axis=1).max());step=min(.04,np.sqrt(8*.00025/max(acc,1e-12)))
            count=int(np.ceil((edges[-1]-edges[0])/step))+1;t=np.linspace(edges[0],edges[-1],count)
            paths[name]=spl(t);errors[name]=acc*(t[1]-t[0])**2/8+1e-9
        intervals=[];todo=[(float(p),float(p+5),0) for p in range(-20,25,5)]
        while todo:
            lo,hi,depth=todo.pop();mid=(lo+hi)/2
            displacement=2*maximum_radius*math.sin(math.radians((hi-lo)/4))
            inverse=np.linalg.inv(np.asarray(rigidtr(yaw,mid)));rows=[]
            for name,p in paths.items():
                bad,near=clear(transform_points(p,inverse),meta['wires'][name]['radius_mm'],ctx.groups['pitch'],
                               error=errors[name]+.0001,gap=.3+displacement)
                checked+=1
                rows.append(dict(wire=name,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near))
            status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED'
            if status=='BLOCKED' and depth<8:
                todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
            item=dict(yaw_deg=yaw,pitch_interval_deg=[lo,hi],midpoint_pitch_deg=mid,status=status,
                      rigid_surface_displacement_bound_mm=displacement,required_midpoint_gap_mm=.3+displacement,rows=rows)
            intervals.append(item)
            if status!='PASS':failures.append(item)
        intervals.sort(key=lambda r:r['pitch_interval_deg'][0]);assert len(intervals)>0
        assert intervals[0]['pitch_interval_deg'][0]==-20 and intervals[-1]['pitch_interval_deg'][1]==25
        assert all(a['pitch_interval_deg'][1]==b['pitch_interval_deg'][0] for a,b in zip(intervals[:-1],intervals[1:]))
        reports.append(dict(yaw_deg=yaw,status='PASS' if all(r['status']=='PASS' for r in intervals) else 'BLOCKED',
                            accepted_intervals=len(intervals),coverage_deg=[-20,25],intervals=intervals))
        print('CONTINUOUS_PITCH_YAW',yaw,reports[-1]['status'],len(intervals),'intervals',flush=True)
    ctx.unchanged()
    status='PASS' if not failures else 'BLOCKED'
    result=dict(status=status,scope='Entire pitch range for each of thirteen stored prefix layouts; yaw angles between layouts excluded',
                revision=P['revision'],sources=ctx.sources,yaws=YAWS,continuous_pitch_deg=[-20,25],native_pitch_parts=pitch_ids,
                pitch_pivot_mm=center.tolist(),native_pitch_part_radius_mm=radii,maximum_native_pitch_radius_mm=maximum_radius,
                reports=reports,failed_intervals=failures,midpoint_wire_checks=checked,
                all_midpoint_AABB_culling_includes_motion_bound=True,required_final_gap_mm=.3,
                yaw_between_key_layouts='NOT_TESTED',upper_tails='NOT_TESTED',physical_dynamic_life='NOT_TESTED',
                restraints='BLOCKED',wired_assembly='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
                manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'pitch_continuous_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PITCH_PREFIX_TERMINAL',status,checked,'midpoint checks',time.time()-started,flush=True)
if __name__=='__main__':main()
