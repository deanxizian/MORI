"""Analytic root/control enclosures for the distributed yaw-frame family."""
from pathlib import Path
import sys,math
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE.parent/'root_direction_R2'),str(HERE.parent)]
from selected_family import SelectedFamily as FamilyR2
from root_motion_bounds import RootBounds as OriginalBounds,extrema,NUMERIC
from family import smooth_d,smooth_dd
import numpy as np

class RootBounds(OriginalBounds):
    def derivatives(self,name,lo,hi):
        mid=(lo+hi)/2;ka,kb,u=self.f.segment(mid)
        assert lo>=ka-1e-9 and hi<=kb+1e-9
        ulo,uhi=(lo-ka)/10,(hi-ka)/10
        sd=extrema(smooth_d,ulo,uhi,[.5])/10
        sdd=extrema(smooth_dd,ulo,uhi,[(3-math.sqrt(3))/6,(3+math.sqrt(3))/6])/100
        w=self.f.frame_weights[name];omega=w*math.pi/180
        la,lb=self.f.local_controls[ka][name],self.f.local_controls[kb][name]
        da,db=self.f.local_directions[ka][name],self.f.local_directions[kb][name]
        def cp_bounds(a,b):
            delta=b-a;xy=np.maximum(np.linalg.norm(a[:,:2],axis=1),np.linalg.norm(b[:,:2],axis=1))
            first=sd*np.linalg.norm(delta,axis=1)+omega*xy
            second=sdd*np.linalg.norm(delta,axis=1)+2*omega*sd*np.linalg.norm(delta[:,:2],axis=1)+omega**2*xy
            return first+NUMERIC,second+NUMERIC
        C1,C2=cp_bounds(la,lb);D1,D2=cp_bounds(da,db)
        c,cy,cyy,d,dy,dyy=self.f.base(name,mid);h=(hi-lo)/2
        def difference_bounds(a,b,first,second):
            # If adjacent controls use the same rotating frame, use the
            # coherent local difference rather than two independent spheres.
            B1=np.linalg.norm(np.diff(first,axis=0),axis=1)+(second[:-1]+second[1:])*h
            B2=second[:-1]+second[1:]
            for i in range(len(B1)):
                if w[i]!=w[i+1]:continue
                aa,bb=a[i+1]-a[i],b[i+1]-b[i];delta=bb-aa;om=omega[i]
                xy=max(np.linalg.norm(aa[:2]),np.linalg.norm(bb[:2]))
                B1[i]=sd*np.linalg.norm(delta)+om*xy+NUMERIC
                B2[i]=sdd*np.linalg.norm(delta)+2*om*sd*np.linalg.norm(delta[:2])+om**2*xy+NUMERIC
            return B1+NUMERIC,B2+NUMERIC
        bC1,bC2=difference_bounds(la,lb,cy,C2)
        bD1,bD2=difference_bounds(da,db,dy,D2)
        maximum_direction=np.maximum(np.linalg.norm(da,axis=1),np.linalg.norm(db,axis=1))+NUMERIC
        return dict(C1=C1,C2=C2,D1=D1,D2=D2,bC1=bC1,bC2=bC2,bD1=bD1,bD2=bD2,
                    maximum_direction_norm=maximum_direction)
