"""Compare pruned variable-envelope checks against complete finite pair sets."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from motion_envelopes import SelectedFamily,Envelopes,sha
from pair_fields import reference,pair_bound,distances,arc_upper,algorithm_checks
import numpy as np

def main():
    started=time.time();rows=algorithm_checks();rng=np.random.default_rng(20261009)
    for case in range(24):
        p=np.cumsum(rng.normal(size=(17,3)),axis=0)
        q=p+.5*rng.normal(size=(17,3)) if case%2==0 else np.cumsum(rng.normal(size=(19,3)),axis=0)+[2,1,0]
        a=reference(dict(points=p,chord_error_mm=.002),.1);b=reference(dict(points=q,chord_error_mm=.003),.15)
        aw,ay=rng.random((2,len(p)-1))*.3;bw,by=rng.random((2,len(q)-1))*.3
        ii,jj=np.meshgrid(np.arange(len(p)-1),np.arange(len(q)-1),indexing='ij');ii,jj=ii.ravel(),jj.ravel()
        d=distances(a['points'][ii],b['points'][jj],a['u'][ii],b['u'][jj])[0]
        full=d-.1-.15-.002-.003-1e-8-np.minimum(aw[ii]+bw[jj],ay[ii]+by[jj])
        expected='PASS' if float(full.min())>=.3 else 'BLOCKED'
        actual=pair_bound(a,b,aw,ay,bw,by);assert actual['status']==expected,(case,expected,actual)
        rows.append(dict(case=f'variable_fields_{case}',status='PASS',expected_result=expected,actual_result=actual['status'],
                         exhaustive_minimum_gap_lower_mm=float(full.min())))
    f=SelectedFamily();e=Envelopes(f,count=1501);speed_checks=[]
    for name,lo,hi,anchor in [('P_J18_2',-39.5,-39.,-40.),('SPK_reservation_3',7.25,7.5,5.),('CAM_1',-55.5,-55.,-55.)]:
        upper=arc_upper(e,name,lo,hi,anchor)
        for yaw in np.linspace(lo,hi,5):
            s=Envelopes(f,count=6001).curve(name,float(yaw))
            # Sum direct fine chords over each coarse interval. A chord sum
            # is a lower bound on the actual curve arc; it must stay beneath
            # the analytic upper integral used for self eligibility.
            segment=np.linalg.norm(np.diff(s['points'],axis=0),axis=1).reshape(1500,4).sum(axis=1)
            assert np.all(segment<=np.diff(upper)+1e-8),(name,yaw)
            speed_checks.append(dict(wire=name,yaw_deg=float(yaw),interval=[lo,hi],status='PASS'))
    f.unchanged();sources=dict(f.sources)
    for path in [Path(__file__),HERE/'pair_fields.py',HERE/'motion_envelopes.py',HERE.parent/'frame_motion_bounds.py',
                 HERE.parent.parent/'root_direction_R2/root_motion_bounds.py']:sources[str(path)]=sha(path)
    result=dict(status='PASS',scope='Finite variable-field pruning and self-arc upper-bound numerical cross-checks only',
       sources=sources,pruning_checks=rows,self_arc_checks=speed_checks,full_harness='BLOCKED',
       main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'pair_algorithm_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PAIR_ALGORITHM_CHECK_PASS',len(rows),len(speed_checks),time.time()-started,flush=True)

if __name__=='__main__':main()
