"""Explicit research configuration, preserving actual source key datums."""
from pathlib import Path
import json
from frame_family import FrameFamily,BSpline,sha,quadrature
HERE=Path(__file__).resolve().parent

class SelectedFamily(FrameFamily):
    def __init__(self):
        config=HERE/'candidate_config.json';q=json.loads(config.read_text())
        source=HERE/'frame_search.json';proof=json.loads(source.read_text())
        assert proof['status']=='PASS' and all(sha(p)==h for p,h in proof['sources'].items())
        candidate=next(r for r in proof['results'] if r['z0_mm']==q['z0_mm'] and r['z1_mm']==q['z1_mm'])
        assert candidate['status']=='PASS' and q['main_changed'] is False
        super().__init__(q['z0_mm'],q['z1_mm'])
        for p in [Path(__file__),config,source]:self.sources[str(p)]=sha(p)
