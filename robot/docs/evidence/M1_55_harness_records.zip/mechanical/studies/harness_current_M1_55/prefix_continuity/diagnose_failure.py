"""Record reproducible analytic curvature witnesses for the rejected yaw family.

Polynomial stationary points locate candidate witnesses; each reported failure
is then evaluated directly using the stored B-spline derivatives. This is not
an all-angle certificate or a claim about an actual purchased wire's life.
"""
from pathlib import Path
import datetime, hashlib, json, sys
import numpy as np
from numpy.polynomial import Polynomial as Poly

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from family import Family, BSpline

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    family = Family()
    source = HERE / 'family_geometry_screen.json'
    screen = json.loads(source.read_text())
    assert screen['status'] == 'BLOCKED' and screen['first_failed_yaw'] == -55
    assert all(sha(p) == h for p, h in screen['sources'].items())
    failed = screen['reports'][-1]
    names = [r['wire'] for r in failed['rows'] if r['status'] != 'PASS']
    rows = []
    for name in names:
        item = family.candidate(name, -55)
        spl = BSpline(family.knots, item['control'], 3)
        best = (float('inf'), None)
        edges = np.unique(family.knots)
        for a, b in zip(edges[:-1], edges[1:]):
            h = b - a
            points = spl([a, b])
            derivatives = spl.derivative()([a, b])
            c = np.array([points[0], points[0] + h*derivatives[0]/3,
                          points[1] - h*derivatives[1]/3, points[1]])
            v = 3*np.diff(c, axis=0)
            V = [Poly([v[0,j], 2*(v[1,j]-v[0,j]), v[2,j]-2*v[1,j]+v[0,j]]) for j in range(3)]
            A = [r.deriv() for r in V]
            W = [V[1]*A[2]-V[2]*A[1], V[2]*A[0]-V[0]*A[2], V[0]*A[1]-V[1]*A[0]]
            S, T = sum(r*r for r in V), sum(r*r for r in W)
            numerator = 3*S.deriv()*T - S*T.deriv()
            roots = [float(r.real) for r in numerator.roots() if abs(r.imag)<1e-7 and 0<=r.real<=1]
            for u in [0., 1.] + roots:
                t = float(a + u*h)
                d1, d2 = spl.derivative()(t), spl.derivative(2)(t)
                cross = float(np.linalg.norm(np.cross(d1, d2)))
                radius = float(np.linalg.norm(d1)**3/cross) if cross>1e-16 else float('inf')
                if radius < best[0]:
                    best = radius, t
        radius, t = best
        assert t is not None and radius < 6.865
        d1, d2 = spl.derivative()(t), spl.derivative(2)(t)
        rows.append(dict(wire=name, status='FAIL', yaw_deg=-55,
                         normalized_parameter=t, witness_point_mm=spl(t).tolist(),
                         analytic_derivative_1=d1.tolist(), analytic_derivative_2=d2.tolist(),
                         radius_at_witness_mm=radius, required_reference_radius_mm=6.865,
                         reference_root_amplitude_mm=item['amplitude_mm'],
                         interpretation='A direct below-target witness; not a certified global minimum'))
    assert len(rows)==3
    assert all(r['status']=='PASS' for r in failed['native']+failed['peers']+failed['pitch'])
    sources = dict(screen['sources'])
    sources.update({str(source):sha(source), str(Path(__file__)):sha(Path(__file__))})
    family.unchanged()
    result = dict(status='PASS', scope='Diagnosis of rejected -55 degree prefix family only',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  sources=sources, witness_count=len(rows), rows=rows,
                  rejected_candidate_status='BLOCKED', candidate_material_selected=False,
                  checked_native_and_peer_gaps='PASS', checked_continuous_pitch='PASS',
                  source_reference_radius_is_dynamic_life_rating=False,
                  full_harness='BLOCKED', main_changed=False, hardware_changed=False,
                  manufacturing_release=False)
    (HERE/'failure_witnesses.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('YAW_FAMILY_FAILURE_DIAGNOSIS_PASS', [(r['wire'],r['radius_at_witness_mm']) for r in rows], flush=True)

if __name__=='__main__': main()
