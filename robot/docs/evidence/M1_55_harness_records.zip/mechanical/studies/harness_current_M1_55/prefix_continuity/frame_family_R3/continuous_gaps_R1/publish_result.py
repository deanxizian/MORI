"""Publish continuous prefix-gap evidence, retaining all unresolved endpoints."""
from pathlib import Path
import datetime,hashlib,json
HERE=Path(__file__).resolve().parent;MECHANICAL=HERE.parents[4];PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    names=['native_interval_inspection.json','peer_interval_inspection.json','native_coverage_verification.json',
           'peer_coverage_verification.json','envelope_crosscheck.json','pair_algorithm_verification.json']
    reports={n:read(HERE/n) for n in names}
    assert all(r['status']=='PASS' for r in reports.values())
    assert all(sha(p)==h for r in reports.values() for p,h in r['sources'].items())
    native=reports['native_interval_inspection.json'];peers=reports['peer_interval_inspection.json']
    nv=reports['native_coverage_verification.json'];pv=reports['peer_coverage_verification.json']
    assert native['native_parts']==201 and len(native['results'])==12
    assert nv['yaw_cells']==5738 and nv['pitch_cells']==51642
    assert peers['wire_pairs_completed']==66 and peers['remote_self_completed']==12 and pv['yaw_cells']==37306
    digest=sha(MECHANICAL/'mori_v1_2.blend')
    assert digest=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    sources={str(HERE/n):sha(HERE/n) for n in names};sources[str(Path(__file__))]=sha(Path(__file__))
    result=dict(status='PASS',scope='Continuous geometry of12 unadopted body/neck reference prefixes only',
       recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,revision='V1.2-M1.55',
       source_blend_sha256=digest,yaw_coverage_deg=[-60,60],pitch_coverage_deg=[-20,25],
       continuous_native_gap_across_yaw_and_pitch='PASS',continuous_peer_gap_across_yaw='PASS',
       continuous_remote_self_across_yaw='PASS',required_gap_mm=.3,native_parts=201,reference_wires=12,
       native_yaw_cells=nv['yaw_cells'],native_pitch_cells=nv['pitch_cells'],pair_and_self_yaw_cells=pv['yaw_cells'],
       native_gap_lower_mm=nv['minimum_certified_gap_lower_mm'],peer_gap_lower_mm=pv['minimum_certified_gap_lower_mm'],
       remote_self_local_arc_exclusion_mm=5.,local_radius_requirement_mm=6.865,
       actual_mixed_material_length='BLOCKED',actual_endpoints_and_clamps='BLOCKED',
       complete_upper_tails='BLOCKED',wired_assembly_and_closure='BLOCKED',dynamic_life='NOT_TESTED',
       main_changed=False,hardware_changed=False,new_commit_or_push=False,
       full_harness='BLOCKED',manufacturing_release=False)
    (HERE/'progress.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 R3 连续前段间隙</title>
<style>body{{max-width:1080px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}</style>
<h1>M1.55 · R3 连续前段间隙</h1><p>2026-10-09 · <strong>参考前段连续几何PASS；完整线束BLOCKED / 未采用</strong>。</p>
<p class="notice">12条身体/颈部参考前段与当前201件原生零件的间隙，覆盖完整−60°～+60°偏航和−20°～+25°俯仰组合区间；66组跨线及12条远端自接近覆盖完整偏航区间。全部满足原0.3mm目标。前段独立于俯仰，跨线/自接近结果也适用于完整俯仰范围。前段上端仍是Z200参考切面，不是真实接头或夹持点，不能据此裁线、制造或确认完整带线装配。</p>
<p><a href="../index.html">R3转弯与数值长度</a> · <a href="../../index.html">剩余四项</a> · <a href="../../../../../mori_v1_2.blend">当前主模型</a> · <a href="../../../../../animation/index.html">M1.55-A1装配视频</a></p>
<h2>检查范围与结果</h2><table><tr><th>检查</th><th>范围</th><th>实际处理</th><th>结果</th></tr>
<tr><td>原生实体间隙</td><td>12条前段 × 201件原生模型，全偏航/俯仰组合</td><td>{nv['yaw_cells']:,}个偏航区间，{nv['pitch_cells']:,}个俯仰区间；计入导线变形、曲线与采样误差、实体运动</td><td>PASS；保守下界≥{nv['minimum_certified_gap_lower_mm']:.8f}mm</td></tr>
<tr><td>跨线间隙</td><td>66组，全偏航；前段独立于俯仰</td><td>与远端自接近共{pv['yaw_cells']:,}个偏航区间，完整覆盖核对</td><td>PASS；保守下界≥0.3mm</td></tr>
<tr><td>远端自接近</td><td>12条，全偏航；前段独立于俯仰</td><td>仅排除经全角度弧长上界确认的≤5mm局部相邻弧段，局部沿用已单独验证的R6.865转弯界</td><td>PASS；不代表线材动态寿命</td></tr></table>
<p>下界是名义几何包络，不是实测净距。曲线与材料仍PLACEHOLDER / ASSUMED；真实安装孔、接头尾线和器件照片估算字段的证据级别没有因此提高。没有缩线径、放宽0.3mm目标、移动PCB或改变打印件。</p>
<h2>怎样覆盖中间角度</h2><p>对每个偏航区间，用解析控制点导数、公共数值长度根的括区间以及曲线正基函数支持，给出导线在身体坐标和偏航坐标中的逐段变形上界。参考样本只在这些上界与曲线误差计入后复用；不足时生成新的区间中点参考并细分角度。</p>
<p>实体距离来自当前原生固体BVH，并用实际固体包含测试排除“正无符号距离但已经在零件内”的情况。AABB未查询点只保留6mm有证明的截断下界，没有给无穷距离。俯仰使用实际俯仰零件半径的运动上界。</p>
<p>跨线使用双精度有限线段距离，逐段加入两条线路的变形包络与曲线误差。在身体与偏航参考系之间取更紧的合法界，不改变实际曲线。共求解{peers['finite_segment_comparisons']:,}个候选线段对；完整覆盖和剪枝逻辑另有独立核对。</p>
<h2>原始证据</h2><p><a href="native_interval_inspection.json">原生实体区间</a> · <a href="peer_interval_inspection.json">跨线/远端自接近区间</a> · <a href="native_coverage_verification.json">实体覆盖核对</a> · <a href="peer_coverage_verification.json">配对覆盖核对</a> · <a href="envelope_crosscheck.json">1,560次变形范围数值核对</a> · <a href="pair_algorithm_verification.json">32个配对算法/剪枝检查及15个自接近弧长核对</a></p>
<h2>下一步仍须完成</h2><ol><li>补齐三根舵机与两根喇叭的上端参考，复核其它上段及其与新前段的接续；旧上段结果没有自动继承。</li><li>冻结真实端接、第一可弯点、夹持/滑移与材料，才能完成混合材料长度和供应商裁线图。</li><li>完成真实端子逐根穿入、后装供电线、带线头身安装和闭壳，再同步正式模型及动画。</li></ol>
<p>SC-0090-C001型号已确认；实发舵盘/锁紧和微雪FPC/FFC按用户决定到货复核。喇叭150mm包含已有插头，插头规格仍待补充。CAM供电源端尚未正式交接；没有把独立R3硬件研究当成已经更新的PCB。正式H06保持AWG28/PH002/PHR-4＋厂配SH尾线，身体端穿线后入壳。</p>
<p><a href="progress.json">进展与边界</a> · <a href="commands.json">实际命令</a> · <a href="README.md">复现说明</a> · <a href="delivery.json">发布哈希</a></p><p>PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# R3前段连续间隙：未采用

当前201件原生零件与12条身体/颈部容量前段，全偏航/俯仰间隙PASS。
66组跨线和12条远端自接近全偏航PASS；前段独立于俯仰。
完整上段、真实端接/材料/夹持、实际线长和带线装配仍BLOCKED。
参考Z200不是实际接头或固定点，公共数值参考长度不是裁线长。

motion_envelopes.py解析包络由独立曲线求值检查；原生实体检查来自当前保存模型。
截断BVH场未查询点保留可证明的6mm下界，真实包含测试保留；不扩大历史静态PASS。
跨线用完整有限线段及逐段变形界，结合身体/偏航两个合法坐标界。
远端自接近只按全角度弧长上界排除<=5mm相邻局部；R6.865连续转弯单独检查。

实际命令见commands.json，各脚本有对应日志。
原生检查由离线Blender5.2.2 LTS d13f752e3b9c读取主模型；其它计算使用自带
Python3.13.13、NumPy2.3.4和独立缓存SciPy1.16.2。
没有改主模型、动画、打印件、硬件或正式H06，无新增commit/push或供应商消息。
几何PASS不是实物装配、强度、压接、动态寿命或制造资格。
''')
    commands=[]
    for script in ['check_envelopes.py','certify_native.py','verify_native_coverage.py','certify_peers.py','check_pair_pruning.py','verify_peer_coverage.py']:
        log=HERE/(Path(script).stem+'.log');assert log.is_file() and 'Traceback (most recent call last)' not in log.read_text()
        runtime='/Applications/Blender.app/Contents/MacOS/Blender' if script=='certify_native.py' else '/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
        args=['-b','mechanical/mori_v1_2.blend','--python'] if script=='certify_native.py' else []
        commands.append(dict(command=[runtime]+args+[str((HERE/script).relative_to(PROJECT))],cwd=str(PROJECT),
                             log=str(log.relative_to(PROJECT)),log_sha256=sha(log)))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands),ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_result.log','verify_publication.log']}
    (HERE/'delivery.json').write_text(json.dumps(dict(status='PASS',scope='Published continuous-prefix research only',
       source_blend_sha256=digest,continuous_native_gap='PASS',continuous_peer_gap='PASS',continuous_remote_self='PASS',
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,new_commit_or_push=False,
       manufacturing_release=False,files=files,published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PREFIX_GAPS_PUBLISHED',len(files),'files',flush=True)

if __name__=='__main__':main()
