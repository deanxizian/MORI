"""Enclose curvature over both the complete curve and the continuous yaw.

Bezier derivative operators retain control correlations. Taylor bounds at the
yaw midpoint and the separately enclosed Gauss64 root bracket account for all
curves within each yaw cell. The result remains capacity geometry, not life.
"""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from selected_family import SelectedFamily,BSpline,sha
from frame_motion_bounds import RootBounds
import numpy as np

RADIUS=6.865

def split(matrix):
    a=(matrix[:-1]+matrix[1:])/2;b=(a[:-1]+a[1:])/2;mid=(b[0]+b[1])/2
    return np.array([matrix[0],a[0],b[0],mid]),np.array([mid,b[1],a[2],matrix[3]])

def matrices(family):
    value=BSpline(family.knots,np.eye(48),3);derivative=value.derivative();result=[]
    edges=np.unique(family.knots)
    for a,b in zip(edges[:-1],edges[1:]):
        h=b-a;M=np.array([value(a),value(a)+h*derivative(a)/3,value(b)-h*derivative(b)/3,value(b)])
        assert np.min(M)>-1e-12 and np.max(abs(M.sum(axis=1)-1))<1e-12
        result.append((M,float(a),float(b)))
    return result

def check_curve(family,operator_list,name,cert,bounds):
    lo,hi=cert['yaw_interval_deg'];h=(hi-lo)/2;it=family.candidate(name,(lo+hi)/2)
    c,cy,cyy,d,dy,dyy=it['base'];a0=it['amplitude_mm'];actual=it['control'];width=cert['amplitude_deviation_bound_mm']
    first=cy+a0*dy;second=bounds['C2']+abs(a0)*bounds['D2']
    evaluated=0;accepted=0;minimum=float('inf')
    def perturbation(M):
        return (h*np.linalg.norm(M@first,axis=1)+.5*h*h*(abs(M)@second)
                +width*(np.linalg.norm(M@d,axis=1)+h*(abs(M)@bounds['D1']))+1e-13)
    for original,left,right in operator_list:
        todo=[(original,left,right,0)]
        while todo:
            M,a,b,depth=todo.pop();evaluated+=1;M1=3*np.diff(M,axis=0);M2=2*np.diff(M1,axis=0)
            velocity=M1@actual;acceleration=M2@actual;jerk=acceleration[1]-acceleration[0]
            vm=.25*velocity[0]+.5*velocity[1]+.25*velocity[2];am=.5*(acceleration[0]+acceleration[1])
            max_a=float(np.linalg.norm(acceleration,axis=1).max())
            speed_lower=float(np.linalg.norm(vm)-.5*max_a)
            speed_upper=float(np.linalg.norm(vm)+.5*max_a)
            dv=float(perturbation(M1).max());da=float(perturbation(M2).max())
            cross=float(np.linalg.norm(np.cross(vm,am))+.5*speed_upper*np.linalg.norm(jerk))
            upper=cross+dv*max_a+da*speed_upper+dv*da+1e-15
            lower=max(0.,speed_lower-dv)**3/upper
            sampled_cross=float(np.linalg.norm(np.cross(vm,am)))
            sampled=float(np.linalg.norm(vm)**3/sampled_cross) if sampled_cross>1e-20 else float('inf')
            if sampled<RADIUS-1e-7:
                return dict(status='FAIL',type='midpoint_analytic_bend',radius_mm=sampled,
                    curve_parameter=(a+b)/2,evaluated_cells=evaluated)
            if lower>=RADIUS and speed_lower>dv:
                accepted+=1;minimum=min(minimum,lower);continue
            if depth>=12:
                return dict(status='BLOCKED',type='yaw_interval_refinement_required',
                    curve_parameter_interval=[a,b],radius_lower_mm=lower,evaluated_cells=evaluated)
            lm,rm=split(M);mid=(a+b)/2;todo.extend([(rm,mid,b,depth+1),(lm,a,mid,depth+1)])
    return dict(status='PASS',radius_lower_mm=minimum,evaluated_cells=evaluated,accepted_cells=accepted)

def main():
    start=time.time();family=SelectedFamily();root=RootBounds(family);operator_list=matrices(family)
    input_path=HERE/'continuous_root_inspection.json';receipt=json.loads(input_path.read_text())
    assert receipt['status']=='PASS' and all(sha(p)==h for p,h in receipt['sources'].items())
    results=[];failures=[];evaluated=0
    for name in family.names:
        accepted=[]
        todo=[(r['yaw_interval_deg'][0],r['yaw_interval_deg'][1],0) for r in receipt['certificates']]
        while todo:
            lo,hi,depth=todo.pop();cert=root.certificate(name,lo,hi)
            result=check_curve(family,operator_list,name,cert,root.derivatives(name,lo,hi)) if cert['status']=='PASS' else dict(status='BLOCKED',type='root_not_enclosed',evaluated_cells=0)
            evaluated+=result['evaluated_cells']
            if result['status']=='PASS':
                accepted.append(dict(yaw_interval_deg=[lo,hi],**result));continue
            if result['status']=='FAIL' or depth>=12:
                failures.append(dict(wire=name,yaw_interval_deg=[lo,hi],**result));break
            mid=(lo+hi)/2;todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
        coverage=sorted(r['yaw_interval_deg'] for r in accepted)
        status='BLOCKED' if any(r['wire']==name for r in failures) else 'PASS'
        if status=='PASS':
            assert coverage[0][0]==-60 and coverage[-1][1]==60
            assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(coverage[:-1],coverage[1:]))
        row=dict(wire=name,status=status,accepted_yaw_cells=len(accepted),
                 minimum_certified_radius_mm=min((r['radius_lower_mm'] for r in accepted),default=None),intervals=accepted)
        results.append(row);print('CONTINUOUS_YAW_BENDING_WIRE',name,status,len(accepted),row['minimum_certified_radius_mm'],'elapsed',time.time()-start,flush=True)
        if status!='PASS':break
    family.unchanged();sources=dict(family.sources)
    for p in [Path(__file__),HERE/'frame_motion_bounds.py',HERE.parent/'root_direction_R2/root_motion_bounds.py',input_path]:sources[str(p)]=sha(p)
    status='PASS' if len(results)==12 and not failures else 'BLOCKED'
    report=dict(status=status,scope='Whole-curve curvature over every yaw in -60..60 for the recorded numerical-length capacity family',
       sources=sources,yaw_coverage_deg=[-60,60],required_radius_mm=RADIUS,wire_count=len(results),
       results=results,failures=failures,evaluated_polynomial_cells=evaluated,
       actual_material_selection='BLOCKED',dynamic_life='NOT_TESTED',native_clearance_between_yaws='NOT_TESTED',
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'continuous_bend_inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_YAW_BENDING_TERMINAL',status,len(results),evaluated,time.time()-start,flush=True)

if __name__=='__main__':main()
