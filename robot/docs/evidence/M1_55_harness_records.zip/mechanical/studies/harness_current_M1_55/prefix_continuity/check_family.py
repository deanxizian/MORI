"""Inspect the new length-root family without implying native clearance."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from family import *
HERE=Path(__file__).resolve().parent

def main():
    started=time.time();family=Family();rows=[];saved={};derivatives=[]
    Q128,w128,_=quadrature(family.knots,128)
    for yaw in np.arange(-60.,60.00001,.5):
        for name in family.names:
            item=family.candidate(name,float(yaw));c=item['control'];length128=float(w128@np.linalg.norm(Q128@c,axis=1))
            start=family.controls[0][name][0];end=item['base'][0][-1]
            assert np.linalg.norm(c[0]-start)<1e-8 and np.linalg.norm(c[-1]-end)<1e-8
            assert abs(length128-family.targets[name])<1e-7,(yaw,name,length128-family.targets[name])
            rows.append(dict(wire=name,yaw_deg=float(yaw),reference_length_residual_mm=length128-family.targets[name],
                             root_amplitude_mm=item['amplitude_mm'],root_derivative=item['length_root_derivative']))
            if yaw in [-60,-45,-30,-15,0,15,30,45,60]:saved[f'{name}_y{yaw:g}']=c
        if int(2*yaw)%30==0:print('CONTINUOUS_FAMILY_SAMPLE',yaw,flush=True)
    # Differentiate only at interior angles, away from segment boundaries.
    for yaw in [-57.1,-42.7,-28.3,-4.6,3.9,27.2,43.1,58.4]:
        for name in family.names:
            item=family.candidate(name,yaw);step=.001
            a=family.candidate(name,yaw-step)['control'];b=family.candidate(name,yaw+step)['control']
            first=(b-a)/(2*step);second=(b-2*item['control']+a)/step**2
            e1=float(abs(first-item['control_y']).max());e2=float(abs(second-item['control_yy']).max())
            assert e1<3e-6 and e2<2e-4,(yaw,name,e1,e2)
            derivatives.append(dict(wire=name,yaw_deg=yaw,first_derivative_error_mm_per_deg=e1,second_derivative_error_mm_per_deg2=e2))
    np.savez_compressed(HERE/'family_sample_controls.npz',knots=family.knots,**saved);family.unchanged()
    result=dict(status='PASS',scope='241 sampled yaw positions of a continuous mathematical prefix family; native clearance and all-angle bounds not yet certified',
                sources=family.sources,wire_count=12,sampled_yaw_positions=241,rows=rows,derivative_checks=derivatives,
                maximum_reference_length_residual_mm=max(abs(r['reference_length_residual_mm']) for r in rows),
                maximum_root_amplitude_mm=max(abs(r['root_amplitude_mm']) for r in rows),
                minimum_sampled_root_derivative=min(r['root_derivative'] for r in rows),native_clearance='NOT_TESTED',
                upper_end_datum='UNSELECTED_Z200_SLICE_NOT_A_PHYSICAL_ANCHOR',upper_end_local_key_span_mm=family.end_local_key_span_mm,
                upper_tails='NOT_TESTED',continuous_length_root_existence='NOT_TESTED',full_harness='BLOCKED',
                main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'family_sample_inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_PREFIX_FAMILY_SAMPLE_TERMINAL',time.time()-started,result['maximum_root_amplitude_mm'],flush=True)
if __name__=='__main__':main()
