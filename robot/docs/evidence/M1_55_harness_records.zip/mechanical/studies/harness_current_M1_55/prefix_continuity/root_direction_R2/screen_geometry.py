"""Independently screen new roots at all keys and yaw midpoints.

Continuous pitch is bounded at each screened yaw. Yaw intervals themselves
are not qualified by this screen. A first actual failure is preserved, not
hidden by changing native geometry or reducing wire radii.
"""
from pathlib import Path
import sys,json,time,itertools,math
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1]/'global_bundle_layout'
sys.path[:0]=[str(HERE),str(BASE),str(HERE.parent)]
from family_R2 import FamilyR2 as Family
from inspect_candidate import *
from common import D
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1]/'global_bundle_layout'

def main():
    started=time.time();ctx=Context();family=Family();ctx.sources.update(family.sources)
    ctx.record([Path(__file__),HERE/'check_math.py',HERE/'math_inspection.json',BASE/'inspect_candidate.py'])
    center=np.array([0.,0.,D['head_z']])
    pitch_radius=max(float(np.linalg.norm(ctx.ss[name].v[:,1:]-center[1:],axis=1).max()) for name in ctx.groups['pitch'])
    reports=[];failed=None;controls_out={};minimum_native=float('inf')
    for yaw in [0]+[int(y) for y in range(-60,61,5) if y!=0]:
        packs={};paths={};rows=[];controls={}
        for name in family.names:
            it=family.candidate(name,yaw);c=it['control'];controls[name]=c;spl=BSpline(family.knots,c,3)
            bend,_=continuous_radius(spl);edges=np.unique(family.knots);acc=float(np.linalg.norm(spl.derivative(2)(edges),axis=1).max())
            step=min(.00025,np.sqrt(8*.0001/max(acc,1e-12)));count=int(np.ceil(1/step))+1;t=np.linspace(0,1,count)
            p=spl(t);error=acc*(t[1]-t[0])**2/8+1e-9;pack=prepared(p,family.radii[name],error);own=self_clear(pack)
            status='PASS' if bend['status']==own['status']=='PASS' else 'BLOCKED'
            rows.append(dict(wire=name,status=status,continuous_bend=bend,remote_self=own,root_amplitude_mm=it['amplitude_mm'],
                             reference_length_residual_mm=it['reference_length_residual_mm'],samples=count,chord_error_mm=error))
            paths[name]=p;packs[name]=pack
        native=[]
        for group in ['body','yaw']:
            inverse=np.eye(4) if group=='body' else np.linalg.inv(np.asarray(rigidtr(yaw,0)))
            for name,p in paths.items():
                bad,near=clear(transform_points(p,inverse),family.radii[name],ctx.groups[group],error=packs[name]['error']+.0001)
                if near:minimum_native=min(minimum_native,near['gap_lower_bound_mm'])
                native.append(dict(group=group,wire=name,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near))
        peers=[]
        for a,b in itertools.combinations(packs,2):
            fast=pair_threshold(packs[a],packs[b]);r=dict(wires=[a,b],**fast)
            if fast['status']!='PASS':
                exact=exact_pair(paths[a],paths[b]);lower=exact['centreline_distance_mm']-packs[a]['radius']-packs[b]['radius']-packs[a]['error']-packs[b]['error']-.0001
                r.update(status='PASS' if lower>=.3 else 'BLOCKED',gap_lower_bound_mm=lower,minimum=exact)
            peers.append(r)
        pitch=[];todo=[(float(p),float(p+5),0) for p in range(-20,25,5)]
        while todo:
            lo,hi,depth=todo.pop();mid=(lo+hi)/2;motion=2*pitch_radius*math.sin(math.radians((hi-lo)/4));inverse=np.linalg.inv(np.asarray(rigidtr(yaw,mid)))
            checked=[]
            for name,p in paths.items():
                bad,near=clear(transform_points(p,inverse),family.radii[name],ctx.groups['pitch'],error=packs[name]['error']+.0001,gap=.3+motion)
                checked.append(dict(wire=name,status='BLOCKED' if bad else 'PASS',hits=bad,nearest=near))
            status='PASS' if all(r['status']=='PASS' for r in checked) else 'BLOCKED'
            if status!='PASS' and depth<8:
                todo.extend([(lo,mid,depth+1),(mid,hi,depth+1)]);continue
            pitch.append(dict(pitch_interval_deg=[lo,hi],status=status,motion_bound_mm=motion,rows=checked))
        status='PASS' if all(r['status']=='PASS' for r in rows+native+peers+pitch) else 'BLOCKED'
        report=dict(yaw_deg=yaw,status=status,rows=rows,native=native,peers=peers,pitch=pitch)
        reports.append(report);controls_out.update({f'{name}_y{yaw}':c for name,c in controls.items()})
        print('R2_FAMILY_GEOMETRY_YAW',yaw,status,flush=True)
        if status!='PASS':failed=report;break
    np.savez_compressed(HERE/'screened_family_controls.npz',knots=family.knots,**controls_out);ctx.unchanged()
    result=dict(status='BLOCKED' if failed else 'PASS',scope='Stored mathematical family at keys and yaw midpoints; continuous pitch at each checked yaw only',
                revision=P['revision'],sources=ctx.sources,reports=reports,first_failed_yaw=failed['yaw_deg'] if failed else None,
                planned_yaw_positions=25,actual_yaw_positions=len(reports),minimum_sampled_native_gap_lower_mm=minimum_native,
                yaw_between_screened_positions='NOT_TESTED',upper_tails='NOT_TESTED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
                manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'family_geometry_screen.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('R2_FAMILY_GEOMETRY_SCREEN_TERMINAL',result['status'],len(reports),time.time()-started,flush=True)
if __name__=='__main__':main()
