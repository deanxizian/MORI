"""Publish current continuity evidence and remaining work; never adopt a route."""
from pathlib import Path
import datetime, hashlib, html, json

HERE = Path(__file__).resolve().parent
MECHANICAL = HERE.parents[2]
PROJECT = MECHANICAL.parent
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    pitch = read(HERE/'pitch_continuous_inspection.json')
    sample = read(HERE/'family_sample_inspection.json')
    screen = read(HERE/'family_geometry_screen.json')
    diagnosis = read(HERE/'failure_witnesses.json')
    seam_path = HERE.parent/'global_bundle_layout/upper_seam_inspection.json'
    seam = read(seam_path)
    assert pitch['status']==sample['status']==diagnosis['status']==seam['status']=='PASS'
    assert screen['status']=='BLOCKED' and screen['first_failed_yaw']==-55
    assert pitch['midpoint_wire_checks']==1404 and pitch['continuous_pitch_deg']==[-20,25]
    assert len(pitch['yaws'])==13 and sample['sampled_yaw_positions']==241
    assert screen['actual_yaw_positions']==3 and diagnosis['witness_count']==3
    assert len(seam['missing_upper_reference_segments'])==5
    latest_path=HERE/'frame_family_R3/progress.json'
    latest=read(latest_path)
    assert latest['status']=='PASS' and latest['continuous_bend_across_yaw']=='PASS'
    assert latest['continuous_numerical_reference_length_root']=='PASS' and latest['static_yaw_positions']==25
    assert all(sha(p)==h for p,h in latest['sources'].items())
    for d in [pitch,sample,screen,diagnosis,seam]:
        assert all(sha(p)==h for p,h in d['sources'].items())
    digest=sha(MECHANICAL/'mori_v1_2.blend')
    assert digest=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    servo_path = MECHANICAL/'procurement/evidence/2026-10-08_SC-0090-C001_confirmation.json'
    speaker_path = MECHANICAL/'procurement/evidence/2026-10-08_SP3040_lead_measurement.json'
    endpoints_path = MECHANICAL/'studies/harness_current_M1_53/servo_endpoints/endpoint_evidence.json'
    usb_path = PROJECT/'hardware/v1_2/cam_usb_source_options_R3_20261008/mechanical_handoff.md'
    servo,speaker,endpoints = read(servo_path),read(speaker_path),read(endpoints_path)
    assert servo['user_confirmation']['purchased_sku']=='SC-0090-C001'
    assert speaker['measurement']['reported_length_mm']==150
    assert speaker['measurement']['plug_length_included'] is True
    facts={r['field']:r for r in endpoints['facts']}
    assert facts['factory_tail_length_mm']['value']==150
    assert facts['tail_connector_family']['value']=='5264-3P'
    assert usb_path.is_file()
    work=[
      dict(id=1,title='补齐上端走线',status='BLOCKED',
           remaining='三根头部舵机参考、两根喇叭参考缺完整上段；其余上段仍需当前模型实体及整段转弯复核。',
           can_continue_now='可继续已知接口的候选与容量比较。',
           dependency='舵机真实尾线出口、配对件及分线附件尺寸；喇叭实际出口与插头。'),
      dict(id=2,title='完成连续运动与线长复核',status='BLOCKED',
           remaining='R3参考前段连续几何与公共数值长度根已闭合；完整上段、混合材料实际线长未闭合。',
           can_continue_now='继续已有上段复核与完整接续，当前没有要求修改打印件。',
           dependency='最终材料及真实两端/固定点才能形成供应商裁线长。'),
      dict(id=3,title='落实接头与应力释放',status='BLOCKED',
           remaining='最终配对件、线桶端点、第一可弯点、夹持/滑移位置及余量未冻结。',
           can_continue_now='可整理接口要求与已知接头资料；不把容量位置当成端接。',
           dependency='CAM供电硬件正式交接、喇叭插头与实发舵机尾线/附件。'),
      dict(id=4,title='验证带线装配、闭壳并同步',status='BLOCKED',
           remaining='真实端子逐根穿入、后装供电线、带线头身安装、拆壳与闭壳尚未完成；正式模型/视频没有采用研究线束。',
           can_continue_now='可继续已知部分的路径准备；完整复核依赖前三项。',
           dependency='路线、接头及固定方式冻结。')]
    sources={str(HERE/n):sha(HERE/n) for n in ['pitch_continuous_inspection.json','family_sample_inspection.json',
              'family_geometry_screen.json','failure_witnesses.json','publish_review.py']}
    for p in [seam_path,servo_path,speaker_path,endpoints_path,usb_path,MECHANICAL/'mori_v1_2.blend']:
        sources[str(p)]=sha(p)
    sources[str(latest_path)]=sha(latest_path)
    review=dict(status='PASS',scope='Verified progress inventory only; unresolved work is not complete',
                revision='V1.2-M1.55',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
                work_packages=work,missing_upper_references=seam['missing_upper_reference_segments'],
                continuous_pitch_at_key_yaws='PASS',continuous_yaw_family='PASS',
                continuous_yaw_family_scope='Unadopted body/neck capacity prefixes only; not full installed mixed-material harness',
                continuous_bend_across_yaw='PASS',continuous_numerical_reference_length_root='PASS',
                continuous_native_gap_across_yaw='PASS',continuous_peer_gap_across_yaw='PASS',continuous_remote_self_across_yaw='PASS',
                purchased_servo_sku='SC-0090-C001',speaker_lead_mm=150,speaker_lead_includes_plug=True,
                servo_endpoint_evidence='Historical vendor document fields only; old CAD fit not inherited',
                servo_factory_tail_length_mm_documented=150,servo_tail_family_documented='5264-3P',
                servo_has_on_body_dual_sockets=False,servo_actual_supplied_junction_board='BLOCKED',
                speaker_plug_identity='BLOCKED',CAM_USB_source='BLOCKED',
                deferred_to_arrival=['SC-0090-C001 horn/spline/locking/accessories','Waveshare FPC/FFC'],
                new_supplier_messages_sent=False,new_user_approval_required_for_this_diagnosis=False,
                main_changed=False,hardware_changed=False,new_commit_or_push=False,
                full_harness='BLOCKED',manufacturing_release=False)
    (HERE/'remaining_work.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
    witness_rows=''.join(f'<tr><td>{html.escape(r["wire"])}</td><td>{r["radius_at_witness_mm"]:.6f} mm</td><td>6.865 mm</td><td>FAIL</td></tr>' for r in diagnosis['rows'])
    work_rows=''.join(f'<tr><td>{r["id"]}. {r["title"]}</td><td>{r["remaining"]}</td><td>{r["can_continue_now"]}<br>{r["dependency"]}</td></tr>' for r in work)
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 连续运动与剩余工作</title>
<style>body{{max-width:1080px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}.scroll{{overflow:auto}}</style>
<h1>M1.55 · 连续运动与剩余工作</h1><p>2026-10-09 · 主模型及动画已采用 R2。线束研究仍<strong> BLOCKED / 未采用</strong>。</p>
<p class="notice"><strong>最新：<a href="frame_family_R3/continuous_gaps_R1/index.html">R3参考前段连续几何已闭合</a></strong>。12条身体/颈部参考前段完成全偏航转弯、公共数值长度连续根、全偏航/俯仰原生实体间隙、66组跨线和12条远端自接近。完整上段、真实端接/材料/夹持与带线装配仍未闭合，四个工作包仍未完成。没有改打印件或硬件，没有新提交／推送。下方初版及R2失败记录保留为历史。</p>
<p><a href="../global_bundle_layout/index.html">静态共同前段 R3</a> · <a href="../index.html">材料与研究总览</a> · <a href="../../../mori_v1_2.blend">当前主模型</a> · <a href="../../../animation/index.html">M1.55-A1 装配视频</a></p>
<h2>已经完成的本轮检查</h2><p>13 个保存偏航布局分别覆盖完整 −20°～+25° 俯仰区间，1,404 次中点线路检查并计入实体运动上界，<a href="pitch_continuous_inspection.json">连续俯仰 PASS</a>。这里只证明这13档布局，不证明档位之间的偏航。</p>
<p>新数学前段族在241个偏航采样位置保持共同数值参考长度，<a href="family_sample_inspection.json">参考长度及解析导数检查 PASS</a>；完整偏航区间的根存在、实体间隙、转弯及柔性线行为未被该采样证明。</p>
<h2>历史卡点：初版偏航过渡转弯</h2><p><a href="family_geometry_screen.json">初版独立实体复核</a>计划25个偏航位置，实际检查0°、−60°、−55°，在−55°停止。该位置的原生实体、跨线间隙和连续俯仰检查通过，但3条参考转弯未通过。下方失败点与初版几何对应，不能当作最新R3的当前失败：</p>
<div class="scroll"><table><tr><th>参考线</th><th>失败点中心线半径</th><th>参考目标</th><th>结果</th></tr>{witness_rows}</table></div>
<p><a href="failure_witnesses.json">坐标与解析导数</a> · <a href="diagnose_failure.py">诊断脚本</a>。这些数字是未选定容量路线的曲率；6.865 mm 是本研究保守参考目标，不能称为实物喇叭线或已采购导线的动态寿命额定值。没有因此缩线径、降低间隙目标或修改模型。</p>
<h2>还差多少</h2><div class="scroll"><table><tr><th>四个未完成工作包</th><th>剩余内容</th><th>可继续工作与依赖</th></tr>{work_rows}</table></div>
<h2>输入边界</h2><p>SC-0090-C001 完整型号已经确认，不再要求订单链接来识别型号。历史厂家图示150mm机身尾线与5264-3P，不能画成舵机本体双插座；实际尾线出口、配对件及附带分线组件仍缺尺寸。舵盘／花键／锁紧附件和微雪FPC／FFC按用户决定到货后核对。</p>
<p>喇叭实物150mm从壳体出线处到已有插头末端，包含插头；不是150mm全可弯导线。插头针数／针距／标记仍待补充，未猜型号。CAM USB源端R3是独立硬件研究，不能当作已定PCB或已验证供电线路。</p>
<p>正式H06保持AWG28／PH002／PHR-4及厂配SH尾线，厂家压接、身体端穿线后入壳保持。Z200接续位置仍是数学容量参考，不能作为实际接头、夹持点或供应商裁线基准。</p>
<p><a href="remaining_work.json">当前待办与来源哈希</a> · <a href="README.md">实际命令</a> · <a href="delivery.json">发布哈希</a></p><p>PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    commands=[
      dict(script='certify_pitch.py',runtime='/Applications/Blender.app/Contents/MacOS/Blender',
           arguments=['-b','mechanical/mori_v1_2.blend','--python',str((HERE/'certify_pitch.py').relative_to(PROJECT))]),
      dict(script='check_family.py',runtime='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',arguments=[str((HERE/'check_family.py').relative_to(PROJECT))]),
      dict(script='screen_family_geometry.py',runtime='/Applications/Blender.app/Contents/MacOS/Blender',
           arguments=['-b','mechanical/mori_v1_2.blend','--python',str((HERE/'screen_family_geometry.py').relative_to(PROJECT))]),
      dict(script='diagnose_failure.py',runtime='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',arguments=[str((HERE/'diagnose_failure.py').relative_to(PROJECT))])]
    for r in commands:
        log=HERE/(Path(r['script']).stem+'.log')
        assert log.is_file() and 'Traceback (most recent call last)' not in log.read_text()
        r.update(cwd=str(PROJECT),log=str(log.relative_to(PROJECT)),log_sha256=sha(log))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,
          initial_attempt_log='check_family_initial_datum_failure.log',
          Blender='5.2.2 LTS d13f752e3b9c',python='3.13.13',numpy='2.3.4',scipy='1.16.2'),ensure_ascii=False,indent=2)+'\n')
    (HERE/'README.md').write_text('''# M1.55 连续运动与剩余工作

本目录只读当前主模型，未采用数学前段或材料候选。
最新frame_family_R3完成12条参考前段的全偏航转弯界及公共数值长度连续根；
continuous_gaps_R1另行完成全偏航/俯仰实体间隙、66组跨线和12条远端自接近。
完整上段、真实端接/材料/夹持、实际线长和带线装配仍未完成。
连续俯仰在13个保存偏航布局PASS；241个偏航采样的数值公共参考长度PASS。
初版偏航实体复核计划25个位置，在第3个位置−55°因转弯失败停止，保留为历史。
failure_witnesses.json直接记录3个解析导数失败点，不是算法保守误报或整机碰撞。
这些是未选定容量路线；不能据此确定实物线材额定、裁线或动态寿命。

四个未完成工作包与已知输入见remaining_work.json及index.html。
完整SC-0090-C001型号已确认；舵盤附件和微雪FPC/FFC按用户决定到货核对。
喇叭150mm包含插头，实际配对件未确认；CAM供电源端待硬件正式交接。
旧M1.53端点记录只复用厂家字段，旧模型空间结果未沿用为M1.55通过。

实际命令及运行目录见commands.json，每次运行日志保留。
无新增打印件/紧固件，无供应商消息，无新commit/push，主模型及硬件保持。
full_harness=BLOCKED；manufacturing_release=false。
''')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*'))
           if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_review.log','verify_review.log']}
    receipt=dict(status='PASS',scope='Publication and source receipt only; historical families rejected, current capacity prefixes scoped PASS; full harness unresolved',
                 recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_blend_sha256=digest,
                 continuous_pitch_at_key_yaws='PASS',continuous_yaw_family='PASS',remaining_work_packages=4,
                 continuous_yaw_family_scope='Unadopted body/neck capacity prefixes only; full harness BLOCKED',
                 continuous_bend_across_yaw='PASS',continuous_numerical_reference_length_root='PASS',
                 continuous_native_gap_across_yaw='PASS',continuous_peer_gap_across_yaw='PASS',continuous_remote_self_across_yaw='PASS',
                 frame_R3_delivery_sha256=sha(HERE/'frame_family_R3/delivery.json'),
                 main_changed=False,hardware_changed=False,new_commit_or_push=False,
                 full_harness='BLOCKED',manufacturing_release=False,files=files)
    (HERE/'delivery.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print('PREFIX_CONTINUITY_PUBLISHED',len(files),'files; four unresolved work packages',flush=True)

if __name__=='__main__': main()
