"""Interpolated material-shape residuals in a distributed yaw frame.

Each control uses one fixed frame weight: body endpoints stay body-fixed and
the last controls rotate coherently with the existing yaw reference. This is
a capacity candidate, not selected restraints or true factory wire endpoints.
"""
from pathlib import Path
import sys,math
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/'root_direction_R2'),str(HERE.parent)]
from family_R2 import FamilyR2,BSpline,sha,quadrature
from family import smooth,smooth_d,smooth_dd
import numpy as np

def rotate(values,angles):
    a=np.radians(angles);c=np.cos(a);s=np.sin(a)
    r=values.copy();r[:,0]=c*values[:,0]-s*values[:,1];r[:,1]=s*values[:,0]+c*values[:,1]
    return r

def omega(values,weights):
    k=weights*math.pi/180
    return np.c_[-k*values[:,1],k*values[:,0],np.zeros(len(values))]

class FrameFamily(FamilyR2):
    def __init__(self,z0=160.,z1=180.):
        super().__init__();self.z0=z0;self.z1=z1;self.frame_weights={};self.local_controls={};self.local_directions={}
        for name,c in self.controls[0].items():
            u=np.clip((c[:,2]-z0)/(z1-z0),0,1);w=smooth(u);w[:2]=0;w[-2:]=1
            self.frame_weights[name]=w
        for yaw,items in self.controls.items():
            self.local_controls[yaw]={};self.local_directions[yaw]={}
            for name,c in items.items():
                w=self.frame_weights[name]
                self.local_controls[yaw][name]=rotate(c,-w*yaw)
                self.local_directions[yaw][name]=rotate(self.directions[yaw][name],-w*yaw)
        self.sources[str(Path(__file__))]=sha(Path(__file__))

    def base(self,name,yaw):
        a,b,u=self.segment(yaw);s=smooth(u);sd=smooth_d(u)/10;sdd=smooth_dd(u)/100
        w=self.frame_weights[name];la,lb=self.local_controls[a][name],self.local_controls[b][name]
        dl=lb-la;local=la+s*dl
        c=rotate(local,w*yaw)
        cy=rotate(sd*dl+omega(local,w),w*yaw)
        cyy=rotate(sdd*dl+2*sd*omega(dl,w)+omega(omega(local,w),w),w*yaw)
        da,db=self.local_directions[a][name],self.local_directions[b][name]
        dd=db-da;direction=da+s*dd
        d=rotate(direction,w*yaw)
        dy=rotate(sd*dd+omega(direction,w),w*yaw)
        dyy=rotate(sdd*dd+2*sd*omega(dd,w)+omega(omega(direction,w),w),w*yaw)
        return c,cy,cyy,d,dy,dyy
