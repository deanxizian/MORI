"""Numerically cross-check interval receipts using direct B-spline evaluation.

These samples are consistency checks, not substitutes for interval bounds.
No final endpoint, material or physical dynamic rating is implied.
"""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from selected_family import SelectedFamily,BSpline,sha
from certify_bending import matrices
import numpy as np

def main():
    start=time.time();f=SelectedFamily();path=HERE/'continuous_bend_inspection.json';proof=json.loads(path.read_text())
    assert proof['status']=='PASS' and proof['wire_count']==12
    assert all(sha(p)==h for p,h in proof['sources'].items())
    operators=matrices(f);matrix_error=0.
    for name in f.names:
        for yaw in [-55.5,7.5,38.5]:
            c=f.candidate(name,yaw)['control'];spl=BSpline(f.knots,c,3)
            for M,a,b in operators:
                bezier=M@c
                for u in [.13,.49,.87]:
                    p=(1-u)**3*bezier[0]+3*(1-u)**2*u*bezier[1]+3*(1-u)*u*u*bezier[2]+u**3*bezier[3]
                    matrix_error=max(matrix_error,float(np.max(abs(p-spl(a+(b-a)*u)))))
    assert matrix_error<1e-9
    ts=np.unique(np.r_[np.linspace(0,1,8001),np.unique(f.knots)]);rows=[]
    for r in proof['results']:
        name=r['wire'];items=r['intervals'];chosen=items[::max(1,len(items)//8)][:9]
        for interval in chosen:
            lo,hi=interval['yaw_interval_deg']
            for yaw in np.linspace(lo,hi,5):
                it=f.candidate(name,float(yaw));spl=BSpline(f.knots,it['control'],3)
                v=spl.derivative()(ts);a=spl.derivative(2)(ts);speed=np.linalg.norm(v,axis=1)
                k=np.linalg.norm(np.cross(v,a),axis=1)/speed**3;minimum=float(1/k.max())
                assert minimum+1e-7>=interval['radius_lower_mm'],(name,yaw,minimum,interval['radius_lower_mm'])
                rows.append(dict(wire=name,yaw_deg=float(yaw),interval=[lo,hi],sampled_radius_mm=minimum,
                                 certified_lower_mm=interval['radius_lower_mm'],status='PASS'))
    f.unchanged();sources=dict(proof['sources'])
    for p in [path,Path(__file__)]:sources[str(p)]=sha(p)
    result=dict(status='PASS',scope='Direct numerical cross-check of analytic B-spline/Bezier mapping and published yaw bounds',
       sources=sources,Bezier_mapping_maximum_error_mm=matrix_error,checks=len(rows),rows=rows,
       curve_samples=len(ts),full_harness='BLOCKED',main_changed=False,hardware_changed=False,
       manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'bounds_crosscheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('R3_BOUNDS_CROSSCHECK_PASS',len(rows),'checks',matrix_error,time.time()-start,flush=True)

if __name__=='__main__':main()
