"""Publish R3 continuity progress with the remaining full-harness boundaries."""
from pathlib import Path
import datetime,hashlib,json
HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[3];PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    reports={n:read(HERE/n) for n in ['math_inspection.json','family_geometry_screen.json',
              'continuous_root_inspection.json','continuous_bend_inspection.json','bounds_crosscheck.json']}
    assert all(d['status']=='PASS' for d in reports.values())
    assert all(sha(p)==h for d in reports.values() for p,h in d['sources'].items())
    geometry=reports['family_geometry_screen.json'];root=reports['continuous_root_inspection.json']
    bending=reports['continuous_bend_inspection.json'];cross=reports['bounds_crosscheck.json']
    assert geometry['actual_yaw_positions']==geometry['planned_yaw_positions']==25
    assert root['wire_count']==bending['wire_count']==12 and root['accepted_yaw_cells']==478
    assert root['yaw_coverage_deg']==bending['yaw_coverage_deg']==[-60,60]
    assert len(cross['rows'])==525
    gap_path=HERE/'continuous_gaps_R1/progress.json';gaps=read(gap_path)
    assert gaps['status']=='PASS' and gaps['continuous_native_gap_across_yaw_and_pitch']=='PASS'
    assert gaps['continuous_peer_gap_across_yaw']==gaps['continuous_remote_self_across_yaw']=='PASS'
    assert all(sha(p)==h for p,h in gaps['sources'].items())
    digest=sha(MECHANICAL/'mori_v1_2.blend')
    assert digest=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    prior=read(HERE.parent/'root_direction_R2/dense_bend_inspection.json')
    assert prior['status']=='BLOCKED' and len(prior['failures'])==1166
    assert all(sha(p)==h for p,h in prior['sources'].items())
    sources={str(HERE/n):sha(HERE/n) for n in reports}
    for p in [Path(__file__),HERE/'candidate_config.json',HERE.parent/'root_direction_R2/dense_bend_inspection.json']:
        sources[str(p)]=sha(p)
    sources[str(gap_path)]=sha(gap_path)
    progress=dict(status='PASS',scope='Recorded numerical capacity-family progress only; not adopted harness or manufacturing release',
       recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
       revision='V1.2-M1.55',source_blend_sha256=digest,reference_wires=12,
       static_yaw_positions=25,continuous_pitch_at_static_yaws='PASS',
       static_native_gap_lower_mm=geometry['minimum_sampled_native_gap_lower_mm'],
       continuous_numerical_reference_length_root='PASS',continuous_bend_across_yaw='PASS',
       yaw_coverage_deg=[-60,60],required_reference_radius_mm=6.865,
       continuous_native_gap_across_yaw='PASS',continuous_peer_gap_across_yaw='PASS',
       continuous_remote_self_across_yaw='PASS',complete_upper_tails='BLOCKED',
       continuous_native_yaw_cells=gaps['native_yaw_cells'],continuous_native_pitch_cells=gaps['native_pitch_cells'],
       continuous_pair_and_self_yaw_cells=gaps['pair_and_self_yaw_cells'],
       actual_mixed_material_length='BLOCKED',physical_terminals_and_restraints='BLOCKED',
       wired_assembly_and_closure='BLOCKED',dynamic_life='NOT_TESTED',
       actual_material_selection='BLOCKED',numerical_root_is_supplier_cut_length=False,
       historical_R2_dense_failure_count=1166,main_changed=False,hardware_changed=False,
       full_harness='BLOCKED',new_commit_or_push=False,manufacturing_release=False)
    (HERE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
    table=''.join(f'<tr><td>{r["wire"]}</td><td>{r["accepted_yaw_cells"]}</td><td>{r["minimum_certified_radius_mm"]:.8f} mm</td><td>PASS</td></tr>' for r in bending['results'])
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 R3 连续偏航前段</title>
<style>body{{max-width:1080px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}.scroll{{overflow:auto}}</style>
<h1>M1.55 · R3 连续偏航前段</h1><p>2026-10-09 · <strong>参考前段取得进展；完整线束 BLOCKED / 未采用</strong>。</p>
<p class="notice"><strong>最新：<a href="continuous_gaps_R1/index.html">参考前段连续几何已闭合</a></strong>。12条身体/颈部容量前段完成全偏航转弯界、公共数值长度连续根，以及全偏航/俯仰的201件原生实体间隙、66组跨线和12条远端自接近。全部满足原0.3mm目标。以下25档检查保留为有限采样证据；完整上段、真实端接/夹持、实际材料长度和带线装配仍BLOCKED，候选没有放进主模型。</p>
<p><a href="../index.html">剩余四项与早期失败记录</a> · <a href="../../global_bundle_layout/index.html">原静态R3布局</a> · <a href="../../../../mori_v1_2.blend">当前主模型</a> · <a href="../../../../animation/index.html">M1.55-A1装配视频</a></p>
<h2>改了什么</h2><p>初版把末端控制点按偏航旋转，其余点直接插值，线长补偿还集中在短区域。R2平顺补偿通过25档，但加密到241档后仍有1,166个单线/角度转弯失败记录，包括7.5°上端急弯。R3把控制点放入连续变化的偏航参考系：身体端保持，靠近上端的整段同步旋转，再插值形状余差、平顺补偿参考长度。保留原13档位置、原生硬件和现有参考端点，不新增固定点、接头、导向件或打印件。</p>
<p><a href="frame_search.json">五种连续参考系的采样比较</a> · <a href="candidate_config.json">研究配置</a> · <a href="../root_direction_R2/dense_bend_inspection.json">R2加密失败记录</a>。当前配置只是PLACEHOLDER / ASSUMED容量族，不是实际线束固定方案。</p>
<h2>全偏航范围的检查</h2><p><a href="continuous_root_inspection.json">478个偏航区间</a>用导数界与单调括区间证明记录的Gauss64参考长度在每个角度都有唯一连续补偿根。241个位置另用Gauss128和解析导数做数值核对；这不等于完整物理材料长度或供应商裁线尺寸。</p>
<p><a href="continuous_bend_inspection.json">完整线路和角度的转弯界</a>覆盖每条参考线的全曲线参数及全偏航区间，计入同一长度根的控制点变化，共处理{bending['evaluated_polynomial_cells']:,}个多项式区间。下表给的是保守界，不是测量值或动态寿命额定：</p>
<div class="scroll"><table><tr><th>参考前段</th><th>偏航区间数</th><th>最小认证半径下界</th><th>结果</th></tr>{table}</table></div>
<p><a href="bounds_crosscheck.json">525次独立数值核对</a>直接使用B样条求值，比对公开界和Bezier映射；映射最大误差{cross['Bezier_mapping_maximum_error_mm']:.3g}mm。数值样本不是替代区间界的依据。</p>
<h2>还差什么</h2><ol><li>前段连续几何已闭合；继续与完整上段接续，旧上段结果未自动继承。</li><li>补齐三根舵机和两根喇叭的上端参考，复核其它上段及混合材料连续转弯/实际线长。</li><li>取得CAM供电源端正式交接、实际喇叭插头及舵机尾线/附件尺寸，冻结端接、第一可弯点、夹持/滑移和应力释放。</li><li>完成真实端子逐根穿入、后装供电线、带线头身安装和闭壳，再同步正式模型及动画。</li></ol>
<p>用户已确认SC-0090-C001型号、喇叭150mm含已有插头；不能再当成型号未选或150mm全可弯线。舵盘/锁紧附件与微雪FPC/FFC按用户决定到货复核。正式H06仍AWG28/PH002/PHR-4＋厂配SH尾线，身体端穿线后入壳。Z200仍是参考切面，不是新增实物端接或夹持点。</p>
<p><a href="progress.json">进展与范围</a> · <a href="math_inspection.json">数值长度/导数</a> · <a href="family_geometry_screen.json">25档独立实体检查</a> · <a href="README.md">实际命令</a> · <a href="delivery.json">发布哈希</a></p>
<p>PROTOTYPE / UNVALIDATED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# M1.55 R3连续偏航参考族

12条身体/颈部容量前段；未采用，未改打印件、真实硬件或正式H06物料。
完整−60°～+60°转弯及公共Gauss64数值参考长度的连续根PASS。
原25档偏航检查保留为有限采样记录；最新continuous_gaps_R1已独立覆盖全偏航/俯仰实体间隙、
66组跨线和12条远端自接近。完整上段、真实端接和带线装配仍BLOCKED。
根检查不是供应商裁线长，转弯目标不是动态寿命额定；全线束仍BLOCKED。

R2虽然25档通过，但241档转弯检查发现1,166个失败样本，原始记录保留。
R3改为分布偏航参考系内的形状插值，不新增实物端接或固定点。

实际运行目录为当前archive-split/MORI工作树。
search_frames.py、check_math.py、certify_roots.py、certify_bending.py、verify_bounds.py
用Blender自带Python3.13执行；screen_geometry.py由离线Blender读取当前主模型。
每个脚本有对应.log。Blender5.2.2 LTS d13f752e3b9c，Python3.13.13、
NumPy2.3.4，SciPy1.16.2独立缓存，不改软件安装或原项目运行环境。

正式H06保持；实物150mm喇叭尾线含插头，插头未确认。
SC-0090-C001型号已确认，实发尾线/分线板、舵盘和微雪软排线仍待到货。
CAM供电源端等待正式硬件交接。供应商询问未发送，无新commit/push。
''')
    commands=[]
    for script in ['search_frames.py','check_math.py','certify_roots.py','certify_bending.py','verify_bounds.py','screen_geometry.py']:
        log=HERE/(Path(script).stem+'.log');assert log.is_file() and 'Traceback (most recent call last)' not in log.read_text()
        runtime='/Applications/Blender.app/Contents/MacOS/Blender' if script=='screen_geometry.py' else '/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
        args=['-b','mechanical/mori_v1_2.blend','--python'] if script=='screen_geometry.py' else []
        args.append(str((HERE/script).relative_to(PROJECT)))
        commands.append(dict(command=[runtime]+args,cwd=str(PROJECT),log=str(log.relative_to(PROJECT)),log_sha256=sha(log)))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands),ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','publish_result.log','verify_publication.log']}
    result=dict(status='PASS',scope='Published R3 research evidence only',source_blend_sha256=digest,
       continuous_bend_across_yaw='PASS',continuous_numerical_reference_length_root='PASS',
       static_yaw_positions=25,continuous_native_gap_across_yaw='PASS',continuous_peer_gap_across_yaw='PASS',
       continuous_remote_self_across_yaw='PASS',continuous_gaps_delivery_sha256=sha(HERE/'continuous_gaps_R1/delivery.json'),
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,new_commit_or_push=False,
       manufacturing_release=False,files=files,published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (HERE/'delivery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('R3_CONTINUOUS_PREFIX_PUBLISHED',len(files),'files',flush=True)

if __name__=='__main__':main()
