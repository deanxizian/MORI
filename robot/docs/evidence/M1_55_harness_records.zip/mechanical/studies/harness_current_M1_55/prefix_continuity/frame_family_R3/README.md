# M1.55 R3连续偏航参考族

12条身体/颈部容量前段；未采用，未改打印件、真实硬件或正式H06物料。
完整−60°～+60°转弯及公共Gauss64数值参考长度的连续根PASS。
原25档偏航检查保留为有限采样记录；最新continuous_gaps_R1已独立覆盖全偏航/俯仰实体间隙、
66组跨线和12条远端自接近。完整上段、真实端接和带线装配仍BLOCKED。
根检查不是供应商裁线长，转弯目标不是动态寿命额定；全线束仍BLOCKED。

R2虽然25档通过，但241档转弯检查发现1,166个失败样本，原始记录保留。
R3改为分布偏航参考系内的形状插值，不新增实物端接或固定点。

实际运行目录为当前archive-split/MORI工作树。
search_frames.py、check_math.py、certify_roots.py、certify_bending.py、verify_bounds.py
用Blender自带Python3.13执行；screen_geometry.py由离线Blender读取当前主模型。
每个脚本有对应.log。Blender5.2.2 LTS d13f752e3b9c，Python3.13.13、
NumPy2.3.4，SciPy1.16.2独立缓存，不改软件安装或原项目运行环境。

正式H06保持；实物150mm喇叭尾线含插头，插头未确认。
SC-0090-C001型号已确认，实发尾线/分线板、舵盘和微雪软排线仍待到货。
CAM供电源端等待正式硬件交接。供应商询问未发送，无新commit/push。
