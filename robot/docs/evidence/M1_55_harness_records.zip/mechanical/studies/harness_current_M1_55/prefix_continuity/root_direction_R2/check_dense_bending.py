"""Independent dense curvature screen before yaw interval certification."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from family_R2 import FamilyR2,BSpline,sha
import numpy as np

def main():
    start=time.time();f=FamilyR2();ts=np.unique(np.r_[np.linspace(0,1,6001),np.unique(f.knots)])
    d=BSpline(f.knots,np.eye(48),3).derivative()(ts);a=BSpline(f.knots,np.eye(48),3).derivative(2)(ts)
    rows=[];failed=[];minimum=float('inf');worst=None
    for yaw in np.linspace(-60,60,241):
        for name in f.names:
            item=f.candidate(name,float(yaw));c=item['control'];v=d@c;acc=a@c;speed=np.linalg.norm(v,axis=1)
            k=np.linalg.norm(np.cross(v,acc),axis=1)/speed**3;i=int(np.argmax(k));r=float(1/k[i])
            row=dict(wire=name,yaw_deg=float(yaw),minimum_sampled_radius_mm=r,normalized_parameter=float(ts[i]),
                     status='PASS' if r>=6.865 else 'FAIL')
            rows.append(row)
            if r<minimum:minimum=r;worst=row
            if row['status']!='PASS':failed.append(row)
    f.unchanged();sources=dict(f.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    report=dict(status='PASS' if not failed else 'BLOCKED',scope='241 sampled yaw positions; not interval certification',
       sources=sources,rows=rows,failures=failed,minimum_sampled_radius_mm=minimum,worst=worst,
       sampled_yaw_positions=241,curve_samples=len(ts),full_harness='BLOCKED',main_changed=False,
       hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'dense_bend_inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('R2_DENSE_BENDING_TERMINAL',report['status'],minimum,worst,len(failed),time.time()-start,flush=True)

if __name__=='__main__':main()
