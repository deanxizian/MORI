"""Continuous yaw capacity-prefix family with explicit reference-length roots.

This is a pure mathematical candidate. Endpoints are existing reference
datums, not new physical terminals. Interior correction cannot move the two
start/end controls. True hardware remains unchanged and complete wiring is
not implied by this family.
"""
from pathlib import Path
import hashlib,json,sys,math
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'global_bundle_layout'
SCIPY=Path('/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
sys.path.insert(0,str(SCIPY))
import numpy as np
from scipy.interpolate import BSpline
from scipy.optimize import brentq

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
OMEGA=np.array([[0.,-1.,0.],[1.,0.,0.],[0.,0.,0.]])*math.pi/180

def rotation(yaw):
    a=math.radians(yaw);c=math.cos(a);s=math.sin(a)
    return np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]])

def smooth(u):return u**3*(10-15*u+6*u*u)
def smooth_d(u):return 30*u*u*(1-u)**2
def smooth_dd(u):return 60*u*(1-u)*(1-2*u)

def quadrature(knots,order=64):
    edges=np.unique(knots);u,w=np.polynomial.legendre.leggauss(order)
    ts=np.concatenate([(a+b)/2+(b-a)*u/2 for a,b in zip(edges[:-1],edges[1:])])
    weights=np.concatenate([(b-a)*w/2 for a,b in zip(edges[:-1],edges[1:])])
    return BSpline(knots,np.eye(len(knots)-4),3).derivative()(ts),weights,ts

class Family:
    def __init__(self):
        path=BASE/'all_yaws_R3_inspection.json';proof=json.loads(path.read_text())
        assert proof['status']=='PASS' and all(sha(p)==h for p,h in proof['sources'].items())
        self.sources={str(Path(__file__)):sha(Path(__file__)),str(path):sha(path)}
        self.yaws=np.arange(-60,61,10);self.controls={};self.meta={};self.names=None
        for yaw in self.yaws:
            folder=BASE/'all_yaws_R3'/f'y{yaw}';source=folder/'candidate.npz';metadata=folder/'optimization.json'
            data=np.load(source);meta=json.loads(metadata.read_text());self.sources[str(source)]=sha(source);self.sources[str(metadata)]=sha(metadata)
            if self.names is None:
                self.names=list(meta['wires']);self.knots=data[self.names[0]+'_knots']/data[self.names[0]+'_knots'][-1]
            self.controls[int(yaw)]={name:data[name+'_controls'] for name in self.names};self.meta[int(yaw)]=meta
            for name in self.names:
                t=data[name+'_knots']/data[name+'_knots'][-1]
                assert np.max(abs(t-self.knots))<1e-14,(yaw,name)
        self.targets={name:self.meta[0]['wires'][name]['reference_length_target_mm'] for name in self.names}
        self.radii={name:self.meta[0]['wires'][name]['radius_mm'] for name in self.names}
        self.Q,self.weights,self.qnodes=quadrature(self.knots)
        self.directions={};self.local_ends={}
        for yaw,items in self.controls.items():
            self.directions[yaw]={};self.local_ends[yaw]={}
            for name,c in items.items():
                v=self.Q@c;n=v/np.linalg.norm(v,axis=1)[:,None]
                g=self.Q.T@(self.weights[:,None]*n)
                mask=np.clip((180.-c[:,2])/15.,0.,1.)**2;g*=mask[:,None];g[:2]=0;g[-2:]=0
                maximum=float(np.linalg.norm(g,axis=1).max());assert maximum>1e-8,(yaw,name)
                self.directions[yaw][name]=g/maximum
                self.local_ends[yaw][name]=c[-2:]@rotation(-yaw).T
        self.end_local_key_span_mm={}
        for name in self.names:
            assert max(np.linalg.norm(c[name][0]-self.controls[0][name][0]) for c in self.controls.values())<1e-9
            # CC's Z200 point is a mathematical slice through a deforming
            # reference, not a selected rigid anchor. CAM also retains tiny
            # float32 transform differences. Preserve every stored key datum
            # and interpolate its local value; never force it to a fake port.
            self.end_local_key_span_mm[name]=max(float(np.linalg.norm(r[name][-1]-self.local_ends[0][name][-1])) for r in self.local_ends.values())

    def segment(self,yaw):
        assert -60<=yaw<=60
        i=min(11,max(0,int(math.floor((yaw+60)/10))));a=-60+10*i;b=a+10
        return a,b,(yaw-a)/10

    def base(self,name,yaw):
        a,b,u=self.segment(yaw);s=smooth(u);sd=smooth_d(u)/10;sdd=smooth_dd(u)/100
        ca,cb=self.controls[a][name],self.controls[b][name];delta=cb-ca
        c=ca+s*delta;cy=sd*delta;cyy=sdd*delta
        local=self.local_ends[a][name]+s*(self.local_ends[b][name]-self.local_ends[a][name])
        dl=self.local_ends[b][name]-self.local_ends[a][name];r=rotation(yaw)
        c[-2:]=local@r.T
        cy[-2:]=(sd*dl+local@OMEGA.T)@r.T
        cyy[-2:]=(sdd*dl+2*sd*dl@OMEGA.T+local@(OMEGA@OMEGA).T)@r.T
        da,db=self.directions[a][name],self.directions[b][name];delta_d=db-da
        direction=da+s*delta_d;dy=sd*delta_d;dyy=sdd*delta_d
        return c,cy,cyy,direction,dy,dyy

    def candidate(self,name,yaw):
        c,cy,cyy,direction,dy,dyy=self.base(name,yaw)
        v0=self.Q@c;dv=self.Q@direction
        def value(a):return float(self.weights@np.linalg.norm(v0+a*dv,axis=1))-self.targets[name]
        width=.001
        while width<=2.:
            if value(-width)<=0<=value(width):break
            width*=2
        else:raise RuntimeError(('No local reference-length root within2mm',name,yaw,value(0)))
        amplitude=float(brentq(value,-width,width,xtol=1e-12,rtol=1e-14));actual=c+amplitude*direction
        v=self.Q@actual;speed=np.linalg.norm(v,axis=1);n=v/speed[:,None];va=self.Q@direction
        vy=self.Q@(cy+amplitude*dy);vyy=self.Q@(cyy+amplitude*dyy);vay=self.Q@dy
        g=float(self.weights@np.sum(n*va,axis=1));fy=float(self.weights@np.sum(n*vy,axis=1));assert g>1e-6,(name,yaw,g)
        ay=-fy/g
        aa=float(self.weights@((np.sum(va*va,axis=1)-np.sum(n*va,axis=1)**2)/speed))
        ya=float(self.weights@((np.sum(vy*va,axis=1)-np.sum(n*vy,axis=1)*np.sum(n*va,axis=1))/speed+np.sum(n*vay,axis=1)))
        yy=float(self.weights@((np.sum(vy*vy,axis=1)-np.sum(n*vy,axis=1)**2)/speed+np.sum(n*vyy,axis=1)))
        ayy=-(yy+2*ya*ay+aa*ay*ay)/g
        actual_y=cy+amplitude*dy+ay*direction
        actual_yy=cyy+amplitude*dyy+2*ay*dy+ayy*direction
        return dict(control=actual,control_y=actual_y,control_yy=actual_yy,amplitude_mm=amplitude,
                    amplitude_derivative_mm_per_deg=ay,amplitude_second_derivative_mm_per_deg2=ayy,
                    reference_length_residual_mm=value(amplitude),length_root_derivative=g,base=(c,cy,cyy,direction,dy,dyy))

    def unchanged(self):assert all(sha(p)==h for p,h in self.sources.items())
