"""Verify sampled R2 numerical length roots and analytic yaw derivatives."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from selected_family import SelectedFamily as FamilyR2,quadrature,sha
import numpy as np

def main():
    start=time.time();f=FamilyR2();q,w,_=quadrature(f.knots,128)
    rows=[];maximum_length_error=0.;maximum_amplitude=0.;minimum_g=float('inf')
    for yaw in np.linspace(-60,60,241):
        for name in f.names:
            item=f.candidate(name,float(yaw));c=item['control'];base=f.base(name,float(yaw))[0]
            assert np.max(abs(c[[0,1,-2,-1]]-base[[0,1,-2,-1]]))<1e-10
            delta=float(w@np.linalg.norm(q@c,axis=1))-f.targets[name]
            assert abs(delta)<1e-7,(name,yaw,delta)
            maximum_length_error=max(maximum_length_error,abs(delta))
            maximum_amplitude=max(maximum_amplitude,abs(item['amplitude_mm']))
            minimum_g=min(minimum_g,item['length_root_derivative'])
            rows.append(dict(wire=name,yaw_deg=float(yaw),reference_length_residual_mm=delta,
                             amplitude_mm=item['amplitude_mm'],root_derivative=item['length_root_derivative']))
    tests=[]
    for yaw in [-59.1,-48.7,-26.2,-3.8,4.1,17.3,35.4,58.1]:
        for name in f.names:
            item=f.candidate(name,yaw);h=.002
            plus=f.candidate(name,yaw+h)['control'];minus=f.candidate(name,yaw-h)['control']
            first=(plus-minus)/(2*h);second=(plus-2*item['control']+minus)/h**2
            e1=float(np.max(abs(first-item['control_y'])));e2=float(np.max(abs(second-item['control_yy'])))
            assert e1<1e-5 and e2<1e-4,(name,yaw,e1,e2)
            tests.append(dict(wire=name,yaw_deg=yaw,first_error_mm_per_deg=e1,second_error_mm_per_deg2=e2))
    f.unchanged();sources=dict(f.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    report=dict(status='PASS',scope='241 sampled yaw positions and analytic derivative checks only; not all-angle fit',
       sources=sources,rows=rows,derivative_checks=tests,wire_count=12,sampled_yaw_positions=241,
       maximum_reference_length_residual_mm=maximum_length_error,maximum_root_amplitude_mm=maximum_amplitude,
       minimum_sampled_root_derivative=minimum_g,continuous_length_root_existence='NOT_TESTED',
       native_clearance='NOT_TESTED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
       manufacturing_release=False,elapsed_s=time.time()-start)
    (HERE/'math_inspection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('R3_MATH_INSPECTION_PASS',len(rows),'root samples',len(tests),'derivative checks',time.time()-start,flush=True)

if __name__=='__main__':main()
