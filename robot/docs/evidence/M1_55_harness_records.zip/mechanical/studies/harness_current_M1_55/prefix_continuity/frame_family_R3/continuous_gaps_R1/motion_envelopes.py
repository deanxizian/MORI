"""Pointwise deformation envelopes around native-clearance reference curves."""
from pathlib import Path
import sys,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from selected_family import SelectedFamily,BSpline,sha
from frame_motion_bounds import RootBounds
from frame_family import rotate,omega
import numpy as np

class Envelopes:
    def __init__(self,family,count=6001):
        self.f=family;self.root=RootBounds(family);self.t=np.linspace(0,1,count);self.dt=self.t[1]-self.t[0]
        self.B=BSpline(family.knots,np.eye(48),3)(self.t)
        # Every nearest-reference-sample parameter cell is contained in the
        # following union of active control supports. No spline support can
        # start and end inside this cell: the positive knot span is much wider.
        edges=np.unique(family.knots);assert self.dt*2<float(np.diff(edges).min())
        active=np.zeros_like(self.B,dtype=bool)
        for offset in [-self.dt,0,self.dt]:
            active|=BSpline(family.knots,np.eye(48),3)(np.clip(self.t+offset,0,1))>0
        support=[np.flatnonzero(row) for row in active];width=max(len(row) for row in support)
        self.support=np.zeros((count,width),dtype=int)
        for i,row in enumerate(support):
            assert len(row)>0
            self.support[i,:len(row)]=row;self.support[i,len(row):]=row[-1]

    def curve(self,name,yaw):
        it=self.f.candidate(name,yaw);c=it['control'];p=self.B@c
        edges=np.unique(self.f.knots);s=BSpline(self.f.knots,c,3)
        maximum=float(np.linalg.norm(s.derivative(2)(edges),axis=1).max())
        error=maximum*self.dt*self.dt/8+1e-9
        half=float(np.linalg.norm(np.diff(p,axis=0),axis=1).max())/2
        return dict(control=c,points=p,chord_error_mm=error,half_step_mm=half)

    def control_envelopes(self,name,lo,hi,anchor_yaw):
        mid=(lo+hi)/2;h=(hi-lo)/2;cert=self.root.certificate(name,lo,hi)
        if cert['status']!='PASS':return None
        it=self.f.candidate(name,mid);a0=it['amplitude_mm'];c,cy,cyy,d,dy,dyy=it['base'];actual=it['control']
        b=self.root.derivatives(name,lo,hi);width=cert['amplitude_deviation_bound_mm']
        velocity=cy+a0*dy;first=b['C1']+abs(a0)*b['D1'];second=b['C2']+abs(a0)*b['D2']
        world=h*np.linalg.norm(velocity,axis=1)+.5*h*h*second+width*b['maximum_direction_norm']+1e-8
        om=math.pi/180
        local_velocity=velocity-omega(actual,np.ones(48))
        local_second=second+2*om*first+om*om*(np.linalg.norm(actual[:,:2],axis=1)+h*first)
        yaw=h*np.linalg.norm(local_velocity,axis=1)+.5*h*h*local_second+width*b['maximum_direction_norm']+1e-8
        reference=self.f.candidate(name,anchor_yaw)['control']
        delta_world=np.linalg.norm(actual-reference,axis=1)+world
        delta_yaw=np.linalg.norm(rotate(actual,np.full(48,-mid))-rotate(reference,np.full(48,-anchor_yaw)),axis=1)+yaw
        return dict(world_control_bound_mm=delta_world,yaw_control_bound_mm=delta_yaw,
                    world_point_bound_mm=delta_world[self.support].max(axis=1),
                    yaw_point_bound_mm=delta_yaw[self.support].max(axis=1),
                    root_certificate=cert,midpoint_yaw_deg=mid,anchor_yaw_deg=anchor_yaw)
