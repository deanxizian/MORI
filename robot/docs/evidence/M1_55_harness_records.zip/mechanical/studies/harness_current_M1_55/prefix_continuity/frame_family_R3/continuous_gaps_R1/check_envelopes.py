"""Cross-check deformation envelopes with independently evaluated yaw curves."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from motion_envelopes import Envelopes,SelectedFamily,rotate,sha
import numpy as np

def main():
    started=time.time();f=SelectedFamily();e=Envelopes(f);path=HERE.parent/'continuous_root_inspection.json'
    proof=json.loads(path.read_text());assert proof['status']=='PASS' and all(sha(p)==h for p,h in proof['sources'].items())
    rows=[]
    for record in proof['certificates'][::max(1,len(proof['certificates'])//24)]:
        lo,hi=record['yaw_interval_deg'];mid=(lo+hi)/2;anchor=float(round(mid/5)*5)
        for name in f.names:
            envelope=e.control_envelopes(name,lo,hi,anchor);assert envelope is not None
            ref=e.curve(name,anchor);local_ref=rotate(ref['control'],np.full(48,-anchor))
            for yaw in np.linspace(lo,hi,5):
                c=f.candidate(name,float(yaw))['control'];local=rotate(c,np.full(48,-yaw))
                assert np.all(np.linalg.norm(c-ref['control'],axis=1)<=envelope['world_control_bound_mm']+1e-8)
                assert np.all(np.linalg.norm(local-local_ref,axis=1)<=envelope['yaw_control_bound_mm']+1e-8)
                p=e.B@c;lp=e.B@local
                assert np.all(np.linalg.norm(p-ref['points'],axis=1)<=envelope['world_point_bound_mm']+1e-8)
                assert np.all(np.linalg.norm(lp-e.B@local_ref,axis=1)<=envelope['yaw_point_bound_mm']+1e-8)
                rows.append(dict(wire=name,yaw_deg=float(yaw),interval=[lo,hi],anchor_yaw_deg=anchor,status='PASS'))
    f.unchanged();sources=dict(f.sources)
    for p in [Path(__file__),HERE/'motion_envelopes.py',path,HERE.parent/'frame_motion_bounds.py',HERE.parent.parent/'root_direction_R2/root_motion_bounds.py']:sources[str(p)]=sha(p)
    report=dict(status='PASS',scope='Numerical cross-check of analytic world/yaw deformation envelopes only',
       sources=sources,checks=len(rows),rows=rows,curve_samples=len(e.t),
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'envelope_crosscheck.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print('DEFORMATION_ENVELOPE_CROSSCHECK_PASS',len(rows),time.time()-started,flush=True)

if __name__=='__main__':main()
