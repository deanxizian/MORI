"""Verify stored yaw/pitch coverage, allowances and unchanged native sources."""
from pathlib import Path
import sys,json,time,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from selected_family import sha

def covered(intervals,lo,hi):
    ordered=sorted(intervals)
    assert ordered and ordered[0][0]==lo and ordered[-1][1]==hi
    assert all(a[0]<a[1] for a in ordered)
    assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(ordered[:-1],ordered[1:]))

def main():
    started=time.time();path=HERE/'native_interval_inspection.json';p=json.loads(path.read_text())
    assert p['status']=='PASS' and p['native_parts']==201 and len(p['results'])==12
    assert p['required_gap_mm']==.3 and p['yaw_coverage_deg']==[-60,60] and p['pitch_coverage_deg']==[-20,25]
    assert all(sha(q)==h for q,h in p['sources'].items())
    cells=0;pitch_cells=0;minimum=float('inf');radius=p['pitch_native_radius_mm']
    for result in p['results']:
        assert result['status']=='PASS' and result['accepted_yaw_cells']==len(result['intervals'])
        covered([i['yaw_interval_deg'] for i in result['intervals']],-60,60)
        for interval in result['intervals']:
            cells+=1;rows=interval['rows'];assert interval['status']=='PASS' and not interval['failed_bounds']
            assert set(r['group'] for r in rows)=={'body','yaw','pitch'}
            assert sum(r['group']=='body' for r in rows)==sum(r['group']=='yaw' for r in rows)==1
            pitch=[r for r in rows if r['group']=='pitch'];covered([r['pitch_interval_deg'] for r in pitch],-20,25)
            pitch_cells+=len(pitch)
            for r in rows:
                assert r['gap_lower_mm']>=.3 and r['wire_motion_bound_mm']>=0
                lo,hi=r['pitch_interval_deg']
                expected=2*radius*math.sin(math.radians((hi-lo)/4)) if r['group']=='pitch' else 0.
                assert abs(r['pitch_surface_motion_bound_mm']-expected)<1e-10
                derived=r['reference_nominal_gap_lower_mm']-r['wire_motion_bound_mm']-expected
                assert abs(derived-r['gap_lower_mm'])<1e-10
                if r['nearest_object']=='AABB_EXCLUSION_CAP':assert r['reference_nominal_gap_lower_mm']==p['AABB_fallback_gap_mm']
                minimum=min(minimum,r['gap_lower_mm'])
    assert abs(minimum-p['minimum_certified_native_gap_lower_mm'])<1e-10
    result=dict(status='PASS',scope='Stored continuous yaw/pitch coverage and allowance consistency, not physical assembly',
       sources={str(path):sha(path),str(Path(__file__)):sha(Path(__file__))},
       native_parts=201,wires=12,yaw_cells=cells,pitch_cells=pitch_cells,
       minimum_certified_gap_lower_mm=minimum,full_harness='BLOCKED',main_changed=False,
       hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'native_coverage_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CONTINUOUS_NATIVE_COVERAGE_PASS',cells,'yaw cells',pitch_cells,'pitch cells',minimum,flush=True)

if __name__=='__main__':main()
