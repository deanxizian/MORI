"""Search smooth length-compensation directions, retaining all real geometry.

This is a curvature search only. No native-gap or all-angle qualification is
implied by a passing row. Earlier rejected family is left byte-for-byte intact.
"""
from pathlib import Path
import sys,json,time,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from family import Family,BSpline
from scipy.ndimage import gaussian_filter1d
import numpy as np
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def directions(family, mode, sigma):
    for yaw,items in family.controls.items():
        for name,c in items.items():
            v=family.Q@c;n=v/np.linalg.norm(v,axis=1)[:,None]
            g=family.Q.T@(family.weights[:,None]*n)
            if mode=='lower':g*=np.clip((180.-c[:,2])/15.,0.,1.)[:,None]**2
            if mode=='upper':g*=np.clip((c[:,2]-165.)/15.,0.,1.)[:,None]**2
            if sigma:g=gaussian_filter1d(g,sigma,axis=0,mode='nearest')
            # Smoothly taper at actual fixed endpoint control sets.
            taper=np.ones(len(c));taper[:4]=[0,0,.25,.75];taper[-4:]=[.75,.25,0,0]
            g*=taper[:,None];g[:2]=0;g[-2:]=0
            maximum=float(np.linalg.norm(g,axis=1).max());assert maximum>1e-8
            family.directions[yaw][name]=g/maximum

def main():
    start=time.time();f=Family();ts=np.unique(np.r_[np.linspace(0,1,3001),np.unique(f.knots)])
    d=BSpline(f.knots,np.eye(48),3).derivative()(ts)
    a=BSpline(f.knots,np.eye(48),3).derivative(2)(ts)
    results=[]
    for mode,sigma in [('all',0),('all',1),('all',2),('all',3),('lower',1),('lower',2),('lower',3),('upper',2)]:
        directions(f,mode,sigma);minimum=float('inf');worst=None;amplitude=0.;failed=[]
        for yaw in range(-60,61,5):
            for name in f.names:
                try:item=f.candidate(name,yaw)
                except (AssertionError,RuntimeError) as e:
                    failed.append(dict(wire=name,yaw=yaw,error=str(e)));continue
                c=item['control'];v=d@c;acc=a@c;speed=np.linalg.norm(v,axis=1)
                k=np.linalg.norm(np.cross(v,acc),axis=1)/speed**3;i=int(np.argmax(k));r=float(1/k[i])
                amplitude=max(amplitude,abs(item['amplitude_mm']))
                if r<minimum:minimum=r;worst=dict(wire=name,yaw=yaw,normalized_parameter=float(ts[i]))
                if r<6.865:failed.append(dict(wire=name,yaw=yaw,radius_mm=r))
        result=dict(mode=mode,sigma=sigma,status='PASS' if not failed else 'BLOCKED',minimum_sampled_radius_mm=minimum,
                    worst=worst,maximum_amplitude_mm=amplitude,failures=failed)
        results.append(result)
        print('DIRECTION_SEARCH',mode,sigma,result['status'],minimum,len(failed),flush=True)
    f.unchanged();sources=dict(f.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    (HERE/'direction_search.json').write_text(json.dumps(dict(status='PASS',scope='Execution of numerical curvature direction search only',
       sources=sources,results=results,yaw_positions=25,wire_count=12,curve_samples=len(ts),
       full_harness='BLOCKED',native_clearance='NOT_TESTED',between_yaw_continuity='NOT_TESTED',
       main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
    print('DIRECTION_SEARCH_TERMINAL',time.time()-start,flush=True)

if __name__=='__main__':main()
