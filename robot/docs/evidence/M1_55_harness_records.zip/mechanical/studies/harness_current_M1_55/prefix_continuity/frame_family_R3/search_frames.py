"""Dense curvature/length search of frame interpolation; geometry not inherited."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from frame_family import FrameFamily,BSpline,sha
import numpy as np

def main():
    start=time.time();results=[]
    for z0,z1 in [(150.,175.),(155.,185.),(160.,180.),(165.,190.),(170.,185.)]:
        f=FrameFamily(z0,z1);ts=np.unique(np.r_[np.linspace(0,1,4001),np.unique(f.knots)])
        d=BSpline(f.knots,np.eye(48),3).derivative()(ts);a=BSpline(f.knots,np.eye(48),3).derivative(2)(ts)
        minimum=float('inf');worst=None;failed=[];amp=0.;min_g=float('inf')
        for yaw in np.linspace(-60,60,241):
            for name in f.names:
                try:it=f.candidate(name,float(yaw))
                except (RuntimeError,AssertionError) as e:
                    failed.append(dict(wire=name,yaw_deg=float(yaw),error=str(e)));continue
                c=it['control'];v=d@c;acc=a@c;speed=np.linalg.norm(v,axis=1)
                k=np.linalg.norm(np.cross(v,acc),axis=1)/speed**3;i=int(np.argmax(k));r=float(1/k[i])
                if r<minimum:minimum=r;worst=dict(wire=name,yaw_deg=float(yaw),normalized_parameter=float(ts[i]))
                amp=max(amp,abs(it['amplitude_mm']));min_g=min(min_g,it['length_root_derivative'])
                if r<6.865:failed.append(dict(wire=name,yaw_deg=float(yaw),radius_mm=r,normalized_parameter=float(ts[i])))
        f.unchanged();result=dict(z0_mm=z0,z1_mm=z1,status='PASS' if not failed else 'BLOCKED',
            minimum_sampled_radius_mm=minimum,worst=worst,maximum_amplitude_mm=amp,
            minimum_sampled_root_derivative=min_g,failures=failed)
        results.append(result);print('FRAME_FAMILY_SEARCH',z0,z1,result['status'],minimum,len(failed),flush=True)
    sources=dict(f.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    (HERE/'frame_search.json').write_text(json.dumps(dict(status='PASS',scope='Execution of sampled frame-family curvature search only',
       sources=sources,results=results,yaw_positions=241,wire_count=12,curve_samples=len(ts),
       native_clearance='NOT_TESTED',between_yaw_continuity='NOT_TESTED',
       full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,
       elapsed_s=time.time()-start),ensure_ascii=False,indent=2)+'\n')
    print('FRAME_SEARCH_TERMINAL',time.time()-start,flush=True)

if __name__=='__main__':main()
