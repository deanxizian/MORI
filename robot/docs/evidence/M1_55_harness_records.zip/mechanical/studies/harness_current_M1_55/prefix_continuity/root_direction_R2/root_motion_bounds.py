"""Bound the R2 numerical length-root branch within a yaw interval.

The functional is the explicitly recorded Gauss64 reference length. This does
not equate quadrature to actual supplier cut length. Analytic control bounds,
positive quadratic B-spline velocity bases and monotonic root brackets bound
all yaw values in the interval, with an explicit numerical reserve.
"""
from pathlib import Path
import sys,math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from family_R2 import FamilyR2,BSpline
from family import smooth_d,smooth_dd
import numpy as np

NUMERIC=1e-9

def extrema(function,lo,hi,critical):
    return max(abs(function(u)) for u in [lo,hi]+[u for u in critical if lo<=u<=hi])

class RootBounds:
    def __init__(self,family):
        self.f=family
        self.coefficients=3/(family.knots[4:-1]-family.knots[1:-4])
        self.VB=BSpline(family.knots[1:-1],np.eye(47),2)(family.qnodes)*self.coefficients[None,:]
        assert np.min(self.VB)>-1e-12
        test=family.controls[0][family.names[0]]
        assert np.max(abs(self.VB@np.diff(test,axis=0)-family.Q@test))<1e-9

    def derivatives(self,name,lo,hi):
        mid=(lo+hi)/2;ka,kb,u=self.f.segment(mid)
        assert lo>=ka-1e-9 and hi<=kb+1e-9
        ulo,uhi=(lo-ka)/10,(hi-ka)/10
        sd=extrema(smooth_d,ulo,uhi,[.5])/10
        sdd=extrema(smooth_dd,ulo,uhi,[(3-math.sqrt(3))/6,(3+math.sqrt(3))/6])/100
        ca,cb=self.f.controls[ka][name],self.f.controls[kb][name]
        delta=cb-ca
        C1=sd*np.linalg.norm(delta,axis=1);C2=sdd*np.linalg.norm(delta,axis=1)
        da,db=self.f.directions[ka][name],self.f.directions[kb][name]
        dd=db-da
        D1=sd*np.linalg.norm(dd,axis=1);D2=sdd*np.linalg.norm(dd,axis=1)
        la,lb=self.f.local_ends[ka][name],self.f.local_ends[kb][name]
        dl=lb-la;omega=math.pi/180
        upper_xy=np.maximum(np.linalg.norm(la[:,:2],axis=1),np.linalg.norm(lb[:,:2],axis=1))
        C1[-2:]=sd*np.linalg.norm(dl,axis=1)+omega*upper_xy
        C2[-2:]=sdd*np.linalg.norm(dl,axis=1)+2*omega*sd*np.linalg.norm(dl[:,:2],axis=1)+omega**2*upper_xy
        bC1=np.empty(47);bC2=np.empty(47)
        bC1[:45]=sd*np.linalg.norm(np.diff(delta[:46],axis=0),axis=1)
        bC2[:45]=sdd*np.linalg.norm(np.diff(delta[:46],axis=0),axis=1)
        c,cy,cyy,d,dy,dyy=self.f.base(name,mid)
        # One adjacent velocity control crosses fixed/world and rotating ends.
        bC2[45]=C2[45]+C2[46]
        bC1[45]=np.linalg.norm(cy[46]-cy[45])+bC2[45]*(hi-lo)/2
        ldiffa,ldiffb=la[1]-la[0],lb[1]-lb[0]
        ldelta=ldiffb-ldiffa;maxxy=max(np.linalg.norm(ldiffa[:2]),np.linalg.norm(ldiffb[:2]))
        bC1[46]=sd*np.linalg.norm(ldelta)+omega*maxxy
        bC2[46]=sdd*np.linalg.norm(ldelta)+2*omega*sd*np.linalg.norm(ldelta[:2])+omega**2*maxxy
        bD1=sd*np.linalg.norm(np.diff(dd,axis=0),axis=1)
        bD2=sdd*np.linalg.norm(np.diff(dd,axis=0),axis=1)
        return dict(C1=C1+NUMERIC,C2=C2+NUMERIC,D1=D1+NUMERIC,D2=D2+NUMERIC,
                    bC1=bC1+NUMERIC,bC2=bC2+NUMERIC,bD1=bD1+NUMERIC,bD2=bD2+NUMERIC,
                    maximum_direction_norm=np.maximum(np.linalg.norm(da,axis=1),np.linalg.norm(db,axis=1))+NUMERIC)

    def certificate(self,name,lo,hi):
        mid=(lo+hi)/2;h=(hi-lo)/2;it=self.f.candidate(name,mid);c,cy,cyy,d,dy,dyy=it['base']
        bounds=self.derivatives(name,lo,hi);a0=it['amplitude_mm'];q=self.f.Q;w=self.f.weights
        velocity=q@it['control'];speed=np.linalg.norm(velocity,axis=1);n=velocity/speed[:,None]
        va=q@d;vy=q@(cy+a0*dy);nva=np.linalg.norm(va,axis=1);nvy=np.linalg.norm(vy,axis=1)
        g0=float(w@np.sum(n*va,axis=1));fy0=float(w@np.sum(n*vy,axis=1))
        Gva=self.VB@bounds['bD1']*h
        Gbase=self.VB@(bounds['bC1']+abs(a0)*bounds['bD1'])*h
        Gvy_base=self.VB@(bounds['bC2']+abs(a0)*bounds['bD2'])*h
        Gvy_a=self.VB@bounds['bD1']
        width=max(1e-7,abs(it['amplitude_derivative_mm_per_deg'])*h*1.2+1e-6)
        trace=[]
        for iteration in range(14):
            Gv=Gbase+width*(nva+Gva)
            gmin=g0-float(w@(2*Gv/speed*nva+Gva))-NUMERIC
            speedmin=float(np.min(speed-Gv))-NUMERIC
            max_partial=abs(fy0)+float(w@(2*Gv/speed*nvy+Gvy_base+width*Gvy_a))+NUMERIC
            demand=(max_partial*h+abs(it['reference_length_residual_mm'])+NUMERIC)/gmin if gmin>0 else float('inf')
            trace.append(dict(width_mm=width,required_width_mm=demand,root_derivative_lower=gmin,speed_lower=speedmin))
            if gmin>0 and speedmin>0 and demand<=width:
                displacement=bounds['C1']*h+abs(a0)*bounds['D1']*h+width*bounds['maximum_direction_norm']+NUMERIC
                return dict(status='PASS',wire=name,yaw_interval_deg=[lo,hi],midpoint_yaw_deg=mid,
                    midpoint_amplitude_mm=a0,amplitude_deviation_bound_mm=width,
                    root_derivative_lower=gmin,speed_lower=speedmin,
                    midpoint_length_residual_mm=it['reference_length_residual_mm'],
                    maximum_control_displacement_bound_mm=float(np.max(displacement)),
                    control_displacement_bound_mm=displacement.tolist(),trace=trace)
            if not np.isfinite(demand) or demand>1.:break
            width=max(width*1.1,demand*1.15)
        return dict(status='BLOCKED',wire=name,yaw_interval_deg=[lo,hi],trace=trace)
