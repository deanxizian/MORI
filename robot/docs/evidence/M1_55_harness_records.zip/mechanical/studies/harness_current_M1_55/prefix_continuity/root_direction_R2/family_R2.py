"""Smooth reference-length compensation; unadopted capacity family only."""
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from family import Family,BSpline,quadrature,sha
from search_directions import directions

class FamilyR2(Family):
    def __init__(self):
        super().__init__()
        path=HERE/'direction_search.json';report=json.loads(path.read_text())
        assert report['status']=='PASS' and all(sha(p)==h for p,h in report['sources'].items())
        result=next(r for r in report['results'] if r['mode']=='all' and r['sigma']==2)
        assert result['status']=='PASS'
        directions(self,'all',2)
        for p in [Path(__file__),HERE/'search_directions.py',path]:self.sources[str(p)]=sha(p)
