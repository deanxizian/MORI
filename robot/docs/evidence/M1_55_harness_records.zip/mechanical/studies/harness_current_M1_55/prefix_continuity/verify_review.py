"""Check publication integrity, local links and unchanged engineering sources."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess
from urllib.parse import urlsplit, unquote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
MECHANICAL = HERE.parents[2]
PROJECT = MECHANICAL.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
delivery = read(HERE/'delivery.json')
assert delivery['status']=='PASS' and delivery['full_harness']=='BLOCKED'
assert sha(MECHANICAL/'mori_v1_2.blend')==delivery['source_blend_sha256']
assert all((HERE/n).is_file() and sha(HERE/n)==h for n,h in delivery['files'].items())
for name in ['pitch_continuous_inspection.json','family_sample_inspection.json',
             'family_geometry_screen.json','failure_witnesses.json','remaining_work.json']:
    report=read(HERE/name)
    assert all(sha(p)==h for p,h in report['sources'].items())
latest=read(HERE/'frame_family_R3/delivery.json')
assert latest['status']=='PASS' and latest['full_harness']=='BLOCKED'
assert delivery['frame_R3_delivery_sha256']==sha(HERE/'frame_family_R3/delivery.json')
assert all(sha(HERE/'frame_family_R3'/p)==h for p,h in latest['files'].items())
latest_verified=read(HERE/'frame_family_R3/publication_verification.json')
assert latest_verified['status']=='PASS' and latest_verified['delivery_sha256']==sha(HERE/'frame_family_R3/delivery.json')
baseline=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in baseline['protected_hardware'].items()
           if '__pycache__' not in n and Path(n).name!='.DS_Store'}
assert all((PROJECT/n).is_file() and sha(PROJECT/n)==h for n,h in protected.items())
links=[]
for link in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(link)
    if parsed.scheme or not parsed.path: continue
    target=(HERE/unquote(parsed.path)).resolve()
    assert target.is_file() and target.is_relative_to(PROJECT),(link,target)
    with urlopen(Request('http://127.0.0.1:58202/'+str(target.relative_to(PROJECT)),method='HEAD'),timeout=10) as response:
        assert response.status==200
    links.append(str(target.relative_to(PROJECT)))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
result=dict(status='PASS',scope='Publication integrity and source preservation only; not geometry or physical qualification',
            recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            source_blend_sha256=delivery['source_blend_sha256'],delivery_sha256=sha(HERE/'delivery.json'),
            checked_files=len(delivery['files']),checked_local_links=links,HTTP_HEAD='PASS',
            protected_hardware_files=len(protected),protected_hardware_unchanged=True,
            Git_HEAD=head,main_changed=False,hardware_changed=False,new_commit_or_push=False,
            full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('PREFIX_CONTINUITY_PUBLICATION_VERIFIED',len(delivery['files']),'files',len(links),'links',len(protected),'protected hardware sources',flush=True)
