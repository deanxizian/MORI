"""Keep the first body bend translated; distribute deformation downstream.

Unadopted finite preflight after the short-local fade failed. Full service
motion, hardware, peers, grip and real wire/crimp remain separate checks.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from prepare_service_family import ServiceFamily, HERE, PARENT, sha, read, BSpline, smooth, continuous_radius


class HeldBendFamily(ServiceFamily):
    def __init__(self, hold, fade_end):
        super().__init__(fade_end)
        assert 0 <= hold < fade_end <= 1
        self.hold, self.fade_end = hold, fade_end
        greville = np.array([self.f.knots[i+1:i+4].mean() for i in range(len(self.base[self.names[0]]))])
        w = 1-smooth(np.clip((greville-hold)/(fade_end-hold),0.,1.))
        w[:2] = 1.
        w[-2:] = 0.
        self.displacement = np.c_[np.zeros((len(w),2)),w]


def main():
    started = time.time()
    prior_path = HERE/'service_family_screen.json'
    prior = read(prior_path)
    assert prior['status'] == 'BLOCKED' and all(sha(p)==h for p,h in prior['sources'].items())
    maximum = prior['maximum_lift_mm']
    rows = []
    for hold, end in [(.10,.40),(.10,.60),(.15,.40),(.15,.60),(.15,.80)]:
        family = HeldBendFamily(hold,end)
        cases = []
        arrays = dict(knots=family.f.knots,displacement_controls=family.displacement)
        for name in family.names:
            arrays[name+'__base_controls'] = family.base[name]
            arrays[name+'__direction_controls'] = family.directions[name]
            for lift in [0.,maximum/2,maximum]:
                try:
                    it = family.candidate(name,lift)
                except RuntimeError as error:
                    cases.append(dict(wire=name,lift_mm=lift,status='BLOCKED',root_error=str(error)))
                    continue
                bend,_ = continuous_radius(BSpline(family.f.knots,it['control'],3))
                cases.append(dict(wire=name,lift_mm=lift,status=bend['status'],
                    amplitude_mm=it['amplitude_mm'],numeric_length_residual_mm=it['residual_mm'],
                    root_slope=it['root_slope'],continuous_curve_bend=bend))
                arrays[name+f'__lift_{lift:.9f}__controls'] = it['control']
        family.f.unchanged()
        row = dict(hold_parameter=hold,fade_end_parameter=end,
            status='PASS' if all(c['status']=='PASS' for c in cases) else 'BLOCKED',cases=cases,
            untested_between_lift_samples=True)
        rows.append(row)
        np.savez_compressed(HERE/f'held_bend_{hold:.2f}_{end:.2f}.npz',**arrays)
        print('PHR4_HELD_BEND',hold,end,row['status'],
            [c['wire'] for c in cases if c['status']!='PASS'],flush=True)
    sources = {**prior['sources'],**family.f.sources,**{str(p):sha(p) for p in [Path(__file__),prior_path]}}
    assert all(sha(p)==h for p,h in sources.items())
    report = dict(status='PASS' if any(r['status']=='PASS' for r in rows) else 'BLOCKED',
        scope='Three nominal lift positions only; continuous curve bend, not continuous lift/native/peer proof',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        maximum_lift_mm=maximum,rows=rows,continuous_lift='NOT_TESTED',native_clearance='NOT_TESTED',
        peer_clearance='NOT_TESTED',actual_mating='BLOCKED',full_wired_assembly='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/'held_bend_screen.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PHR4_HELD_BEND_TERMINAL',report['status'],len(rows),round(report['elapsed_s'],2),flush=True)


if __name__ == '__main__':
    main()
