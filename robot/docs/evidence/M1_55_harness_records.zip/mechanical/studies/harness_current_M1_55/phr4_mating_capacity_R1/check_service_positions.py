"""Current-native and mutual clearance at three body-plug lift positions.

These are finite capacity screens with the head at zero. A PASS here is not
continuous service motion, actual materials, grip, mating or wired assembly.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from screen_held_bend import HeldBendFamily
from prepare_service_family import sha,read,BSpline,PARENT,continuous_radius
sys.path[:0]=[str(PARENT/'upper_smooth_review_R2'),str(PARENT/'upper_length_match_R1'),str(PARENT)]
from piecewise_geometry import pieces
from sample_geometry import sample
from context import clear,manifold,BVHTree,prepared
from bounded_curve_checks import pair_threshold
from curve_self_partition import self_clear
from scipy.spatial import cKDTree
PROJECT=HERE.parents[3]


def own_join(lower,upper,lr,ur):
    # A local material neighbourhood at the exact seam is excluded, with
    # arc UPPER bounds so uncertain near-5mm spans are tested conservatively.
    p,q=lower['points'],upper['points']
    separation_lower_end=lower['arc_upper'][-1]-lower['arc_upper']
    separation_upper_start=upper['arc_upper']
    threshold=lr+ur+.3+.03+lower['error']+upper['error']+.0001
    tree=cKDTree(q)
    for i,near in enumerate(tree.query_ball_point(p,threshold)):
        ids=np.array(near,dtype=int)
        if not len(ids):continue
        remote=separation_lower_end[i]+separation_upper_start[ids]>5.
        if not remote.any():continue
        ids=ids[remote]
        distances=np.linalg.norm(q[ids]-p[i],axis=1)
        j=int(np.argmin(distances))
        if distances[j]<threshold:
            return dict(status='BLOCKED',point_a_mm=p[i].tolist(),point_b_mm=q[ids[j]].tolist(),
                centreline_sample_distance_mm=float(distances[j]),gap_lower_bound_mm=float(distances[j]-threshold+.3),
                method='Both chord/half-step allowances; only certified local arc-upper neighbourhood excluded')
    return dict(status='PASS',gap_lower_bound_mm=.3,local_join_arc_upper_exclusion_mm=5.,
        method='All nearby sampled pairs; actual-cubic arc upper sums for local-neighbour exclusion')


def main():
    started=time.time()
    pre_path=HERE/'held_bend_screen.json';pre=read(pre_path)
    assert pre['status']=='PASS' and all(sha(p)==h for p,h in pre['sources'].items())
    current=PARENT/'terminal_install_review_R1'
    receipt_path=current/'current_native_receipt.json';native_path=current/'current_native_parts.npz'
    receipt=read(receipt_path);native=np.load(native_path)
    assert receipt['native_part_count']==201 and sha(native_path)==receipt['output_sha256']
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    targets={}
    for row in receipt['native_parts']:
        n=row['id'];v=native[n+'__vertices_mm'];f=native[n+'__triangles']
        m=manifold.Manifold(manifold.Mesh64(v,f.astype(np.uint64)))
        assert m.status()==manifold.Error.NoError
        targets[n]=dict(m=m,lo=v.min(0),hi=v.max(0),tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True))
    bundle_path=PARENT/'moving_bundle_entry_review_R1/bundle_receipt.json'
    bundle=read(bundle_path);array_path=bundle_path.parent/'bundle_zero.npz';arrays=np.load(array_path)
    assert bundle['status']=='PASS' and sha(array_path)==bundle['arrays_sha256']
    assert all(sha(p)==h for p,h in bundle['sources'].items())
    fixed={};own={}
    names=[f'CAM_{i}' for i in range(1,5)]
    for row in bundle['rows']:
        key=row['key'];wire=row['wire']
        if row['role']=='prefix' and wire in names:continue
        sampled=sample(arrays[key+'__controls_mm'],max_step=.03)
        assert np.max(abs(sampled['points']-arrays[key+'__points_mm']))<1e-10
        item=dict(row=row,sampled=sampled,pack=prepared(sampled['points'],row['radius_capacity_mm'],sampled['error']))
        fixed[key]=item
        if row['role']=='upper' and wire in names:own[wire]=item
    assert len(fixed)==15 and len(own)==4
    results=[];out={}
    for variant in pre['rows']:
        if variant['status']!='PASS':continue
        hold,end=variant['hold_parameter'],variant['fade_end_parameter']
        family=HeldBendFamily(hold,end);cases=[]
        for lift in [0.,pre['maximum_lift_mm']/2,pre['maximum_lift_mm']]:
            moving={};wire_rows=[];pairs=[]
            for name in names:
                it=family.candidate(name,lift);spl=BSpline(family.f.knots,it['control'],3)
                bend,cubics=continuous_radius(spl)
                geometry=sample(cubics,max_step=.03)
                pack=prepared(geometry['points'],family.f.radii[name],geometry['error'])
                hits,near=clear(geometry['points'],pack['radius'],targets,error=geometry['error'],gap=.3)
                remote=self_clear(pack)
                joined=own_join(geometry,own[name]['sampled'],pack['radius'],own[name]['pack']['radius'])
                moving[name]=dict(pack=pack,geometry=geometry)
                wire_rows.append(dict(wire=name,status='PASS' if not hits and bend['status']==remote['status']==joined['status']=='PASS' else 'BLOCKED',
                    continuous_curve_bend=bend,native_hits=hits,nearest_native=near,remote_self=remote,own_upper_join=joined,
                    numeric_length_residual_mm=it['residual_mm'],root_amplitude_mm=it['amplitude_mm']))
                out[f'h{hold:.2f}_e{end:.2f}_z{lift:.9f}_{name}__controls']=cubics
                out[f'h{hold:.2f}_e{end:.2f}_z{lift:.9f}_{name}__points']=geometry['points']
            for a,b in itertools.combinations(names,2):
                result=pair_threshold(moving[a]['pack'],moving[b]['pack'])
                pairs.append(dict(a=a+'__prefix',b=b+'__prefix',**result))
            for name in names:
                for key,item in fixed.items():
                    if key==name+'__upper':continue
                    result=pair_threshold(moving[name]['pack'],item['pack'])
                    pairs.append(dict(a=name+'__prefix',b=key,**result))
            assert len(pairs)==62
            case=dict(lift_mm=lift,status='PASS' if all(r['status']=='PASS' for r in wire_rows+pairs) else 'BLOCKED',
                      wire_rows=wire_rows,mutual_pairs=pairs,unchanged_upper_sections=7,other_prefix_sections=8,
                      native_current_parts=201,head_pose_deg=[0,0])
            cases.append(case)
            print('PHR4_SERVICE_POSITION',hold,end,lift,case['status'],
                'native',sum(bool(r['native_hits']) for r in wire_rows),'peers',sum(r['status']!='PASS' for r in pairs),flush=True)
            if case['status']!='PASS':break
        family.f.unchanged()
        results.append(dict(hold_parameter=hold,fade_end_parameter=end,
            status='PASS' if len(cases)==3 and all(c['status']=='PASS' for c in cases) else 'BLOCKED',cases=cases))
    target=HERE/'service_position_arrays.npz';np.savez_compressed(target,**out)
    sources={**pre['sources'],**receipt['sources'],**bundle['sources'],**{str(p):sha(p) for p in [
        Path(__file__),HERE/'screen_held_bend.py',pre_path,receipt_path,native_path,bundle_path,array_path,
        PARENT/'context.py',PARENT/'upper_length_match_R1/sample_geometry.py',
        PARENT/'upper_smooth_review_R1/smooth_geometry.py',
        Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49/curve_clearance.py'),
        Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49/bounded_curve_checks.py'),
        Path('/Users/dean/Documents/MORI/mechanical/studies/prearrival_finish/head_harness_M1_49/curve_self_partition.py')]}}
    assert all(sha(p)==h for p,h in sources.items())
    report=dict(status='PASS' if any(r['status']=='PASS' for r in results) else 'BLOCKED',
        scope='Three lift positions at zero head pose, all201 native and62 mutual pairs plus4 own joins/self checks; no continuous service or real harness qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,rows=results,
        arrays_sha256=sha(target),lift_positions_mm=[0.,pre['maximum_lift_mm']/2,pre['maximum_lift_mm']],
        continuous_lift='NOT_TESTED',actual_mating='BLOCKED',actual_materials_and_terminals='BLOCKED',
        grip_and_restraints='NOT_TESTED',full_wired_assembly='BLOCKED',main_changed=False,animation_changed=False,
        hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'service_positions.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PHR4_SERVICE_POSITIONS_TERMINAL',report['status'],len(results),round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
