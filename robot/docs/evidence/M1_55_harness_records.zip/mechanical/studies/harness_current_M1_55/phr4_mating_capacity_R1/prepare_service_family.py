"""Screen unchanged-length CAM prefixes while the body plug is lifted.

Only a zero-head-pose outside-capacity insertion candidate. The four body
starts move with the assumed plug; all Z200 cut ends and upper references
stay fixed. It does not select a wire, cut length, crimp, restraint or grip.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path[:0] = [str(PARENT/'prefix_continuity/frame_family_R3'),
               str(PARENT/'global_bundle_layout')]
from selected_family import SelectedFamily, BSpline
from family import smooth
from scipy.optimize import brentq
from inspect_candidate import continuous_radius

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


class ServiceFamily:
    def __init__(self, span):
        self.f = SelectedFamily()
        self.span = span
        self.names = [f'CAM_{i}' for i in range(1, 5)]
        self.base = {n:self.f.candidate(n, 0)['control'] for n in self.names}
        self.directions = {n:self.f.base(n, 0)[3] for n in self.names}
        self.targets = {n:float(self.f.weights@np.linalg.norm(self.f.Q@self.base[n], axis=1)) for n in self.names}
        greville = np.array([self.f.knots[i+1:i+4].mean() for i in range(len(self.base[self.names[0]]))])
        w = 1-smooth(np.clip(greville/span, 0., 1.))
        w[:2] = 1.
        w[-2:] = 0.
        self.displacement = np.c_[np.zeros((len(w), 2)), w]
        assert np.max(abs(self.displacement[-2:])) == 0
        assert all(np.max(abs(d[:2])) == np.max(abs(d[-2:])) == 0 for d in self.directions.values())

    def candidate(self, name, lift):
        base = self.base[name] + lift*self.displacement
        direction = self.directions[name]
        v, dv = self.f.Q@base, self.f.Q@direction
        value = lambda a:float(self.f.weights@np.linalg.norm(v+a*dv, axis=1))-self.targets[name]
        width = .001
        while width <= 2.:
            if value(-width) <= 0 <= value(width):
                break
            width *= 2
        else:
            raise RuntimeError(('No root in source-style local2mm compensation range', name, lift, value(0)))
        amplitude = float(brentq(value, -width, width, xtol=1e-12, rtol=1e-14))
        c = base + amplitude*direction
        expected_start = self.base[name][0] + np.array([0., 0., lift])
        assert np.max(abs(c[0]-expected_start)) < 1e-12
        assert np.max(abs(c[-2:]-self.base[name][-2:])) == 0
        assert np.max(abs((c[1]-c[0])-(self.base[name][1]-self.base[name][0]))) < 1e-12
        speed = v+amplitude*dv
        slope = float(self.f.weights@np.sum(speed/np.linalg.norm(speed, axis=1)[:, None]*dv, axis=1))
        assert slope > 1e-6
        return dict(control=c, amplitude_mm=amplitude, residual_mm=value(amplitude), root_slope=slope)


def main():
    started = time.time()
    housing_path = HERE/'housing_capacity.json'
    housing = read(housing_path)
    assert housing['status'] == 'PASS' and all(sha(p)==h for p,h in housing['sources'].items())
    maximum = housing['release_lift_mm']
    rows = []
    for span in [.08, .12, .16, .20, .24, .28, .32]:
        family = ServiceFamily(span)
        cases = []
        arrays = dict(knots=family.f.knots, displacement_controls=family.displacement)
        for name in family.names:
            arrays[name+'__base_controls'] = family.base[name]
            arrays[name+'__direction_controls'] = family.directions[name]
            for lift in [0., maximum/2, maximum]:
                try:
                    it = family.candidate(name, lift)
                except RuntimeError as error:
                    cases.append(dict(wire=name,lift_mm=lift,status='BLOCKED',root_error=str(error)))
                    continue
                bend, _ = continuous_radius(BSpline(family.f.knots, it['control'], 3))
                cases.append(dict(wire=name,lift_mm=lift,status=bend['status'],
                    amplitude_mm=it['amplitude_mm'],numeric_length_residual_mm=it['residual_mm'],
                    root_slope=it['root_slope'],continuous_curve_bend=bend,
                    endpoint_scope='Moved four body starts only; incoming tangents and Z200 end/tangent unchanged'))
                arrays[name+f'__lift_{lift:.9f}__controls'] = it['control']
        family.f.unchanged()
        row = dict(span_parameter=span,status='PASS' if all(c['status']=='PASS' for c in cases) else 'BLOCKED',cases=cases,
                   untested_between_lift_samples=True)
        rows.append(row)
        np.savez_compressed(HERE/f'service_span_{span:.2f}.npz', **arrays)
        print('PHR4_SERVICE_BEND_SCREEN',span,row['status'],
              [c['wire'] for c in cases if c['status']!='PASS'],flush=True)
    sources = {**housing['sources'],**family.f.sources, **{str(p):sha(p) for p in [
        Path(__file__),housing_path,PARENT/'global_bundle_layout/inspect_candidate.py',PARENT/'global_bundle_layout/solve.py']}}
    assert all(sha(p)==h for p,h in sources.items())
    report = dict(status='PASS' if any(r['status']=='PASS' for r in rows) else 'BLOCKED',
        scope='Finite three-lift preflight and continuous curve-radius checks only; not continuous lift or native/peer clearance',
        sources=sources,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        maximum_lift_mm=maximum,rows=rows,
        numeric_prefix_length_targets_mm=family.targets,numeric_lengths_are_not_supplier_cuts=True,
        candidate_parameters='Local deformation span; no purchased hardware changed',
        continuous_lift='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        actual_mating='BLOCKED',full_wired_assembly='BLOCKED',main_changed=False,animation_changed=False,
        hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'service_family_screen.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PHR4_SERVICE_PREPARATION',report['status'],len(rows),round(report['elapsed_s'],2),flush=True)


if __name__ == '__main__':
    main()
