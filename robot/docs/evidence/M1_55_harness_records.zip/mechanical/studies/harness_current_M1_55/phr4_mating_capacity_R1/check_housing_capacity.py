"""Conditional PHR-4 outside-box capacity at unchanged motion J5.

The catalogue supplies three outside dimensions, not the interior, actual
wire exits, insertion depth, grip or tolerance. A documented-size box uses
an ASSUMED datum tied to the existing four reference starts. It is only a
capacity probe and never a complete connector or a mating qualification.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
PROJECT = HERE.parents[3]
sys.path.insert(0, str(PROJECT / 'mechanical/scripts/vendor'))
import manifold3d as manifold

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def solid(v, f):
    m = manifold.Manifold(manifold.Mesh64(v, np.asarray(f, np.uint64)))
    assert m.status() == manifold.Error.NoError
    return m


def box(lo, hi):
    return manifold.Manifold.cube((hi-lo).tolist()).translate(lo.tolist())


def minimum_pitch_z(v, center, low=-20., high=25.):
    """Minimum of each vertex's z under Rx; yaw does not affect z."""
    a = v[:, 1] - center[1]
    b = v[:, 2] - center[2]
    lo, hi = math.radians(low), math.radians(high)
    values = [center[2] + a*math.sin(p) + b*math.cos(p) for p in [lo, hi]]
    critical = np.arctan2(a, b)
    for k in range(-2, 3):
        theta = critical + k*math.pi
        valid = (theta >= lo) & (theta <= hi)
        values.append(np.where(valid, center[2]+a*np.sin(theta)+b*np.cos(theta), np.inf))
    return float(np.min(values))


def main():
    started = time.time()
    current = PARENT / 'terminal_install_review_R1'
    receipt_path = current / 'current_native_receipt.json'
    arrays_path = current / 'current_native_parts.npz'
    receipt = read(receipt_path)
    assert receipt['status'] == 'PASS' and receipt['native_part_count'] == 201
    assert sha(arrays_path) == receipt['output_sha256']
    assert all(sha(p) == h for p, h in receipt['sources'].items())
    native = np.load(arrays_path)
    facts_path = PARENT / 'phr4_source_review_R1/source_facts.json'
    audit_path = PARENT / 'phr4_source_review_R1/source_verification.json'
    facts, audit = read(facts_path), read(audit_path)
    assert facts['status'] == audit['status'] == 'PASS' and not facts['CAD_data_received']
    assert all(sha(p) == h for p, h in audit['sources'].items())
    config_path = PROJECT / 'config/geometry.json'
    config = read(config_path)
    bs = config['native_electronics']['boards']['motion']
    assert bs['object'] == 'MCU_Carrier' and bs['rotation_xyz_deg'] == [0, 0, 0]
    mesh_path = PROJECT / bs['mesh']
    cache = read(mesh_path)
    pcb = next(c for c in cache['components'] if c['reference'] == 'PCB')
    bounds = np.asarray(pcb['bounds_xyz_mm'])
    translation = np.array([*bs['board_center_xy_mm'], bs['substrate_reference_z_mm']])
    translation -= np.array([bounds[0].mean(), bounds[1].mean(), 0.])
    assert sha(PROJECT/cache['source_native_file']) == cache['source_native_sha256']

    # Replay exactly native_electronics.aggregate/solid_from for motion.
    # Only its one J5 component is separated. All other components and PCB
    # stay in the check; invalid source solids retain the recorded AABB fallback.
    components = {}
    fallbacks = []
    component_rows = []
    for c in cache['components']:
        items = []
        for index, s in enumerate(c['solids']):
            v = np.asarray(s['vertices_mm'], float) + translation
            f = np.asarray(s['triangles'], np.uint64)
            m = manifold.Manifold(manifold.Mesh64(v, f))
            if m.status() != manifold.Error.NoError:
                fallbacks.append(dict(component=f"MCU_Carrier/{c['reference']}/{index}",
                                      error=str(m.status()), method='Existing conservative per-solid AABB'))
                m = box(v.min(0)-.001, v.max(0)+.001)
            items.append(m)
        components[c['reference']] = manifold.Manifold.batch_boolean(items, manifold.OpType.Add)
        assert components[c['reference']].status() == manifold.Error.NoError
        component_rows.append(dict(reference=c['reference'], value=c.get('value'),
                                   bounds_xyz_mm=list(components[c['reference']].bounding_box())))
    reconstructed = manifold.Manifold.batch_boolean(list(components.values()), manifold.OpType.Add)
    carrier = solid(native['MCU_Carrier__vertices_mm'], native['MCU_Carrier__triangles'])
    discrepancy = float((reconstructed-carrier).volume()+(carrier-reconstructed).volume())
    assert discrepancy < 1e-8, discrepancy
    assert len(components) == 49 and 'J5' in components and 'PCB' in components
    (HERE/'motion_component_receipt.json').write_text(json.dumps(dict(
        status='PASS', source=str(mesh_path), source_sha256=sha(mesh_path),
        translation_mm=translation.tolist(), component_count=len(components),
        union_symmetric_difference_mm3=discrepancy, fallbacks=fallbacks,
        components=component_rows), indent=2)+'\n')

    fields = facts['documented_fields']
    size = np.array([fields['housing_width_B_mm'], fields['housing_depth_mm'], fields['housing_height_mm']])
    starts = np.array(list(facts['current_model_reference_only']['CAM_body_reference_starts_mm'].values()))
    assert starts.shape == (4, 3) and np.max(abs(starts[:, 1:]-starts[0, 1:])) == 0
    top = float(starts[0, 2])
    center_xy = starts[:, :2].mean(0)
    lo = np.r_[center_xy-size[:2]/2, top-size[2]]
    hi = np.r_[center_xy+size[:2]/2, top]
    header_bounds = np.array(components['J5'].bounding_box())
    lift = float(header_bounds[5]-lo[2]+.3001)
    assert lift > 0
    swept_hi = hi + np.array([0., 0., lift])
    envelope = box(lo, swept_hi)
    at_seat = box(lo, hi)
    released = box(lo+np.array([0., 0., lift]), swept_hi)

    # Body shells are fitted later. They are also recorded as separate closed-
    # state diagnostics rather than silently removed from the current inventory.
    deferred = ['Body_Front', 'Body_Rear']
    height = config['ground_clearance_mm']+config['body_diameter_mm']-config['body_top_cut_depth_mm']
    center = np.array([0., 0., height+config['head_diameter_mm']/2-config['head_embedding_depth_mm']])
    rows = []
    for item in receipt['native_parts']:
        n, group = item['id'], item['group']
        if n in deferred or n == 'MCU_Carrier':
            continue
        v, f = native[n+'__vertices_mm'], native[n+'__triangles']
        if group in ['yaw', 'pitch']:
            minimum = minimum_pitch_z(v, center) if group == 'pitch' else float(v[:, 2].min())
            gap = minimum-swept_hi[2]-.0001
            rows.append(dict(object=n, group=group, status='PASS' if gap >= .3 else 'BLOCKED',
                             gap_lower_bound_mm=float(gap), certificate='Entire native triangle/vertex Z separation for all nominal yaw/pitch',
                             minimum_native_Z_mm=minimum))
        else:
            m = solid(v, f)
            gap = float(envelope.min_gap(m, 5.))
            overlap = float((envelope ^ m).volume())
            rows.append(dict(object=n, group=group, status='PASS' if gap >= .3001 and overlap < 1e-10 else 'BLOCKED',
                             gap_lower_bound_mm=gap-.0001, overlap_mm3=overlap,
                             certificate='Whole translation swept rectangular prism versus exact current native solid'))
    for n, m in components.items():
        if n == 'J5':
            continue
        gap = float(envelope.min_gap(m, 5.))
        overlap = float((envelope ^ m).volume())
        rows.append(dict(object='MCU_Carrier/'+n, group='body', status='PASS' if gap >= .3001 and overlap < 1e-10 else 'BLOCKED',
                         gap_lower_bound_mm=gap-.0001, overlap_mm3=overlap,
                         certificate='Unchanged raw component solid; verified exact union with current carrier'))
    door_rows = []
    for n in deferred:
        m = solid(native[n+'__vertices_mm'], native[n+'__triangles'])
        door_rows.append(dict(object=n, gap_mm=float(envelope.min_gap(m, 5.)), overlap_mm3=float((envelope^m).volume()),
                              scope='Closed body state only; not installed during this mating-space probe'))
    raw_mating_overlap = float((at_seat ^ components['J5']).volume())
    release_gap = float(released.min_gap(components['J5'], 5.))
    assert release_gap >= .3001-1e-10
    sources = {**receipt['sources'], **audit['sources'], **{str(p):sha(p) for p in [
        Path(__file__), receipt_path, arrays_path, facts_path, audit_path, config_path, mesh_path,
        PROJECT/'mechanical/scripts/native_electronics.py', PROJECT/'mechanical/scripts/common.py']}}
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT/p) == h for p,h in protected.items())
    assert all(sha(p) == h for p,h in sources.items())
    report = dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        scope='ASSUMED external-box position and translation capacity only; exact mating/grip/wired assembly BLOCKED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=sources,
        source_native_count=201, native_carrier_component_count=49, exact_carrier_union_difference_mm3=discrepancy,
        box_dimensions_mm=size.tolist(), box_dimension_evidence='VENDOR_DOCUMENTED catalogue fields only',
        box_shape_and_datum_evidence='PLACEHOLDER / ASSUMED outer capacity box, tied to unchanged four reference starts',
        box_lo_mm=lo.tolist(), box_hi_mm=hi.tolist(), release_lift_mm=lift,
        release_basis='Source header top minus assumed box bottom plus0.3001mm planning clearance; not an actual insertion stroke',
        swept_box_hi_mm=swept_hi.tolist(), unchanged_reference_starts_mm=starts.tolist(),
        nominal_motion_ranges_deg=dict(yaw=[-60,60],pitch=[-20,25]), nominal_pitch_center_mm=center.tolist(),
        checked_rows=rows, deferred_body_shells=deferred, closed_shell_diagnostics=door_rows,
        source_header_seated_box_overlap_mm3=raw_mating_overlap,
        header_release_box_gap_mm=release_gap, actual_connector_mating='BLOCKED: missing inner cavity, insertion and exit datums',
        actual_wire_grip='BLOCKED', actual_wire_and_crimp='BLOCKED', full_wired_assembly='BLOCKED',
        main_changed=False, animation_changed=False, hardware_changed=False, manufacturing_release=False,
        protected_hardware_files=846, elapsed_s=time.time()-started)
    (HERE/'housing_capacity.json').write_text(json.dumps(report, indent=2)+'\n')
    print('PHR4_OUTER_CAPACITY', report['status'], len(rows), 'lift', lift,
          'failures', [r['object'] for r in rows if r['status']!='PASS'], flush=True)


if __name__ == '__main__':
    main()
