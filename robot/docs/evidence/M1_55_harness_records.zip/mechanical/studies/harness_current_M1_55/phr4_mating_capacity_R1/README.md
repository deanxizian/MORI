# M1.55 PHR-4 external capacity and wired service probes

Unadopted PLACEHOLDER / ASSUMED capacity box using three public catalogue
dimensions only. Actual inner cavity, mating/wire-exit datums, crimp, grip,
tolerance and chosen wire are missing. MotionJ5 and all original references
remain fixed. Assumed box release travel5.150100610mm is NOT insertion depth.
External swept-box clearance246 rows PASS; head Z separation covers nominal
yaw/pitch. Two body shells are separate closed-state diagnostics. The49 native
motion components reproduce current carrier union exactly; only J5 internal
mating is unresolved, all48 other components/substrate remain checked.

Seven short-local fade variants failed geometric bend capacity. Five first-
bend held variants passed whole-curve bending at three finite lift positions.
All five subsequently fail current-native clearance at the midpoint lift.
Native service checks cover zero/midpoint only (40 curves), all201 current
parts,620 mutual pairs,40 own/self joins. Later maximum lift not executed.
Twenty independently reconstructed sample witnesses:18 true capacity-sphere
intersections and2 planning0.3mm clearance violations, all fixedYaw_Base.
The section uses actual current-native Manifold geometry and a witness sphere.

No actual complete mating, physical material or full wired assembly release.
No main, animation or hardware edit, no supplier contact/order or Git delivery.
Four full-harness work groups remain. Speaker150mm case-to-plug measurement
is unchanged; user will provide plug dimensions after reaching the office.
