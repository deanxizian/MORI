"""Publish the outside-box PASS and failed wired service probes separately."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote,unquote,urlsplit
import datetime
import hashlib
import json
import sys
import urllib.request

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):self.links.extend(v for k,v in attrs if k in ['href','src'])


def main():
    cap=read(HERE/'housing_capacity.json')
    short=read(HERE/'service_family_screen.json')
    held=read(HERE/'held_bend_screen.json')
    positions=read(HERE/'service_positions.json')
    audit=read(HERE/'service_witness_verification.json')
    section=read(HERE/'section_receipt.json')
    assert cap['status']==held['status']==audit['status']==section['status']=='PASS'
    assert short['status']==positions['status']=='BLOCKED'
    assert len(cap['checked_rows'])==246 and len(short['rows'])==7 and len(held['rows'])==5
    assert audit['capacity_intersection_witnesses']==18 and audit['clearance_only_witnesses']==2
    cases=[c for r in positions['rows'] for c in r['cases']]
    assert len(cases)==10 and sum(len(c['wire_rows']) for c in cases)==40
    assert sum(len(c['mutual_pairs']) for c in cases)==620
    assert sha(HERE/'service_collision_section.svg')==section['image_sha256']
    sources={}
    for r in [cap,short,held,positions,audit,section]:
        assert all(sha(p)==h for p,h in r['sources'].items())
        for p,h in r['sources'].items():
            assert p not in sources or sources[p]==h
            sources[p]=h
    for p in [Path(__file__),*[HERE/n for n in ['housing_capacity.json','service_family_screen.json',
        'held_bend_screen.json','service_positions.json','service_witness_verification.json','section_receipt.json']]]:
        sources[str(p)]=sha(p)
    py='/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
    blender='/Applications/Blender.app/Contents/MacOS/Blender'
    commands=[]
    for script in ['check_housing_capacity','prepare_service_family','screen_held_bend',
                   'check_service_positions','verify_service_witnesses','draw_witness']:
        command=[py,str(HERE/(script+'.py'))]
        if script in ['prepare_service_family','screen_held_bend','check_service_positions']:
            command=[blender,'-b','--factory-startup','--python-exit-code','1','--python',str(HERE/(script+'.py'))]
        commands.append(dict(command=command,log=script+'.log',exit_code=0))
    logs=[(HERE/c['log']).read_text() for c in commands]
    assert 'PHR4_OUTER_CAPACITY PASS 246' in logs[0]
    assert 'PHR4_SERVICE_PREPARATION BLOCKED 7' in logs[1]
    assert 'PHR4_HELD_BEND_TERMINAL PASS 5' in logs[2]
    assert 'PHR4_SERVICE_POSITIONS_TERMINAL BLOCKED 5' in logs[3]
    assert 'PHR4_SERVICE_WITNESSES_VERIFIED 20 18 2 846' in logs[4]
    assert 'PHR4_WITNESS_SECTION PASS' in logs[5]
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',cwd=str(PROJECT),
        versions=dict(python='3.13.13',numpy='2.3.4',scipy='1.16.2',manifold3d='3.5.3',blender='5.2.2 LTS'),
        commands=commands,initial_diagnostics=[dict(log='initial_source_key_error.log',exit_code=1,
            reason='Reader used housing_width_mm rather than actual source field housing_width_B_mm; fixed without changing a dimension'),
            dict(log='initial_local_import_error.log',exit_code=1,
            reason='Factory Blender requires explicit local import path; fixed without changing geometry or criteria')],
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 PHR-4外形空间与带线插合诊断</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1050px;margin:32px auto;padding:0 22px;color:#27343b}}table{{width:100%;border-collapse:collapse;margin:20px 0}}td,th{{padding:9px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}img{{width:100%;height:auto}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}</style>
<h1>PHR-4身体端：外形空间通过，带线插合候选失败</h1>
<p class="scope">独立容量研究，未采用。外形框为PLACEHOLDER / ASSUMED，仅9.8×4.5×6.85mm三个字段来自公开目录。PROTOTYPE / UNVALIDATED；完整插合、实际端子／线材／夹持及整束带线装配BLOCKED。</p>
<p>保持运动基板J5、打印件和四个原参考线口不动。未取得完整壳体内腔，因此只按外形容量框检查；从假定位置抬起{cap['release_lift_mm']:.4f}mm使框与原J5外形分离。这是容量框行程，不是已确认的插入深度。没有把框与J5的内部重叠当作完整插合通过。</p>
<table><thead><tr><th>检查</th><th>实际范围</th><th>结果与边界</th></tr></thead><tbody>
<tr><td>外形框空间／整段平移</td><td>246项；两个身体壳另记闭合状态诊断；全名义头部偏航／俯仰用Z分离界</td><td>PASS；名义最小净距下界约0.9703mm。只替换检查框，没有改变主模型。</td></tr>
<tr><td>运动基板拆分检查</td><td>48个原生元件及PCB，共49项；仅J5配对内部另列未知</td><td>重新并合与当前MCU_Carrier实体差0mm³；其余48项保留，没有整块排除基板。</td></tr>
<tr><td>仅移动插头附近短段</td><td>7种形变范围，4根线，3个抬起量</td><td>7种均BLOCKED：第一处弯部分低于6.865mm名义容量半径要求；实际线材弯折数据仍未知。</td></tr>
<tr><td>第一处弯整体移动</td><td>5种分散形变；4根线×3个抬起量；曲线数值长度保持</td><td>有限位置的整条曲线弯曲PASS；只证明曲线几何，未证明插合可行。</td></tr>
<tr><td>带线候选／当前实体与其他线</td><td>5种各检零位和中途，共40条前段；全部201件当前原生实体、620组互线、40条自身及自身上段接续</td><td>5种均在中途{cap['release_lift_mm']/2:.4f}mm失败；后续最大抬起量未继续检查。互线及自身检查通过，固定Yaw_Base净距失败。</td></tr>
<tr><td>独立失败复现</td><td>20个曲线取样点重新构建，并与当前Yaw_Base作内接球实体检查</td><td>18处容量球／原生实体相交，2处未相交但不足0.3mm规划净距。不是实物碰线测量。</td></tr>
</tbody></table>
<figure><img src="service_collision_section.svg" alt="已复现的CAM1容量球与当前固定偏航座剖面相交"><figcaption>实际当前原生实体的剖面；红色为内接容量球的相交区域，坐标和实体来自独立复现。</figcaption></figure>
<p>这次没有找到可采用的完整插合方案。后续仍需临时整理与分步穿线、实际材料／端接／固定、缺失上段及整束闭壳。喇叭线150mm含现有插头保持；插头尺寸等用户到公司后补充。主Blender、视频和846个硬件工程源保持，制造放行false。</p>
<p><a href="housing_capacity.json">外形空间与假定基准</a> · <a href="service_family_screen.json">短段形变失败</a> · <a href="held_bend_screen.json">整体随动弯曲预检</a> · <a href="service_positions.json">带线有限位置检查</a> · <a href="service_witness_verification.json">20处独立复现</a> · <a href="commands.json">实际命令与初始诊断</a> · <a href="../phr4_source_review_R1/index.html">目录来源与未知字段</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# M1.55 PHR-4 external capacity and wired service probes

Unadopted PLACEHOLDER / ASSUMED capacity box using three public catalogue
dimensions only. Actual inner cavity, mating/wire-exit datums, crimp, grip,
tolerance and chosen wire are missing. MotionJ5 and all original references
remain fixed. Assumed box release travel5.150100610mm is NOT insertion depth.
External swept-box clearance246 rows PASS; head Z separation covers nominal
yaw/pitch. Two body shells are separate closed-state diagnostics. The49 native
motion components reproduce current carrier union exactly; only J5 internal
mating is unresolved, all48 other components/substrate remain checked.

Seven short-local fade variants failed geometric bend capacity. Five first-
bend held variants passed whole-curve bending at three finite lift positions.
All five subsequently fail current-native clearance at the midpoint lift.
Native service checks cover zero/midpoint only (40 curves), all201 current
parts,620 mutual pairs,40 own/self joins. Later maximum lift not executed.
Twenty independently reconstructed sample witnesses:18 true capacity-sphere
intersections and2 planning0.3mm clearance violations, all fixedYaw_Base.
The section uses actual current-native Manifold geometry and a witness sphere.

No actual complete mating, physical material or full wired assembly release.
No main, animation or hardware edit, no supplier contact/order or Git delivery.
Four full-harness work groups remain. Speaker150mm case-to-plug measurement
is unchanged; user will provide plug dimensions after reaching the office.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
        and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json','publish_review.log']}
    delivery=dict(status='PASS',scope='Scoped publication of outside capacity PASS and failed wired service probes',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        conditional_external_box_capacity='PASS',external_capacity_checks=246,fixed_head_service_probes='BLOCKED',
        independently_replayed_service_witnesses=20,capacity_intersections=18,planning_gap_only_violations=2,
        native_service_curves=40,finite_native_lift_positions=2,mutual_pair_checks=620,
        actual_mating='BLOCKED',full_harness='BLOCKED',remaining_work_packages=4,
        protected_hardware_files=846,main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
    assert all(sha(p)==h for p,h in sources.items()) and all(sha(HERE/p)==h for p,h in files.items())
    parser=Links();parser.feed((HERE/'index.html').read_text());targets=[HERE/'index.html']
    for link in parser.links:
        u=urlsplit(link)
        if not u.scheme and u.path:targets.append((HERE/unquote(u.path)).resolve())
    served=[]
    for p in dict.fromkeys(targets):
        relative=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(relative),timeout=10) as response:
            assert response.status==200 and response.read()==p.read_bytes()
        served.append(dict(path=relative,sha256=sha(p)))
    (HERE/'publication_verification.json').write_text(json.dumps(dict(status='PASS',delivery_sha256=sha(HERE/'delivery.json'),
        verified_files=len(files),served_links=len(served),served=served,full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')
    print('PHR4_CAPACITY_AND_SERVICE_PUBLISHED',len(files),len(served),20,18,2,flush=True)


if __name__=='__main__':main()
