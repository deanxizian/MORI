"""Independent numeric/solid replay of the failed held-bend service probes.

Each reference curve sample is reconstructed from the source family. An
inscribed sphere at that sample either overlaps the current fixed yaw base
or comes within the planning0.3mm clearance. No physical wire is certified.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]
sys.path[:0]=[str(PARENT/'prefix_continuity/frame_family_R3'),str(PROJECT/'mechanical/scripts/vendor')]
from selected_family import SelectedFamily,BSpline
from family import smooth
from scipy.optimize import brentq
import manifold3d as manifold
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    started=time.time()
    report_path=HERE/'service_positions.json';report=read(report_path)
    assert report['status']=='BLOCKED' and len(report['rows'])==5
    assert all(sha(p)==h for p,h in report['sources'].items())
    saved_path=HERE/'service_position_arrays.npz';saved=np.load(saved_path)
    assert sha(saved_path)==report['arrays_sha256']
    current=PARENT/'terminal_install_review_R1'
    receipt=read(current/'current_native_receipt.json');native_path=current/'current_native_parts.npz'
    assert sha(native_path)==receipt['output_sha256'] and receipt['native_part_count']==201
    data=np.load(native_path)
    v=data['Yaw_Base__vertices_mm'];f=data['Yaw_Base__triangles']
    yawbase=manifold.Manifold(manifold.Mesh64(v,f.astype(np.uint64)))
    assert yawbase.status()==manifold.Error.NoError
    family=SelectedFamily();verified=[]
    greville=np.array([family.knots[i+1:i+4].mean() for i in range(len(family.controls[0]['CAM_1']))])
    for variant in report['rows']:
        hold,end=variant['hold_parameter'],variant['fade_end_parameter']
        w=1-smooth(np.clip((greville-hold)/(end-hold),0.,1.));w[:2]=1.;w[-2:]=0.
        displacement=np.c_[np.zeros((len(w),2)),w]
        case=next(c for c in variant['cases'] if c['status']=='BLOCKED')
        assert case['head_pose_deg']==[0,0] and len(case['mutual_pairs'])==62
        assert all(r['status']=='PASS' for r in case['mutual_pairs'])
        assert case['lift_mm']==report['lift_positions_mm'][1]
        for row in case['wire_rows']:
            name=row['wire'];start=family.candidate(name,0)['control'];direction=family.base(name,0)[3]
            target=float(family.weights@np.linalg.norm(family.Q@start,axis=1))
            base=start+case['lift_mm']*displacement
            value=lambda a:float(family.weights@np.linalg.norm(family.Q@(base+a*direction),axis=1))-target
            root=float(brentq(value,-2.,2.,xtol=1e-12,rtol=1e-14))
            control=base+root*direction
            spline=BSpline(family.knots,control,3);d=spline.derivative();edges=np.unique(family.knots)
            cubics=np.array([[spline(a),spline(a)+(b-a)*d(a)/3,
                              spline(b)-(b-a)*d(b)/3,spline(b)] for a,b in zip(edges[:-1],edges[1:])])
            key=f'h{hold:.2f}_e{end:.2f}_z{case["lift_mm"]:.9f}_{name}'
            discrepancy=float(np.max(abs(cubics-saved[key+'__controls'])))
            assert discrepancy<1e-10
            p=[]
            for c in cubics:
                steps=max(1,int(np.ceil(np.linalg.norm(3*np.diff(c,axis=0),axis=1).max()/.03)))
                u=np.linspace(0.,1.,steps+1)[:,None]
                q=(1-u)**3*c[0]+3*u*(1-u)**2*c[1]+3*u*u*(1-u)*c[2]+u**3*c[3]
                p.append(q if not p else q[1:])
            p=np.concatenate(p)
            assert np.max(abs(p-saved[key+'__points']))<1e-9
            hit=next(h for h in row['native_hits'] if h['object']=='Yaw_Base')
            point=np.array(hit['point_mm']);error=float(np.linalg.norm(p-point,axis=1).min())
            assert error<1e-9
            probe=manifold.Manifold.sphere(family.radii[name],32).translate(point.tolist())
            overlap=float((probe^yawbase).volume())
            gap=float(probe.min_gap(yawbase,.5))
            assert overlap>1e-5 or gap<.3-1e-5,(name,hold,end,overlap,gap)
            verified.append(dict(wire=name,hold_parameter=hold,fade_end_parameter=end,lift_mm=case['lift_mm'],
                object='Yaw_Base',point_mm=point.tolist(),exact_curve_sample_replay_error_mm=error,
                control_reconstruction_error_mm=discrepancy,inscribed_capacity_sphere_radius_mm=family.radii[name],
                overlap_mm3=overlap,sphere_to_native_gap_mm=gap,
                classification='Actual capacity-tube intersection witness' if overlap>1e-5 else 'Planning0.3mm clearance violation witness',
                actual_wire_evidence='Not a selected wire or physical measurement'))
    assert len(verified)==20
    family.unchanged()
    baseline_path=PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json';baseline=read(baseline_path)
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    sources={**report['sources'],**family.sources,**{str(p):sha(p) for p in [
        Path(__file__),report_path,saved_path,current/'current_native_receipt.json',native_path,baseline_path]}}
    assert all(sha(p)==h for p,h in sources.items())
    result=dict(status='PASS',scope='Replay20 failed service-capacity witnesses, not qualification of the failed variants',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        verified_witnesses=verified,capacity_intersection_witnesses=sum(r['overlap_mm3']>1e-5 for r in verified),
        clearance_only_witnesses=sum(r['overlap_mm3']<=1e-5 for r in verified),
        failed_variants=5,full_wired_assembly='BLOCKED',actual_mating='BLOCKED',
        protected_hardware_files=846,main_changed=False,animation_changed=False,hardware_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'service_witness_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PHR4_SERVICE_WITNESSES_VERIFIED',len(verified),result['capacity_intersection_witnesses'],
          result['clearance_only_witnesses'],846,flush=True)


if __name__=='__main__':main()
