"""Draw one actual current-native cross section at a replayed witness."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[3]
sys.path.insert(0,str(PROJECT/'mechanical/scripts/vendor'))
import manifold3d as manifold
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    verification=HERE/'service_witness_verification.json'
    audit=json.loads(verification.read_text())
    assert audit['status']=='PASS' and all(sha(p)==h for p,h in audit['sources'].items())
    witness=next(r for r in audit['verified_witnesses'] if r['overlap_mm3']>1e-5)
    native_path=HERE.parent/'terminal_install_review_R1/current_native_parts.npz'
    data=np.load(native_path)
    m=manifold.Manifold(manifold.Mesh64(data['Yaw_Base__vertices_mm'],data['Yaw_Base__triangles'].astype(np.uint64)))
    point=np.array(witness['point_mm']);radius=witness['inscribed_capacity_sphere_radius_mm']
    probe=manifold.Manifold.sphere(radius,32).translate(point.tolist())
    # Ry90 sends original (X,Y,Z) to (Z,Y,-X), allowing an exact YZ slice.
    fixed=m.rotate([0.,90.,0.]).slice(-point[0])
    circle=probe.rotate([0.,90.,0.]).slice(-point[0])
    intersection=fixed^circle
    assert intersection.area()>1e-5
    ymax,ymin=point[1]+4.,point[1]-4.
    zmax,zmin=point[2]+3.,point[2]-3.
    scale=60.
    def path(section):
        polygons=section.to_polygons()
        items=[]
        for poly in polygons:
            coordinates=[(80+(p[1]-ymin)*scale,90+(zmax-p[0])*scale) for p in poly]
            items.append('M'+' L'.join(f'{x:.5f},{y:.5f}' for x,y in coordinates)+' Z')
        return ' '.join(items)
    image=HERE/'service_collision_section.svg'
    image.write_text(f'''<svg xmlns="http://www.w3.org/2000/svg" width="940" height="525" viewBox="0 0 940 525">
<style>text{{font-family:system-ui,sans-serif;fill:#293a43}}.small{{font-size:14px}}.label{{font-size:17px}}</style>
<rect width="940" height="525" fill="#f8f9f7"/><text x="30" y="35" font-size="23">CAM身体端插合候选：固定偏航座碰线剖面</text>
<text x="30" y="62" class="small">当前M1.55原生实体 · X={point[0]:.4f} mm剖面 · 容量候选，未采用</text>
<defs><clipPath id="crop"><rect x="80" y="90" width="480" height="360"/></clipPath></defs>
<rect x="80" y="90" width="480" height="360" fill="white" stroke="#bdc7c8"/>
<g clip-path="url(#crop)">
<path d="{path(fixed)}" fill="#607378" fill-rule="evenodd"/>
<path d="{path(circle)}" fill="#c7983a" fill-opacity=".6" stroke="#9b6c15" fill-rule="evenodd"/>
<path d="{path(intersection)}" fill="#bb4a42" fill-rule="evenodd"/>
</g>
<path d="M80 450H575 M80 450V75" stroke="#293a43" fill="none"/>
<text x="568" y="477" class="small">+Y</text><text x="49" y="78" class="small">+Z</text>
<text x="80" y="477" class="small">Y={ymin:.2f}</text><text x="386" y="477" class="small">Y={ymax:.2f} mm</text>
<text x="600" y="130" class="label">CAM 1 · 第一处弯整体随动</text>
<text x="600" y="162" class="label">插头名义抬起 {witness['lift_mm']:.3f} mm</text>
<rect x="600" y="195" width="19" height="19" fill="#607378"/><text x="630" y="210" class="label">固定Yaw_Base的真实切片</text>
<rect x="600" y="231" width="19" height="19" fill="#c7983a"/><text x="630" y="246" class="label">导线容量内接球 Ø{2*radius:.3f} mm</text>
<rect x="600" y="267" width="19" height="19" fill="#bb4a42"/><text x="630" y="282" class="label">已复现的相交区域</text>
<text x="600" y="328" class="small">整球／原生实体相交 {witness['overlap_mm3']:.5f} mm³</text>
<text x="600" y="356" class="small">剖面相交 {intersection.area():.5f} mm²</text>
<text x="600" y="402" class="small">不是已选线材、压接外形或实物测量。</text>
<text x="30" y="511" class="small">整体弯曲通过不能替代装入净距；此候选BLOCKED，主模型／动画未改。</text></svg>''')
    receipt=dict(status='PASS',scope='One replayed capacity-sphere/native YZ section only',
        witness=witness,section_X_mm=float(point[0]),section_overlap_mm2=float(intersection.area()),
        sources={str(p):sha(p) for p in [Path(__file__),verification,native_path]},
        image_sha256=sha(image),full_wired_assembly='BLOCKED',main_changed=False,manufacturing_release=False)
    (HERE/'section_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('PHR4_WITNESS_SECTION',receipt['status'],intersection.area(),flush=True)


if __name__=='__main__':main()
