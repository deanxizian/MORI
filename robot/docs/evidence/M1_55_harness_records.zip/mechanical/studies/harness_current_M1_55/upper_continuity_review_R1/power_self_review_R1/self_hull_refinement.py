"""Closed parameter-product self bounds with a complete local arc/join cap."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'cam_peer_review_R1'))
from fan_geometry import half,bound
from power_self_envelopes import arc_upper


def refine(a,b,densities,joins,i,j,radius,max_depth=16):
    assert len(a)==len(b)==2
    pending = [(a,b,(0.,1.,0.,1.),0)]
    accepted = []
    visited = 0
    while pending:
        ca,cb,rectangle,depth = pending.pop()
        visited += 1
        local = arc_upper(densities,joins,i,j,rectangle)
        if local<=5.:
            accepted.append(dict(parameter_rectangle=list(rectangle),method='local_arc',arc_upper_mm=local))
            continue
        gap = max(bound(x,y,2*radius) for x,y in zip(ca,cb))
        if gap>=.3:
            accepted.append(dict(parameter_rectangle=list(rectangle),method='complete_hull',gap_lower_mm=gap))
            continue
        if depth>=max_depth:
            return dict(status='BLOCKED',visited=visited,
                        unresolved_parameter_rectangle=list(rectangle),arc_upper_mm=local,gap_lower_mm=gap)
        ta,tb,ua,ub = rectangle
        # Balance complete parameter arc upper widths; retain both children.
        if densities[i]*(tb-ta)>=densities[j]*(ub-ua):
            children = [half(c) for c in ca]
            left,right = [c[0] for c in children],[c[1] for c in children]
            middle = (ta+tb)/2
            pending.extend([(left,cb,(ta,middle,ua,ub),depth+1),(right,cb,(middle,tb,ua,ub),depth+1)])
        else:
            children = [half(c) for c in cb]
            left,right = [c[0] for c in children],[c[1] for c in children]
            middle = (ua+ub)/2
            pending.extend([(ca,left,(ta,tb,ua,middle),depth+1),(ca,right,(ta,tb,middle,ub),depth+1)])
    return dict(status='PASS',visited=visited,accepted=accepted)
