# Complete nominal four-CAM-upper mutual clearance

PASS: six unordered CAM-upper pairs over yaw[-60,60], pitch[-20,25],
and both complete cubic parameters. Separate exhaustive categories:

1. Fan/fan: guarded source construction is pitch/height independent in
   the ideal yaw frame. All-yaw hull and complete parameter refinement proof.
2. Fixed tail/tail: invariant in the ideal pitch frame;16,000 closed cells
   per reference and explicit AABB/centre-sphere separation.
3. All other mixed/loop products:648 mathematical angular parents,3,888
   pair/angular rows; complete cubic control hulls in two valid rigid frames.

Independent category enumeration confirms an exhaustive, disjoint cover.
The target-capped0.3mm lower bound is not a measured minimum separation.

Still incomplete:12 CAM/power/CC upper cross pairs, moving self, own prefix,
actual materials/terminals/slack, wired insertion and closure. No main-model,
hardware or animation adoption. Full harness BLOCKED; manufacturing false.

Initial whole-curve-ball BLOCKED and stopped fixed-axis pilot are retained.
The adaptive pilot covers the same windows but is not itself the full proof.
The fan generator's inline cache-policy comment is only a construction note;
its implementation recomputes the two controls for each pair/interval.
