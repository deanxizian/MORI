"""Faster complete-parameter balls with unchanged source geometry.

Enclose each parameter midpoint's two-angle movement, then add half the cell
width times the maximum cubic speed. The quadratic derivative control hull
covers the entire polynomial piece, including its particular short cell.
This replaces four duplicated position boxes, never the curve or gap target.
"""
import numpy as np
from power_native_envelopes import NUMERIC,rotate_box
from power_enclosures import Box,magnitude,yaw_box


def movement(e,name,rectangle,certificate,reference):
    yl,yh,pl,ph=rectangle;center=e.center
    amplitude=Box(certificate['midpoint_amplitude_mm']-certificate['amplitude_deviation_bound_mm'],
                  certificate['midpoint_amplitude_mm']+certificate['amplitude_deviation_bound_mm'])
    M=e.poly_midpoints
    F,K,first,last,total=e.split_local(name,rectangle,M)
    F=F+amplitude*(M@e.e.D)
    error=e.e.ey*magnitude(F).hi+e.e.et*np.linalg.norm(K,axis=1)+e.e.ty*abs(first)+e.e.tt*abs(last)+NUMERIC
    poly=F+rotate_box(K,pl,ph,'X')+total[:,None]*center+Box(-error[:,None],error[:,None])
    # Coherent derivative rows have zero translation weight.
    V=e.e.V.reshape(-1,6)
    v=e.e.mapped_controls(name,rectangle,V)+amplitude*(V@e.e.D)
    polynomial_speed=(1+e.e.ey)*magnitude(v).hi.reshape(128,3).max(1)+6*NUMERIC
    polynomial_radius=np.repeat(polynomial_speed/(2*e.poly_steps),e.poly_steps)
    controls,velocity=e.e.inputs(name,*rectangle)
    start=yaw_box(e.e.end_keys[name],yl,yh)
    error=(e.e.ey*magnitude(start-center).hi+e.e.ty)/(1-e.e.ey)+NUMERIC
    start=start+Box(-error,error)
    S=e.stub_midpoints
    q=(S[:,0]+S[:,1])[:,None]*start+(S[:,2]+S[:,3])[:,None]*controls[0]+\
       (S[:,1,None]*velocity[0]-S[:,2,None]*velocity[2])/3
    error=e.e.ey*magnitude(q-center).hi+e.e.ty+NUMERIC
    stub=q+Box(-error[:,None],error[:,None])
    stub_speed=(1+e.e.ey)*float(magnitude(velocity).hi.max())+6*NUMERIC
    stub_radius=np.full(e.stub_steps,stub_speed/(2*e.stub_steps))
    lo=np.concatenate([stub.lo,poly.lo]);hi=np.concatenate([stub.hi,poly.hi])
    points=e.relative_points(reference,'yaw')
    radius=np.linalg.norm(np.maximum(abs(lo-points),abs(hi-points)),axis=1)+\
           np.r_[stub_radius,polynomial_radius]+NUMERIC
    assert len(radius)==len(e.parameter_cells)
    return radius
