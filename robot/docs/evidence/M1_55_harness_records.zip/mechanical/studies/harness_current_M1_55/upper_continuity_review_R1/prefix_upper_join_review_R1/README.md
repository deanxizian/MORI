# M1.55 nominal prefix-upper joins

All84 combinations of12 body/neck prefixes and7 known uppers PASS over
nominal yaw -60..60 / pitch -20..25 and complete closed curve parameters:
7 own-prefix remote-self joins and77 other-prefix mutual comparisons.
Independent root/angle/parameter coverage:PASS,9072
angular rectangles / 4185 refined parameter rectangles.

Every prefix has45 canonical cubics; CAM uppers have237/238, power/CC129.
The original0.3mm target is unchanged. Each side uses its own allocation
radius, including CAM body0.565mm and upper0.3302mm. This does not define
an actual wire/splice. Only own joins exclude full arc upper<=5mm, with
arithmetic join reserves.180 original-prefix source poses /540 control
comparisons and105 original-upper endpoint/tangent/derivative probes PASS.

Five upper endpoints, actual mixed materials/splices/cut lengths, matching
connectors, restraints/strain relief and full wired assembly/closure remain
BLOCKED. No main, animation, hardware change or manufacturing release.
The initial independent audit's source-order assumption failure is retained;
coverage sorts a copy while preserving original source indices.
