"""Complete closed parameter products, using valid common yaw and pitch frames."""
import numpy as np
from fan_geometry import half, bound


def refine(a, b, radius_sum, max_depth=14):
    assert len(a) == len(b) == 2
    pending = [(a,b,(0.,1.,0.,1.),0)]
    accepted = []
    visited = 0
    while pending:
        ca,cb,rectangle,depth = pending.pop()
        visited += 1
        gap = max(bound(x,y,radius_sum) for x,y in zip(ca,cb))
        if gap >= .3:
            accepted.append(dict(parameter_rectangle=list(rectangle),gap_lower_mm=gap))
            continue
        if depth >= max_depth:
            return dict(status='BLOCKED',visited=visited,
                        unresolved_parameter_rectangle=list(rectangle),gap_lower_mm=gap)
        ta,tb,ua,ub = rectangle
        # These sizes choose only the split order; both children remain covered.
        size = lambda c: float(np.linalg.norm(np.diff((c.lo+c.hi)/2,axis=0),axis=1).sum())
        if max(map(size,ca)) >= max(map(size,cb)):
            children = [half(c) for c in ca]
            left,right = [c[0] for c in children],[c[1] for c in children]
            middle = (ta+tb)/2
            pending.extend([(left,cb,(ta,middle,ua,ub),depth+1),(right,cb,(middle,tb,ua,ub),depth+1)])
        else:
            children = [half(c) for c in cb]
            left,right = [c[0] for c in children],[c[1] for c in children]
            middle = (ua+ub)/2
            pending.extend([(ca,left,(ta,tb,ua,middle),depth+1),(ca,right,(ta,tb,middle,ub),depth+1)])
    return dict(status='PASS',visited=visited,accepted=accepted,
                gap_lower_mm=min(r['gap_lower_mm'] for r in accepted))
