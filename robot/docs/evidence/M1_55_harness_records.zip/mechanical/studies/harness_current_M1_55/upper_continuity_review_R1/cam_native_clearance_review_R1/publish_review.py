"""Publish completed CAM native reference checks with exact scope boundaries."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    proof=read(HERE/'native_verification.json')
    audit=read(HERE/'native_coverage_verification.json')
    cross=read(HERE/'envelope_crosscheck.json')
    pilot=read(HERE/'pilot_native_coverage_verification.json')
    assert proof['status']==audit['status']==cross['status']==pilot['status']=='PASS'
    assert proof['mode']==audit['mode']=='all_angles' and audit['source_math_rectangles']==2592
    assert proof['native_parts']==201 and proof['required_gap_mm']==.3
    sources={}
    for result in [proof,audit,cross,pilot]:
        for p,h in result['sources'].items():
            assert sha(p)==h,p
            assert p not in sources or sources[p]==h
            sources[p]=h
    failed=read(HERE/'initial_numpy_index_serialization/source_archive_receipt.json')
    assert failed['status']=='PASS' and all(sha(r['archived'])==r['sha256'] for r in failed['files'])
    stopped=read(HERE/'older_pilot_stop.json')
    assert stopped['status']=='NOT_TESTED' and stopped['verified_terminal_exit_code']==143
    assert stopped['partial_log_sha256']==sha(HERE/'native_pilot.log')
    assert 'CAM_NATIVE_CACHED_TERMINAL PASS all_angles' in (HERE/'native_full.log').read_text()
    assert 'Traceback (most recent call last)' not in (HERE/'native_full.log').read_text()
    commands=dict(status='PASS',Python_numeric='3.13.13',NumPy='2.3.4',SciPy='1.16.2',mpmath='1.3.0',
        Python_publication='3.12.14',Blender='5.2.2 LTS d13f752e3b9c',
        commands=[
          dict(command=['/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',
                        str((HERE/'check_envelopes.py').relative_to(PROJECT)),'--pilot'],
               environment={'OPENBLAS_NUM_THREADS':'1'},log='check_envelopes_pilot.log',result='envelope_pilot_crosscheck.json'),
          dict(command=['/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13',
                        str((HERE/'run_crosscheck_serialized.py').relative_to(PROJECT))],
               environment={'OPENBLAS_NUM_THREADS':'1'},log='check_envelopes_serialized.log',result='envelope_crosscheck.json'),
          dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','mechanical/mori_v1_2.blend','--python-exit-code','1',
                        '--python',str((HERE/'run_native_cached.py').relative_to(PROJECT)),'--','--pilot'],
               log='native_cached_pilot.log',result='pilot_native_adaptive_verification.json'),
          dict(command=['/Applications/Blender.app/Contents/MacOS/Blender','-b','mechanical/mori_v1_2.blend','--python-exit-code','1',
                        '--python',str((HERE/'run_native_cached.py').relative_to(PROJECT))],
               log='native_full.log',result='native_verification.json'),
          dict(command=['/Users/dean/.cache/codex-runtimes/mori-cad/bin/python',str((HERE/'verify_native.py').relative_to(PROJECT)),'--pilot'],
               result='pilot_native_coverage_verification.json'),
          dict(command=['/Users/dean/.cache/codex-runtimes/mori-cad/bin/python',str((HERE/'verify_native.py').relative_to(PROJECT))],
               result='native_coverage_verification.json')],
        cwd=str(PROJECT),initial_failed_numeric_execution='initial_numpy_index_serialization/source_archive_receipt.json',
        initial_launch_failure='The full cross-check first failed to launch because its cwd omitted the leading slash. No process/result existed for that request.',
        older_same_scope_pilot_stop='older_pilot_stop.json',
        field_cache_note='Only complete byte-identical tail point arrays and identical target dictionaries/radii are reused. All curve cells/native targets remain.',
        actual_BVH_queries=proof['BVH_distance_queries'],main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False)
    for command in commands['commands']:
        if 'log' in command:command['log_sha256']=sha(HERE/command['log'])
        command['result_sha256']=sha(HERE/command['result'])
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    table=''.join('<tr><td>'+html.escape(r['wire'])+'</td><td>'+str(r['source_parents'])+'</td><td>'+str(r['accepted_rectangles'])+
                  '</td><td>'+str(proof['parameter_cells_per_reference'][r['wire']])+'</td><td>PASS</td></tr>' for r in audit['per_wire'])
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>四条CAM名义参考的全范围实体间隙</title><style>body{{max-width:1040px;margin:30px auto;padding:0 22px;font:16px/1.7 system-ui;color:#233541;background:#f5f7f8}}section{{padding:20px;margin:20px 0;background:white;border:1px solid #d8e1e6;border-radius:10px}}table{{width:100%;border-collapse:collapse}}th,td{{padding:10px;border:1px solid #d8e1e6;text-align:left}}a{{color:#195c95}}</style>
<p><a href="../index.html">已知上段连续检查</a> · <a href="../cam_math_review_R1/index.html">CAM长度与弯折</a> · <a href="../../index.html">线束研究</a></p>
<h1>四条CAM名义参考：全范围实体间隙通过</h1><p>PLACEHOLDER / ASSUMED · 未采用 · 完整线束仍BLOCKED</p>
<section><h2>完成范围</h2><p>覆盖偏航−60°～+60°、俯仰−20°～+25°，与当前201件模型实体分身体、偏航、俯仰框架核对。
2,592个源长度区间及必要细分全部覆盖；独立逐父区间核对覆盖，无遗漏或重复。原0.3mm目标保持，最小实体下界约{audit['minimum_certified_native_gap_lower_mm']:.8f}mm。</p>
<table><tr><th>参考</th><th>源数学区间</th><th>通过的细分区间</th><th>完整闭参数区间</th><th>结果</th></tr>{table}</table>
<p>完整三次控制包络与实体AABB可证明分离时直接采用；其余区间使用BVH距离与整个闭参数区间的运动球。
零长度引线及零俯仰圆弧保留为退化点槽，不省略非零小圆弧。每个原三次段的完整参数均被覆盖。</p></section>
<section><h2>独立核对与查询</h2><p>包络与80位源构造的72个普通姿态、56个零位附近案例及完整参数实现探测通过。
距离只复用同一实体字典、半径和逐位相同尾段点数组；并保留分割处额外包含检查。曲线、硬件和间隙目标保持。</p>
<p>旧较慢试查在同范围的新16个父区间／48个细分区间及独立覆盖通过后停止，旧未完成日志不计作整组PASS。
原完整包络检查的NumPy整数JSON写入错误保留，正确序列化执行单独记录。</p></section>
<section><h2>仍未完成</h2><p>这是当前模型和理想名义旋转下的容量参考检查，完整实发硬件／插头与实际材料未资格化。
假定USB外形另列条件检查，下界最小约{audit['minimum_conditional_USB_gap_lower_mm']:.8f}mm，不代表实际插头合格。
四条CAM的全范围互线、自身及前段接续、电源／CC连续自身接近、五条缺实际端点线路、材料／端接／固定、裁线图与带线装头／闭壳仍未完成。
主模型M1.55、视频M1.55-A1及846个硬件文件保持。manufacturing_release=false。</p></section>
<section><h2>证据</h2><p><a href="native_verification.json">完整实体区间</a> · <a href="native_coverage_verification.json">独立覆盖</a> ·
<a href="envelope_crosscheck.json">源构造与包络核对</a> · <a href="pilot_native_coverage_verification.json">同范围试查覆盖</a> ·
<a href="commands.json">实际命令</a> · <a href="native_full.log">完整执行日志</a> · <a href="older_pilot_stop.json">旧试查停止记录</a> · <a href="README.md">范围说明</a></p></section></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text(f'''# 四条CAM名义参考的全范围实体间隙：未采用

当前201模型实体，名义偏航±60°／俯仰−20°～+25°。
2,592个数学父区间、{audit['accepted_rectangles']}个实体细分区间；独立覆盖核对通过。
每条完整闭参数区间：{proof['parameter_cells_per_reference']}。零长度槽位作为退化点保留。
最小模型实体间隙下界{audit['minimum_certified_native_gap_lower_mm']:.12g}mm，原目标0.3mm。
假定USB条件下界{audit['minimum_conditional_USB_gap_lower_mm']:.12g}mm；实际完整插头／尾线未知。

只复用逐位相同尾段点数组与同一实体字典／半径的查询，未省略点或物体。两个细分子区间仍全部检查。
包络与保留80位构造的72个普通姿态、56个近零案例核对通过，未把有限探测当作全运动证明。
旧慢试查未完成，在同范围新试查及独立覆盖通过后主动停止；精确日志和停止原因保留。
首次完整包络数值比较已计算，但报告写入拒绝NumPy整数，未产生合格报告；正确序列化执行另存。

新CAM互线／自身／前段接续、实际材料／端点／固定／供应商裁线图、带线装头与闭壳仍未完成。
当前零位硬件／主模型／动画和846个硬件文件保持。只针对容量参考；PLACEHOLDER / ASSUMED。
理想名义旋转证明不资格化旧Float32框架助手的全角度舍入或实际线束。manufacturing_release=false。
''')
    for p in [Path(__file__),HERE/'native_verification.json',HERE/'native_coverage_verification.json',
              HERE/'envelope_crosscheck.json',HERE/'commands.json',HERE/'older_pilot_stop.json']:
        sources[str(p)]=sha(p)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json']}
    out=dict(status='PASS',scope='Four complete nominal CAM native reference proofs and independent coverage only',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
             continuous_nominal_CAM_native_clearance='PASS',native_parts=201,source_math_rectangles=2592,
             accepted_rectangles=audit['accepted_rectangles'],parameter_cells_per_reference=proof['parameter_cells_per_reference'],
             minimum_certified_native_gap_lower_mm=audit['minimum_certified_native_gap_lower_mm'],
             minimum_conditional_USB_gap_lower_mm=audit['minimum_conditional_USB_gap_lower_mm'],required_gap_mm=.3,
             native_frame=proof['native_frame'],source_float32_all_angle_rounding='NOT_TESTED',
             source_blend_sha256=audit['source_blend_sha256'],source_video_sha256=audit['source_video_sha256'],
             peer_clearance='NOT_TESTED',remote_self='NOT_TESTED',full_harness='BLOCKED',
             actual_material_and_endpoints='BLOCKED',protected_hardware_files=846,main_changed=False,
             hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_NATIVE_PUBLISHED',len(files),len(sources),audit['accepted_rectangles'],flush=True)


if __name__=='__main__':
    main()
