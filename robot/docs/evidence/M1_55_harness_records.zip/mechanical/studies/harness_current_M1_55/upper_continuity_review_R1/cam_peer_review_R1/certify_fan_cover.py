"""All-yaw fan/fan clearance in the common ideal yaw frame.

The exact region ends before pitch_shift_first_0. Its source construction
depends on yaw and body-prefix joins, and contains no pitch or length-height
terms. Source/implementation probes guard this independence. The remainder
of each upper is covered by distinct full two-angle and fixed-tail reports.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time
import numpy as np
HERE=Path(__file__).resolve().parent
NATIVE=HERE.parent/'cam_native_clearance_review_R1'
sys.path[:0]=[str(NATIVE)]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,RADII,sha
from fan_geometry import matrix,refine


def main():
    started=time.time();pilot='--pilot' in sys.argv;e=NativeCAMEnvelopes()
    cuts={n:e.layout[n]['labels'].index('pitch_shift_first_0') for n in NAMES}
    assert cuts==dict(CAM_1=37,CAM_2=37,CAM_3=36,CAM_4=36)
    cross_path=NATIVE/'envelope_crosscheck.json';cross=json.loads(cross_path.read_text())
    assert cross['status']=='PASS' and all(sha(p)==h for p,h in cross['sources'].items())
    sources=dict(e.sources)
    for p in [Path(__file__),HERE/'fan_geometry.py',cross_path]:sources[str(p)]=sha(p)
    def controls(name,lo,hi,pitch=0.,height=None):
        height=Box(e.saved_heights[name,0.,0.]) if height is None else height
        whole=e.controls(name,(lo,hi,pitch,pitch),height,'yaw')[0]
        return whole[:cuts[name]]
    independence=[]
    for lo,hi in [(-60.,-50.),(-10.,0.),(50.,60.)]:
        for name in NAMES:
            base=controls(name,lo,hi)
            for pitch in [-20.,-1e-8,0.,1e-8,25.]:
                other=controls(name,lo,hi,pitch,Box(.5,12.))
                assert np.array_equal(base.lo,other.lo) and np.array_equal(base.hi,other.hi)
                independence.append(dict(wire=name,yaw_interval_deg=[lo,hi],pitch_deg=pitch,
                                         height_interval_mm=[.5,12.],status='PASS'))
    pairs=list(itertools.combinations(NAMES,2));results=[];failures=[];visits=0
    seeds=[(-60.,-50.),(-10.,0.),(50.,60.)] if pilot else [(float(y),float(y+10)) for y in range(-60,60,10)]
    # Cache at most one yaw interval; the six pairs share its four controls.
    for pair in pairs:
        accepted=[];pending=[(*r,0) for r in seeds]
        while pending:
            lo,hi,depth=pending.pop();visits+=1
            a,b=[controls(n,lo,hi) for n in pair]
            lower=matrix(a,b,sum(RADII[n] for n in pair))
            unresolved=np.argwhere(lower<.3)
            fine=[];ok=True;minimum=float(lower.min())
            for i,j in unresolved:
                checked=refine(a[int(i)],b[int(j)],sum(RADII[n] for n in pair))
                if checked['status']!='PASS':
                    ok=False;break
                fine.append(dict(pieces=[int(i),int(j)],parameter_rectangles=checked['accepted'],
                                 gap_lower_mm=checked['gap_lower_mm'],visited_parameter_boxes=checked['visited']))
            if ok:
                other=lower[lower>=.3]
                minimum=min([float(other.min()) if other.size else float('inf')]+
                            [r['gap_lower_mm'] for r in fine])
                accepted.append(dict(yaw_interval_deg=[lo,hi],status='PASS',
                    whole_cubic_piece_pairs=int(lower.size),coarse_accepted_piece_pairs=int(np.count_nonzero(lower>=.3)),
                    coarse_unresolved_pieces=unresolved.tolist(),parameter_refinements=fine,
                    gap_lower_mm=minimum))
            elif depth>=16:
                failures.append(dict(wires=list(pair),yaw_interval_deg=[lo,hi],
                    reason='Undecided complete-parameter fan enclosure',unresolved_pieces=[int(i),int(j)],details=checked))
                break
            else:
                mid=(lo+hi)/2;pending.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
            if visits%50==0:print('CAM_FAN_PROGRESS',list(pair),visits,len(accepted),round(time.time()-started,1),flush=True)
        results.append(dict(wires=list(pair),status='PASS' if not failures else 'BLOCKED',intervals=accepted))
        print('CAM_FAN_PAIR',list(pair),results[-1]['status'],len(accepted),round(time.time()-started,1),flush=True)
        if failures:break
    e.unchanged();assert all(sha(p)==h for p,h in sources.items())
    out=dict(status='PASS' if len(results)==6 and not failures else 'BLOCKED',
        mode='pilot' if pilot else 'all_yaw',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Six complete fan/fan curve-parameter pairs over common ideal yaw; pitch-independent region only',
        sources=sources,fan_piece_counts=cuts,independence_probes=independence,pilot_windows=seeds if pilot else None,
        yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],required_gap_mm=.3,numeric_reserve_mm=.0001,
        results=results,failures=failures,visited_yaw_rectangles=visits,
        complete_CAM_mutual='NOT_TESTED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/('fan_pilot_verification.json' if pilot else 'fan_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FAN_TERMINAL',out['status'],visits,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
