"""Independent coverage, source, field-identity and enclosure readback.

The source family and saved 475-pose curves provide independent field samples.
Samples diagnose enclosure/implementation errors; interval proofs, not samples,
provide the claim over the complete angular domain.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from power_enclosures import PowerEnclosures,NAMES,sha,convert

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
PROJECT=HERE.parents[3]


def coverage(rows,base):
    assert rows
    edges=sorted(set(x for r in rows for x in r['rectangle_deg'][:2]))
    assert edges[0]==base[0] and edges[-1]==base[1]
    checked=0
    for a,b in zip(edges[:-1],edges[1:]):
        x=(a+b)/2
        active=sorted(r['rectangle_deg'][2:] for r in rows if r['rectangle_deg'][0]<x<r['rectangle_deg'][1])
        assert active and active[0][0]==base[2] and active[-1][1]==base[3]
        assert all(lo<hi for lo,hi in active)
        assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(active[:-1],active[1:])),(base,a,b,active)
        checked+=1
    return checked


def reconstruct(enclosure,pre,amplitude):
    matrix=pre['matrix']
    c=convert(pre['control']+amplitude*enclosure.D)
    c=c@matrix[:3,:3].T+matrix[:3,3]
    # The source construction restores its explicit vector-evaluated endpoints
    # after batched matrix multiplication. Preserve this same repair; a visual
    # tolerance is not permission to move either reference datum.
    seam=pre['prefix'][-1]-c[0,0]
    expected_end=pre['control'][-1]@matrix[:3,:3].T+matrix[:3,3]
    end=expected_end-c[-1,-1]
    c[0,:2]+=seam;c[-1,-2:]+=end
    pre['last_endpoint_roundoff_mm']=float(max(np.linalg.norm(seam),np.linalg.norm(end)))
    return np.concatenate([pre['prefix'][None],c])


def main():
    started=time.time();path=HERE/'power_math_verification.json'
    report=json.loads(path.read_text())
    assert report['status']=='PASS' and report['names']==NAMES and report['mode']=='complete_math'
    assert all(sha(p)==h for p,h in report['sources'].items())
    assert report['yaw_range_deg']==[-60,60] and report['pitch_range_deg']==[-20,25]
    assert report['source_key_rectangles']==108 and not report['manufacturing_release']
    f=PowerEnclosures();strips=0;groups={}
    for row in report['rows']:
        assert row['status']=='PASS' and row['global_unit_bracket_derivative_lower']>0 and row['speed_lower']>0
        assert abs(row['midpoint_amplitude_mm'])+row['amplitude_deviation_bound_mm']<1
        bend=row['continuous_bending']
        assert bend['status']=='PASS' and bend['derivative_nonzero'] and bend['radius_lower_mm']>=bend['required_radius_mm']
        groups.setdefault((row['wire'],tuple(row['source_key_rectangle_deg'])),[]).append(row)
    expected={(n,(float(y),float(y+10),float(p),float(p+5))) for n in NAMES
              for y in range(-60,60,10) for p in range(-20,25,5)}
    assert set(groups)==expected and report['accepted_rectangles']==len(report['rows'])
    for key,rows in groups.items():strips+=coverage(rows,key[1])
    source=PARENT/'upper_motion_family_R1/half_grid_inspection.json'
    curves=PARENT/'upper_motion_family_R1/half_grid_curves.npz'
    old=json.loads(source.read_text());assert old['status']=='PASS' and sha(curves)==old['arrays_sha256']
    assert all(sha(p)==h for p,h in old['sources'].items())
    data=np.load(curves);rows=old['rows'];assert len(rows)==1425
    maximum_field=0.;maximum_root_difference=0.;maximum_functional_difference=0.;maximum_roundoff=0.;endpoints_exact=True
    for index,row in enumerate(rows):
        n,y,p=row['wire'],row['yaw_deg'],row['pitch_deg'];pre=f.prepare(n,y,p)
        saved=data[f'{n}_y{y:g}_p{p:g}_controls']
        actual=reconstruct(f,pre,row['amplitude_mm'])
        maximum_roundoff=max(maximum_roundoff,pre['last_endpoint_roundoff_mm'])
        error=float(np.linalg.norm(actual-saved,axis=-1).max())
        assert error<1e-7,(n,y,p,error)
        root=f.root(pre);assert root is not None
        fresh=reconstruct(f,pre,root[0])
        maximum_roundoff=max(maximum_roundoff,pre['last_endpoint_roundoff_mm'])
        difference=float(np.linalg.norm(fresh-saved,axis=-1).max())
        assert difference<1e-7,(n,y,p,difference)
        endpoints_exact&=bool(np.array_equal(fresh[[0,-1],[0,-1]],saved[[0,-1],[0,-1]]))
        residual=abs(f.value(pre,row['amplitude_mm'])[0]-pre['target'])
        assert residual<2e-8,(n,y,p,residual)
        maximum_field=max(maximum_field,error);maximum_root_difference=max(maximum_root_difference,difference)
        maximum_functional_difference=max(maximum_functional_difference,residual)
        if index%250==0:print('POWER_FIELD_READBACK',index,maximum_root_difference,flush=True)
    assert endpoints_exact
    # Off-grid source-family evaluations, additional to the saved half-grid.
    probes=[(-57.3,-18.4),(-42.4,3.7),(-5.7,-.3),(2.5,1.25),(17.4,11.3),(52.7,23.9)]
    offgrid=[];enclosure_checks=0
    for y,p in probes:
        ya=np.floor((y+60)/10)*10-60;pa=np.floor((p+20)/5)*5-20
        rectangle=(float(ya),float(ya+10),float(pa),float(pa+5))
        for n in NAMES:
            pre=f.prepare(n,y,p);root=f.root(pre);assert root is not None
            original,info=f.f.upper(n,y,p);assert original is not None,(n,y,p,info)
            fresh=reconstruct(f,pre,root[0]);difference=float(np.linalg.norm(fresh-original,axis=-1).max())
            assert difference<1e-7,(n,y,p,difference)
            operator=np.r_[np.eye(6),f.Q[::317]]
            bound=f.mapped_controls(n,rectangle,operator)
            exact=operator@pre['control']
            assert np.all(exact>=bound.lo-1e-9) and np.all(exact<=bound.hi+1e-9),(n,y,p)
            enclosure_checks+=len(exact)
            offgrid.append(dict(wire=n,yaw_deg=y,pitch_deg=p,maximum_control_difference_mm=difference,
                                length_residual_mm=root[1],status='PASS'))
    baseline=PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json'
    b=json.loads(baseline.read_text())
    protected={n:h for n,h in b['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
    f.sources.update({str(p):sha(p) for p in [Path(__file__),path,source,curves,baseline]})
    f.unchanged()
    out=dict(status='PASS',scope='Complete angular partition and three power/CC mathematical reference fields; no native clearance or physical wiring qualification',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=f.sources,
        accepted_rectangles=report['accepted_rectangles'],independent_y_slab_coverage_checks=strips,
        finite_source_curve_poses=1425,maximum_existing_field_difference_mm=maximum_field,
        maximum_fresh_root_curve_difference_mm=maximum_root_difference,
        maximum_source_functional_residual_mm=maximum_functional_difference,
        maximum_endpoint_roundoff_repair_mm=maximum_roundoff,
        saved_source_endpoints_exact=endpoints_exact,offgrid_source_comparisons=offgrid,
        direct_offgrid_enclosure_points=enclosure_checks,protected_hardware_files=len(protected),
        source_blend_sha256=sha(PROJECT/'mechanical/mori_v1_2.blend'),
        source_video_sha256=sha(PROJECT/'mechanical/animation/MORI_assembly.mp4'),
        native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',CAM_continuous_math='NOT_TESTED',
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'power_math_readback.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_MATH_READBACK_TERMINAL','PASS',report['accepted_rectangles'],strips,1425,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
