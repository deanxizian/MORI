"""Independent scalar-hull and cubic-restriction implementation probes."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/'cam_native_clearance_review_R1')]
from cam_native_envelopes import Box
from fan_geometry import matrix,half,refine
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def evaluate(c,t):
    t=np.asarray(t,float)
    return ((1-t)**3)[:,None]*c[0]+(3*t*(1-t)**2)[:,None]*c[1]+(3*t*t*(1-t))[:,None]*c[2]+(t**3)[:,None]*c[3]


def main():
    rng=np.random.default_rng(20261010);comparisons=0;restrictions=0;rows=[]
    for seed in range(12):
        ac=rng.uniform(-10,10,(8,4,3));bc=rng.uniform(-10,10,(13,4,3))
        aw=rng.uniform(0,.02,ac.shape);bw=rng.uniform(0,.02,bc.shape)
        a=Box(ac-aw,ac+aw);b=Box(bc-bw,bc+bw)
        actual=matrix(a,b,.6604)
        for i in range(len(ac)):
            for j in range(len(bc)):
                delta=[]
                for k in range(3):
                    delta.append(max(float(b.lo[j,:,k].min()-a.hi[i,:,k].max()),
                                     float(a.lo[i,:,k].min()-b.hi[j,:,k].max()),0.))
                expected=math.sqrt(sum(v*v for v in delta))-.6604-.0001
                assert abs(float(actual[i,j])-expected)<1e-12
                comparisons+=1
        for i in range(len(ac)):
            selected=ac[i]+rng.uniform(-1,1,(4,3))*aw[i]
            children=half(a[i]);t=np.linspace(0,1,129)
            for index,child in enumerate(children):
                samples=evaluate(selected,(t+index)/2)
                lo,hi=child.lo.min(0),child.hi.max(0)
                assert np.all(samples>=lo-1e-12) and np.all(samples<=hi+1e-12)
                # Check the actual restricted controls at u=0,1/3,2/3,1
                # via direct cubic endpoint/derivative formulas.
                start=index/2;finish=(index+1)/2
                p,q=evaluate(selected,np.array([start,finish]))
                velocity=lambda u:3*((1-u)**2*(selected[1]-selected[0])+2*u*(1-u)*(selected[2]-selected[1])+u*u*(selected[3]-selected[2]))
                expected=np.array([p,p+(finish-start)*velocity(start)/3,
                                   q-(finish-start)*velocity(finish)/3,q])
                assert np.all(expected>=child.lo-1e-12) and np.all(expected<=child.hi+1e-12)
                restrictions+=1
    def circle(r):
        angle=.2;u=np.array([1.,0.,0.]);v=np.array([0.,1.,0.])
        p=r*u;q=r*(math.cos(angle)*u+math.sin(angle)*v)
        return np.array([p,p+r*angle*v/3,
                         q-r*angle*(-math.sin(angle)*u+math.cos(angle)*v)/3,q])
    a,b=Box(circle(7)),Box(circle(8))
    checked=refine(a,b,.6604)
    assert checked['status']=='PASS' and len(checked['accepted'])>1
    t=np.linspace(0,1,513);pa=evaluate(circle(7),t);pb=evaluate(circle(8),t)
    finite=float(np.linalg.norm(pa[:,None]-pb[None],axis=2).min())-.6604-.0001
    assert checked['gap_lower_mm']<=finite+1e-10 and finite>=.3
    rows.append(dict(case='radially_offset_cubics_requiring_parameter_refinement',status='PASS',
                     complete_bound_mm=checked['gap_lower_mm'],sampled_gap_mm=finite,
                     parameter_rectangles=len(checked['accepted'])))
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Scalar all-pair hull and independently derived restriction probes; not route proof',
        sources={str(p):sha(p) for p in [Path(__file__),HERE/'fan_geometry.py']},
        scalar_hull_pairs_compared=comparisons,restricted_control_boxes_compared=restrictions,rows=rows,
        all_angle_CAM_peer='NOT_TESTED',main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'fan_geometry_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FAN_GEOMETRY_CHECK_PASS',comparisons,restrictions,len(checked['accepted']),flush=True)


if __name__=='__main__':main()
