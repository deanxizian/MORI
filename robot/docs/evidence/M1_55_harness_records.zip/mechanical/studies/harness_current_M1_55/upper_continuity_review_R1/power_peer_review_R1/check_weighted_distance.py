"""Independent brute force checks of weighted KD/exclusion-sphere bounds."""
from pathlib import Path
import datetime,json,sys,time
import numpy as np
sys.path.insert(0,'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
from weighted_peer import field,score
from hashlib import sha256
HERE=Path(__file__).resolve().parent
sha=lambda p:sha256(Path(p).read_bytes()).hexdigest()

def main():
    started=time.time();rng=np.random.default_rng(550073);rows=[]
    # Variable radii include remote centres that outrank the nearest64 centres.
    for case in range(12):
        a=rng.normal(size=(300,3));b=rng.normal(size=(500,3))
        if case%3==0:b+=np.array([5.,0,0])
        ra=rng.uniform(0,.8,len(a));rb=rng.uniform(0,2.,len(b));rsum=.5
        value=score(field(a,b),ra,rb,rsum)
        brute=np.linalg.norm(a[:,None,:]-b[None,:,:],axis=-1)-ra[:,None]-rb[None,:]-rsum-.0001
        exact=brute.min(1);excess=float(np.max(value['lower']-exact))
        assert excess<=1e-10,(case,excess)
        if value['gap_lower_mm']>=.3:assert exact.min()>=.3
        rows.append(dict(case=case,status='PASS',maximum_lower_minus_exact_mm=excess,
                         exact_ball_gap_min_mm=float(exact.min()),reported_gap_lower_mm=value['gap_lower_mm'],
                         exclusion_sphere_queries=value['exclusion_sphere_queries'],candidate_pairs_checked=value['candidate_pairs_checked']))
    result=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                scope='Synthetic independent all-pair distance comparison; not reference route clearance',
                sources={str(p):sha(p) for p in [Path(__file__),HERE/'weighted_peer.py']},rows=rows,
                exact_pairs_compared=12*300*500,required_gap_mm=.3,main_changed=False,hardware_changed=False,
                manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'weighted_distance_crosscheck.json').write_text(json.dumps(result,indent=2)+'\n')
    print('WEIGHTED_DISTANCE_BRUTE_PASS',len(rows),12*300*500,round(result['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
