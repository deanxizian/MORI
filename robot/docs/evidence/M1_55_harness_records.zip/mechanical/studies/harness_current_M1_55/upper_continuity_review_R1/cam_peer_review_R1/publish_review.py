"""Publish the combined complete nominal four-CAM mutual clearance proof."""
from pathlib import Path
import datetime
import hashlib
import html
import json
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    proof=read(HERE/'combined_peer_verification.json')
    audit=read(HERE/'combined_peer_coverage_verification.json')
    assert proof['status']==audit['status']==proof['continuous_nominal_CAM_mutual']=='PASS'
    sources=proof['sources']|audit['sources']
    for p in [Path(__file__),HERE/'combined_peer_verification.json',HERE/'combined_peer_coverage_verification.json']:
        sources[str(p)]=sha(p)
    assert all(sha(p)==h for p,h in sources.items())
    table='\n'.join(f"<tr><td>{html.escape(' / '.join(r['wires']))}</td><td>{r['complete_cubic_piece_products']:,}</td>"
                    f"<td>{r['fan_fan_products']:,}</td><td>{r['fixed_tail_tail_products']:,}</td>"
                    f"<td>{r['all_remaining_products']:,}</td><td>PASS</td></tr>" for r in audit['results'])
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM 全范围互线检查</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1060px;margin:40px auto;padding:0 22px;color:#232c30}}table{{border-collapse:collapse;width:100%}}th,td{{padding:9px;border:1px solid #ccd3d6;text-align:left}}a{{color:#20526c}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #6b767a}}</style>
<h1>四条 CAM 上段：全范围互线检查</h1>
<p class="scope">PROTOTYPE / UNVALIDATED · 六组名义 CAM 上段配对通过。新线束尚未进入主模型或视频；与电源／CC的跨组配对、活动段自身、上下接续、实际端接及带线装配仍未完成。</p>
<p>覆盖偏航 −60°～+60°、俯仰 −20°～+25°和每条曲线的完整闭参数。独立核对三类互不重叠且无遗漏的曲线段配对：扇出／扇出、固定尾线／固定尾线、全部其他组合。保持原0.3 mm间隙要求。</p>
<table><thead><tr><th>线路配对</th><th>全部三次段组合</th><th>扇出组合</th><th>固定尾线组合</th><th>其他组合</th><th>检查</th></tr></thead><tbody>{table}</tbody></table>
<p>扇出段在理想偏航坐标系中不依赖俯仰或长度补偿高度，已做源依赖核对；{audit['fan_accepted_yaw_intervals']}个偏航区间和{audit['fan_parameter_refinement_rectangles']:,}个参数细分区间通过。固定尾线在理想俯仰坐标系内固定，每条16,000个闭参数区间另检。其他全部组合使用648个数学角度父区间，六组配对共3,888条全范围记录通过。</p>
<p>证明下界保守截断在0.3 mm，不代表实际最小线距。只适用于当前四条名义 CAM 上段，不能推广到全部七条上段、真实材料、实际接头或完整装机。CAM与电源／CC之间的12组配对仍NOT_TESTED；活动段自身和自身接续仍NOT_TESTED。</p>
<p>早期整段球包络在固定尾线处未能判定，记录保留；首轮参考点间隙没有低于目标。固定轴细分试算后来停止，由同范围的自适应试点和独立覆盖替代。最终结果来自三个完整范围证明的合并，没有降低要求或移动硬件。</p>
<p><a href="combined_peer_verification.json">合并结果</a> · <a href="combined_peer_coverage_verification.json">独立完整分类核对</a> · <a href="fan_coverage_verification.json">扇出角度及参数覆盖</a> · <a href="fan_independence_verification.json">俯仰独立的源核对</a> · <a href="remaining_hull_coverage_verification.json">其他组合的全角度覆盖</a> · <a href="commands.json">实际命令</a> · <a href="../cam_self_review_R1/index.html">固定尾线自身检查</a> · <a href="../index.html">检查总览</a></p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# Complete nominal four-CAM-upper mutual clearance

PASS: six unordered CAM-upper pairs over yaw[-60,60], pitch[-20,25],
and both complete cubic parameters. Separate exhaustive categories:

1. Fan/fan: guarded source construction is pitch/height independent in
   the ideal yaw frame. All-yaw hull and complete parameter refinement proof.
2. Fixed tail/tail: invariant in the ideal pitch frame;16,000 closed cells
   per reference and explicit AABB/centre-sphere separation.
3. All other mixed/loop products:648 mathematical angular parents,3,888
   pair/angular rows; complete cubic control hulls in two valid rigid frames.

Independent category enumeration confirms an exhaustive, disjoint cover.
The target-capped0.3mm lower bound is not a measured minimum separation.

Still incomplete:12 CAM/power/CC upper cross pairs, moving self, own prefix,
actual materials/terminals/slack, wired insertion and closure. No main-model,
hardware or animation adoption. Full harness BLOCKED; manufacturing false.

Initial whole-curve-ball BLOCKED and stopped fixed-axis pilot are retained.
The adaptive pilot covers the same windows but is not itself the full proof.
The fan generator's inline cache-policy comment is only a construction note;
its implementation recomputes the two controls for each pair/interval.
''')
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
           and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json']}
    receipt=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources=sources,files=files,continuous_nominal_CAM_mutual='PASS',unordered_pairs=6,
        fan_accepted_yaw_intervals=audit['fan_accepted_yaw_intervals'],
        fan_parameter_refinement_rectangles=audit['fan_parameter_refinement_rectangles'],
        mixed_pair_angular_rows=3888,mixed_parent_rectangles=648,
        minimum_certified_gap_lower_mm=audit['minimum_certified_gap_lower_mm'],required_gap_mm=.3,
        CAM_power_cross_pairs='NOT_TESTED',moving_self='NOT_TESTED',own_prefix='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('CAM_MUTUAL_PUBLICATION_PASS',len(files),len(sources),flush=True)


if __name__=='__main__':main()
