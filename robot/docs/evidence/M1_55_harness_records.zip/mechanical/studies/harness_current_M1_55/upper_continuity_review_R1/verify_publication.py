"""Check published evidence, source/file hashes and actual local served bytes."""
from pathlib import Path
import datetime
import hashlib
import json
import re
from urllib.parse import urlsplit,unquote,quote
from urllib.request import Request,urlopen

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    delivery=read(HERE/'delivery.json')
    assert delivery['status']=='PASS' and delivery['full_harness']=='BLOCKED'
    assert delivery['accepted_rectangles']==18095
    assert delivery['continuous_native_clearance']=='PASS' and delivery['native_angular_rectangles']==19068
    assert delivery['native_parts']==201 and delivery['whole_parameter_cells']==9216
    assert delivery['continuous_peer_clearance']==delivery['continuous_CAM_math']=='PASS'
    assert delivery['power_peer_unordered_pairs']==3
    assert delivery['power_continuous_remote_self']==delivery['known_upper_continuous_remote_self']=='PASS'
    assert delivery['known_upper_remote_self_references']==7 and delivery['power_self_angular_rectangles']==418
    assert delivery['CAM_positive_length_rectangles']==2592 and delivery['CAM_bending_yaw_intervals']==48
    assert delivery['CAM_saved_curve_readbacks']==1900
    assert delivery['CAM_continuous_native_clearance']==delivery['CAM_continuous_peer_clearance']=='PASS'
    assert delivery['CAM_peer_unordered_pairs']==6 and delivery['CAM_power_cross_pairs']=='PASS'
    assert delivery['CAM_power_cross_unordered_pairs']==12
    assert delivery['known_upper_continuous_mutual']=='PASS' and delivery['known_upper_unordered_pairs']==21
    assert delivery['CAM_native_source_math_rectangles']==2592 and delivery['known_upper_native_references']==7
    assert delivery['CAM_fixed_tail_remote_self']=='PASS' and delivery['CAM_fixed_tail_self_parameter_cells']==64000
    assert delivery['CAM_moving_lower_self']==delivery['CAM_continuous_upper_remote_self']=='PASS'
    assert delivery['CAM_own_prefix']==delivery['known_continuous_own_prefix']==delivery['known_continuous_other_prefix']=='PASS'
    assert delivery['prefix_upper_comparisons']==84 and delivery['own_prefix_pairs']==7 and delivery['other_prefix_pairs']==77
    assert delivery['prefix_upper_angular_rectangles']==9072 and delivery['prefix_upper_parameter_rectangles']==4185
    assert delivery['CAM_self_mixed_angular_rectangles']==2592
    assert delivery['unpublished_research_directories']==[]
    for name in ['cam_math_review_R1','power_peer_review_R1','cam_native_clearance_review_R1','cam_moving_self_review_R1','cam_power_cross_review_R1','power_self_review_R1','prefix_upper_join_review_R1']:
        child=read(HERE/name/'delivery.json');verified=read(HERE/name/'publication_verification.json')
        assert child['status']==verified['status']=='PASS'
        assert verified['delivery_sha256']==sha(HERE/name/'delivery.json')
        assert all(sha(p)==h for p,h in child['sources'].items())
        assert all(sha(HERE/name/p)==h for p,h in child['files'].items())
    assert delivery['source_float32_all_angle_rounding']=='NOT_TESTED'
    assert delivery['CAM_tiny_angle_origin_diagnostic']=='PASS' and delivery['CAM_tiny_angle_diagnosed_samples']==8
    assert all(sha(p)==h for p,h in delivery['sources'].items())
    assert all((HERE/p).is_file() and sha(HERE/p)==h for p,h in delivery['files'].items())
    for name in ['initial_triangle_bound','gradient_pilot_before_solver_update','initial_readback_before_endpoint_repair',
                 'readback_endpoint_index_diagnostic','native_clearance_review_R1/initial_module_path']:
        receipt=read(HERE/name/'source_archive_receipt.json')
        assert receipt['status']=='PASS'
        assert all(sha(r['archived'])==r['sha256'] for r in receipt['files'])
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')==delivery['source_blend_sha256']
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')==delivery['source_video_sha256']
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={n:h for n,h in baseline['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
    page=HERE/'index.html';url='http://127.0.0.1:58202/'+quote(str(page.relative_to(PROJECT)))
    with urlopen(url,timeout=10) as response:served=response.read()
    assert hashlib.sha256(served).hexdigest()==sha(page)
    links=[]
    for link in re.findall(r'(?:href|src)="([^"]+)"',page.read_text()):
        parsed=urlsplit(link)
        if parsed.scheme or not parsed.path:continue
        p=(HERE/unquote(parsed.path)).resolve()
        assert p.is_file() and p.is_relative_to(PROJECT),(link,p)
        url='http://127.0.0.1:58202/'+quote(str(p.relative_to(PROJECT)))
        with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
        with urlopen(url,timeout=10) as response:content=response.read()
        assert hashlib.sha256(content).hexdigest()==sha(p)
        links.append(dict(link=link,target=str(p.relative_to(PROJECT))))
    result=dict(status='PASS',scope='Local source/file/publication verification only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        delivery_sha256=sha(HERE/'delivery.json'),files_checked=len(delivery['files']),
        sources_checked=len(delivery['sources']),links=links,served_bytes_equal=True,
        protected_hardware_files=len(protected),main_changed=False,hardware_changed=False,animation_changed=False,
        full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
    (HERE/'publication_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('UPPER_POWER_PUBLICATION_VERIFIED',len(delivery['files']),len(delivery['sources']),len(links),846,flush=True)


if __name__=='__main__':main()
