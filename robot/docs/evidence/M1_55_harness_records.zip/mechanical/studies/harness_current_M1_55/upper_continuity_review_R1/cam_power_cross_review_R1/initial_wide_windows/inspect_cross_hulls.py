"""Read-only cross-group hull diagnostics at three windows and their midpoints."""
from pathlib import Path
import datetime
import itertools
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent/'cam_peer_review_R1')]
from cross_envelopes import CrossEnvelopes, CAM_NAMES, POWER_NAMES, RADII, sha
from fan_geometry import matrix


def main():
    e = CrossEnvelopes()
    windows = [(-60.,-50.,-20.,-19.), (-10.,0.,0.,.03125), (50.,60.,24.,25.)]
    rectangles = windows + [((r[0]+r[1])/2,)*2 + ((r[2]+r[3])/2,)*2 for r in windows]
    rows = []
    for rectangle in rectangles:
        cams = {n:e.cam.certificate(n, rectangle) for n in CAM_NAMES}
        powers = {n:e.power.e.certificate(n, rectangle) for n in POWER_NAMES}
        for a,b in itertools.product(CAM_NAMES, POWER_NAMES):
            if powers[b]['status'] != 'PASS':
                rows.append(dict(wires=[a,b], rectangle_deg=list(rectangle), status='BLOCKED',
                                 reason='Power length branch unresolved', power=powers[b]))
                continue
            bounds = []
            for group in ['yaw','pitch']:
                ac = e.cam_controls(a, rectangle, cams[a], group)
                bc = e.power_controls(b, rectangle, powers[b], group)
                bounds.append(matrix(ac, bc, RADII[a]+RADII[b]))
            lower = np.maximum(*bounds)
            i,j = np.unravel_index(np.argmin(lower), lower.shape)
            rows.append(dict(wires=[a,b], rectangle_deg=list(rectangle),
                             status='PASS' if lower.min() >= .3 else 'BLOCKED',
                             gap_lower_mm=float(lower.min()), unresolved_piece_pairs=int(np.count_nonzero(lower < .3)),
                             worst_piece_indices=[int(i),int(j)],
                             worst_labels=[e.cam.layout[a]['labels'][i], 'neck_stub' if j == 0 else f'polynomial_{j-1}']))
        print('CAM_POWER_CROSS_HULL_WINDOW', list(rectangle), sum(r['status']!='PASS' for r in rows[-12:]), flush=True)
    e.unchanged()
    sources = dict(e.sources)
    for p in [Path(__file__), HERE.parent/'cam_peer_review_R1/fan_geometry.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Diagnostic execution only; individual rows state hull separability, not full-angle clearance',
               sources=sources, rows=rows, required_gap_mm=.3, full_cross_pairs='NOT_TESTED',
               main_changed=False, hardware_changed=False, animation_changed=False, manufacturing_release=False)
    (HERE/'hull_inspection.json').write_text(json.dumps(out, indent=2)+'\n')


if __name__ == '__main__':
    main()
