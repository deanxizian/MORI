"""Fixed-tail parameter coverage, arc reserve and preserved-source audit.

Rebuild canonical cells from the unchanged envelope library, independently of
the proof generator. The dense algorithm cross-check is guarded separately;
this audit does not claim a second execution of every self distance query.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np
HERE = Path(__file__).resolve().parent
MATH = HERE.parent
PROJECT = HERE.parents[4]
sys.path[:0] = [str(MATH/'cam_native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,linear
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p:json.loads(Path(p).read_text())


def main():
    path = HERE/'fixed_tail_verification.json'
    proof = read(path)
    assert proof['status']=='PASS' and all(sha(p)==h for p,h in proof['sources'].items())
    assert proof['required_gap_mm']==.3 and proof['local_arc_exclusion_upper_mm']==5.
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    assert proof['moving_lower_self']==proof['own_prefix']=='NOT_TESTED'
    assert not any(proof[k] for k in ['main_changed','hardware_changed','animation_changed','manufacturing_release'])
    algorithm = read(HERE/'self_box_crosscheck.json')
    assert algorithm['status']=='PASS' and algorithm['dense_remote_pairs_compared']==268861
    assert all(sha(p)==h for p,h in algorithm['sources'].items())
    e = NativeCAMEnvelopes()
    assert [r['wire'] for r in proof['rows']]==NAMES
    counts = []
    for row in proof['rows']:
        name = row['wire']
        assert row['status']=='PASS' and row['gap_lower_mm']>=.3
        assert row['local_curvature']['radius_lower_mm']>=6.9342
        assert row['tail_first_piece']==e.layout[name]['tail_index']
        cells = e.layout[name]['parameter_cells']
        cells = cells[cells[:,0]>=row['tail_first_piece']]
        assert len(cells)==row['parameter_cells']==16000
        checked = 0
        lengths = []
        controls = Box(e.tail[name]-1e-8,e.tail[name]+1e-8)
        for i,M in enumerate(e.operators[name][row['tail_first_piece']:]):
            piece = row['tail_first_piece']+i
            local = cells[cells[:,0]==piece]
            assert len(local)==len(M) and local[0,1]==0 and local[-1,2]==1
            assert np.array_equal(local[:-1,2],local[1:,1])
            assert np.all(local[:,1]<local[:,2])
            differences = M[:,1:]-M[:,:-1]
            interval = linear(differences.reshape(-1,4),controls[i])
            bound = np.maximum(abs(interval.lo),abs(interval.hi)).reshape(-1,3,3)
            lengths.extend((np.linalg.norm(bound,axis=2).sum(1)+1e-9).tolist())
            checked+=len(local)
        arc = np.r_[0.,np.cumsum(lengths)]
        assert np.all(np.diff(arc)>0) and float(arc[-1])==row['whole_tail_arc_upper_mm']
        assert checked==16000 and len(e.tail[name])==130
        counts.append(dict(wire=name,whole_parameter_cells=checked,cubic_pieces=130,
                           arc_upper_mm=float(arc[-1]),status='PASS'))
    e.unchanged()
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    blend = PROJECT/'mechanical/mori_v1_2.blend'
    video = PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(blend)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = dict(proof['sources'])
    for p in [Path(__file__),path,HERE/'self_box_crosscheck.json']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Independent closed fixed-tail parameter coverage and re-built arc-upper sums; guarded self-distance proof',
        sources=sources,rows=counts,whole_parameter_cells=64000,
        minimum_certified_gap_lower_mm=min(r['gap_lower_mm'] for r in proof['rows']),
        required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,protected_hardware_files=846,
        source_blend_sha256=sha(blend),source_video_sha256=sha(video),
        moving_lower_self='NOT_TESTED',own_prefix='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'fixed_tail_coverage_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FIXED_TAIL_SELF_COVERAGE_PASS',len(counts),64000,846,flush=True)


if __name__=='__main__':
    main()
