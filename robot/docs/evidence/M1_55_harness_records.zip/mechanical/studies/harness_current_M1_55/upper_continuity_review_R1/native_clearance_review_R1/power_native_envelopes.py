"""Whole-curve/two-angle position boxes for the existing power/CC references.

Every query centre owns one closed Bezier parameter interval. Its four
restricted controls, not just centre samples, enclose the complete interval.
Native geometry follows the declared ideal nominal yaw/pitch rotations;
the reference family's recorded numerical frame residuals are retained.
"""
from pathlib import Path
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=[str(MATH),'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313']
from power_enclosures import (PowerEnclosures,Box,stacked,magnitude,yaw_box,
                              trigonometric_box,interp,basis,NAMES,sha)
from verify_power_math import reconstruct
from piecewise_geometry import RADII

NUMERIC=1e-8


def restrictions(control,intervals):
    a,b=intervals[:,0],intervals[:,1]
    derivative=3*np.diff(control,axis=0)
    p=basis(a,3)@control;q=basis(b,3)@control
    u=basis(a,2)@derivative;v=basis(b,2)@derivative
    h=(b-a)[:,None]/3
    return np.stack([p,p+h*u,q-h*v,q],axis=1)


def rotate_box(value,lo,hi,axis):
    value=value if isinstance(value,Box) else Box(value)
    sin=trigonometric_box(math.sin,math.radians(lo),math.radians(hi))
    cos=trigonometric_box(math.cos,math.radians(lo),math.radians(hi))
    if axis=='Z':items=[cos*value[:,0]-sin*value[:,1],sin*value[:,0]+cos*value[:,1],value[:,2]]
    else:items=[value[:,0],cos*value[:,1]-sin*value[:,2],sin*value[:,1]+cos*value[:,2]]
    result=stacked(items)
    return Box(result.lo.T,result.hi.T)


def ideal_matrix(center,yaw,pitch):
    y,p=map(math.radians,[yaw,pitch]);cy,sy,cp,sp=math.cos(y),math.sin(y),math.cos(p),math.sin(p)
    A=np.array([[cy,-sy*cp,sy*sp],[sy,cy*cp,-cy*sp],[0.,sp,cp]])
    out=np.eye(4);out[:3,:3]=A;out[:3,3]=center-A@center
    return out


class NativeEnvelopes:
    def __init__(self,poly_steps=64,stub_steps=1024):
        self.e=PowerEnclosures();self.center=self.e.center
        self.sources=dict(self.e.sources)
        self.poly_steps=poly_steps;self.stub_steps=stub_steps
        p=np.linspace(0.,1.,poly_steps+1);pi=np.c_[p[:-1],p[1:]]
        self.poly_intervals=np.stack([restrictions(H,pi) for H in self.e.H]).reshape(-1,4,6)
        self.poly_midpoints=np.stack([basis(pi.mean(1),3)@H for H in self.e.H]).reshape(-1,6)
        s=np.linspace(0.,1.,stub_steps+1);si=np.c_[s[:-1],s[1:]]
        self.stub_intervals=restrictions(np.eye(4),si)
        self.stub_midpoints=basis(si.mean(1),3)
        self.parameter_cells=np.vstack([np.c_[np.zeros(stub_steps),si],
            np.vstack([np.c_[np.full(poly_steps,i+1),pi] for i in range(128)])])
        assert len(self.parameter_cells)==len(self.stub_midpoints)+len(self.poly_midpoints)
        self.sources[str(Path(__file__))]=sha(Path(__file__))
        for path in [MATH/'power_math_verification.json',MATH/'power_math_readback.json',MATH/'endpoint_numeric_reserve.json']:
            import json
            r=json.loads(path.read_text());assert r['status']=='PASS'
            assert all(sha(p)==h for p,h in r['sources'].items())
            self.sources[str(path)]=sha(path)
        self.sources[str(MATH/'verify_power_math.py')]=sha(MATH/'verify_power_math.py')

    def reference(self,name,yaw,pitch):
        pre=self.e.prepare(name,yaw,pitch);root=self.e.root(pre);assert root is not None
        controls=reconstruct(self.e,pre,root[0])
        stub=self.stub_midpoints@controls[0]
        p=np.stack([basis((np.arange(self.poly_steps)+.5)/self.poly_steps,3)@c for c in controls[1:]]).reshape(-1,3)
        points=np.concatenate([stub,p])
        return dict(points=points,controls=controls,amplitude_mm=root[0],length_residual_mm=root[1],
                    yaw_deg=yaw,pitch_deg=pitch)

    def split_local(self,name,rectangle,operator):
        ylo,yhi,plo,phi=rectangle;operator=np.asarray(operator,float).reshape(-1,6)
        samples=[]
        for y in [ylo,yhi]:
            for p in [plo,phi]:
                base=interp(self.e.f.controls[name],y,p)-self.center
                base[4:]=interp(self.e.f.end_residual[name],y,p)
                samples.append(operator@base)
        samples=np.stack(samples)
        F=Box(samples.min(0)-NUMERIC,samples.max(0)+NUMERIC)
        K=operator[:,4:]@(self.e.f.end_canonical[name]-self.center)
        return F,K,operator[:,:4].sum(1),operator[:,4:].sum(1),operator.sum(1)

    def polynomial_boxes(self,name,rectangle,certificate,group):
        ylo,yhi,plo,phi=rectangle;M=self.poly_intervals.reshape(-1,6)
        F,K,first,last,total=self.split_local(name,rectangle,M)
        a=certificate['midpoint_amplitude_mm'];w=certificate['amplitude_deviation_bound_mm']
        F=F+Box(a-w,a+w)*(M@self.e.D)
        if group=='body':
            out=rotate_box(F+rotate_box(K,plo,phi,'X'),ylo,yhi,'Z')
        elif group=='yaw':out=F+rotate_box(K,plo,phi,'X')
        else:out=rotate_box(F,-phi,-plo,'X')+K
        error=self.e.ey*magnitude(F).hi+self.e.et*np.linalg.norm(K,axis=1)+\
              self.e.ty*abs(first)+self.e.tt*abs(last)+NUMERIC
        out=out+total[:,None]*self.center+Box(-error[:,None],error[:,None])
        shape=self.poly_intervals.shape[:2]+(3,)
        return Box(out.lo.reshape(shape),out.hi.reshape(shape))

    def stub_boxes(self,name,rectangle,group):
        ylo,yhi,plo,phi=rectangle
        c,velocity=self.e.inputs(name,*rectangle)
        start=yaw_box(self.e.end_keys[name],ylo,yhi)
        error=(self.e.ey*magnitude(start-self.center).hi+self.e.ty)/(1-self.e.ey)+NUMERIC
        start=start+Box(-error,error)
        M=self.stub_intervals.reshape(-1,4)
        q=(M[:,0]+M[:,1])[:,None]*start+(M[:,2]+M[:,3])[:,None]*c[0]+\
          (M[:,1,None]*velocity[0]-M[:,2,None]*velocity[2])/3
        local=q-self.center
        if group=='body':out=rotate_box(local,ylo,yhi,'Z')
        elif group=='yaw':out=local
        else:out=rotate_box(local,-phi,-plo,'X')
        error=self.e.ey*magnitude(local).hi+self.e.ty+NUMERIC
        out=out+self.center+Box(-error[:,None],error[:,None])
        shape=self.stub_intervals.shape[:2]+(3,)
        return Box(out.lo.reshape(shape),out.hi.reshape(shape))

    def point_boxes(self,name,rectangle,certificate,group):
        a=self.stub_boxes(name,rectangle,group)
        b=self.polynomial_boxes(name,rectangle,certificate,group)
        return Box(np.concatenate([a.lo,b.lo]).min(1),np.concatenate([a.hi,b.hi]).max(1))

    def relative_points(self,reference,group):
        if group=='body':return reference['points']
        mat=ideal_matrix(self.center,reference['yaw_deg'],reference['pitch_deg'] if group=='pitch' else 0.)
        inverse=np.linalg.inv(mat)
        return reference['points']@inverse[:3,:3].T+inverse[:3,3]

    def motion(self,name,rectangle,certificate,reference,group):
        box=self.point_boxes(name,rectangle,certificate,group)
        p=self.relative_points(reference,group)
        return np.linalg.norm(np.maximum(abs(box.lo-p),abs(box.hi-p)),axis=1)+NUMERIC

    def unchanged(self):
        self.e.unchanged();assert all(sha(p)==h for p,h in self.sources.items())
