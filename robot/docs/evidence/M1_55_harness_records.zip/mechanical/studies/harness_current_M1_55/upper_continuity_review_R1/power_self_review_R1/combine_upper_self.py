"""Compose the complete upper-only remote-self scope of all seven known wires."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
NAMES = ['CAM_1','CAM_2','CAM_3','CAM_4','P_J18_1','P_J18_2','CC_allocation']


def main():
    paths = [ROOT/'cam_moving_self_review_R1/combined_self_coverage_verification.json',
             HERE/'self_coverage_verification.json']
    reports = [read(p) for p in paths]
    sources = {}
    for report in reports:
        assert report['status']=='PASS' and report['required_gap_mm']==.3
        assert report['local_arc_exclusion_upper_mm']==5.
        for p,h in report['sources'].items():
            assert sha(p)==h and (p not in sources or sources[p]==h)
            sources[p] = h
    cam,power = reports
    assert cam['continuous_nominal_CAM_upper_remote_self']=='PASS' and cam['references']==4
    assert power['mode']=='all_angles' and power['power_upper_remote_self']=='PASS' and power['references']==3
    rows = []
    for group,report in [('CAM',cam),('power_CC',power)]:
        for row in report['results']:
            assert row['status']=='PASS'
            pieces = row.get('cubic_pieces',row.get('canonical_cubic_pieces'))
            assert row['complete_unordered_piece_pairs']==pieces*(pieces+1)//2
            rows.append(dict(wire=row['wire'],status='PASS',group=group,cubic_pieces=pieces,
                             complete_unordered_piece_pairs=row['complete_unordered_piece_pairs']))
    assert [r['wire'] for r in rows]==NAMES
    for p in [Path(__file__),*paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Complete nominal upper-only remote-self of seven known references; body-prefix joins and real wires excluded',
               sources=sources,results=rows,references=7,yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
               required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,
               known_upper_continuous_remote_self='PASS',own_prefix='NOT_TESTED',missing_actual_upper_endpoint_references=5,
               full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'complete_upper_self_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('KNOWN_UPPER_SELF_COMBINED_PASS',7,flush=True)


if __name__ == '__main__':
    main()
