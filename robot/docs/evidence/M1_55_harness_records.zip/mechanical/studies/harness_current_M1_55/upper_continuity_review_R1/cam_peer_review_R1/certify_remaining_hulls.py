"""Full-angle complete-cubic hull bounds for rest/rest and fan/rest pairs.

This uses the same guarded CAM control enclosures and no curve samples. A
passing whole-piece hull pair certifies all of its two curve parameters;
unresolved hulls require refinement and are not a collision finding.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/'cam_native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,RADII,sha


def main():
    e=NativeCAMEnvelopes()
    selected=list(range(len(e.parents[NAMES[0]])))
    assert len(selected)==648
    assert all([r['rectangle_deg'] for r in e.parents[n]]==[r['rectangle_deg'] for r in e.parents[NAMES[0]]] for n in NAMES)
    rows=[]
    for index in selected:
        rectangle=e.parents[NAMES[0]][index]['rectangle_deg']
        enclosures={}
        for name in NAMES:
            c=e.parents[name][index]
            h=Box(c['height_lower_mm'],c['height_upper_mm'])
            for group in ['yaw','pitch']:
                box=e.controls(name,rectangle,h,group)[0]
                enclosures[name,group]=box.lo.min(1),box.hi.max(1)
        for pair in itertools.combinations(NAMES,2):
            bounds=[];matrices=[]
            for group in ['yaw','pitch']:
                al,ah=enclosures[pair[0],group];bl,bh=enclosures[pair[1],group]
                delta=np.maximum(np.maximum(bl[None]-ah[:,None],al[:,None]-bh[None]),0.)
                lower=np.linalg.norm(delta,axis=2)-sum(RADII[n] for n in pair)-.0001
                lower[e.layout[pair[0]]['tail_index']:,e.layout[pair[1]]['tail_index']:]=np.inf
                af=e.layout[pair[0]]['labels'].index('pitch_shift_first_0')
                bf=e.layout[pair[1]]['labels'].index('pitch_shift_first_0')
                lower[:af,:bf]=np.inf
                matrices.append(lower)
                i,j=np.unravel_index(np.argmin(lower),lower.shape)
                bounds.append(dict(group=group,gap_lower_mm=float(lower.min()),
                    unresolved_piece_pairs=int(np.count_nonzero(lower<.3)),
                    worst_pieces=[int(i),int(j)],
                    worst_labels=[e.layout[n]['labels'][k] for n,k in zip(pair,[i,j])]))
            row=dict(wires=list(pair),source_math_parent_index=index,rectangle_deg=rectangle,
                     status='PASS' if np.maximum(*matrices).min()>=.3 else 'BLOCKED',frames=bounds,combined_frame_gap_lower_mm=float(np.maximum(*matrices).min()))
            rows.append(row)
        if (index+1)%36==0:print('CAM_REST_HULL_PROGRESS',index+1,len(rows),sum(r['status']!='PASS' for r in rows),flush=True)
        if any(r['status']!='PASS' for r in rows):break
    print('CAM_REST_HULL_TERMINAL','PASS' if len(rows)==648*6 and all(r['status']=='PASS' for r in rows) else 'BLOCKED',len(rows),flush=True)
    e.unchanged()
    sources=dict(e.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    (HERE/'remaining_hull_verification.json').write_text(json.dumps(dict(
        status='PASS' if len(rows)==648*6 and all(r['status']=='PASS' for r in rows) else 'BLOCKED',scope='Full nominal yaw/pitch root-cover rest/rest and fan/rest complete-cubic hulls only; fan/fan and fixed-tail pairs remain separate proofs',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,rows=rows,
        rest_and_mixed_piece_pairs='PASS' if len(rows)==648*6 and all(r['status']=='PASS' for r in rows) else 'BLOCKED',source_math_parent_rectangles=648,required_gap_mm=.3,fan_fan_full_yaw='NOT_TESTED',complete_CAM_mutual='NOT_TESTED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')


if __name__=='__main__':main()
