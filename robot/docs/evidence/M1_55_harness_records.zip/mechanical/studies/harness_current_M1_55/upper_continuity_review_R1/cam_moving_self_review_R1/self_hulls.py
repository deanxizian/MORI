"""Complete parameter-product remote-self bounds with a proved local arc cap."""
import numpy as np
from arc_speed_bounds import arc_upper
from fan_geometry import half,bound


def refine(a,b,densities,i,j,radius,max_depth=14):
    if not isinstance(a,list):a=[a];b=[b]
    assert len(a)==len(b)
    pending=[(a,b,(0.,1.,0.,1.),0)];accepted=[];visited=0
    while pending:
        ca,cb,rectangle,depth=pending.pop();visited+=1
        local=arc_upper(densities,i,j,rectangle)
        if local<=5.:
            accepted.append(dict(parameter_rectangle=list(rectangle),method='local_arc',arc_upper_mm=local))
            continue
        gap=max(bound(x,y,2*radius) for x,y in zip(ca,cb))
        if gap>=.3:
            accepted.append(dict(parameter_rectangle=list(rectangle),method='complete_hull',gap_lower_mm=gap))
            continue
        if depth>=max_depth:
            return dict(status='BLOCKED',unresolved_parameter_rectangle=list(rectangle),
                        arc_upper_mm=local,gap_lower_mm=gap,visited=visited)
        ta,tb,ua,ub=rectangle
        # Balance actual parameter arc upper widths, not the angular inflation
        # of spatial boxes. Both children remain included.
        if densities[i]*(tb-ta)>=densities[j]*(ub-ua):
            children=[half(c) for c in ca];left=[c[0] for c in children];right=[c[1] for c in children];t=(ta+tb)/2
            pending.extend([(left,cb,(ta,t,ua,ub),depth+1),(right,cb,(t,tb,ua,ub),depth+1)])
        else:
            children=[half(c) for c in cb];left=[c[0] for c in children];right=[c[1] for c in children];u=(ua+ub)/2
            pending.extend([(ca,left,(ta,tb,ua,u),depth+1),(ca,right,(ta,tb,u,ub),depth+1)])
    return dict(status='PASS',accepted=accepted,visited=visited)
