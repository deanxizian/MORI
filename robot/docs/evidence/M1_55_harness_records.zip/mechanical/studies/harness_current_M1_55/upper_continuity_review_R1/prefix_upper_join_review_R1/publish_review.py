"""Publish only the independently audited nominal prefix-upper scope."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
NUMERIC_PYTHON = '/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'


def main():
    audit = read(HERE/'join_coverage_verification.json')
    assert audit['status']=='PASS' and audit['mode']=='all_angles'
    assert audit['comparisons']==84 and audit['own_prefix_pairs']==7 and audit['other_prefix_pairs']==77
    assert audit['own_prefix']==audit['other_prefix']=='PASS' and audit['full_harness']=='BLOCKED'
    sources = dict(audit['sources'])
    versions = json.loads(subprocess.check_output([NUMERIC_PYTHON,'-c',
        "import sys,json,numpy;sys.path[:0]=['/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313','/Users/dean/.cache/codex-runtimes/mori-harness-mpmath'];import scipy,mpmath;print(json.dumps(dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,mpmath=mpmath.__version__)))"],text=True))
    commands = dict(numeric_python=NUMERIC_PYTHON,versions=versions,
                    commands=[
        dict(script='check_prefix_envelopes.py',arguments=[],log='prefix_envelope_check.log',exit_code=0,scope='180 finite original-prefix implementation probes'),
        dict(script='certify_join_hulls.py',arguments=['--pilot','--own-only'],log='own_pilot.log',exit_code=0,scope='seven own joins in three angular windows'),
        dict(script='check_join_sources.py',arguments=[],log='join_source_check.log',exit_code=0,scope='105 finite original-source endpoint/tangent/derivative probes'),
        dict(script='verify_join_coverage.py',arguments=['--pilot','--own-only'],log='own_pilot_audit.log',exit_code=0,scope='independent pilot coverage; initial ordering assumption failure retained separately'),
        dict(script='certify_join_hulls.py',arguments=[],log='join_full.log',exit_code=0,scope='all 84 comparisons over complete nominal yaw/pitch and curve parameters'),
        dict(script='verify_join_coverage.py',arguments=[],log='join_full_audit.log',exit_code=0,scope='independent full source-union, angular and parameter coverage'),
                    ],full_harness='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    for p in [Path(__file__),HERE/'join_coverage_verification.json',HERE/'commands.json']:
        sources[str(p)] = sha(p)
    assert all(sha(p)==h for p,h in sources.items())
    own = [r for r in audit['results'] if r['own_prefix']]
    table = ''.join(f"<tr><td>{r['upper']}</td><td>{r['angular_rectangles']}</td><td>PASS</td></tr>" for r in own)
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 上下段接续与跨线检查</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:32px auto;padding:0 22px;color:#24313a}}table{{width:100%;border-collapse:collapse}}td,th{{padding:10px;border:1px solid #cbd3d9;text-align:left}}a{{color:#22536b}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #747f82}}</style>
<h1>身体前段与已知上段：接续和完整跨线检查</h1>
<p class="scope">PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED · 独立线束容量参考，尚未进入主模型或视频。完整线束 BLOCKED。</p>
<p>七条已知上段与十二条身体／颈部前段的84组比较覆盖完整名义偏航−60°～+60°、俯仰−20°～+25°及闭曲线参数，PASS。分为7组同一线路上下段的非局部自身接近，以及77组其他前段的互线间隙。</p>
<table><thead><tr><th>同一线路的接续</th><th>独立核对角度区间</th><th>状态</th></tr></thead><tbody>{table}</tbody></table>
<p>独立覆盖核对共{audit['angular_rectangles']:,}个角度区间，必要组合另有{audit['parameter_rectangles']:,}个完整二维曲线参数区间。每条身体前段45段三次曲线；CAM上段237或238段，电源／CC上段129段。源长度根范围按全部相交父区间重建，角度与参数覆盖无遗漏或重叠。</p>
<p>原0.3mm保守间隙目标保持。两侧分别使用源线径参考：CAM身体段半径0.565mm、头内上段0.3302mm；这不代表真实粗细线接续已经设计。局部排除只用于同一根线，且整个区间弧长上界≤5mm，计入各数值连接余量；其他前段不使用局部排除。</p>
<p>另有180个原身体曲线姿态、540次完整控制包络实现核对，以及105个原上段构造的端点／切向／速度核对，均通过。这些有限样本是实现核对，完整范围来自上述连续包络和覆盖证明。</p>
<p>仍待完成：五条缺实际端点的上段、实际线材及接续／裁线尺寸、配对端子和应力释放、完整带线装入与闭壳。既有前段和上段分别通过的检查现已补上本页接续范围；不据此放行真实线束、供应商裁线或整机制造。</p>
<p>主模型、视频及846个受保护硬件文件保持，manufacturing_release=false。初次覆盖审计误把源记录顺序当作时间顺序；诊断已保留，复核改为排序副本，源索引和曲线均保持。</p>
<p><a href="join_verification.json">完整84组数值检查</a> · <a href="join_coverage_verification.json">独立完整覆盖</a> · <a href="prefix_envelope_crosscheck.json">前段实现核对</a> · <a href="join_source_crosscheck.json">原端点与导数核对</a> · <a href="commands.json">实际命令与版本</a> · <a href="initial_parent_order_audit/diagnostic.json">初次审计诊断</a> · <a href="../index.html">上段研究总览</a> · <a href="../../index.html">完整线束待办</a></p></html>''')
    (HERE/'README.md').write_text(f'''# M1.55 nominal prefix-upper joins

All84 combinations of12 body/neck prefixes and7 known uppers PASS over
nominal yaw -60..60 / pitch -20..25 and complete closed curve parameters:
7 own-prefix remote-self joins and77 other-prefix mutual comparisons.
Independent root/angle/parameter coverage:PASS,{audit['angular_rectangles']}
angular rectangles / {audit['parameter_rectangles']} refined parameter rectangles.

Every prefix has45 canonical cubics; CAM uppers have237/238, power/CC129.
The original0.3mm target is unchanged. Each side uses its own allocation
radius, including CAM body0.565mm and upper0.3302mm. This does not define
an actual wire/splice. Only own joins exclude full arc upper<=5mm, with
arithmetic join reserves.180 original-prefix source poses /540 control
comparisons and105 original-upper endpoint/tangent/derivative probes PASS.

Five upper endpoints, actual mixed materials/splices/cut lengths, matching
connectors, restraints/strain relief and full wired assembly/closure remain
BLOCKED. No main, animation, hardware change or manufacturing release.
The initial independent audit's source-order assumption failure is retained;
coverage sorts a copy while preserving original source indices.
''')
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               sources=sources,files=files,prefix_upper_comparisons=84,own_prefix_pairs=7,other_prefix_pairs=77,
               prefix_upper_angular_rectangles=audit['angular_rectangles'],
               prefix_upper_parameter_rectangles=audit['parameter_rectangles'],
               continuous_own_prefix='PASS',continuous_other_prefix='PASS',known_upper_references=7,prefix_references=12,
               required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,actual_transitions='BLOCKED',full_harness='BLOCKED',
               protected_hardware_files=846,main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_UPPER_PUBLICATION_PASS',len(files),len(sources),84,flush=True)


if __name__=='__main__':
    main()
