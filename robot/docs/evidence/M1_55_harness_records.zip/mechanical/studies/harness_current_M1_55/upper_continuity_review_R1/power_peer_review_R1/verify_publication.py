"""Verify peer proof publication, guarded evidence, and local served bytes."""
from pathlib import Path
from urllib.parse import unquote, urlsplit, quote
from urllib.request import urlopen
import datetime
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    delivery = read(HERE/'delivery.json')
    assert delivery['status'] == 'PASS' and delivery['continuous_power_peer_clearance'] == 'PASS'
    assert delivery['unordered_pairs'] == 3 and delivery['full_harness'] == 'BLOCKED'
    assert delivery['required_gap_mm'] == .3 and not delivery['manufacturing_release']
    assert delivery['remote_self'] == delivery['CAM_upper'] == 'NOT_TESTED'
    assert all(sha(p) == h for p,h in delivery['sources'].items())
    assert all((HERE/p).is_file() and sha(HERE/p) == h for p,h in delivery['files'].items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend') == delivery['source_blend_sha256']
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4') == delivery['source_video_sha256']
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT/p) == h for p,h in protected.items())
    page = HERE/'index.html'
    targets = [page]
    links = []
    for link in re.findall(r'(?:href|src)="([^"]+)"',page.read_text()):
        parsed = urlsplit(link)
        if parsed.scheme or not parsed.path:
            continue
        target = (HERE/unquote(parsed.path)).resolve()
        assert target.is_file() and target.is_relative_to(PROJECT)
        targets.append(target)
        links.append(dict(link=link,target=str(target.relative_to(PROJECT))))
    for target in targets:
        url = 'http://127.0.0.1:58202/'+quote(str(target.relative_to(PROJECT)))
        with urlopen(url,timeout=15) as response:
            content = response.read()
        assert hashlib.sha256(content).hexdigest() == sha(target)
    out = dict(status='PASS',scope='Publication/source preservation and served-byte checks only',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),delivery_sha256=sha(HERE/'delivery.json'),
               files_checked=len(delivery['files']),sources_checked=len(delivery['sources']),links=links,
               served_bytes_equal=True,protected_hardware_files=846,main_changed=False,hardware_changed=False,
               animation_changed=False,full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
    (HERE/'publication_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PEER_PUBLICATION_VERIFIED',len(delivery['files']),len(delivery['sources']),len(links),flush=True)


if __name__ == '__main__':
    main()
