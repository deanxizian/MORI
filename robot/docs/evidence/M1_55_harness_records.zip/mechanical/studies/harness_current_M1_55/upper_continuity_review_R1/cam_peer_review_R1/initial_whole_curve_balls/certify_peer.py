"""Complete-parameter mutual clearance of the four precision-safe CAM uppers.

All four mathematical parent partitions are identical and verified before
reuse. Shared references and enclosure calculations reduce duplicate work;
each of the six unordered wire pairs must pass in an identical rigid frame.
No printed geometry, reference curves, diameters, or clearance target changes.
"""
from pathlib import Path
from collections import OrderedDict
import datetime
import itertools
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
MATH = HERE.parent
NATIVE = MATH/'cam_native_clearance_review_R1'
POWER_PEER = MATH/'power_peer_review_R1'
sys.path[:0] = [str(NATIVE),str(POWER_PEER),
               '/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313']
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,RADII,sha
from weighted_peer import field,score

GAP = .3
NUMERIC = .0001
PAIRS = list(itertools.combinations(NAMES,2))


def retain(cache,key,value,limit):
    cache[key] = value
    cache.move_to_end(key)
    while len(cache)>limit:
        cache.popitem(last=False)
    return value


def clip(box,window):
    r = (max(box[0],window[0]),min(box[1],window[1]),
         max(box[2],window[2]),min(box[3],window[3]))
    return r if r[0]<r[1] and r[2]<r[3] else None


def main():
    started = time.time()
    pilot = '--pilot' in sys.argv
    e = NativeCAMEnvelopes()
    cross_paths = [NATIVE/'envelope_crosscheck.json',
                   POWER_PEER/'weighted_single_crosscheck.json']
    for p in cross_paths:
        q = json.loads(p.read_text())
        assert q['status']=='PASS' and all(sha(f)==h for f,h in q['sources'].items())
    assert all([q['rectangle_deg'] for q in e.parents[n]]==
               [q['rectangle_deg'] for q in e.parents[NAMES[0]]] for n in NAMES)
    sources = dict(e.sources)
    for p in [Path(__file__),POWER_PEER/'weighted_peer.py',*cross_paths]:
        sources[str(p)] = sha(p)
    windows = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),
               (50.,60.,24.,25.)] if pilot else [(-60.,60.,-20.,25.)]
    references = OrderedDict()
    fields = OrderedDict()
    counters = dict(reference_constructions=0,fields_created=0,
                    anchor_distance_queries=0,new_root_enclosures=0,
                    visited_rectangles=0,motion_fields=0,
                    exclusion_sphere_queries=0,candidate_pairs_checked=0)
    def reference(name,pose):
        key = (name,*pose)
        if key not in references:
            counters['reference_constructions']+=1
            retain(references,key,e.reference(name,*pose),64)
        references.move_to_end(key)
        return references[key]
    def distance(pair,pose,group):
        key = (*pair,*pose,group)
        if key not in fields:
            a,b = [reference(n,pose)['points'][group] for n in pair]
            counters['fields_created']+=1
            counters['anchor_distance_queries']+=len(a)
            retain(fields,key,field(a,b,k=1),24)
        fields.move_to_end(key)
        return fields[key]
    def compare(pair,rectangle,certificates,pose,motions):
        best = None
        for group in ['yaw','pitch']:
            radii = []
            for name in pair:
                key = name,group
                if key not in motions:
                    motions[key] = e.motion(name,rectangle,certificates[name],
                                            reference(name,pose),group)
                    counters['motion_fields']+=1
                radii.append(motions[key])
            checked = score(distance(pair,pose,group),*radii,
                            sum(RADII[n] for n in pair),GAP,NUMERIC)
            failing = int(np.argmin(checked['lower']))
            checked.pop('lower')
            counters['exclusion_sphere_queries']+=checked['exclusion_sphere_queries']
            counters['candidate_pairs_checked']+=checked['candidate_pairs_checked']
            result = dict(status='PASS' if checked['gap_lower_mm']>=GAP else 'BLOCKED',
                          group=group,reference_pose_deg=list(pose),
                          maximum_complete_parameter_radius_mm=[float(a.max()) for a in radii],
                          worst_parameter_cell_index=failing,**checked)
            if best is None or result['gap_lower_mm']>best['gap_lower_mm']:
                best = result
            if result['status']=='PASS':
                break
        return best

    results = {pair:[] for pair in PAIRS}
    failures = []
    base_rows = []
    minimum = float('inf')
    for index,parent in enumerate(e.parents[NAMES[0]]):
        for window in windows:
            base = clip(tuple(parent['rectangle_deg']),window)
            if base is None:
                continue
            base_rows.append(dict(source_math_parent_index=index,rectangle_deg=list(base)))
            certs = {n:e.parents[n][index] for n in NAMES}
            pending = [(base,0,certs,PAIRS)]
            while pending:
                rectangle,depth,certificates,pairs = pending.pop()
                counters['visited_rectangles']+=1
                yl,yh,pl,ph = rectangle
                pose = ((yl+yh)/2,(pl+ph)/2)
                if certificates is None:
                    names = sorted(set(itertools.chain.from_iterable(pairs)))
                    certificates = {n:e.certificate(n,rectangle) for n in names}
                    counters['new_root_enclosures']+=len(names)
                motions = {}
                blocked = []
                details = []
                for pair in pairs:
                    checked = compare(pair,rectangle,certificates,pose,motions)
                    details.append((pair,checked))
                    if checked['status']=='PASS':
                        results[pair].append(dict(rectangle_deg=list(rectangle),
                            base_rectangle_deg=list(base),source_math_parent_index=index,
                            root_ranges_reused=depth==0,**checked))
                        minimum = min(minimum,checked['gap_lower_mm'])
                    else:
                        blocked.append(pair)
                if blocked:
                    actual = [(p,c) for p,c in details if p in blocked and
                              c['anchor_point_surface_gap_mm']<GAP]
                    if actual or depth>=20:
                        failures.append(dict(rectangle_deg=list(rectangle),depth=depth,
                            details=[dict(wires=list(p),**c) for p,c in details if p in blocked],
                            reason='Finite reference point pair below target' if actual else
                                   'Undecided full-angle complete-parameter bound'))
                        break
                    # Test the stricter normalized width first. Both children
                    # are retained; this policy changes no proof coverage.
                    if (yh-yl)/10>(ph-pl):
                        pending.extend([((yl,pose[0],pl,ph),depth+1,None,blocked),
                                        ((pose[0],yh,pl,ph),depth+1,None,blocked)])
                    else:
                        pending.extend([((yl,yh,pl,pose[1]),depth+1,None,blocked),
                                        ((yl,yh,pose[1],ph),depth+1,None,blocked)])
                if counters['visited_rectangles']%100==0:
                    print('CAM_PEER_PROGRESS',len(base_rows),counters['visited_rectangles'],
                          sum(map(len,results.values())),round(time.time()-started,1),flush=True)
            if failures:
                break
        if failures:
            break
        if (index+1)%36==0:
            print('CAM_PEER_PARENT',index+1,len(base_rows),
                  sum(map(len,results.values())),round(time.time()-started,1),flush=True)
    e.unchanged()
    assert all(sha(p)==h for p,h in sources.items())
    out = dict(status='PASS' if base_rows and not failures else 'BLOCKED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        mode='pilot' if pilot else 'all_angles',
        scope='Six full mutual CAM-upper reference pairs in common ideal yaw/pitch frames',
        sources=sources,pilot_windows=windows if pilot else None,
        yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
        parameter_cells_per_reference={n:len(e.layout[n]['parameter_cells']) for n in NAMES},
        source_parent_rectangles=base_rows,
        results=[dict(wires=list(p),status='PASS' if not failures else 'BLOCKED',
                      accepted_rectangles=len(results[p]),intervals=results[p]) for p in PAIRS],
        failures=failures,required_gap_mm=GAP,query_numeric_reserve_mm=NUMERIC,
        minimum_certified_gap_lower_mm=minimum,
        reference_anchor_policy='Exact rectangle midpoint',
        nearest_neighbours_per_initial_field_query=1,counters=counters,
        remote_self='NOT_TESTED',own_prefix='NOT_TESTED',other_upper_pairs='NOT_TESTED',
        actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    target = HERE/('pilot_verification.json' if pilot else 'peer_verification.json')
    target.write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_PEER_TERMINAL',out['status'],len(base_rows),
          sum(map(len,results.values())),counters,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
