"""Independent source construction probes of the cross-group proof wrapper.

Finite probes check implementation only. Continuous clearance requires the
separate complete-angle and closed-parameter proof, not these samples.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(HERE),str(ROOT/'cam_native_clearance_review_R1')]
from cross_envelopes import CrossEnvelopes, CAM_NAMES, POWER_NAMES, sha
from source_root_covers import RootCovers
from check_envelopes import canonical
from power_native_envelopes import ideal_matrix


def main():
    started = time.time()
    e = CrossEnvelopes()
    covers = RootCovers(e)
    windows = [(-60.,-50.,-20.,-15.),(-10.,0.,0.,5.),(50.,60.,20.,25.)]
    rows = []
    maximum = -float('inf')
    for name in [*CAM_NAMES,*POWER_NAMES]:
        for rectangle in windows:
            certificate = covers.certificate(name,rectangle)
            boxes = {g:(e.cam_controls if name in CAM_NAMES else e.power_controls)(name,rectangle,certificate,g)
                     for g in ['yaw','pitch']}
            yl,yh,pl,ph = rectangle
            for y,p in [(yl,pl),(yh,ph),(yl,ph),(yh,pl),((yl+yh)/2,(pl+ph)/2)]:
                if name in CAM_NAMES:
                    _,actual,_,metrics = e.cam.f.upper(name,y,p)
                    assert metrics['status']=='PASS'
                else:
                    actual,metrics = e.power.e.f.upper(name,y,p)
                    assert actual is not None
                for group,box in boxes.items():
                    if name in CAM_NAMES:
                        source = canonical(e.cam,name,y,p,actual,group)
                    else:
                        inverse = np.linalg.inv(ideal_matrix(e.power.center,y,p if group=='pitch' else 0.))
                        source = actual@inverse[:3,:3].T+inverse[:3,3]
                    assert source.shape == box.lo.shape
                    excess = float(np.maximum(box.lo-source,source-box.hi).max())
                    assert excess <= 1e-8,(name,rectangle,y,p,group,excess)
                    maximum = max(maximum,excess)
                    rows.append(dict(wire=name,rectangle_deg=list(rectangle),pose_deg=[y,p],group=group,
                                     canonical_cubic_pieces=len(source),maximum_control_box_excess_mm=excess,status='PASS'))
        print('CAM_POWER_CROSS_ENVELOPE_WIRE',name,len(rows),round(time.time()-started,1),flush=True)
    e.unchanged()
    covers.unchanged()
    sources = e.sources | covers.sources
    for p in [Path(__file__),ROOT/'cam_native_clearance_review_R1/check_envelopes.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Finite independent high-precision CAM/original power source probes inside whole cubic hulls; not full-angle clearance',
               sources=sources,rows=rows,source_pose_comparisons=105,group_control_comparisons=210,
               maximum_positive_excess_mm=max(0.,maximum),power_canonical_cubic_pieces=129,
               full_cross_pairs='NOT_TESTED',main_changed=False,hardware_changed=False,
               animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'envelope_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_POWER_CROSS_ENVELOPE_PASS',105,210,round(out['elapsed_s'],1),flush=True)


if __name__ == '__main__':
    main()
