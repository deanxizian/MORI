"""Read-only diagnostics at guarded source-parent intersections and midpoints."""
from pathlib import Path
import datetime
import itertools
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent/'cam_peer_review_R1')]
from cross_envelopes import CrossEnvelopes, CAM_NAMES, POWER_NAMES, RADII, sha
from fan_geometry import matrix


def main():
    e = CrossEnvelopes()
    probes = [(-55.,-19.5), (-5.,.015625), (55.,24.5)]
    power_proof = json.loads((HERE.parent/'power_math_verification.json').read_text())
    assert power_proof['status'] == 'PASS'
    powers = {n:[r for r in power_proof['rows'] if r['wire']==n] for n in POWER_NAMES}
    rows = []
    def parent(parents, point):
        return next((i,r) for i,r in enumerate(parents)
                    if r['rectangle_deg'][0]<=point[0]<=r['rectangle_deg'][1]
                    and r['rectangle_deg'][2]<=point[1]<=r['rectangle_deg'][3])
    for point in probes:
        for a,b in itertools.product(CAM_NAMES, POWER_NAMES):
            ai,ca = parent(e.cam.parents[a], point);bi,cb = parent(powers[b], point)
            x,y = ca['rectangle_deg'], cb['rectangle_deg']
            rectangle = (max(x[0],y[0]), min(x[1],y[1]), max(x[2],y[2]), min(x[3],y[3]))
            midpoint = ((rectangle[0]+rectangle[1])/2,)*2 + ((rectangle[2]+rectangle[3])/2,)*2
            for r,acert,bcert in [(rectangle,ca,cb),
                                  (midpoint,e.cam.certificate(a,midpoint),e.power.e.certificate(b,midpoint))]:
                assert bcert['status']=='PASS'
                bounds = []
                for group in ['yaw','pitch']:
                    ac = e.cam_controls(a, r, acert, group)
                    bc = e.power_controls(b, r, bcert, group)
                    bounds.append(matrix(ac, bc, RADII[a]+RADII[b]))
                lower = np.maximum(*bounds)
                i,j = np.unravel_index(np.argmin(lower), lower.shape)
                rows.append(dict(wires=[a,b], rectangle_deg=list(r), source_parent_indices=[ai,bi],
                                 status='PASS' if lower.min() >= .3 else 'BLOCKED',
                                 gap_lower_mm=float(lower.min()), unresolved_piece_pairs=int(np.count_nonzero(lower < .3)),
                                 worst_piece_indices=[int(i),int(j)],
                                 worst_labels=[e.cam.layout[a]['labels'][i], 'neck_stub' if j == 0 else f'polynomial_{j-1}']))
        print('CAM_POWER_CROSS_HULL_PROBE', list(point), sum(r['status']!='PASS' for r in rows[-24:]), flush=True)
    e.unchanged()
    sources = dict(e.sources)
    for p in [Path(__file__), HERE.parent/'cam_peer_review_R1/fan_geometry.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Diagnostic execution only; individual rows state hull separability, not full-angle clearance',
               sources=sources, rows=rows, required_gap_mm=.3, full_cross_pairs='NOT_TESTED',
               main_changed=False, hardware_changed=False, animation_changed=False, manufacturing_release=False)
    (HERE/'hull_inspection.json').write_text(json.dumps(out, indent=2)+'\n')


if __name__ == '__main__':
    main()
