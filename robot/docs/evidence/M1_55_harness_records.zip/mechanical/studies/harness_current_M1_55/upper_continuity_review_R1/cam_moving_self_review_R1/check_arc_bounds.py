"""Finite independent derivative probes of the nominal arc-density formulas."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
HERE=Path(__file__).resolve().parent
NATIVE=HERE.parent/'cam_native_clearance_review_R1'
sys.path[:0]=[str(NATIVE)]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,sha
from arc_speed_bounds import speeds


def main():
    started=time.time();e=NativeCAMEnvelopes();rows=[];minimum=float('inf')
    t=np.linspace(0.,1.,129)
    for name in NAMES:
        for index in np.unique(np.linspace(0,len(e.parents[name])-1,6,dtype=int)):
            cert=e.parents[name][int(index)];rectangle=cert['rectangle_deg'];bounds=speeds(e,name,rectangle,cert)
            yl,yh,pl,ph=rectangle
            for y,p in [(yl,pl),(yh,ph),((yl+yh)/2,(pl+ph)/2)]:
                c=e.reference(name,y,p)['controls']['yaw'];v=3*np.diff(c,axis=1)
                actual=((1-t)**2)[None,:,None]*v[:,0,None]+(2*t*(1-t))[None,:,None]*v[:,1,None]+(t*t)[None,:,None]*v[:,2,None]
                maximum=np.linalg.norm(actual,axis=2).max(1)
                margin=float((bounds-maximum).min())
                assert margin>=-1e-6,(name,y,p,int(np.argmin(bounds-maximum)),margin)
                minimum=min(minimum,margin)
                rows.append(dict(wire=name,source_parent_index=int(index),pose_deg=[y,p],
                                 status='PASS',minimum_speed_upper_reserve_mm=margin))
        print('CAM_SELF_ARC_WIRE',name,len(rows),round(time.time()-started,1),flush=True)
    e.unchanged();sources=dict(e.sources)
    for p in [Path(__file__),HERE/'arc_speed_bounds.py']:sources[str(p)]=sha(p)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        scope='Finite derivative implementation probes; actual all-angle bound follows explicit interval/translation-invariant formulas',
        rows=rows,curve_pose_probes=len(rows),minimum_speed_upper_reserve_mm=minimum,
        local_arc_exclusion_upper_mm=5.,full_CAM_self='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'arc_bound_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_SELF_ARC_CHECK_PASS',len(rows),minimum,flush=True)


if __name__=='__main__':main()
