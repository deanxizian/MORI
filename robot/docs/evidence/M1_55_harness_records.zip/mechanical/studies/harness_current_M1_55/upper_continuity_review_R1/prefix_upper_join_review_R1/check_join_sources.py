"""Independent source join and derivative probes, without changing routes.

These finite probes validate the new wrapper's implementation only.
They do not certify a physical splice, connector, dynamic cable or cut length.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
from join_envelopes import JoinEnvelopes,UPPER_NAMES,CAM_NAMES,sha
sys.path.insert(0,str(HERE.parent/'cam_native_clearance_review_R1'))
from check_envelopes import canonical
from frame_family import BSpline


def main():
    started = time.time()
    e = JoinEnvelopes()
    windows = [(-60.,-50.,-20.,-15.),(-10.,0.,0.,5.),(50.,60.,20.,25.)]
    rows = []
    max_seam,max_tangent = 0.,0.
    min_speed,min_join = float('inf'),float('inf')
    for name in UPPER_NAMES:
        for rectangle in windows:
            cert = e.roots.certificate(name,rectangle)
            density = e.upper_speeds(name,rectangle,cert)
            joins = e.upper_joins(name)
            yl,yh,pl,ph = rectangle
            for y,p in [(yl,pl),(yh,ph),(yl,ph),(yh,pl),((yl+yh)/2,(pl+ph)/2)]:
                body = e.prefix.f.candidate(name,y)['control']
                incoming = BSpline(e.prefix.f.knots,body,3).derivative()(1.)
                if name in CAM_NAMES:
                    _,raw,_,metrics = e.cross.cam.f.upper(name,y,p)
                    assert metrics['status']=='PASS'
                    actual = canonical(e.cross.cam,name,y,p,raw,'yaw')
                else:
                    raw,metrics = e.cross.power.e.f.upper(name,y,p)
                    assert raw is not None
                    actual = raw
                seam = float(np.linalg.norm(raw[0,0]-body[-1]))
                outgoing = raw[0,1]-raw[0,0]
                tangent = float(np.linalg.norm(incoming/np.linalg.norm(incoming)-outgoing/np.linalg.norm(outgoing)))
                source_speed = np.linalg.norm(3*np.diff(actual,axis=1),axis=2).max(1)
                speed_reserve = float((density-source_speed).min())
                jumps = np.linalg.norm(actual[:-1,-1]-actual[1:,0],axis=1)
                join_reserve = float((joins-jumps).min())
                assert seam<=1e-8 and tangent<=1e-8 and speed_reserve>=0 and join_reserve>=0,(
                    name,rectangle,y,p,seam,tangent,speed_reserve,join_reserve)
                max_seam,max_tangent = max(max_seam,seam),max(max_tangent,tangent)
                min_speed,min_join = min(min_speed,speed_reserve),min(min_join,join_reserve)
                rows.append(dict(wire=name,rectangle_deg=list(rectangle),pose_deg=[y,p],status='PASS',
                                 endpoint_gap_mm=seam,tangent_unit_error=tangent,
                                 minimum_speed_upper_reserve_mm=speed_reserve,minimum_join_reserve_mm=join_reserve))
        print('PREFIX_UPPER_SOURCE',name,len(rows),round(time.time()-started,1),flush=True)
    e.unchanged()
    sources = dict(e.sources)
    for p in [Path(__file__),HERE.parent/'cam_native_clearance_review_R1/check_envelopes.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='105 finite independent original-source endpoint/tangent/derivative probes only',
               sources=sources,rows=rows,source_pose_comparisons=len(rows),known_upper_references=7,
               maximum_endpoint_gap_mm=max_seam,maximum_tangent_unit_error=max_tangent,
               minimum_speed_upper_reserve_mm=min_speed,minimum_join_reserve_mm=min_join,
               full_angle_joins='NOT_TESTED',actual_transitions='BLOCKED',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
               elapsed_s=time.time()-started)
    (HERE/'join_source_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_UPPER_SOURCE_PASS',len(rows),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
