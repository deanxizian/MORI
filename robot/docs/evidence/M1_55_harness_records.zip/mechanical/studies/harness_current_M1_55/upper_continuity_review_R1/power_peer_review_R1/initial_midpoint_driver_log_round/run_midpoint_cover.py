"""Run the proven core at exact rectangle midpoints using one-neighbour fields.

The scoped runtime overrides affect only anchor/query policy, never curve
geometry, interval covers, diameters or thresholds. Actual query counts and
the raw core report are preserved independently of its legacy64 accounting.
"""
from pathlib import Path
import datetime,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
import certify_math_cover as core
from weighted_peer import field


def main():
    cross_path=HERE/'weighted_single_crosscheck.json';cross=json.loads(cross_path.read_text())
    assert cross['status']=='PASS' and all(sha(p)==h for p,h in cross['sources'].items())
    sources={str(p):sha(p) for p in [Path(__file__),HERE/'certify_math_cover.py',HERE/'weighted_peer.py',cross_path]}
    actual=dict(fields_created=0,anchor_distance_queries=0)
    def query(a,b):
        actual['fields_created']+=1;actual['anchor_distance_queries']+=len(a)
        return field(a,b,k=1)
    core.round=lambda value:value
    core.weighted_field=query
    core.main()
    pilot='--pilot' in sys.argv
    report_path=HERE/('math_cover_pilot_verification.json' if pilot else 'peer_verification.json')
    raw=report_path.read_bytes();raw_path=HERE/('midpoint_pilot_core_output.json' if pilot else 'midpoint_core_output.json')
    raw_path.write_bytes(raw)
    assert all(sha(p)==h for p,h in sources.items())
    result=json.loads(raw)
    result['sources'].update(sources);result['sources'][str(raw_path)]=sha(raw_path)
    result['anchor_query_allocation_units_in_core']=result['anchor_distance_queries']
    result.update(actual)
    result['execution_driver']=str(Path(__file__))
    result['reference_anchor_policy']='Exact rectangle midpoint; runtime identity rounding override'
    result['nearest_neighbours_per_initial_field_query']=1
    result['query_policy']='One neighbour plus complete variable-radius exclusion-sphere checks'
    result['driver_recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['core_report_path']=str(raw_path)
    result['core_report_sha256']=sha(raw_path)
    report_path.write_text(json.dumps(result,indent=2)+'\n')
    print('POWER_PEER_MIDPOINT_DRIVER',result['status'],actual['fields_created'],actual['anchor_distance_queries'],flush=True)


if __name__=='__main__':main()
