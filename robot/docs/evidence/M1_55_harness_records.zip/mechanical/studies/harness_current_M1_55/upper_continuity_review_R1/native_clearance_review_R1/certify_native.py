"""Whole-curve native gap proof for three numerical upper references.

Targets are the current 201 triangulated sources under nominal continuous
rotations. The full 0.3mm target is retained. An assumed USB proxy is separate.
"""
from pathlib import Path
from collections import OrderedDict
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=[str(HERE),str(PARENT)]
from context import Context,Vector,manifold,sha,rigidtr
from power_native_envelopes import NativeEnvelopes,NAMES,RADII,ideal_matrix

GAP=.3;CAP=4.;NUMERIC=.0001


def distance_field(points,radius,targets):
    bound=radius+CAP+NUMERIC
    values=np.full(len(points),CAP);closest=np.full(len(points),-1,dtype=np.int16)
    inside=[];queries=0;names=list(targets)
    for oi,(name,target) in enumerate(targets.items()):
        ids=np.flatnonzero(np.all(points>=target['lo']-bound,axis=1)&np.all(points<=target['hi']+bound,axis=1))
        if not len(ids):continue
        distances=np.array([target['tree'].find_nearest(Vector(points[i]))[3] for i in ids]);queries+=len(ids)
        lower=distances-radius-NUMERIC;use=lower<values[ids]
        values[ids[use]]=lower[use];closest[ids[use]]=oi
        # A positive gap on every closed curve cell prevents unnoticed boundary
        # crossing. Probe the first centre of each contiguous candidate window
        # to distinguish an entirely contained interval from an exterior one.
        for i in ids[np.r_[True,np.diff(ids)>1]]:
            q=points[i]
            if np.all(q>=target['lo']) and np.all(q<=target['hi']):
                probe=manifold.Manifold.sphere(.005,12).translate(q.tolist())
                if (probe^target['m']).volume()>probe.volume()/2:
                    inside.append(dict(object=name,parameter_cell=int(i),point_mm=q.tolist()))
    return dict(values=values,closest=closest,names=names,inside=inside,queries=queries)


def store_cache(cache,key,value,limit):
    cache[key]=value;cache.move_to_end(key)
    while len(cache)>limit:cache.popitem(last=False)


def main():
    started=time.time();ctx=Context();e=NativeEnvelopes()
    proof=json.loads((MATH/'power_math_verification.json').read_text())
    cross=json.loads((HERE/'envelope_crosscheck.json').read_text())
    assert proof['status']==cross['status']=='PASS'
    assert all(sha(p)==h for p,h in cross['sources'].items())
    assert cross['parameter_cells_per_reference']==len(e.parameter_cells)
    ctx.sources.update(e.sources)
    ctx.record([Path(__file__),HERE/'power_native_envelopes.py',HERE/'envelope_crosscheck.json',
                MATH/'power_math_verification.json'])
    targets=ctx.groups|{'USB_conditional':ctx.usb}
    pilot='--pilot' in sys.argv
    curves=OrderedDict();fields=OrderedDict();queries=0;field_count=0
    def reference(name,y,p):
        key=name,y,p
        if key in curves:curves.move_to_end(key);return curves[key]
        value=e.reference(name,y,p);store_cache(curves,key,value,64);return value
    def field(name,y,p,group):
        nonlocal queries,field_count
        key=name,y,p,group
        if key in fields:fields.move_to_end(key);return fields[key]
        geometry=reference(name,y,p)
        points=e.relative_points(geometry,'pitch' if group=='USB_conditional' else group)
        value=distance_field(points,RADII[name],targets[group])
        queries+=value['queries'];field_count+=1;store_cache(fields,key,value,128)
        return value
    def compare(name,rectangle,certificate,anchor):
        geometry=reference(name,*anchor);records=[];failed=[];nominal=[]
        for group in targets:
            ref=field(name,*anchor,group)
            motion=e.motion(name,rectangle,certificate,geometry,'pitch' if group=='USB_conditional' else group)
            lower=ref['values']-motion;i=int(np.argmin(lower));gap=float(lower[i]);oi=int(ref['closest'][i])
            row=dict(group=group,gap_lower_mm=gap,reference_nominal_gap_lower_mm=float(ref['values'][i]),
                whole_parameter_cell_motion_bound_mm=float(motion[i]),
                nearest_object=ref['names'][oi] if oi>=0 else 'PROVED_AABB_CAP',
                curve_piece_and_parameter_interval=e.parameter_cells[i].tolist(),reference_pose_deg=list(anchor))
            records.append(row)
            if gap<GAP or ref['inside']:failed.append(row)
            if ref['inside'] or float(ref['values'].min())<GAP:
                nominal.append(dict(group=group,gap_lower_mm=float(ref['values'].min()),inside=ref['inside']))
        return dict(status='PASS' if not failed else 'BLOCKED',rows=records,failed_bounds=failed,nominal_failures=nominal)
    results=[];failures=[];minimum=float('inf');visits=0;frame_probes=[]
    for name in NAMES:
        parents=[r for r in proof['rows'] if r['wire']==name]
        if pilot:
            parents=[parents[i] for i in np.unique(np.r_[np.linspace(0,len(parents)-1,8,dtype=int),
                                                        np.argmin([r['continuous_bending']['radius_lower_mm'] for r in parents])])]
        accepted=[]
        for parent in parents:
            base=tuple(parent['rectangle_deg']);todo=[(base,0,parent)]
            while todo:
                rectangle,depth,certificate=todo.pop();visits+=1
                yl,yh,pl,ph=rectangle;mid=((yl+yh)/2,(pl+ph)/2)
                if certificate is None:certificate=e.e.certificate(name,rectangle)
                result=None
                if certificate['status']=='PASS':
                    anchor=(max(-60.,min(60.,round(mid[0]/5)*5)),max(-20.,min(25.,round(mid[1]/2.5)*2.5)))
                    result=compare(name,rectangle,certificate,anchor)
                    if result['status']!='PASS':result=compare(name,rectangle,certificate,mid)
                if result and result['status']=='PASS':
                    accepted.append(dict(rectangle_deg=list(rectangle),source_math_rectangle_deg=list(base),
                        rows=result['rows'],status='PASS'))
                    minimum=min(minimum,min(r['gap_lower_mm'] for r in result['rows'] if r['group']!='USB_conditional'))
                    continue
                if result and result['nominal_failures'] or depth>=18:
                    failures.append(dict(wire=name,rectangle_deg=list(rectangle),root_status=certificate['status'],
                        details=result,reason='Fresh nominal reference fails' if result and result['nominal_failures'] else 'Unresolved enclosure'))
                    break
                # Shrink the angle contributing the larger positional change at
                # the worst cell; no native body or 0.3mm target is altered.
                if (yh-yl)/10>(ph-pl)/5:
                    todo.extend([((yl,mid[0],pl,ph),depth+1,None),((mid[0],yh,pl,ph),depth+1,None)])
                else:
                    todo.extend([((yl,yh,pl,mid[1]),depth+1,None),((yl,yh,mid[1],ph),depth+1,None)])
                if visits%100==0:
                    print('POWER_NATIVE_PROGRESS',name,visits,len(accepted),field_count,queries,round(time.time()-started,1),flush=True)
            if failures:break
        status='PASS' if not failures else 'BLOCKED'
        results.append(dict(wire=name,status=status,planned_math_rectangles=len(parents),
            accepted_rectangles=len(accepted),intervals=accepted))
        print('POWER_NATIVE_WIRE',name,status,len(accepted),field_count,queries,round(time.time()-started,1),flush=True)
        if failures:break
    # Compare the nominal continuous convention with the source float32 helper.
    # This is a finite diagnostic, not a proof of its arbitrary-angle rounding.
    for y,p in [(-60,-20),(-45,2.5),(0,0),(17.3,12.7),(60,25)]:
        native=np.array(rigidtr(y,p));ideal=ideal_matrix(e.center,y,p)
        frame_probes.append(dict(pose_deg=[y,p],maximum_matrix_difference=float(np.max(abs(native-ideal)))))
    ctx.unchanged();e.unchanged()
    status='PASS' if len(results)==3 and not failures else 'BLOCKED'
    out=dict(status=status,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Three power/CC upper capacity references versus current201 native meshes under full nominal ideal yaw/pitch motion; USB proxy separate',
        mode='pilot' if pilot else 'all_angles',sources=ctx.sources,results=results,failures=failures,
        names=NAMES,native_parts=201,required_gap_mm=GAP,native_numeric_query_reserve_mm=NUMERIC,
        yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
        minimum_certified_native_gap_lower_mm=minimum,parameter_cells_per_reference=len(e.parameter_cells),
        cached_reference_fields_created=field_count,BVH_distance_queries=queries,AABB_fallback_gap_mm=CAP,
        native_frame='Ideal nominal Rz(yaw)Rx(pitch) about current head centre',
        source_float32_frame_diagnostics=frame_probes,source_float32_all_angle_rounding='NOT_TESTED',
        peer_gap='NOT_TESTED',remote_self='NOT_TESTED',CAM_upper='NOT_TESTED',
        actual_USB_tail='BLOCKED',actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    (HERE/('pilot_native_verification.json' if pilot else 'native_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_NATIVE_TERMINAL',status,len(results),field_count,queries,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
