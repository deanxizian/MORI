"""Refresh only the scoped harness progress rows and concise open-work notice."""
from pathlib import Path
import datetime
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    power = read(HERE/'delivery.json')
    verified = read(HERE/'publication_verification.json')
    cam = read(HERE/'cam_math_review_R1/delivery.json')
    peer = read(HERE/'power_peer_review_R1/delivery.json')
    cam_native = read(HERE/'cam_native_clearance_review_R1/delivery.json')
    cam_self = read(HERE/'cam_self_review_R1/delivery.json')
    cam_peer = read(HERE/'cam_peer_review_R1/delivery.json')
    cam_upper_self = read(HERE/'cam_moving_self_review_R1/delivery.json')
    cam_power_cross = read(HERE/'cam_power_cross_review_R1/delivery.json')
    power_self = read(HERE/'power_self_review_R1/delivery.json')
    joins = read(HERE/'prefix_upper_join_review_R1/delivery.json')
    assert joins['continuous_own_prefix']==joins['continuous_other_prefix']=='PASS'
    assert joins['prefix_upper_comparisons']==84 and joins['own_prefix_pairs']==7 and joins['other_prefix_pairs']==77
    assert power['known_continuous_own_prefix']==power['known_continuous_other_prefix']=='PASS'
    assert power_self['power_upper_remote_self']==power_self['known_upper_continuous_remote_self']=='PASS'
    assert power['power_continuous_remote_self']==power['known_upper_continuous_remote_self']=='PASS'
    assert cam_power_cross['CAM_power_cross_pairs']=='PASS' and cam_power_cross['known_upper_unordered_pairs']==21
    assert power['known_upper_continuous_mutual']=='PASS' and power['known_upper_unordered_pairs']==21
    assert cam_upper_self['continuous_nominal_CAM_upper_remote_self']=='PASS' and cam_upper_self['references']==4
    assert power['CAM_continuous_upper_remote_self']==power['CAM_own_prefix']=='PASS'
    assert cam_peer['continuous_nominal_CAM_mutual']=='PASS' and cam_peer['unordered_pairs']==6
    assert cam_self['CAM_fixed_tail_remote_self']=='PASS' and cam_self['whole_parameter_cells']==64000
    assert power['status'] == verified['status'] == cam['status'] == peer['status'] == cam_native['status'] == 'PASS'
    assert verified['delivery_sha256'] == sha(HERE/'delivery.json')
    assert power['continuous_CAM_math'] == power['continuous_peer_clearance'] == 'PASS'
    assert power['full_harness'] == 'BLOCKED' and not power['manufacturing_release']
    doc = PROJECT/'docs/CURRENT_STATUS.md'
    text = doc.read_text()
    notice = ('当前机械侧仍剩 **4组线束工作**：完整路线与全运动范围、实际材料／裁线长度、'
              '配对端接／固定／应力释放、带线装配／闭壳。12条身体／颈部参考前段已完成名义连续几何检查；'
              '7条已知上段的名义长度／弯折及当前201模型的全范围实体间隙已通过，3条电源／CC互线间隙另检通过。'
              '7条已知上段全部21组互线及全部非局部自身检查随后齐全；与12条身体前段的84组名义接续／跨线也已完整通过，含7组自身接续和77组其他前段。另3条舵机总线参考与2条喇叭参考缺实际上端信息。'
              '新增线束参考尚未进入主模型或视频；不能据此放行裁线或打样整机。')
    text = re.sub(r'^当前机械侧仍剩 \*\*4组线束工作\*\*：.*\n\n', '', text, flags=re.M)
    marker = '## 未完成项目\n\n'
    assert marker in text
    text = text.replace(marker,marker+notice+'\n\n',1)
    power_row = ('| M1.55 电源／CC上段连续检查 | '
                 '[全范围长度、弯折与间隙](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/index.html)：'
                 'P_J18_1、P_J18_2、CC_allocation覆盖名义偏航−60°～+60°／俯仰−20°～+25°，'
                 '18,095个二维长度／弯折区间、19,068个当前201件实体间隙区间及独立覆盖核对PASS。'
                 '[三组互线检查](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/power_peer_review_R1/index.html)随后PASS，'
                 f"独立重建{peer['source_parent_intersections']:,}个父区间交集、核对{peer['accepted_rectangles']:,}个细分区间；"
                 '每条9,216个闭参数区间、原0.3mm目标保持。采用理想名义旋转，原浮点助手全范围舍入及实际USB未资格化。'
                 '7条已知上段全部21组互线及全部非局部自身随后已齐全，上下段名义接续随后另检完成；五条缺实际端点线路、材料／端接／带线装配仍未闭合。主模型／视频未采用，剩4组工作 |')
    cam_row = ('| M1.55 CAM连续数学参考 | '
               '[新名义参考及独立回读](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_math_review_R1/index.html)：'
               '4条CAM全范围数值长度与弯折PASS，48个身体接续偏航区间、2,592个长度二维区间；'
               '475姿态／1,900条保存曲线回读PASS。身体接续点、硬件零位和原扇出／余量圈／头内尾线布局保持。'
               '采用一致名义框架、80位构造及固定可变圆弧分段，解决原框架复合与微弧数值问题；不等于原浮点数组逐位一致。'
               '[新CAM全范围实体间隙](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_native_clearance_review_R1/index.html)随后独立PASS：'
               f"2,592个数学父区间、{cam_native['accepted_rectangles']:,}个细分区间，完整闭参数及零角度退化槽均覆盖，最小模型实体下界约{cam_native['minimum_certified_native_gap_lower_mm']:.8f}mm。"
               '原0.3mm目标保持，假定USB另列条件检查；CAM完整上段自身、7条已知上段全部21组互线及身体前段名义接续随后独立通过。主模型／视频未采用 |')
    peer_row = ('| M1.55 CAM全范围内部配对 | '
                '[六组配对与独立完整分类核对](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_peer_review_R1/index.html)：'
                '四条名义CAM上段的6组配对覆盖偏航−60°～+60°／俯仰−20°～+25°及完整闭曲线参数，PASS。'
                f"扇出段{cam_peer['fan_accepted_yaw_intervals']}个偏航区间／{cam_peer['fan_parameter_refinement_rectangles']:,}个参数细分区间，"
                '其他组合648个角度父区间／3,888条配对记录，固定尾线每条16,000闭参数区间另检。'
                '三类完整、互斥组合独立枚举；0.3mm保守目标保持。CAM完整上段自身、与电源／CC的12组跨组配对及身体前段名义接续随后通过；真实材料／接头与完整带线装配BLOCKED。主模型／视频未采用 |')
    self_row = ('| M1.55 CAM固定尾线自身检查 | '
                '[当前固定尾线及独立覆盖](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_self_review_R1/index.html)：'
                '四条头内固定尾线的非局部自身间隙PASS，每条130段三次曲线、16,000个闭参数区间，共64,000个区间；独立参数覆盖／源核对PASS。'
                '理想俯仰坐标系内固定，覆盖名义全偏航／俯仰。只排除整段弧长上界≤5mm的局部相邻段，当前尾线曲率另检R6.9342要求；'
                '0.3mm是保守证明目标，不是实测最小间隙。活动段自身随后由完整上段检查补齐，上下段名义接续随后另检完成；实际材料／端子／穿线／闭壳仍未完成，主模型／视频未采用 |')
    upper_self_row = ('| M1.55 CAM完整上段自身检查 | '
                      '[完整自身及独立分类核对](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_moving_self_review_R1/index.html)：'
                      '四条名义CAM上段非局部自身间隙覆盖全偏航−60°～+60°／俯仰−20°～+25°及全部闭曲线参数，PASS。'
                      '扇出48个偏航区间、其他活动组合2,592个二维角度区间，与固定尾线64,000个参数区间合并，三类完整互斥组合独立枚举通过；'
                      f"需细分组合另核对{cam_upper_self['parameter_refinement_rectangles']:,}个二维参数区间。"
                      '局部排除仅限完整弧长上界≤5mm，另检R6.9342曲率要求，原0.3mm目标保持。'
                      '与电源／CC的12组跨组配对及同一条线与身体前段名义接续随后已通过；材料／端接／带线装配仍未完成，主模型／视频未采用 |')
    cross_row = ('| M1.55 七条上段完整互线检查 | '
                 '[12组跨组及全部21组配对](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_power_cross_review_R1/index.html)：'
                 '四条CAM与三条电源／CC的12组跨组间隙覆盖全偏航−60°～+60°／俯仰−20°～+25°及完整闭曲线参数，PASS。'
                 f"独立核对{cam_power_cross['cross_angular_rectangles']:,}个角度区间、必要组合{cam_power_cross['cross_parameter_refinement_rectangles']:,}个二维参数区间；"
                 '105个原构造姿态／210次完整控制包络实现核对通过。结合6组CAM内部配对、3组电源／CC配对，7条已知上段全部21组互线无重复、无遗漏。'
                 '原0.3mm目标保持；7条上段全部非局部自身及上下段名义接续随后也已通过。5条缺实际端点线路、真实材料／端接及完整带线装配仍未完成，主模型／视频未采用 |')
    power_self_row = ('| M1.55 七条上段完整自身检查 | '
                      '[电源／CC自身与7条上段自身汇总](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/power_self_review_R1/index.html)：'
                      '三条电源／CC上段非局部自身间隙覆盖全名义偏航−60°～+60°／俯仰−20°～+25°及完整闭曲线参数，PASS。'
                      f"每条129段三次曲线、8,385组无序段组合；独立核对{power_self['power_self_angular_rectangles']:,}个角度区间和必要组合{power_self['power_self_parameter_rectangles']:,}个二维参数区间。"
                      '45个原构造姿态／17,415个导数控制向量另检实现，局部排除弧长上界≤5mm并计入连接余量；原0.3mm及既有曲率目标保持。'
                      '与四条CAM上段结果合并后，7条已知上段全部非局部自身齐全，身体前段名义接续随后另检完成；5条缺真实端点线路、材料／端接／带线装配仍未完成，主模型／视频未采用 |')
    joins_row = ('| M1.55 上下段完整接续与跨线 | '
                 '[84组比较及独立覆盖](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/prefix_upper_join_review_R1/index.html)：'
                 '12条身体／颈部前段与7条已知上段，覆盖全名义偏航−60°～+60°／俯仰−20°～+25°及完整闭曲线参数，PASS。'
                 f"含7组同线自身接续、77组其他前段互线，独立核对{joins['prefix_upper_angular_rectangles']:,}个角度区间、必要组合{joins['prefix_upper_parameter_rectangles']:,}个二维参数区间。"
                 '两侧分别使用源线径参考，原0.3mm目标保持；同线局部排除仅限完整弧长上界≤5mm并计入数值连接余量。'
                 '180个原前段构造姿态／540次包络核对和105个原上段端点／切向／速度核对另检通过。'
                 '五条缺实际端点上段、实际材料／粗细线接续／裁线、配对端子／应力释放、带线装配／闭壳仍未完成。主模型／视频未采用，仍剩4组工作 |')
    old_diagnostic = ('| CAM 极小角度检查异常 | '
                      '[历史八个同曲线局部坐标诊断](../mechanical/studies/harness_current_M1_55/upper_continuity_review_R1/cam_zero_angle_review_R1/README.md)保留：'
                      '±0.00001°的八个样本原控制点保持，局部坐标细分通过。后续更广检查还发现插值框架复合和微弧构造问题，'
                      '不能把全部异常只归因于原八例检查。上方CAM新名义数学参考已单列完成范围及尚未执行的间隙检查 |')
    for label,row in [('M1.55 电源／CC上段连续检查',power_row),('CAM 极小角度检查异常',old_diagnostic)]:
        pattern = r'^\| '+re.escape(label)+r' \|.*$'
        assert len(re.findall(pattern,text,re.M)) == 1, label
        text = re.sub(pattern,lambda _:row,text,flags=re.M)
    cam_pattern = r'^\| M1\.55 CAM连续数学参考 \|.*$'
    if re.search(cam_pattern,text,re.M):
        text = re.sub(cam_pattern,lambda _:cam_row,text,flags=re.M)
    else:
        text = text.replace(power_row,power_row+'\n'+cam_row,1)
    self_pattern = r'^\| M1\.55 CAM固定尾线自身检查 \|.*$'
    if re.search(self_pattern,text,re.M):
        text = re.sub(self_pattern,lambda _:self_row,text,flags=re.M)
    else:
        text = text.replace(cam_row,cam_row+'\n'+self_row,1)
    peer_pattern = r'^\| M1\.55 CAM全范围内部配对 \|.*$'
    if re.search(peer_pattern,text,re.M):
        text = re.sub(peer_pattern,lambda _:peer_row,text,flags=re.M)
    else:
        text = text.replace(cam_row,cam_row+'\n'+peer_row,1)
    upper_self_pattern = r'^\| M1\.55 CAM完整上段自身检查 \|.*$'
    if re.search(upper_self_pattern,text,re.M):
        text = re.sub(upper_self_pattern,lambda _:upper_self_row,text,flags=re.M)
    else:
        text = text.replace(self_row,self_row+'\n'+upper_self_row,1)
    cross_pattern = r'^\| M1\.55 七条上段完整互线检查 \|.*$'
    if re.search(cross_pattern,text,re.M):
        text = re.sub(cross_pattern,lambda _:cross_row,text,flags=re.M)
    else:
        text = text.replace(peer_row,peer_row+'\n'+cross_row,1)
    power_self_pattern = r'^\| M1\.55 七条上段完整自身检查 \|.*$'
    if re.search(power_self_pattern,text,re.M):
        text = re.sub(power_self_pattern,lambda _:power_self_row,text,flags=re.M)
    else:
        text = text.replace(upper_self_row,upper_self_row+'\n'+power_self_row,1)
    joins_pattern = r'^\| M1\.55 上下段完整接续与跨线 \|.*$'
    if re.search(joins_pattern,text,re.M):
        text = re.sub(joins_pattern,lambda _:joins_row,text,flags=re.M)
    else:
        text = text.replace(power_self_row,power_self_row+'\n'+joins_row,1)
    doc.write_text(text)
    sources = {str(p):sha(p) for p in [Path(__file__),HERE/'delivery.json',HERE/'publication_verification.json',
                                      HERE/'cam_math_review_R1/delivery.json',HERE/'power_peer_review_R1/delivery.json',
                                      HERE/'cam_native_clearance_review_R1/delivery.json',
                                      HERE/'cam_self_review_R1/delivery.json',HERE/'cam_peer_review_R1/delivery.json',
                                      HERE/'cam_moving_self_review_R1/delivery.json',HERE/'cam_power_cross_review_R1/delivery.json',
                                      HERE/'power_self_review_R1/delivery.json',HERE/'prefix_upper_join_review_R1/delivery.json',doc]}
    out = dict(status='PASS',scope='Current status documentation refresh only; four work packages remain incomplete',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
               remaining_work_packages=4,known_upper_nominal_math_references=7,power_native_and_peer_references=3,
               CAM_new_reference_native='PASS',CAM_new_reference_peer='PASS',CAM_peer_unordered_pairs=6,
               CAM_power_cross_pairs='PASS',CAM_power_cross_unordered_pairs=12,
               known_upper_continuous_mutual='PASS',known_upper_unordered_pairs=21,
               known_upper_continuous_remote_self='PASS',known_upper_remote_self_references=7,
               known_continuous_own_prefix='PASS',known_continuous_other_prefix='PASS',
               prefix_upper_comparisons=84,own_prefix_pairs=7,other_prefix_pairs=77,
               power_continuous_remote_self='PASS',power_self_angular_rectangles=418,
               CAM_continuous_upper_remote_self='PASS',CAM_self_mixed_angular_rectangles=2592,
               CAM_fixed_tail_remote_self='PASS',CAM_fixed_tail_self_parameter_cells=64000,
               known_upper_native_references=7,missing_actual_upper_endpoint_references=5,
               full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'current_status_update.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CURRENT_HARNESS_STATUS_UPDATED',7,3,5,4,flush=True)


if __name__ == '__main__':
    main()
