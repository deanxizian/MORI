"""Reuse identical fixed-tail native distance fields with unchanged geometry.

The full ordered point field is split into a variable prefix and fixed tail.
Keys include target identity, radius and the complete Float64 tail point bytes.
Only byte-identical fields are reused; all points and native objects remain.
Extra containment probes at the split are conservative, never a waiver.
"""
from pathlib import Path
from collections import OrderedDict
import datetime
import hashlib
import importlib.util
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from cam_native_envelopes import sha


def main():
    path=HERE/'certify_native_adaptive.py'
    spec=importlib.util.spec_from_file_location('mori_cam_adaptive_native_proof',path)
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    sources={str(p):sha(p) for p in [Path(__file__),path,HERE/'adaptive_source_lineage.json']}
    lineage=json.loads((HERE/'adaptive_source_lineage.json').read_text())
    assert sha(lineage['original'])==lineage['original_sha256']
    assert sha(lineage['generated'])==lineage['generated_sha256']
    original_factory=core.NativeCAMEnvelopes
    original_distance=core.distance_field
    tail_counts=[];cache=OrderedDict()
    actual=dict(static_fields_created=0,static_cache_hits=0,variable_fields_created=0,actual_BVH_distance_queries=0)
    def factory(*args,**kwargs):
        e=original_factory(*args,**kwargs)
        for name in core.NAMES:
            tail_index=e.layout[name]['tail_index']
            tail_counts.append(sum(len(M) for M in e.operators[name][tail_index:]))
        assert len(set(tail_counts))==1
        return e
    def distance(points,radius,targets):
        count=tail_counts[0];offset=len(points)-count;assert offset>0
        tail=np.ascontiguousarray(points[offset:],dtype=np.float64)
        digest=hashlib.sha256(tail.tobytes()).hexdigest()
        key=id(targets),float(radius),tail.shape,digest
        variable=original_distance(points[:offset],radius,targets)
        actual['variable_fields_created']+=1
        queries=variable['queries']
        if key not in cache:
            fixed=original_distance(tail,radius,targets)
            cache[key]=(fixed,tail.copy());actual['static_fields_created']+=1
            queries+=fixed['queries']
            while len(cache)>128:cache.popitem(last=False)
        else:
            actual['static_cache_hits']+=1
        cache.move_to_end(key)
        fixed,stored=cache[key]
        assert np.array_equal(tail,stored) and variable['names']==fixed['names']
        actual['actual_BVH_distance_queries']+=queries
        inside=list(variable['inside'])+[
            dict(row,parameter_cell=row['parameter_cell']+offset) for row in fixed['inside']]
        return dict(values=np.r_[variable['values'],fixed['values']],
                    closest=np.r_[variable['closest'],fixed['closest']],names=variable['names'],
                    inside=inside,queries=queries)
    core.NativeCAMEnvelopes=factory
    core.distance_field=distance
    core.main()
    assert all(sha(p)==h for p,h in sources.items())
    pilot='--pilot' in sys.argv
    report=HERE/('pilot_native_adaptive_verification.json' if pilot else 'native_verification.json')
    raw=report.read_bytes()
    raw_path=HERE/('cached_pilot_core_output.json' if pilot else 'cached_core_output.json')
    raw_path.write_bytes(raw)
    out=json.loads(raw)
    assert out['BVH_distance_queries']==actual['actual_BVH_distance_queries']
    out['sources'].update(sources);out['sources'][str(raw_path)]=sha(raw_path)
    out.update(execution_driver=str(Path(__file__)),fixed_tail_cells=tail_counts[0],
               byte_identical_tail_cache=actual,core_report_path=str(raw_path),core_report_sha256=sha(raw_path),
               query_policy='All native targets and ordered points retained; cache only exact identical fixed-tail fields',
               driver_recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    report.write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_NATIVE_CACHED_TERMINAL',out['status'],out['mode'],actual,flush=True)


if __name__=='__main__':
    main()
