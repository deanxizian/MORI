"""Verify retained source/file hashes, scoped claims and actual served bytes."""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import json
import urllib.request

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key == 'href':
                self.links.append(value)


def main():
    path = HERE/'delivery.json'
    delivery = json.loads(path.read_text())
    assert delivery['status'] == delivery['continuous_nominal_CAM_upper_remote_self'] == 'PASS'
    assert delivery['references'] == 4 and delivery['mixed_angular_rectangles'] == 2592
    assert delivery['own_prefix'] == delivery['CAM_power_cross_pairs'] == 'NOT_TESTED'
    assert delivery['full_harness'] == 'BLOCKED' and not delivery['manufacturing_release']
    assert all(sha(p) == h for p,h in delivery['sources'].items())
    assert all(sha(HERE/p) == h for p,h in delivery['files'].items())
    page = (HERE/'index.html').read_text()
    assert '尚未进入主模型或视频' in page and '身体前段的接续' in page
    assert '12组配对' in page and '≤5 mm' in page
    parser = Links()
    parser.feed(page)
    served = []
    for p in [HERE/'index.html', *((HERE/link).resolve() for link in parser.links)]:
        assert p.is_file()
        relative = p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+relative, timeout=10) as response:
            assert response.read() == p.read_bytes(), relative
        served.append(dict(path=relative, sha256=sha(p)))
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               delivery_sha256=sha(path), verified_files=len(delivery['files']),
               verified_sources=len(delivery['sources']), served_links=len(served), served=served,
               continuous_nominal_CAM_upper_remote_self='PASS', own_prefix='NOT_TESTED',
               CAM_power_cross_pairs='NOT_TESTED', full_harness='BLOCKED',
               main_changed=False, hardware_changed=False, animation_changed=False, manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(out, indent=2)+'\n')
    print('CAM_UPPER_SELF_PUBLICATION_VERIFIED', len(delivery['files']), len(served), flush=True)


if __name__ == '__main__':
    main()
