"""Publish the independently audited power-self and seven-upper self scopes."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    audit = read(HERE/'self_coverage_verification.json')
    combined = read(HERE/'complete_upper_self_verification.json')
    assert audit['status']==combined['status']=='PASS' and audit['mode']=='all_angles'
    assert audit['references']==3 and combined['references']==7
    sources = audit['sources'] | combined['sources']
    for p in [Path(__file__),HERE/'self_coverage_verification.json',HERE/'complete_upper_self_verification.json',HERE/'commands.json']:
        sources[str(p)] = sha(p)
    assert all(sha(p)==h for p,h in sources.items())
    table = ''.join(f"<tr><td>{r['wire']}</td><td>{r['angular_rectangles']}</td><td>PASS</td></tr>" for r in audit['results'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 电源／CC上段自身检查</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;max-width:960px;margin:38px auto;padding:0 22px;color:#243039}}table{{border-collapse:collapse;width:100%}}td,th{{padding:10px;border:1px solid #ccd3d6;text-align:left}}a{{color:#20526c}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #6b767a}}</style>
<h1>三条电源／CC上段：完整自身接近检查</h1>
<p class="scope">PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED · 独立容量参考，尚未进入主模型或视频。完整线束 BLOCKED。</p>
<p>三条名义上段的非局部自身间隙覆盖偏航 −60°～+60°、俯仰 −20°～+25°及完整闭曲线参数，PASS。每条129段三次曲线，全部8,385组无序段组合均纳入。</p>
<table><thead><tr><th>参考线</th><th>独立核对的角度区间</th><th>自身间隙</th></tr></thead><tbody>{table}</tbody></table>
<p>独立覆盖复核：共{audit['angular_rectangles']:,}个角度区间，需参数细分的{audit['refined_piece_pairs']:,}组组合另有{audit['parameter_rectangles']:,}个完整二维参数区间。局部排除仅限整个参数区间的弧长上界≤5 mm，包含端点恢复的连接余量；其余组合达到原0.3 mm保守目标。局部曲率按既有全角度源证明分别保持P_J18_1／2的R5.842 mm和CC的R3.683 mm要求。</p>
<p>速度上界先对连续控制族应用导数算子，再使用导数控制包络；45个原构造姿态、17,415个导数控制向量另做实现核对。端点恢复使用此前单独证明的Float64误差界，没有调整曲线或硬件。</p>
<p>结合四条CAM完整上段的结果，7条已知上段的全部非局部自身检查已齐全；7条上段全部21组互线组合此前另检通过。两者都不覆盖身体前段与上段的接续，亦不等于真实材料、配对端子或完整带线装配通过。</p>
<p>剩余：上下段接续、5条缺实际端点线路、材料／裁线、端接／夹持／应力释放、带线装入与闭壳。主模型、视频和846个硬件文件保持，manufacturing_release=false。</p>
<p><a href="self_verification.json">全范围自身检查</a> · <a href="self_coverage_verification.json">独立角度与参数覆盖</a> · <a href="complete_upper_self_verification.json">7条已知上段自身汇总</a> · <a href="speed_bound_crosscheck.json">原速度与连接实现核对</a> · <a href="commands.json">实际命令</a> · <a href="../cam_moving_self_review_R1/index.html">CAM完整上段自身证据</a> · <a href="../cam_power_cross_review_R1/index.html">7条全部21组互线</a> · <a href="../index.html">上段研究总览</a></p></html>''')
    (HERE/'README.md').write_text('''# M1.55 power/CC upper remote-self review

Three unchanged nominal power/CC uppers PASS over yaw -60..60 and pitch
-20..25 degrees with complete closed parameters. Each reference has 129
cubic pieces and 8,385 unordered piece pairs. Independent coverage/root
union audit: PASS,418 angular rectangles / 39,687 parameter rectangles.

Local exclusions require a complete <=5 mm arc upper including numerical
join reserves. Other pairs preserve the original 0.3 mm gap target. The
separate all-angle radius requirements remain R5.842 mm (power) and R3.683
mm (CC). Independent source velocity/join probes:45 poses / 17,415 derivative
control vectors. These probes are implementation evidence, not full coverage.

Together with four CAM uppers, all seven known nominal upper remote-self
scopes are now covered. Their 21 mutual combinations are separately covered.
Own body-prefix joins, five missing upper endpoints, actual materials/cut
lengths/terminals/restraints, and full wired assembly/closure remain pending.
Full harness BLOCKED; no main/animation/hardware change or manufacturing
release. Initial local import-path failure is retained separately.
''')
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               sources=sources,files=files,power_upper_remote_self='PASS',power_references=3,
               power_self_angular_rectangles=audit['angular_rectangles'],
               power_self_parameter_rectangles=audit['parameter_rectangles'],
               known_upper_continuous_remote_self='PASS',known_upper_references=7,
               required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,own_prefix='NOT_TESTED',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_SELF_PUBLICATION_PASS',len(files),len(sources),3,7,flush=True)


if __name__ == '__main__':
    main()
