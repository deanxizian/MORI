"""Independent root-union and complete closed angular/parameter cover audit.

The generator, envelope and arc-refinement helpers are not imported.
Every reported root union is reconstructed from original retained records.
Counts distinguish seven own joins from 77 other-prefix comparisons.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
CAM = ['CAM_1','CAM_2','CAM_3','CAM_4']
POWER = ['P_J18_1','P_J18_2','CC_allocation']
UPPERS = CAM+POWER
COUNTS = dict(CAM_1=238,CAM_2=238,CAM_3=237,CAM_4=237,P_J18_1=129,P_J18_2=129,CC_allocation=129)
UPPER_RADII = dict(CAM_1=.3302,CAM_2=.3302,CAM_3=.3302,CAM_4=.3302,P_J18_1=.5842,P_J18_2=.5842,CC_allocation=.3683)


def coverage_2d(boxes,base):
    assert boxes and all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in boxes)
    edges = sorted({v for r in boxes for v in r[:2]})
    assert edges[0]==base[0] and edges[-1]==base[1]
    for a,b in zip(edges[:-1],edges[1:]):
        mid = (a+b)/2
        strips = sorted(r[2:4] for r in boxes if r[0]<mid<r[1])
        assert strips and strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))


def main():
    pilot = '--pilot' in sys.argv
    own_only = '--own-only' in sys.argv
    target = ('own_' if own_only else '')+('pilot_verification.json' if pilot else 'join_verification.json')
    path = HERE/target
    proof = read(path)
    assert proof['status']=='PASS' and not proof['failures']
    assert proof['mode']==('pilot' if pilot else 'all_angles') and proof['own_only']==own_only
    assert proof['required_gap_mm']==.3 and proof['local_arc_exclusion_upper_mm']==5.
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    assert all(sha(p)==h for p,h in proof['sources'].items())
    frame = ROOT.parent/'prefix_continuity/frame_family_R3'
    math_paths = [frame/'continuous_root_inspection.json',frame/'continuous_bend_inspection.json',
                  ROOT/'cam_math_review_R1/nominal_math_verification.json',ROOT/'power_math_verification.json']
    body,bend,cm,pm = [read(p) for p in math_paths]
    assert all(q['status']=='PASS' and all(sha(p)==h for p,h in q['sources'].items()) for q in [body,bend,cm,pm])
    assert body['wire_count']==bend['wire_count']==12 and bend['required_radius_mm']==6.865
    prefix_probe_path = HERE/'prefix_envelope_crosscheck.json'
    prefix_probe = read(prefix_probe_path)
    assert prefix_probe['status']=='PASS' and prefix_probe['source_pose_comparisons']==180
    assert prefix_probe['group_control_comparisons']==540 and prefix_probe['maximum_positive_excess_mm']==0.
    assert prefix_probe['minimum_speed_upper_reserve_mm']>=0 and prefix_probe['canonical_cubic_pieces']==45
    assert all(sha(p)==h for p,h in prefix_probe['sources'].items())
    names = list(prefix_probe['prefix_radii_mm'])
    assert len(names)==12 and set(UPPERS)<=set(names)
    prefix_rows = [{q['wire']:q for q in row['certificates']} for row in body['certificates']]
    assert all(set(q)==set(names) for q in prefix_rows)
    intervals = [row['yaw_interval_deg'] for row in body['certificates']]
    assert intervals[0][0]==-60 and intervals[-1][1]==60
    assert all(p[1]==q[0] for p,q in zip(intervals[:-1],intervals[1:]))
    upper_parents = {n:[r for r in cm['length_rectangles'] if r['wire']==n] for n in CAM}
    upper_parents.update({n:[r for r in pm['rows'] if r['wire']==n] for n in POWER})
    for rows in upper_parents.values():
        coverage_2d([r['rectangle_deg'] for r in rows],(-60.,60.,-20.,25.))
    bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    assert proof['bases']==[list(r) for r in bases]
    pairs = [(n,n) for n in UPPERS] if own_only else list(itertools.product(names,UPPERS))
    assert proof['expected_pairs']==len(pairs) and [(r['prefix'],r['upper']) for r in proof['results']]==pairs
    totals = dict(angular_rectangles=0,refined_piece_products=0,parameter_rectangles=0,
                  local_parameter_rectangles=0,hull_parameter_rectangles=0,own_prefix_pairs=0,other_prefix_pairs=0)
    summaries = []
    minimum = float('inf')
    for result in proof['results']:
        a,b = result['prefix'],result['upper']
        own = a==b
        assert result['status']=='PASS' and result['own_prefix']==own
        assert result['prefix_radius_mm']==prefix_probe['prefix_radii_mm'][a]
        assert result['upper_radius_mm']==UPPER_RADII[b]
        assert result['radius_sum_mm']==result['prefix_radius_mm']+result['upper_radius_mm']
        totals['own_prefix_pairs' if own else 'other_prefix_pairs'] += 1
        expected = {base:[] for base in bases}
        for row in result['intervals']:
            r,base = tuple(row['rectangle_deg']),tuple(row['base_rectangle_deg'])
            assert row['status']=='PASS' and base in expected
            expected[base].append(r)
            assert len(row['root_certificates'])==2
            c,d = row['root_certificates']
            assert c['status']=='PASS' and c['wire']==a and c['method']=='guarded_body_parent_union'
            assert c['yaw_interval_deg']==list(r[:2])
            ids = [i for i,q in enumerate(intervals) if q[0]<r[1] and q[1]>r[0]]
            assert ids and c['parent_indices']==ids
            source = [prefix_rows[i][a] for i in ids]
            lo = min(q['midpoint_amplitude_mm']-q['amplitude_deviation_bound_mm'] for q in source)
            hi = max(q['midpoint_amplitude_mm']+q['amplitude_deviation_bound_mm'] for q in source)
            mid = c['midpoint_amplitude_mm']
            assert c['amplitude_deviation_bound_mm']==max(abs(lo-mid),abs(hi-mid))+1e-8
            assert c['midpoint_yaw_deg']==(r[0]+r[1])/2
            assert d['status']=='PASS' and d['wire']==b and d['method']=='guarded_parent_union'
            assert d['rectangle_deg']==list(r)
            ids = [i for i,q in enumerate(upper_parents[b])
                   if q['rectangle_deg'][0]<r[1] and q['rectangle_deg'][1]>r[0]
                   and q['rectangle_deg'][2]<r[3] and q['rectangle_deg'][3]>r[2]]
            assert ids and d['parent_indices']==ids
            source = [upper_parents[b][i] for i in ids]
            if b in CAM:
                for key,op in [('height_lower_mm',min),('height_upper_mm',max),('return_lower_mm',min),('return_upper_mm',max)]:
                    assert d[key]==op(q[key] for q in source)
            else:
                lo = min(q['midpoint_amplitude_mm']-q['amplitude_deviation_bound_mm'] for q in source)
                hi = max(q['midpoint_amplitude_mm']+q['amplitude_deviation_bound_mm'] for q in source)
                assert d['midpoint_amplitude_mm']==(lo+hi)/2 and d['amplitude_deviation_bound_mm']==(hi-lo)/2+1e-9
            parts = [tuple(q) for q in row['refined_piece_products']]
            assert len(parts)==len(set(parts)) and all(0<=i<45 and 0<=j<COUNTS[b] for i,j in parts)
            assert row['complete_piece_products']==45*COUNTS[b]
            assert row['coarse_local_products']+row['coarse_separated_products']+len(parts)==45*COUNTS[b]
            assert own or row['coarse_local_products']==0
            assert [tuple(q['pieces']) for q in row['parameter_refinements']]==parts
            for detail in row['parameter_refinements']:
                cells = detail['parameter_rectangles']
                coverage_2d([q['parameter_rectangle'] for q in cells],(0.,1.,0.,1.))
                for q in cells:
                    if q['method']=='local_arc':
                        assert own and 0<=q['arc_upper_mm']<=5.
                        totals['local_parameter_rectangles'] += 1
                    else:
                        assert q['method']=='complete_hull' and q['gap_lower_mm']>=.3
                        totals['hull_parameter_rectangles'] += 1
                totals['parameter_rectangles'] += len(cells)
            assert row['gap_lower_mm'] is None or row['gap_lower_mm']>=.3
            if row['gap_lower_mm'] is not None:
                minimum = min(minimum,row['gap_lower_mm'])
            totals['refined_piece_products'] += len(parts)
            totals['angular_rectangles'] += 1
        for base,rectangles in expected.items():
            coverage_2d(rectangles,base)
        summaries.append(dict(prefix=a,upper=b,own_prefix=own,status='PASS',angular_rectangles=len(result['intervals']),
                              complete_cubic_piece_products=45*COUNTS[b]))
    join_probe_path = HERE/'join_source_crosscheck.json'
    probe = read(join_probe_path)
    assert probe['status']=='PASS' and probe['source_pose_comparisons']==105 and probe['known_upper_references']==7
    assert probe['maximum_endpoint_gap_mm']<=1e-8 and probe['maximum_tangent_unit_error']<=1e-8
    assert probe['minimum_speed_upper_reserve_mm']>=0 and probe['minimum_join_reserve_mm']>=0
    assert all(sha(p)==h for p,h in probe['sources'].items())
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = proof['sources'] | probe['sources'] | prefix_probe['sources']
    for p in [Path(__file__),path,join_probe_path,prefix_probe_path,*math_paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               mode=proof['mode'],scope='Independent complete nominal prefix-upper root/angle/parameter covers',
               sources=sources,results=summaries,comparisons=len(pairs),**totals,
               minimum_certified_gap_lower_mm=minimum,required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,
               own_prefix='PASS' if not pilot else 'NOT_TESTED',
               other_prefix='PASS' if not pilot and not own_only else 'NOT_TESTED',
               actual_transitions='BLOCKED',full_harness='BLOCKED',protected_hardware_files=846,
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    name = ('own_' if own_only else '')+('pilot_coverage_verification.json' if pilot else 'join_coverage_verification.json')
    (HERE/name).write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_UPPER_COVERAGE_PASS',proof['mode'],len(pairs),totals,846,flush=True)


if __name__=='__main__':
    main()
