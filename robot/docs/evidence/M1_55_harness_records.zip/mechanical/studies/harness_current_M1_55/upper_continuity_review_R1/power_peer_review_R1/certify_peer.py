"""Whole-angle pair separation for the existing three power/CC references.

Use the verified complete-parameter boxes in one common ideal yaw frame.
Every point on both curves lies in its own closed-cell cover. KD queries are
only anchor distance fields; movement/parameter radii give conservative bounds.
No purchased/printed geometry, curve constructor or threshold is changed.
"""
from pathlib import Path
from collections import OrderedDict
import datetime,itertools,json,sys,time
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent
sys.path[:0]=[str(HERE),'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',
             str(MATH/'native_clearance_review_R1'),str(MATH)]
from scipy.spatial import cKDTree
from power_native_envelopes import NativeEnvelopes,NAMES,sha
from piecewise_geometry import RADII
from parameter_balls import movement

GAP=.3;NUMERIC=.0001


def cache(store,key,value,limit):
    store[key]=value;store.move_to_end(key)
    while len(store)>limit:store.popitem(last=False)
    return value


def main():
    started=time.time();e=NativeEnvelopes();pairs=list(itertools.combinations(NAMES,2))
    references=OrderedDict();fields=OrderedDict();certificates=OrderedDict();visits=0;queries=0
    def ref(name,pose):
        key=name,*pose
        if key not in references:
            r=e.reference(name,*pose);r['yaw_points']=e.relative_points(r,'yaw')
            cache(references,key,r,64)
        references.move_to_end(key);return references[key]
    def field(pair,pose):
        nonlocal queries
        key=*pair,*pose
        if key not in fields:
            a,b=[ref(n,pose)['yaw_points'] for n in pair]
            da,_=cKDTree(b).query(a,workers=1);db,_=cKDTree(a).query(b,workers=1)
            queries+=len(a)+len(b);cache(fields,key,(da,db),64)
        fields.move_to_end(key);return fields[key]
    def certificate(name,rectangle):
        key=name,*rectangle
        if key not in certificates:cache(certificates,key,e.e.certificate(name,rectangle),512)
        certificates.move_to_end(key);return certificates[key]
    def compare(pair,rectangle,certs,pose):
        da,db=field(pair,pose);radii=[movement(e,n,rectangle,c,ref(n,pose)) for n,c in zip(pair,certs)]
        ra,rb=radii;nominal=float(min(da.min(),db.min()))-sum(RADII[n] for n in pair)-NUMERIC
        lower=max(float(np.min(da-ra)-rb.max()),float(np.min(db-rb)-ra.max()))-sum(RADII[n] for n in pair)-NUMERIC
        return dict(status='PASS' if lower>=GAP else 'BLOCKED',gap_lower_mm=lower,
                    anchor_point_surface_gap_mm=nominal,reference_pose_deg=list(pose),
                    maximum_complete_parameter_radius_mm=[float(ra.max()),float(rb.max())])
    pilot='--pilot' in sys.argv
    bases=[(y,y+10,p,p+5) for y in range(-60,60,10) for p in range(-20,25,5)]
    if pilot:bases=[(-60,-50,-20,-15),(-10,0,0,5),(50,60,20,25)]
    results=[];failures=[];minimum=float('inf')
    for pair in pairs:
        accepted=[]
        for base in bases:
            todo=[(base,0)]
            while todo:
                rectangle,depth=todo.pop();visits+=1;yl,yh,pl,ph=rectangle
                mid=((yl+yh)/2,(pl+ph)/2);certs=[certificate(n,rectangle) for n in pair]
                checked=None
                if all(c['status']=='PASS' for c in certs):
                    anchor=(max(-60.,min(60.,round(mid[0]/5)*5)),max(-20.,min(25.,round(mid[1]/2.5)*2.5)))
                    checked=compare(pair,rectangle,certs,anchor)
                    if checked['status']!='PASS':checked=compare(pair,rectangle,certs,mid)
                if checked and checked['status']=='PASS':
                    accepted.append(dict(rectangle_deg=list(rectangle),base_rectangle_deg=list(base),**checked))
                    minimum=min(minimum,checked['gap_lower_mm'])
                elif checked and checked['anchor_point_surface_gap_mm']<GAP or depth>=18:
                    failures.append(dict(wires=list(pair),rectangle_deg=list(rectangle),depth=depth,
                        roots=[c['status'] for c in certs],details=checked,
                        reason='Finite source point pair below target' if checked and checked['anchor_point_surface_gap_mm']<GAP else 'Undecided closed-parameter/angle cover'))
                    break
                else:
                    if (yh-yl)/10>(ph-pl)/5:
                        todo.extend([((yl,mid[0],pl,ph),depth+1),((mid[0],yh,pl,ph),depth+1)])
                    else:todo.extend([((yl,yh,pl,mid[1]),depth+1),((yl,yh,mid[1],ph),depth+1)])
                if visits%500==0:print('POWER_PEER_PROGRESS',list(pair),visits,len(accepted),queries,round(time.time()-started,1),flush=True)
            if failures:break
        status='PASS' if not failures else 'BLOCKED'
        results.append(dict(wires=list(pair),status=status,accepted_rectangles=len(accepted),intervals=accepted))
        print('POWER_PEER_PAIR',list(pair),status,len(accepted),round(time.time()-started,1),flush=True)
        if failures:break
    e.unchanged();sources=dict(e.sources)
    for p in [Path(__file__),HERE/'parameter_balls.py']:sources[str(p)]=sha(p)
    out=dict(status='PASS' if len(results)==3 and not failures else 'BLOCKED',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
             scope='Three current power/CC upper reference pairs, complete curve-parameter covers and ideal nominal common yaw frame; not physical wires',
             mode='pilot' if pilot else 'all_angles',bases=[list(b) for b in bases],results=results,failures=failures,
             minimum_certified_gap_lower_mm=minimum,required_gap_mm=GAP,query_numeric_reserve_mm=NUMERIC,
             parameter_cells_per_reference=len(e.parameter_cells),yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
             anchor_distance_queries=queries,visited_rectangles=visits,CAM_upper='NOT_TESTED',remote_self='NOT_TESTED',
             actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
             animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/('pilot_verification.json' if pilot else 'peer_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PEER_TERMINAL',out['status'],len(results),visits,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
