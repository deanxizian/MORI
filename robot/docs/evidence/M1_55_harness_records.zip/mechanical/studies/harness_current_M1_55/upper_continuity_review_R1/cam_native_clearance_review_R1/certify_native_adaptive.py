"""Adaptive subdivision of the unchanged four nominal CAM native gap checks.

Unchanged201 native targets are separated into body, yaw, and pitch frames.
An assumed USB proxy is checked separately. Canonical zero-length slots are
included, not discarded around pitch zero. No route or hardware is resized.
"""
from pathlib import Path
from collections import OrderedDict
import datetime
import importlib.util
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=[str(HERE),str(PARENT),str(MATH/'native_clearance_review_R1')]
from context import Context,sha
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,RADII,Box,restrictions,linear

DISTANCE_SOURCE=MATH/'native_clearance_review_R1/certify_native.py'
spec=importlib.util.spec_from_file_location('mori_power_native_distance_reference',DISTANCE_SOURCE)
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
distance_field=legacy.distance_field
GAP=.3;NUMERIC=.0001


def store(cache,key,value,limit):
    cache[key]=value;cache.move_to_end(key)
    while len(cache)>limit:cache.popitem(last=False)


def aabb_separation(controls,radius,targets):
    """Distance from complete cubic control hull boxes to all target AABBs.

    A positive bound proves separation without a native surface query. A low
    AABB bound is only inconclusive and falls through to the retained BVH
    method; it never establishes a collision or waives an object.
    """
    names=list(targets)
    lo=controls.lo.min(1);hi=controls.hi.max(1)
    target_lo=np.array([targets[n]['lo'] for n in names])
    target_hi=np.array([targets[n]['hi'] for n in names])
    outside=np.maximum(np.maximum(target_lo[None]-hi[:,None],lo[:,None]-target_hi[None]),0.)
    distances=np.linalg.norm(outside,axis=-1)-radius-NUMERIC
    index=np.unravel_index(int(np.argmin(distances)),distances.shape)
    return dict(gap_lower_mm=float(distances[index]),curve_piece=int(index[0]),nearest_object=names[index[1]])


def choose_axis(e,name,rectangle,checked,reference):
    """Choose the half-box with the smaller worst failed-cell motion bound.

    This affects subdivision order only. Both children are still covered and
    verified with the same whole-parameter native gap requirements.
    """
    yl,yh,pl,ph=rectangle;ym=(yl+yh)/2;pm=(pl+ph)/2
    failed=sorted(checked['failed_bounds'],key=lambda row:row['gap_lower_mm'])[:2]
    if not failed:return 0 if (yh-yl)/10>(ph-pl)/5 else 1
    trials=[[(yl,ym,pl,ph),(ym,yh,pl,ph)],[(yl,yh,pl,pm),(yl,yh,pm,ph)]]
    scores=[]
    for children in trials:
        score=-float('inf')
        for child in children:
            certificate=e.certificate(name,child)
            height=Box(certificate['height_lower_mm'],certificate['height_upper_mm'])
            for row in failed:
                frame='pitch' if row['group']=='USB_conditional' else row['group']
                controls=e.controls(name,child,height,frame)[0]
                piece,a,b=row['curve_piece_and_parameter_interval'];piece=int(piece)
                ops=restrictions(np.eye(4),np.array([[a,b]]))[0]
                bounded=linear(ops,controls[piece])
                lo=bounded.lo.min(0);hi=bounded.hi.max(0)
                layout=e.layout[name]['parameter_cells']
                ids=np.flatnonzero((layout[:,0]==piece)&(layout[:,1]==a)&(layout[:,2]==b))
                assert len(ids)==1
                point=reference(name,*row['reference_pose_deg'])['points'][frame][int(ids[0])]
                motion=float(np.linalg.norm(np.maximum(abs(lo-point),abs(hi-point))))+1e-8
                score=max(score,motion-row['reference_nominal_gap_lower_mm'])
        scores.append(score)
    return int(scores[1]<scores[0])


def main():
    started=time.time();pilot='--pilot' in sys.argv
    ctx=Context();e=NativeCAMEnvelopes()
    cross_path=HERE/('envelope_pilot_crosscheck.json' if pilot else 'envelope_crosscheck.json')
    cross=json.loads(cross_path.read_text())
    assert cross['status']=='PASS'
    if not pilot:assert cross['mode']=='full_crosscheck'
    assert all(sha(p)==h for p,h in cross['sources'].items())
    assert cross['parameter_cells_per_reference']=={n:len(e.layout[n]['parameter_cells']) for n in NAMES}
    ctx.sources.update(e.sources)
    ctx.record([Path(__file__),DISTANCE_SOURCE,cross_path,HERE/'cam_native_envelopes.py'])
    targets=ctx.groups|{'USB_conditional':ctx.usb}
    references=OrderedDict();fields=OrderedDict()
    queries=field_count=visits=aabb_proofs=0
    minimum=float('inf');conditional_minimum=float('inf')
    def reference(name,y,p):
        key=name,y,p
        if key not in references:store(references,key,e.reference(name,y,p),32)
        references.move_to_end(key);return references[key]
    def field(name,y,p,group):
        nonlocal queries,field_count
        key=name,y,p,group
        if key not in fields:
            geometry=reference(name,y,p)
            points=geometry['points']['pitch' if group=='USB_conditional' else group]
            value=distance_field(points,RADII[name],targets[group])
            queries+=value['queries'];field_count+=1;store(fields,key,value,64)
        fields.move_to_end(key);return fields[key]
    def compare(name,rectangle,certificate,anchor):
        nonlocal aabb_proofs
        records=[];failed=[];nominal=[]
        height=Box(certificate['height_lower_mm'],certificate['height_upper_mm'])
        for group in targets:
            frame='pitch' if group=='USB_conditional' else group
            controls=e.controls(name,rectangle,height,frame)[0]
            coarse=aabb_separation(controls,RADII[name],targets[group])
            if coarse['gap_lower_mm']>=GAP:
                aabb_proofs+=1
                records.append(dict(group=group,method='complete_cubic_control_AABB_separation',
                                    whole_parameter_cell_motion_bound_mm=None,reference_pose_deg=None,**coarse))
                continue
            geometry=reference(name,*anchor)
            measured=field(name,*anchor,group)
            motion=e.motion(name,rectangle,certificate,geometry,frame)
            lower=measured['values']-motion
            i=int(np.argmin(lower));gap=float(lower[i]);oi=int(measured['closest'][i])
            row=dict(group=group,method='closed_parameter_cell_BVH_distance_and_motion_ball',
                     gap_lower_mm=gap,reference_nominal_gap_lower_mm=float(measured['values'][i]),
                     whole_parameter_cell_motion_bound_mm=float(motion[i]),
                     nearest_object=measured['names'][oi] if oi>=0 else 'PROVED_AABB_CAP',
                     curve_piece_and_parameter_interval=e.layout[name]['parameter_cells'][i].tolist(),
                     reference_pose_deg=list(anchor))
            records.append(row)
            if gap<GAP or measured['inside']:failed.append(row)
            if measured['inside'] or float(measured['values'].min())<GAP:
                nominal.append(dict(group=group,anchor_surface_gap_mm=float(measured['values'].min()),
                                    inside=measured['inside'],anchor_pose_deg=list(anchor)))
        return dict(status='PASS' if not failed else 'BLOCKED',rows=records,failed_bounds=failed,
                    nominal_failures=nominal)
    results=[];failures=[]
    for name in NAMES:
        parents=e.parents[name]
        if pilot:
            indices=np.unique(np.r_[0,len(parents)//2,len(parents)-1,
                                    np.argmin([r['height_lower_mm'] for r in parents])])
            selected=[(int(i),parents[int(i)]) for i in indices]
        else:selected=list(enumerate(parents))
        accepted=[]
        for parent_index,parent in selected:
            base=tuple(parent['rectangle_deg']);todo=[(base,0,parent)]
            while todo:
                rectangle,depth,certificate=todo.pop();visits+=1
                yl,yh,pl,ph=rectangle;mid=((yl+yh)/2,(pl+ph)/2)
                if certificate is None:certificate=e.certificate(name,rectangle)
                anchor=(max(-60.,min(60.,round(mid[0]/5)*5)),max(-20.,min(25.,round(mid[1]/2.5)*2.5)))
                checked=compare(name,rectangle,certificate,anchor)
                if checked['status']!='PASS':checked=compare(name,rectangle,certificate,mid)
                if checked['status']=='PASS':
                    accepted.append(dict(status='PASS',rectangle_deg=list(rectangle),source_math_parent_index=parent_index,
                                         source_math_rectangle_deg=list(base),rows=checked['rows']))
                    minimum=min(minimum,min(r['gap_lower_mm'] for r in checked['rows'] if r['group']!='USB_conditional'))
                    conditional_minimum=min(conditional_minimum,next(r['gap_lower_mm'] for r in checked['rows'] if r['group']=='USB_conditional'))
                elif checked['nominal_failures'] or depth>=18:
                    failures.append(dict(wire=name,rectangle_deg=list(rectangle),depth=depth,details=checked,
                                         reason='Fresh nominal query below target' if checked['nominal_failures'] else 'Unresolved closed-parameter/angle enclosure'))
                    break
                else:
                    if choose_axis(e,name,rectangle,checked,reference)==0:
                        todo.extend([((yl,mid[0],pl,ph),depth+1,None),((mid[0],yh,pl,ph),depth+1,None)])
                    else:
                        todo.extend([((yl,yh,pl,mid[1]),depth+1,None),((yl,yh,mid[1],ph),depth+1,None)])
                if visits%100==0:
                    print('CAM_NATIVE_PROGRESS',name,visits,len(accepted),field_count,queries,round(time.time()-started,1),flush=True)
            if failures:break
        result=dict(wire=name,status='PASS' if not failures else 'BLOCKED',planned_math_rectangles=len(selected),
                    source_math_parent_indices=[i for i,_ in selected],accepted_rectangles=len(accepted),intervals=accepted)
        results.append(result)
        print('CAM_NATIVE_WIRE',name,result['status'],len(accepted),field_count,queries,round(time.time()-started,1),flush=True)
        if failures:break
    ctx.unchanged();e.unchanged()
    out=dict(status='PASS' if len(results)==4 and not failures else 'BLOCKED',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode='pilot' if pilot else 'all_angles',
             scope='Four nominal CAM upper references against current201 native meshes; whole closed curve parameters, assumed USB separate',
             sources=ctx.sources,results=results,failures=failures,names=NAMES,native_parts=201,required_gap_mm=GAP,
             reference_radii_mm={n:RADII[n] for n in NAMES},native_numeric_query_reserve_mm=NUMERIC,
             minimum_certified_native_gap_lower_mm=minimum,minimum_conditional_USB_gap_lower_mm=conditional_minimum,
             parameter_cells_per_reference={n:len(e.layout[n]['parameter_cells']) for n in NAMES},
             canonical_pieces_per_reference={n:len(e.layout[n]['labels']) for n in NAMES},
             visited_rectangles=visits,cached_reference_fields_created=field_count,BVH_distance_queries=queries,
             complete_control_AABB_proofs=aabb_proofs,yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
             native_frame='Ideal nominal Rz(yaw)Rx(pitch) about current head centre',
             canonical_zero_angle_slots='Degenerate points included; no source geometry or small nonzero arcs omitted',
             source_float32_all_angle_rounding='NOT_TESTED',actual_USB_tail='BLOCKED',peer_clearance='NOT_TESTED',
             remote_self='NOT_TESTED',actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',
             main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
             elapsed_s=time.time()-started)
    (HERE/('pilot_native_adaptive_verification.json' if pilot else 'native_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_NATIVE_TERMINAL',out['status'],len(results),field_count,queries,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
