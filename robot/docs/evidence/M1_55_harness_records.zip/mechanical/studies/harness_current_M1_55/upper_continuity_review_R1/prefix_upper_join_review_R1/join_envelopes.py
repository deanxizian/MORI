"""Nominal body-prefix/upper envelopes, with each source's own allocation.

This wrapper retains the original 12 body prefixes and seven known uppers.
Existing complete root covers and frozen derivative helpers are reused.
Body and upper radii are deliberately separate: CAM changes allocation at
the join. No physical splice, connector or material is inferred from this.
"""
from pathlib import Path
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT/'cam_power_cross_review_R1'),
               str(ROOT/'power_self_review_R1'),
               str(ROOT/'cam_moving_self_review_R1'),
               str(ROOT/'cam_peer_review_R1')]
from cross_envelopes import CrossEnvelopes,CAM_NAMES,POWER_NAMES,RADII,sha
from source_root_covers import RootCovers
from power_self_envelopes import PowerSelfEnvelopes
from arc_speed_bounds import speeds as cam_speeds
from prefix_envelopes import PrefixEnvelopes

UPPER_NAMES = tuple(CAM_NAMES+POWER_NAMES)
NUMERIC = 1e-8


class JoinEnvelopes:
    def __init__(self):
        self.cross = CrossEnvelopes()
        self.prefix = PrefixEnvelopes(self.cross)
        self.roots = RootCovers(self.cross)
        self.power_speed = PowerSelfEnvelopes()
        # The independently guarded helper uses the identical power family.
        assert np.array_equal(self.power_speed.e.e.H,self.cross.power.e.H)
        assert np.array_equal(self.power_speed.e.center,self.cross.power.center)
        self.prefix_names = tuple(self.prefix.f.names)
        assert set(UPPER_NAMES)<=set(self.prefix_names) and len(self.prefix_names)==12
        self.sources = self.cross.sources | self.prefix.sources | self.roots.sources | self.power_speed.sources
        for p in [Path(__file__),ROOT/'cam_moving_self_review_R1/arc_speed_bounds.py']:
            self.sources[str(p)] = sha(p)
        for name in ['prefix_envelope_crosscheck.json']:
            p = HERE/name
            proof = json.loads(p.read_text())
            assert proof['status']=='PASS' and all(sha(q)==h for q,h in proof['sources'].items())
            self.sources[str(p)] = sha(p)

    def upper(self,name,rectangle,certificate,group):
        if name in CAM_NAMES:
            return self.cross.cam_controls(name,rectangle,certificate,group)
        return self.cross.power_controls(name,rectangle,certificate,group)

    def upper_speeds(self,name,rectangle,certificate):
        if name in CAM_NAMES:
            return cam_speeds(self.cross.cam,name,rectangle,certificate)
        return self.power_speed.speeds(name,rectangle,certificate)

    def upper_joins(self,name):
        if name in CAM_NAMES:
            # The high-precision constructor joins exact symbolic datums.
            # One arithmetic reserve per Float64 conversion is conservative.
            count = self.cross.cam.layout[name]['tail_index']+len(self.cross.cam.tail[name])
            return np.full(count-1,NUMERIC)
        return self.power_speed.join_upper(name)

    def combined_arcs(self,prefix_density,upper_density,upper_joins):
        # Bezier extraction reuses identical adjacent endpoint operators.
        # Count the arithmetic join reserve at every body and upper seam.
        a = np.asarray(prefix_density,float)
        b = np.asarray(upper_density,float)
        n,m = len(a),len(b)
        prefix_remaining = np.cumsum(a[::-1])[::-1]+NUMERIC*np.arange(n,0,-1)
        upper_to_end = np.cumsum(b)+np.r_[0.,np.cumsum(upper_joins)]
        return prefix_remaining[:,None]+upper_to_end[None,:]

    def arc_upper(self,a,b,joins,i,j,rectangle):
        ta,tb,ua,ub = rectangle
        return (float(a[i])*(1-ta)+float(a[i+1:].sum())
                +float(b[:j].sum())+float(b[j])*ub
                +NUMERIC*(len(a)-i)+float(joins[:j].sum()))

    def unchanged(self):
        self.cross.unchanged()
        self.prefix.unchanged()
        self.roots.unchanged()
        self.power_speed.unchanged()
        assert all(sha(p)==h for p,h in self.sources.items())
