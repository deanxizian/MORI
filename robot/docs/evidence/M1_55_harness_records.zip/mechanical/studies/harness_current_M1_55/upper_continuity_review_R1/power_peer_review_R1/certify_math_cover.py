"""Reuse verified length-root covers for full-angle power/CC pair clearance.

Intersect the two complete mathematical partitions, then reuse each parent's
certified amplitude range. Recompute a narrower root enclosure only when a gap
bound needs refinement. Existing curves, 0.3mm target and whole-parameter balls
are identical to the independently probed peer implementation.
"""
from pathlib import Path
from collections import OrderedDict
import datetime,itertools,json,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;MATH=HERE.parent
sys.path[:0]=[str(HERE),'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',
             str(MATH/'native_clearance_review_R1'),str(MATH)]
from scipy.spatial import cKDTree
from power_native_envelopes import NativeEnvelopes,NAMES,sha
from parameter_balls import movement
from piecewise_geometry import RADII
from weighted_peer import field as weighted_field,score as weighted_score

GAP=.3;NUMERIC=.0001


def cache(store,key,value,limit=64):
    store[key]=value;store.move_to_end(key)
    while len(store)>limit:store.popitem(last=False)
    return value


def intersections(a,b,windows=None):
    bounds=np.array([q['rectangle_deg'] for q in b])
    for ia,left in enumerate(a):
        yl,yh,pl,ph=left['rectangle_deg']
        matched=np.flatnonzero((bounds[:,0]<yh)&(bounds[:,1]>yl)&(bounds[:,2]<ph)&(bounds[:,3]>pl))
        for ib in matched:
            r=bounds[ib];base=(max(yl,r[0]),min(yh,r[1]),max(pl,r[2]),min(ph,r[3]))
            for w in windows or [base]:
                box=(max(base[0],w[0]),min(base[1],w[1]),max(base[2],w[2]),min(base[3],w[3]))
                if box[0]<box[1] and box[2]<box[3]:yield ia,int(ib),box


def main():
    started=time.time();e=NativeEnvelopes();pilot='--pilot' in sys.argv
    proof_path=MATH/'power_math_verification.json';proof=json.loads(proof_path.read_text())
    cross_path=HERE/'parameter_ball_crosscheck.json';cross=json.loads(cross_path.read_text())
    assert proof['status']==cross['status']=='PASS' and cross['parameter_cells_per_curve']==9216
    assert all(sha(p)==h for p,h in cross['sources'].items())
    source=dict(e.sources)
    for p in [Path(__file__),HERE/'parameter_balls.py',HERE/'weighted_peer.py',cross_path,proof_path]:source[str(p)]=sha(p)
    parents={n:[r for r in proof['rows'] if r['wire']==n] for n in NAMES}
    references=OrderedDict();fields=OrderedDict();visits=0;queries=0;new_roots=0
    def ref(name,pose):
        key=name,*pose
        if key not in references:
            r=e.reference(name,*pose);r['yaw_points']=e.relative_points(r,'yaw');cache(references,key,r)
        references.move_to_end(key);return references[key]
    def field(pair,pose,group):
        nonlocal queries
        key=*pair,*pose,group
        if key not in fields:
            a,b=[e.relative_points(ref(n,pose),group) for n in pair]
            queries+=len(a)*64;cache(fields,key,weighted_field(a,b),16)
        fields.move_to_end(key);return fields[key]
    def compare(pair,r,certs,pose):
        best=None
        for group in ['yaw','pitch']:
            ra,rb=[movement(e,n,r,c,ref(n,pose)) if group=='yaw' else e.motion(n,r,c,ref(n,pose),'pitch') for n,c in zip(pair,certs)]
            measured=weighted_score(field(pair,pose,group),ra,rb,sum(RADII[n] for n in pair),GAP,NUMERIC)
            measured.pop('lower');lower=measured['gap_lower_mm']
            result=dict(status='PASS' if lower>=GAP else 'BLOCKED',group=group,reference_pose_deg=list(pose),
                        maximum_complete_parameter_radius_mm=[float(ra.max()),float(rb.max())],**measured)
            if best is None or lower>best['gap_lower_mm']:best=result
            if result['status']=='PASS':break
        return best
    windows=[(-60,-50,-20,-15),(-10,0,0,5),(50,60,20,25)] if pilot else None
    results=[];failures=[];minimum=float('inf')
    for pair in itertools.combinations(NAMES,2):
        accepted=[];base_count=0
        for ia,ib,base in intersections(parents[pair[0]],parents[pair[1]],windows):
            base_count+=1;todo=[(base,0,[parents[pair[0]][ia],parents[pair[1]][ib]])]
            while todo:
                rectangle,depth,certs=todo.pop();visits+=1;yl,yh,pl,ph=rectangle
                mid=((yl+yh)/2,(pl+ph)/2);checked=None
                if certs is None:
                    certs=[e.e.certificate(n,rectangle) for n in pair];new_roots+=2
                if all(c['status']=='PASS' for c in certs):
                    anchor=(max(-60.,min(60.,round(mid[0]/5)*5)),max(-20.,min(25.,round(mid[1]/2.5)*2.5)))
                    checked=compare(pair,rectangle,certs,anchor)
                    if checked['status']!='PASS':checked=compare(pair,rectangle,certs,mid)
                if checked and checked['status']=='PASS':
                    accepted.append(dict(rectangle_deg=list(rectangle),base_rectangle_deg=list(base),
                        source_math_parent_indices=[ia,ib],root_ranges_reused=depth==0,**checked))
                    minimum=min(minimum,checked['gap_lower_mm'])
                elif checked and checked['anchor_point_surface_gap_mm']<GAP or depth>=18:
                    failures.append(dict(wires=list(pair),rectangle_deg=list(rectangle),depth=depth,details=checked,
                        reason='Finite source point pair below target' if checked and checked['anchor_point_surface_gap_mm']<GAP else 'Undecided complete-parameter/angle bound'))
                    break
                else:
                    if (yh-yl)/10>(ph-pl)/5:
                        todo.extend([((yl,mid[0],pl,ph),depth+1,None),((mid[0],yh,pl,ph),depth+1,None)])
                    else:todo.extend([((yl,yh,pl,mid[1]),depth+1,None),((yl,yh,mid[1],ph),depth+1,None)])
                if visits%1000==0:print('POWER_PEER_MATH_PROGRESS',list(pair),visits,len(accepted),new_roots,round(time.time()-started,1),flush=True)
            if failures:break
        status='PASS' if not failures else 'BLOCKED'
        results.append(dict(wires=list(pair),status=status,source_parent_intersections=base_count,
                            accepted_rectangles=len(accepted),intervals=accepted))
        print('POWER_PEER_MATH_PAIR',list(pair),status,base_count,len(accepted),round(time.time()-started,1),flush=True)
        if failures:break
    e.unchanged();assert all(sha(p)==h for p,h in source.items())
    out=dict(status='PASS' if len(results)==3 and not failures else 'BLOCKED',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             sources=source,mode='pilot' if pilot else 'all_angles',
             scope='Three existing power/CC upper pairs; exact root-cover intersections and complete-parameter balls in the common ideal yaw frame',
             results=results,failures=failures,pilot_windows=windows,yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
             required_gap_mm=GAP,query_numeric_reserve_mm=NUMERIC,parameter_cells_per_reference=9216,
             minimum_certified_gap_lower_mm=minimum,visited_rectangles=visits,new_root_enclosures=new_roots,
             anchor_distance_queries=queries,remote_self='NOT_TESTED',CAM_upper='NOT_TESTED',
             actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
             animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/('math_cover_pilot_verification.json' if pilot else 'peer_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PEER_MATH_TERMINAL',out['status'],visits,new_roots,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
