"""Publish the completed three-pair nominal reference proof and its audit."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    proof = read(HERE/'peer_verification.json')
    audit = read(HERE/'peer_coverage_verification.json')
    pilot = read(HERE/'pilot_coverage_verification.json')
    assert proof['status'] == audit['status'] == pilot['status'] == 'PASS'
    assert proof['mode'] == audit['mode'] == 'all_angles'
    assert audit['unordered_pairs'] == 3 and audit['required_gap_mm'] == .3
    sources = {}
    for report in [proof, audit, pilot]:
        for p,h in report['sources'].items():
            assert sha(p) == h, p
            assert p not in sources or sources[p] == h
            sources[p] = h
    assert sha(PROJECT/'mechanical/mori_v1_2.blend') == audit['source_blend_sha256']
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4') == audit['source_video_sha256']
    assert 'Traceback (most recent call last)' not in (HERE/'peer_full.log').read_text()
    assert 'POWER_PEER_MIDPOINT_DRIVER PASS' in (HERE/'peer_full.log').read_text()
    runs = [
        ('check_parameter_balls.py',[], 'parameter_ball_crosscheck.json'),
        ('check_weighted_distance.py',[], 'weighted_distance_crosscheck.json'),
        ('check_weighted_single.py',[], 'weighted_single_crosscheck.json'),
        ('run_midpoint_cover.py',['--pilot'],'math_cover_pilot_verification.json'),
        ('run_midpoint_cover.py',[],'peer_verification.json'),
        ('verify_peer.py',['--pilot'],'pilot_coverage_verification.json'),
        ('verify_peer.py',[],'peer_coverage_verification.json')]
    command_rows = []
    for script,arguments,report in runs:
        result = read(HERE/report)
        assert result['status'] == 'PASS'
        interpreter = '/Users/dean/.cache/codex-runtimes/mori-cad/bin/python' if script == 'verify_peer.py' else '/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
        command_rows.append(dict(command=[interpreter,str((HERE/script).relative_to(PROJECT)),*arguments],
                                 cwd=str(PROJECT),result=report,result_sha256=sha(HERE/report),
                                 scope='The actual numeric execution and saved result; full geometric proof is only the non-pilot run.'))
        if script == 'run_midpoint_cover.py' and not arguments:
            command_rows[-1].update(environment={'OPENBLAS_NUM_THREADS':'1'},stdout_stderr_log='peer_full.log')
    archived = []
    for receipt_path in sorted(HERE.rglob('source_archive_receipt.json')):
        receipt = read(receipt_path)
        assert receipt['status'] == 'PASS'
        assert all(sha(r['archived']) == r['sha256'] for r in receipt['files'])
        archived.append(dict(receipt=str(receipt_path.relative_to(HERE)),sha256=sha(receipt_path),
                             scope='Retained exact source/log bytes, including unsuccessful executions; not substituted into the final proof.'))
    commands = dict(status='PASS',Python_numeric='3.13.13',NumPy='2.3.4',SciPy='1.16.2',
                    Python_publication='3.12.14',commands=command_rows,archived_attempts=archived,
                    full_execution_log='peer_full.log',full_execution_log_sha256=sha(HERE/'peer_full.log'),
                    actual_initial_anchor_queries=proof['anchor_distance_queries'],
                    legacy_core_allocation_units=proof['anchor_query_allocation_units_in_core'],
                    core_accounting_note='The original core counts64 allocation units per centre. Actual midpoint-driver queries use one neighbour; both are preserved.',
                    main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    table = ''.join('<tr><td>'+html.escape(' / '.join(r['wires']))+'</td><td>'+str(r['source_parent_intersections'])+
                    '</td><td>'+str(r['accepted_rectangles'])+'</td><td>PASS</td></tr>' for r in audit['pair_counts'])
    page = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>电源／CC上段全范围互线间隙</title><style>body{{max-width:1000px;margin:30px auto;padding:0 22px;font:16px/1.7 system-ui;color:#253641;background:#f5f7f8}}section{{background:white;padding:20px;margin:20px 0;border:1px solid #d6dfe5;border-radius:10px}}table{{border-collapse:collapse;width:100%}}td,th{{padding:10px;border:1px solid #d9e2e7;text-align:left}}a{{color:#185e95}}</style>
<p><a href="../index.html">已知上段连续检查</a> · <a href="../../index.html">线束研究总页</a></p>
<h1>三条电源／CC参考：全范围互线间隙通过</h1>
<p>PLACEHOLDER / ASSUMED · 未采用 · 完整线束仍 BLOCKED</p>
<section><h2>已完成</h2><p>P_J18_1、P_J18_2 与 CC_allocation 共三组配对，覆盖偏航−60°～+60°、俯仰−20°～+25°。
每条参考完整曲线分为9,216个闭参数区间；中点位置包络加完整导数控制包络得到整段占用球。
对源长度根区间的交集及必要的细分区间逐项检查，原0.3mm间隙目标保持。</p>
<table><tr><th>配对</th><th>源父区间交集</th><th>通过的细分区间</th><th>结果</th></tr>{table}</table>
<p>独立用偏航扫描和俯仰区间归并重新建立父区间交集，并核对每个交集的细分覆盖，无遗漏或重复。
共{audit['source_parent_intersections']:,}个父区间交集、{audit['accepted_rectangles']:,}个通过区间。</p></section>
<section><h2>距离查询范围</h2><p>单个最近点只用于初始查询。可能影响下界的其他完整占用球由可变半径排除球查询全部纳入；排除球外的球按最大占用半径证明超过目标。
下界{audit['minimum_certified_gap_lower_mm']:.6f}mm包含查询数值预留；恰为0.3mm的行是排除球证明的保守截断，不能解读为实际线距只有0.3mm。</p>
<p>每行选用共同名义yaw或pitch框架。原始继承报告的scope字符串只写yaw，实际行和独立审计同时记录两种框架。
实际初始中心查询{proof['anchor_distance_queries']:,}次；原核心64倍分配计数另存，未把它当作实际距离查询次数。</p></section>
<section><h2>仍未完成</h2><p>三条参考的连续自身接近、四条CAM新参考的实体／互线／自身／前段接续、五条缺实际端点的线路仍未闭合。
实际材料、完整端接、应力释放、供应商裁线图、带线装头和闭壳还需完成。</p>
<p>主模型M1.55、视频M1.55-A1和846个硬件文件保持。这里是理想名义旋转下的参考几何证明，原浮点变换助手全范围舍入和实物动态线束均未资格化。</p></section>
<section><h2>证据</h2><p><a href="peer_verification.json">完整配对证明</a> · <a href="peer_coverage_verification.json">独立交集与覆盖审计</a> ·
<a href="midpoint_core_output.json">未调整计数的原核心报告</a> · <a href="parameter_ball_crosscheck.json">整参数占用球实现核对</a> ·
<a href="weighted_single_crosscheck.json">独立加权距离核对</a> · <a href="commands.json">实际命令与历史记录</a> · <a href="peer_full.log">完整执行日志</a> · <a href="README.md">范围说明</a></p></section></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text(f'''# 三条电源／CC上段全范围互线检查，未采用

三组配对覆盖名义偏航±60°、俯仰−20°～+25°。每条参考的9,216个闭参数区间均被覆盖。
{audit['source_parent_intersections']}个原长度根父区间交集，{audit['accepted_rectangles']}个通过的细分区间；原0.3mm目标保持。
独立偏航扫描／俯仰归并重建所有父区间交集，再核对每个交集内的叶区间覆盖。
实现的完整中点／导数占用球及加权排除球查询另有独立交叉核对。

采用共同名义yaw或pitch框架；原继承核心scope字符串只写yaw，实际行及独立审计含两者。
最小认证下界{audit['minimum_certified_gap_lower_mm']:.6f}mm。排除球外的球按最大半径证明超过目标，
因此部分行保守截断在0.3mm；这是下界而非实际线距。
原核心按64倍记分配量；驱动实际采用1个初始邻居，加完整可变半径排除球核对。
实际初始中心查询{proof['anchor_distance_queries']}次，原分配量{proof['anchor_query_allocation_units_in_core']}单列保留。

三条连续自身接近和四条新CAM参考的间隙尚未完成。材料、实际端点、固定、裁线图、带线装头与闭壳仍未闭合。
主模型、视频及846个硬件文件保持；PLACEHOLDER / ASSUMED，manufacturing_release=false。
工具、命令、日志及失败／早期试探的精确归档见commands.json。数字几何通过不代表实物或制造放行。
''')
    for p in [Path(__file__),HERE/'peer_verification.json',HERE/'peer_coverage_verification.json',
              HERE/'pilot_coverage_verification.json',HERE/'commands.json']:
        sources[str(p)] = sha(p)
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p.name not in ['delivery.json','publication_verification.json']}
    out = dict(status='PASS',scope='Three full-angle pair reference proofs and independent cover audit only',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
               continuous_power_peer_clearance='PASS',unordered_pairs=3,accepted_rectangles=audit['accepted_rectangles'],
               source_parent_intersections=audit['source_parent_intersections'],
               minimum_certified_gap_lower_mm=audit['minimum_certified_gap_lower_mm'],required_gap_mm=.3,
               native_frame='Ideal nominal Rz(yaw)Rx(pitch) about current head centre',
               source_float32_all_angle_rounding='NOT_TESTED',remote_self='NOT_TESTED',CAM_upper='NOT_TESTED',
               source_blend_sha256=audit['source_blend_sha256'],source_video_sha256=audit['source_video_sha256'],
               protected_hardware_files=846,full_harness='BLOCKED',main_changed=False,hardware_changed=False,
               animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PEER_PUBLISHED',len(files),len(sources),audit['accepted_rectangles'],flush=True)


if __name__ == '__main__':
    main()
