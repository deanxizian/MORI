"""Direct source-curve probes of whole-cell position enclosures.

These samples catch implementation mistakes. They do not supply the continuous
clearance claim; that claim requires the analytic boxes and native proof.
"""
from pathlib import Path
import datetime
import json
import time
import numpy as np
from power_native_envelopes import NativeEnvelopes,NAMES,sha,ideal_matrix,basis

HERE=Path(__file__).resolve().parent;MATH=HERE.parent


def main():
    started=time.time();e=NativeEnvelopes()
    proof=json.loads((MATH/'power_math_verification.json').read_text())
    rows=[];max_excess=0.;maximum_root_curve_difference=0.;rng=np.random.default_rng(55103)
    for name in NAMES:
        cells=[r for r in proof['rows'] if r['wire']==name]
        selected=[cells[i] for i in np.unique(np.r_[np.linspace(0,len(cells)-1,7,dtype=int),np.argmin([r['continuous_bending']['radius_lower_mm'] for r in cells])])]
        for certificate in selected:
            rectangle=certificate['rectangle_deg'];yl,yh,pl,ph=rectangle
            groups={g:e.point_boxes(name,rectangle,certificate,g) for g in ['body','yaw','pitch']}
            tests=[((yl+yh)/2,(pl+ph)/2),(yl,pl),(yh,ph),(yl,ph),(yh,pl)]
            indices=np.unique(np.r_[0,e.stub_steps-1,e.stub_steps,len(e.parameter_cells)-1,
                                     rng.integers(0,len(e.parameter_cells),32)])
            for y,p in tests:
                original,info=e.e.f.upper(name,y,p);assert original is not None,(name,y,p,info)
                reference=e.reference(name,y,p)
                difference=float(np.linalg.norm(reference['controls']-original,axis=-1).max())
                assert difference<1e-7,(name,y,p,difference)
                maximum_root_curve_difference=max(maximum_root_curve_difference,difference)
                values=[]
                for i in indices:
                    piece,lo,hi=e.parameter_cells[i]
                    # Evaluate the source cubic at independent parameter points,
                    # including both ends of the complete assigned interval.
                    u=np.linspace(lo,hi,7)
                    values.append(basis(u,3)@original[int(piece)])
                values=np.stack(values)
                for group,box in groups.items():
                    q=values
                    if group!='body':
                        matrix=np.linalg.inv(ideal_matrix(e.center,y,p if group=='pitch' else 0.))
                        q=q@matrix[:3,:3].T+matrix[:3,3]
                    lo,hi=box.lo[indices,None,:],box.hi[indices,None,:]
                    excess=float(max(np.max(lo-q),np.max(q-hi)))
                    max_excess=max(max_excess,excess)
                    assert excess<=1e-8,(name,rectangle,y,p,group,excess)
                    rows.append(dict(wire=name,rectangle_deg=rectangle,pose_deg=[y,p],group=group,
                        checked_parameter_cells=len(indices),parameters_per_cell=7,maximum_excess_mm=excess,status='PASS'))
    e.sources[str(Path(__file__))]=sha(Path(__file__));e.unchanged()
    out=dict(status='PASS',scope='Independent source construction samples inside analytic position boxes; not a continuous/native clearance test',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=e.sources,
        results=rows,maximum_excess_mm=max_excess,maximum_root_curve_difference_mm=maximum_root_curve_difference,
        parameter_cells_per_reference=len(e.parameter_cells),poly_steps=e.poly_steps,stub_steps=e.stub_steps,
        native_frame='Ideal nominal Rz(yaw)Rx(pitch) about current head centre',
        native_clearance='NOT_TESTED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'envelope_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_NATIVE_ENVELOPE_CROSSCHECK','PASS',len(rows),len(e.parameter_cells),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
