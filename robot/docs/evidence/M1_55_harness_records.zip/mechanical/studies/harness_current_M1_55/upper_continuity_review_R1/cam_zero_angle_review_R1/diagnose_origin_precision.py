"""Distinguish source cubic geometry from absolute-coordinate subdivision loss."""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=['/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',str(PARENT/'upper_motion_family_R1')]
from cam_family import CAMFamily,sha
from piecewise_geometry import split_many,radius_bound


def relative_radius(ctrl,depth=7):
    # Subtraction is a translation, not a geometry change. All subsequent
    # de Casteljau work happens near each piece's own origin.
    c=np.asarray(ctrl,float);c=c-c[:,0:1,:]
    for _ in range(depth):c=split_many(c)
    v=3*np.diff(c,axis=1);a=2*np.diff(v,axis=1)
    lo,hi=v.min(1),v.max(1)
    near=np.where(lo>0,lo,np.where(hi<0,hi,0.))
    speed=np.linalg.norm(near,axis=1)
    cross=np.linalg.norm(np.cross(v[:,:,None,:],a[:,None,:,:]),axis=-1).max((1,2))
    r=np.divide(speed**3,cross,out=np.full(len(c),np.inf),where=cross>0)
    r[speed==0]=0
    return dict(radius_lower_mm=max(0.,float(r.min())-.0001),minimum_speed=float(speed.min()),
                cells=len(c),derivative_nonzero=bool(np.all(speed>0)),numeric_radius_reserve_mm=.0001)


def main():
    started=time.time();family=CAMFamily()
    source=HERE/'small_angle_inspection.json';old=json.loads(source.read_text())
    assert old['status']=='BLOCKED' and len(old['failures'])==8
    assert all(sha(p)==h for p,h in old['sources'].items())
    rows=[]
    for row in old['failures']:
        name=row['wire'];y,p=row['pose_deg'];pin=int(name[-1])
        controls,L,details=family.construct(pin,y,p,row['height_mm'])
        before=controls.copy();absolute=radius_bound(controls)
        local=relative_radius(controls)
        assert np.array_equal(controls,before)
        # Dense evaluation of the implicated original cubic is diagnostic only;
        # the Bernstein derivative enclosure provides the conservative bound.
        i=row['continuous_bending']['worst_piece_index'];piece=controls[i]
        origin=piece[0];c=piece-origin
        t=np.linspace(0.,1.,1001)[:,None];v=3*np.diff(c,axis=0);a=2*np.diff(v,axis=0)
        velocity=(1-t)**2*v[0]+2*t*(1-t)*v[1]+t*t*v[2]
        acceleration=(1-t)*a[0]+t*a[1]
        numerator=np.linalg.norm(velocity,axis=1)**3
        denominator=np.linalg.norm(np.cross(velocity,acceleration),axis=1)
        radius=np.divide(numerator,denominator,out=np.full(len(t),np.inf),where=denominator>0)
        rows.append(dict(wire=name,pose_deg=[y,p],absolute_check=absolute,per_piece_origin_check=local,
            original_worst_piece=i,original_worst_piece_control_offsets_mm=c.tolist(),
            dense_original_piece_radius_min_mm=float(radius.min()),required_reference_radius_mm=row['required_reference_radius_mm'],
            controls_unchanged=True,status='PASS' if local['radius_lower_mm']>=row['required_reference_radius_mm'] else 'BLOCKED'))
    family.ctx.record([Path(__file__),source]);family.unchanged()
    out=dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        scope='Same eight source cubic curves, translation-invariant bending checks; dense samples are diagnostic only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=family.sources,
        rows=rows,curve_geometry_changed=False,native_clearance='NOT_TESTED',continuous_CAM_math='NOT_TESTED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'origin_precision_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_ORIGIN_DIAGNOSTIC',out['status'],len(rows),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
