# 三条电源／CC上段连续实体间隙参考

P_J18_1、P_J18_2、CC_allocation 与当前 M1.55 的201件原生实体，在偏航−60°～+60°、俯仰−20°～+25°的名义运动范围内，间隙下界通过原0.3mm目标。

完整证明为19,068个二维角度区间；每条曲线使用9,216个闭参数区间的控制包络，包含短接续段和128个三次段。`verify_native.py` 独立核对18,095个数学父区间的覆盖与源哈希，19,044个偏航分带无重复或遗漏。原曲线／实体／端点保持。

运动采用当前头中心的理想名义 Rz(yaw)Rx(pitch)，不是对原 Float32 助手全角度舍入的证明。实体最小下界约0.30001130mm，条件USB代理最小下界约0.415677mm；数值裕量不能等同加工／装配公差。完整实发USB插头及尾线仍BLOCKED。

`check_native_envelopes.py` 的360项直接原构造比较用于检查实现；连续结论来自完整闭区间包络与距离下界。`pilot_native_verification.json` 仅为试探，完整结果见 `native_verification.json`，独立覆盖见 `native_coverage_verification.json`。

初次Blender调用退出码为0但发生模块导入异常，实际没有执行证明。确切脚本、日志、哈希保留在 `initial_module_path/`；后续调用增加 `--python-exit-code 1`，实际终止状态PASS。执行命令与工具版本见 `commands.json`。

全角度跨线／自身接近、四条CAM连续检查、五条缺实发端点的线路、实际混合材料／线长、接头／应力释放、带线装头与闭壳尚未闭合。参考为PLACEHOLDER / ASSUMED，未采用到主模型或视频；硬件源保持，manufacturing_release=false。
