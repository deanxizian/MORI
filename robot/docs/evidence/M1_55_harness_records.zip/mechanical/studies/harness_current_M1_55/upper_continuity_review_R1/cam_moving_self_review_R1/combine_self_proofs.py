"""Compose the exhaustive upper-only remote-self regions of four CAM wires.

Fan/fan is independent of pitch, tail/tail is fixed in the common pitch
frame, and every remaining unordered piece pair uses the full two-angle
cover. Local arc exclusions are limited to <=5 mm and require the separately
guarded all-angle curvature evidence. Body-prefix joins and physical wiring
are outside this scope.
"""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
NAMES = ['CAM_1', 'CAM_2', 'CAM_3', 'CAM_4']


def main():
    paths = [HERE/'fan_coverage_verification.json',
             HERE/'mixed_coverage_verification.json',
             ROOT/'cam_self_review_R1/fixed_tail_verification.json',
             ROOT/'cam_self_review_R1/fixed_tail_coverage_verification.json',
             ROOT/'cam_peer_review_R1/fan_independence_verification.json',
             ROOT/'cam_math_review_R1/nominal_math_verification.json']
    reports = [read(p) for p in paths]
    sources = {}
    for report in reports:
        assert report['status'] == 'PASS'
        for p, h in report['sources'].items():
            assert sha(p) == h and (p not in sources or sources[p] == h)
            sources[p] = h
    fan, mixed, tail, tail_audit, independence, math = reports
    assert fan['mode'] == mixed['mode'] == 'all_angles'
    assert fan['region'] == 'fan' and mixed['region'] == 'mixed'
    assert fan['angular_rectangles'] == 48 and mixed['angular_rectangles'] == 2592
    assert independence['all_pitch_independence'] == 'PASS'
    assert tail_audit['whole_parameter_cells'] == 64000
    for report in [fan, mixed, tail, tail_audit]:
        assert report['required_gap_mm'] == .3
        assert report['local_arc_exclusion_upper_mm'] == 5.
    assert math['yaw_range_deg'] == tail['yaw_range_deg'] == [-60, 60]
    assert math['pitch_range_deg'] == tail['pitch_range_deg'] == [-20, 25]
    assert all(r['status'] == 'PASS' and r['radius_lower_mm'] >= 6.9342
               for r in math['bending_intervals'])
    assert math['circle_minimum_radius_lower_mm'] >= 6.9342
    assert all(r['status'] == 'PASS' and r['local_curvature']['radius_lower_mm'] >= 6.9342
               for r in tail['rows'])
    counts = dict(CAM_1=238, CAM_2=238, CAM_3=237, CAM_4=237)
    cuts = dict(CAM_1=37, CAM_2=37, CAM_3=36, CAM_4=36)
    assert [r['wire'] for r in fan['wire_counts']] == NAMES
    assert [r['wire'] for r in mixed['wire_counts']] == NAMES
    assert [r['wire'] for r in tail['rows']] == NAMES
    rows = []
    for i, name in enumerate(NAMES):
        n, f = counts[name], cuts[name]
        total, ff, tt = n*(n+1)//2, f*(f+1)//2, 130*131//2
        rest = total - ff - tt
        assert fan['wire_counts'][i]['complete_piece_pairs_per_rectangle'] == ff
        assert mixed['wire_counts'][i]['complete_piece_pairs_per_rectangle'] == rest
        assert tail['rows'][i]['tail_first_piece'] == n-130
        assert tail['rows'][i]['parameter_cells'] == 16000
        rows.append(dict(wire=name, status='PASS', cubic_pieces=n,
                         complete_unordered_piece_pairs=total,
                         fan_fan_pairs=ff, fixed_tail_tail_pairs=tt,
                         remaining_pairs=rest))
    for p in [Path(__file__), *paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Complete nominal CAM upper remote-self only; body-prefix joins and physical wiring excluded',
               sources=sources, results=rows, references=4,
               yaw_range_deg=[-60, 60], pitch_range_deg=[-20, 25],
               frame='Ideal consistent nominal Rz(yaw)Rx(pitch)',
               fan_angular_rectangles=48, mixed_angular_rectangles=2592,
               parameter_refinement_rectangles=fan['parameter_rectangles']+mixed['parameter_rectangles'],
               fixed_tail_closed_parameter_cells=64000,
               required_gap_mm=.3, local_arc_exclusion_upper_mm=5., local_radius_requirement_mm=6.9342,
               continuous_nominal_CAM_upper_remote_self='PASS', own_prefix='NOT_TESTED',
               CAM_power_cross_pairs='NOT_TESTED', actual_material_and_endpoints='BLOCKED',
               full_harness='BLOCKED', main_changed=False, hardware_changed=False,
               animation_changed=False, manufacturing_release=False)
    (HERE/'combined_self_verification.json').write_text(json.dumps(out, indent=2)+'\n')
    print('CAM_SELF_COMBINED_PASS', 4, 48, 2592, out['parameter_refinement_rectangles'], flush=True)


if __name__ == '__main__':
    main()
