"""Bound the unchanged cubic derivatives directly, avoiding point subdivision.

Positions are exact input float64 data, promoted before differentiation.
The derivative control polygons are restricted in long double; differentiating
subdivided absolute coordinates is intentionally avoided. This is numerical
reference geometry evidence, not qualification of physical cable material.
"""
import numpy as np


def split_controls(c):
    levels=[c]
    while levels[-1].shape[1]>1:
        levels.append((levels[-1][:,:-1]+levels[-1][:,1:])/2)
    left=np.stack([q[:,0] for q in levels],axis=1)
    right=np.stack([q[:,-1] for q in levels[::-1]],axis=1)
    return np.concatenate([left,right])


def norm(a):return np.sqrt(np.sum(a*a,axis=-1))


def radius_bound(ctrl,depth=7):
    original=np.asarray(ctrl)
    c=np.asarray(original,dtype=np.longdouble)
    assert c.ndim==3 and c.shape[1:]==(4,3) and np.all(np.isfinite(c))
    c=c-c[:,0:1]
    v=3*np.diff(c,axis=1);a=2*np.diff(v,axis=1)
    for _ in range(depth):
        v=split_controls(v);a=split_controls(a)
    eps=np.finfo(np.longdouble).eps
    lo,hi=v.min(1),v.max(1)
    near=np.where(lo>0,lo,np.where(hi<0,hi,0))
    vmax=norm(v).max(1);amax=norm(a).max(1)
    speed=np.maximum(0,norm(near)-32*eps*vmax)
    cross=norm(np.cross(v[:,:,None,:],a[:,None,:,:])).max((1,2))
    cross+=64*eps*vmax*amax
    r=np.divide(speed**3,cross,out=np.full(len(v),np.inf,dtype=np.longdouble),where=cross>0)
    r[speed==0]=0
    lower=max(0,float(np.nextafter(r.min(),-np.inf))-.0001)
    return dict(radius_lower_mm=lower,cells=len(v),
                worst_piece_index=int(np.argmin(r)%len(original)),
                minimum_speed=float(speed.min()),derivative_nonzero=bool(np.all(speed>0)),
                numeric_reserve_mm=.0001,longdouble_precision_bits=np.finfo(np.longdouble).nmant+1,
                method='Exact input positions promoted before direct derivative restriction; no curve changes')
