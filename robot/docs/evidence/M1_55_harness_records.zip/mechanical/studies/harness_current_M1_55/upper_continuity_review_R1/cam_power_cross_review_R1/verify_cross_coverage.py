"""Independent angular, root-cover and closed-parameter classification audit.

No generator/root-cover helper is imported. Parent indices and union ranges
are rebuilt from the guarded mathematical source partitions. Finite source
construction probes are checked separately from the continuous proof scope.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
CAM = ['CAM_1','CAM_2','CAM_3','CAM_4']
POWER = ['P_J18_1','P_J18_2','CC_allocation']
COUNTS = dict(CAM_1=238,CAM_2=238,CAM_3=237,CAM_4=237)


def coverage_2d(boxes, base):
    assert boxes and all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in boxes)
    edges = sorted({x for r in boxes for x in r[:2]})
    assert edges[0]==base[0] and edges[-1]==base[1]
    for a,b in zip(edges[:-1],edges[1:]):
        middle = (a+b)/2
        strips = sorted(r[2:4] for r in boxes if r[0]<middle<r[1])
        assert strips and strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    pilot = '--pilot' in sys.argv
    path = HERE/('pilot_verification.json' if pilot else 'cross_verification.json')
    proof = read(path)
    assert proof['status']=='PASS' and not proof['failures']
    assert proof['mode']==('pilot' if pilot else 'all_angles')
    assert proof['required_gap_mm']==.3
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    assert all(sha(p)==h for p,h in proof['sources'].items())
    math_paths = [ROOT/'cam_math_review_R1/nominal_math_verification.json',ROOT/'power_math_verification.json']
    cm,pm = [read(p) for p in math_paths]
    for report in [cm,pm]:
        assert report['status']=='PASS' and all(sha(p)==h for p,h in report['sources'].items())
    parents = {n:[r for r in cm['length_rectangles'] if r['wire']==n] for n in CAM}
    parents.update({n:[r for r in pm['rows'] if r['wire']==n] for n in POWER})
    parent_coverage = {n:coverage_2d([r['rectangle_deg'] for r in rows],(-60.,60.,-20.,25.))
                       for n,rows in parents.items()}
    expected_bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    assert proof['bases']==[list(r) for r in expected_bases]
    assert [tuple(r['wires']) for r in proof['results']]==list(itertools.product(CAM,POWER))
    angular = parameter = refined = union_roots = fresh_roots = 0
    minimum = float('inf')
    summaries = []
    for result in proof['results']:
        a,b = result['wires']
        assert result['status']=='PASS'
        expected = {base:[] for base in expected_bases}
        for row in result['intervals']:
            r = tuple(row['rectangle_deg'])
            base = tuple(row['base_rectangle_deg'])
            assert base in expected and row['status']=='PASS'
            expected[base].append(r)
            assert len(row['root_certificates'])==2
            for name,certificate in zip([a,b],row['root_certificates']):
                assert certificate['status']=='PASS' and certificate['wire']==name
                assert certificate['rectangle_deg']==list(r)
                if certificate['method']=='guarded_parent_union':
                    ids = [i for i,p in enumerate(parents[name])
                           if p['rectangle_deg'][0]<r[1] and p['rectangle_deg'][1]>r[0]
                           and p['rectangle_deg'][2]<r[3] and p['rectangle_deg'][3]>r[2]]
                    assert ids and ids==certificate['parent_indices']
                    source = [parents[name][i] for i in ids]
                    if name in CAM:
                        for key,operation in [('height_lower_mm',min),('height_upper_mm',max),
                                              ('return_lower_mm',min),('return_upper_mm',max)]:
                            assert certificate[key]==operation(p[key] for p in source)
                    else:
                        lo = min(p['midpoint_amplitude_mm']-p['amplitude_deviation_bound_mm'] for p in source)
                        hi = max(p['midpoint_amplitude_mm']+p['amplitude_deviation_bound_mm'] for p in source)
                        assert certificate['midpoint_amplitude_mm']==(lo+hi)/2
                        assert certificate['amplitude_deviation_bound_mm']==(hi-lo)/2+1e-9
                    union_roots += 1
                else:
                    assert certificate['method']=='fresh_guarded_root' and name in POWER
                    assert certificate['root_derivative_lower']>0 and certificate['global_unit_bracket_derivative_lower']>0
                    assert 0<certificate['amplitude_deviation_bound_mm']<1
                    assert abs(certificate['midpoint_amplitude_mm'])+certificate['amplitude_deviation_bound_mm']<1
                    fresh_roots += 1
            pairs = [tuple(p) for p in row['refined_piece_products']]
            assert len(pairs)==len(set(pairs))
            assert all(0<=i<COUNTS[a] and 0<=j<129 for i,j in pairs)
            assert row['complete_piece_products']==COUNTS[a]*129
            assert row['coarse_separated_products']+len(pairs)==row['complete_piece_products']
            assert [tuple(d['pieces']) for d in row['parameter_refinements']]==pairs
            for detail in row['parameter_refinements']:
                cells = detail['parameter_rectangles']
                assert all(c['gap_lower_mm']>=.3 for c in cells)
                coverage_2d([c['parameter_rectangle'] for c in cells],(0.,1.,0.,1.))
                parameter += len(cells)
            assert row['gap_lower_mm']>=.3
            minimum = min(minimum,row['gap_lower_mm'])
            angular += 1
            refined += len(pairs)
        for base,rectangles in expected.items():
            coverage_2d(rectangles,base)
        summaries.append(dict(wires=[a,b],status='PASS',angular_rectangles=len(result['intervals']),
                              complete_cubic_piece_products=COUNTS[a]*129))
    cross_path = HERE/'envelope_crosscheck.json'
    cross = read(cross_path)
    assert cross['status']=='PASS' and cross['source_pose_comparisons']==105
    assert cross['group_control_comparisons']==210 and cross['maximum_positive_excess_mm']==0.
    assert all(sha(p)==h for p,h in cross['sources'].items())
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = proof['sources'] | cross['sources']
    for p in [Path(__file__),path,cross_path,*math_paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               mode=proof['mode'],scope='Independent complete angular and parameter covers, root-parent unions, and guarded source implementation probes',
               sources=sources,results=summaries,unordered_cross_pairs=12,
               angular_rectangles=angular,refined_piece_products=refined,parameter_refinement_rectangles=parameter,
               parent_union_certificates=union_roots,fresh_root_certificates=fresh_roots,
               original_parent_yaw_slabs=parent_coverage,minimum_certified_gap_lower_mm=minimum,
               required_gap_mm=.3,full_harness='BLOCKED',own_prefix='NOT_TESTED',power_remote_self='NOT_TESTED',
               protected_hardware_files=846,main_changed=False,hardware_changed=False,
               animation_changed=False,manufacturing_release=False)
    target = 'pilot_coverage_verification.json' if pilot else 'cross_coverage_verification.json'
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_POWER_CROSS_COVERAGE_PASS',proof['mode'],12,angular,parameter,846,flush=True)


if __name__ == '__main__':
    main()
