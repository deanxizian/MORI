"""Independent enumeration of all unordered canonical CAM upper piece pairs."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROJECT = HERE.parents[4]
sys.path[:0] = [str(ROOT/'cam_native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes, NAMES

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    path = HERE/'combined_self_verification.json'
    proof = read(path)
    assert proof['status'] == proof['continuous_nominal_CAM_upper_remote_self'] == 'PASS'
    assert proof['references'] == 4
    assert proof['required_gap_mm'] == .3 and proof['local_arc_exclusion_upper_mm'] == 5.
    assert proof['yaw_range_deg'] == [-60, 60] and proof['pitch_range_deg'] == [-20, 25]
    assert proof['own_prefix'] == proof['CAM_power_cross_pairs'] == 'NOT_TESTED'
    assert all(sha(p) == h for p, h in proof['sources'].items())
    paths = [HERE/'fan_coverage_verification.json', HERE/'mixed_coverage_verification.json',
             ROOT/'cam_self_review_R1/fixed_tail_coverage_verification.json',
             ROOT/'cam_peer_review_R1/fan_independence_verification.json']
    fan, mixed, tail, independence = [read(p) for p in paths]
    for audit in [fan, mixed, tail, independence]:
        assert audit['status'] == 'PASS' and all(sha(p) == h for p, h in audit['sources'].items())
    assert fan['mode'] == mixed['mode'] == 'all_angles'
    assert independence['all_pitch_independence'] == 'PASS'
    assert fan['angular_rectangles'] == 48 and mixed['angular_rectangles'] == 2592
    assert tail['whole_parameter_cells'] == 64000
    e = NativeCAMEnvelopes()
    assert [r['wire'] for r in proof['results']] == NAMES
    enumerated = []
    for index, row in enumerate(proof['results']):
        name = row['wire']
        layout = e.layout[name]
        n = len(layout['labels'])
        f = layout['labels'].index('pitch_shift_first_0')
        t = layout['tail_index']
        assert n-t == 130
        a, b = np.indices((n, n))
        upper = b >= a
        ff = upper & (a < f) & (b < f)
        tt = upper & (a >= t) & (b >= t)
        rest = upper & ~(ff | tt)
        assert np.array_equal(ff.astype(int)+tt.astype(int)+rest.astype(int), upper.astype(int))
        values = dict(cubic_pieces=n, complete_unordered_piece_pairs=int(upper.sum()),
                      fan_fan_pairs=int(ff.sum()), fixed_tail_tail_pairs=int(tt.sum()),
                      remaining_pairs=int(rest.sum()))
        assert all(row[k] == v for k, v in values.items())
        assert fan['wire_counts'][index]['complete_piece_pairs_per_rectangle'] == values['fan_fan_pairs']
        assert mixed['wire_counts'][index]['complete_piece_pairs_per_rectangle'] == values['remaining_pairs']
        assert np.count_nonzero(layout['parameter_cells'][:, 0] >= t) == 16000
        enumerated.append(dict(wire=name, status='PASS', **values))
    e.unchanged()
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT/p) == h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend') == '3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4') == '9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = proof['sources'] | e.sources
    for p in [Path(__file__), path, *paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Independent exhaustive disjoint four CAM upper remote-self category audit',
               sources=sources, results=enumerated, references=4,
               fan_angular_rectangles=48, mixed_angular_rectangles=2592,
               parameter_refinement_rectangles=proof['parameter_refinement_rectangles'],
               fixed_tail_closed_parameter_cells=64000, required_gap_mm=.3,
               local_arc_exclusion_upper_mm=5., continuous_nominal_CAM_upper_remote_self='PASS',
               own_prefix='NOT_TESTED', CAM_power_cross_pairs='NOT_TESTED', full_harness='BLOCKED',
               protected_hardware_files=846, main_changed=False, hardware_changed=False,
               animation_changed=False, manufacturing_release=False)
    (HERE/'combined_self_coverage_verification.json').write_text(json.dumps(out, indent=2)+'\n')
    print('CAM_SELF_COMBINED_COVERAGE_PASS', 4, 48, 2592, 846, flush=True)


if __name__ == '__main__':
    main()
