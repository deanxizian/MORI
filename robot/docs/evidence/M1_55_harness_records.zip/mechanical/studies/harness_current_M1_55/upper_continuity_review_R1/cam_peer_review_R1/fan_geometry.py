"""Complete cubic hull bounds for the pitch-independent fan region.

Every cubic parameter interval is represented by its restricted Bernstein
control hull. All source controls remain interval boxes over the same yaw
interval. Parameter bisection retains both children; unresolved parameter
boxes trigger yaw refinement and never become a collision waiver.
"""
import numpy as np
from cam_native_envelopes import Box,linear,restrictions

HALVES=restrictions(np.eye(4),np.array([[0.,.5],[.5,1.]]))


def matrix(a,b,radius_sum):
    al,ah=a.lo.min(1),a.hi.max(1)
    bl,bh=b.lo.min(1),b.hi.max(1)
    outside=np.maximum(np.maximum(bl[None]-ah[:,None],al[:,None]-bh[None]),0.)
    return np.linalg.norm(outside,axis=2)-radius_sum-.0001


def bound(a,b,radius_sum):
    outside=np.maximum(np.maximum(b.lo.min(0)-a.hi.max(0),a.lo.min(0)-b.hi.max(0)),0.)
    return float(np.linalg.norm(outside))-radius_sum-.0001


def half(c):
    return [linear(M,c) for M in HALVES]


def refine(a,b,radius_sum,max_depth=12):
    pending=[(a,b,(0.,1.,0.,1.),0)]
    accepted=[]
    visited=0
    while pending:
        ca,cb,rectangle,depth=pending.pop();visited+=1
        lower=bound(ca,cb,radius_sum)
        if lower>=.3:
            accepted.append([*rectangle,lower])
            continue
        if depth>=max_depth:
            return dict(status='BLOCKED',visited=visited,accepted=[],
                        unresolved_parameter_rectangle=list(rectangle),gap_lower_mm=lower)
        ta,tb,ua,ub=rectangle
        # Midpoint control polygons choose only the parameter split order.
        # Both children remain in the proof, regardless of this estimate.
        a_mid=(ca.lo+ca.hi)/2;b_mid=(cb.lo+cb.hi)/2
        a_size=float(np.linalg.norm(np.diff(a_mid,axis=0),axis=1).sum())
        b_size=float(np.linalg.norm(np.diff(b_mid,axis=0),axis=1).sum())
        if a_size>=b_size:
            left,right=half(ca);t=(ta+tb)/2
            pending.extend([(left,cb,(ta,t,ua,ub),depth+1),(right,cb,(t,tb,ua,ub),depth+1)])
        else:
            left,right=half(cb);u=(ua+ub)/2
            pending.extend([(ca,left,(ta,tb,ua,u),depth+1),(ca,right,(ta,tb,u,ub),depth+1)])
    return dict(status='PASS',visited=visited,accepted=accepted,
                gap_lower_mm=min(r[-1] for r in accepted))
