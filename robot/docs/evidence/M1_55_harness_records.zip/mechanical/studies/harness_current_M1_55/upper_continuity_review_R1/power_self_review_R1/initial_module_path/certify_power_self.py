"""Three power/CC upper remote-self covers over both angles and closed parameters.

Local exclusions require a complete <=5 mm arc upper including join reserves.
The unchanged mathematical parents independently certify local curvature.
All other products use complete common-frame cubic hulls or closed parameter
refinement. An undecided bound remains BLOCKED; no source curve is changed.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE),str(HERE.parent/'cam_peer_review_R1')]
from power_self_envelopes import PowerSelfEnvelopes,NAMES,sha
from power_native_envelopes import Box
from piecewise_geometry import RADII
from fan_geometry import matrix
from self_hull_refinement import refine


def main():
    started = time.time()
    pilot = '--pilot' in sys.argv
    cross_path = HERE/'speed_bound_crosscheck.json'
    cross = json.loads(cross_path.read_text())
    assert cross['status']=='PASS' and cross['source_pose_comparisons']==45
    assert cross['minimum_speed_upper_reserve_mm']>=0 and cross['minimum_join_upper_reserve_mm']>=0
    assert all(sha(p)==h for p,h in cross['sources'].items())
    e = PowerSelfEnvelopes()
    bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    ai,bi = np.indices((129,129))
    mask = bi>=ai
    assert mask.sum()==8385
    results,failures = [],[]
    visited,new_roots = 0,0
    for name in NAMES:
        accepted = []
        for base in bases:
            pending = [(base,0)]
            while pending:
                rectangle,depth = pending.pop()
                visited += 1
                certificate = e.certificate(name,rectangle)
                if depth:
                    fresh = e.e.e.certificate(name,rectangle)
                    new_roots += 1
                    if fresh['status']=='PASS' and fresh['amplitude_deviation_bound_mm']<certificate['amplitude_deviation_bound_mm']:
                        certificate = dict(status='PASS',wire=name,rectangle_deg=list(rectangle),method='fresh_guarded_root',
                                           midpoint_amplitude_mm=fresh['midpoint_amplitude_mm'],
                                           amplitude_deviation_bound_mm=fresh['amplitude_deviation_bound_mm'],
                                           root_derivative_lower=fresh['root_derivative_lower'],
                                           global_unit_bracket_derivative_lower=fresh['global_unit_bracket_derivative_lower'])
                boxes = [e.controls(name,rectangle,certificate,g) for g in ['yaw','pitch']]
                densities = e.speeds(name,rectangle,certificate)
                joins = e.join_upper(name)
                prefix = np.r_[0.,np.cumsum(densities)]
                join_prefix = np.r_[0.,np.cumsum(joins)]
                arcs = prefix[bi+1]-prefix[ai]+join_prefix[bi]-join_prefix[ai]
                gaps = np.maximum.reduce([matrix(c,c,2*RADII[name]) for c in boxes])
                local = mask&(arcs<=5.)
                separated = mask&~local&(gaps>=.3)
                unresolved = np.argwhere(mask&~local&~separated)
                details = []
                passed = True
                for i,j in unresolved:
                    checked = refine([c[int(i)] for c in boxes],[c[int(j)] for c in boxes],
                                     densities,joins,int(i),int(j),RADII[name])
                    if checked['status']!='PASS':
                        passed = False
                        break
                    details.append(dict(pieces=[int(i),int(j)],parameter_rectangles=checked['accepted']))
                if passed:
                    accepted.append(dict(status='PASS',rectangle_deg=list(rectangle),base_rectangle_deg=list(base),
                                         root_certificate=certificate,complete_unordered_piece_pairs=8385,
                                         coarse_local_pairs=int(local.sum()),coarse_separated_pairs=int(separated.sum()),
                                         refined_piece_pairs=unresolved.tolist(),parameter_refinements=details,
                                         required_gap_mm=.3,local_arc_exclusion_upper_mm=5.))
                elif depth>=16:
                    failures.append(dict(wire=name,rectangle_deg=list(rectangle),depth=depth,
                                         unresolved_pieces=[int(i),int(j)],details=checked,
                                         reason='Undecided complete-parameter remote-self/arc cover'))
                    break
                else:
                    yl,yh,pl,ph = rectangle
                    y,p = (yl+yh)/2,(pl+ph)/2
                    if (yh-yl)/10>(ph-pl)/5:
                        pending.extend([((yl,y,pl,ph),depth+1),((y,yh,pl,ph),depth+1)])
                    else:
                        pending.extend([((yl,yh,pl,p),depth+1),((yl,yh,p,ph),depth+1)])
                if visited%50==0:
                    print('POWER_SELF_PROGRESS',name,visited,len(accepted),new_roots,round(time.time()-started,1),flush=True)
            if failures:
                break
        results.append(dict(wire=name,status='PASS' if not failures else 'BLOCKED',intervals=accepted))
        print('POWER_SELF_WIRE',name,results[-1]['status'],len(accepted),round(time.time()-started,1),flush=True)
        if failures:
            break
    e.unchanged()
    sources = dict(e.sources)
    for p in [Path(__file__),HERE/'self_hull_refinement.py',cross_path,HERE.parent/'cam_peer_review_R1/fan_geometry.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS' if len(results)==3 and not failures else 'BLOCKED',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               mode='pilot' if pilot else 'all_angles',sources=sources,results=results,failures=failures,
               bases=[list(r) for r in bases],yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
               required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,radius_requirements_mm=e.radius_requirements,
               canonical_cubic_pieces_per_reference=129,visited_angular_rectangles=visited,new_root_certificates=new_roots,
               scope='Three nominal power/CC upper remote-self references only; body-prefix joins and actual materials excluded',
               full_harness='BLOCKED',own_prefix='NOT_TESTED',main_changed=False,hardware_changed=False,
               animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/('pilot_verification.json' if pilot else 'self_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_SELF_TERMINAL',out['status'],len(results),visited,round(out['elapsed_s'],1),flush=True)


if __name__ == '__main__':
    main()
