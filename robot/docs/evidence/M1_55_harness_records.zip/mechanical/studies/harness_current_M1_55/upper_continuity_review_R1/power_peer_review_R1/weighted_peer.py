"""Exact per-cell weighted anchor bounds with a proved exclusion sphere.

Only distance-field queries change. All complete-parameter movement balls,
reference curves, diameters and 0.3mm requirement are retained.
"""
import numpy as np
from scipy.spatial import cKDTree


def field(a,b,k=64):
    a=np.asarray(a,float);b=np.asarray(b,float);tree=cKDTree(b)
    distances,indices=tree.query(a,k=min(k,len(b)),workers=1)
    if distances.ndim==1:distances=distances[:,None];indices=indices[:,None]
    return dict(a=a,b=b,tree=tree,distances=distances,indices=indices)


def score(data,ra,rb,radius_sum,required=.3,numeric=.0001):
    ra=np.asarray(ra,float);rb=np.asarray(rb,float)
    d,j=data['distances'],data['indices'];rmax=float(rb.max())
    inside=(d-rb[j]).min(1)-ra-radius_sum-numeric
    outside=d[:,-1]-rmax-ra-radius_sum-numeric
    lower=np.minimum(inside,outside)
    # If an included ball already violates the bound, increasing the query
    # cannot establish PASS. Resolve only unknown excluded-ball bounds.
    uncertain=np.flatnonzero((outside<required)&(inside>=required))
    pairs=0
    if len(uncertain):
        radii=ra[uncertain]+rmax+radius_sum+required+2*numeric
        candidates=data['tree'].query_ball_point(data['a'][uncertain],radii,workers=1,return_sorted=False)
        counts=np.fromiter((len(c) for c in candidates),dtype=np.int64,count=len(candidates))
        ai=np.repeat(uncertain,counts)
        bj=np.concatenate([np.asarray(c,dtype=np.int64) for c in candidates]) if counts.sum() else np.empty(0,np.int64)
        pairs=len(ai);values=np.full(len(ra),np.inf)
        if pairs:
            distances=np.linalg.norm(data['a'][ai]-data['b'][bj],axis=1)
            scores=distances-ra[ai]-rb[bj]-radius_sum-numeric
            np.minimum.at(values,ai,scores)
        # Each excluded centre is beyond ra_i+max(rb)+radii+target+2*reserve.
        # After subtracting movement and query reserve, its gap exceeds target.
        lower[uncertain]=np.minimum(values[uncertain],required)
    return dict(lower=lower,gap_lower_mm=float(lower.min()),
                anchor_point_surface_gap_mm=float(d[:,0].min())-radius_sum-numeric,
                exclusion_sphere_queries=len(uncertain),candidate_pairs_checked=pairs)
