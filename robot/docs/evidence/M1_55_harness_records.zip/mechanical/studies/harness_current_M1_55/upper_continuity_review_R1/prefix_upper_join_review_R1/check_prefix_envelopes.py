"""Original-source control/velocity probes of the unchanged body-prefix cover."""
from pathlib import Path
import datetime
import json
import time
import numpy as np
from prefix_envelopes import PrefixEnvelopes,CrossEnvelopes,BSpline,rotate,sha
from power_native_envelopes import ideal_matrix

HERE = Path(__file__).resolve().parent


def main():
    started = time.time()
    cross = CrossEnvelopes()
    e = PrefixEnvelopes(cross)
    windows = [(-60.,-50.,-20.,-15.),(-10.,0.,0.,5.),(50.,60.,20.,25.)]
    rows = []
    maximum = -float('inf')
    minimum_speed = float('inf')
    maximum_extraction_error = 0.
    for name in e.f.names:
        for rectangle in windows:
            yl,yh,pl,ph = rectangle
            certificate = e.certificate(name,yl,yh)
            boxes = {g:e.controls(name,rectangle,certificate,g) for g in ['body','yaw','pitch']}
            density = e.speeds(name,rectangle,certificate)
            for y,p in [(yl,pl),(yh,ph),(yl,ph),(yh,pl),((yl+yh)/2,(pl+ph)/2)]:
                c = e.f.candidate(name,y)['control']
                spl = BSpline(e.f.knots,c,3)
                d = spl.derivative()
                a,b = e.edges[:-1],e.edges[1:]
                h = (b-a)[:,None]/3
                source = np.stack([spl(a),spl(a)+h*d(a),spl(b)-h*d(b),spl(b)],axis=1)
                extraction = float(np.linalg.norm(source-np.einsum('ijk,kl->ijl',e.M,c),axis=2).max())
                assert extraction<=1e-10
                maximum_extraction_error = max(maximum_extraction_error,extraction)
                velocities = np.linalg.norm(3*np.diff(source,axis=1),axis=2).max(1)
                reserve = float((density-velocities).min())
                assert reserve>=0,(name,rectangle,y,reserve)
                minimum_speed = min(minimum_speed,reserve)
                groups = {}
                for group,box in boxes.items():
                    q = source
                    if group!='body':
                        inverse = np.linalg.inv(ideal_matrix(cross.power.center,y,p if group=='pitch' else 0.))
                        q = source@inverse[:3,:3].T+inverse[:3,3]
                    excess = float(np.maximum(box.lo-q,q-box.hi).max())
                    assert excess<=1e-8,(name,rectangle,y,p,group,excess)
                    maximum = max(maximum,excess)
                    groups[group] = excess
                rows.append(dict(wire=name,rectangle_deg=list(rectangle),pose_deg=[y,p],status='PASS',
                                 groups_control_box_excess_mm=groups,minimum_speed_upper_reserve_mm=reserve))
        print('PREFIX_JOIN_ENVELOPE_WIRE',name,len(rows),round(time.time()-started,1),flush=True)
    cross.unchanged()
    e.unchanged()
    sources = cross.sources | e.sources
    sources[str(Path(__file__))] = sha(Path(__file__))
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='180 finite original body-prefix spline construction probes only; not full-angle join clearance',
               sources=sources,rows=rows,prefix_references=12,source_pose_comparisons=180,
               canonical_cubic_pieces=45,group_control_comparisons=540,
               maximum_positive_excess_mm=max(0.,maximum),minimum_speed_upper_reserve_mm=minimum_speed,
               maximum_Bspline_to_cubic_extraction_error_mm=maximum_extraction_error,
               prefix_radii_mm=e.f.radii,full_join_pairs='NOT_TESTED',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
               elapsed_s=time.time()-started)
    (HERE/'prefix_envelope_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_JOIN_ENVELOPE_PASS',180,540,round(out['elapsed_s'],1),flush=True)


if __name__ == '__main__':
    main()
