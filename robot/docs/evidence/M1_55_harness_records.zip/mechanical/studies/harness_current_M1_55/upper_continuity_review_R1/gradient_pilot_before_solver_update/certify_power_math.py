"""Cover both head angles for three existing upper numerical references.

Certifies their unique local length-root branch and cubic bend radius, never
physical material, supplier cut lengths, native/peer clearance or all wiring.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

from power_enclosures import PowerEnclosures,Box,NAMES,MINIMUM_RADIUS,sha,RESERVE

HERE=Path(__file__).resolve().parent


def split_coefficients(values):
    row=values.copy();left=[row[:,0]];right=[row[:,-1]]
    while row.shape[1]>1:
        row=(row[:,:-1]+row[:,1:])/2
        left.append(row[:,0]);right.append(row[:,-1])
    return np.concatenate([np.stack(left,1),np.stack(right[::-1],1)])


def cross(a,b):
    return Box(np.stack([(a[:,1]*b[:,2]-a[:,2]*b[:,1]).lo,
                         (a[:,2]*b[:,0]-a[:,0]*b[:,2]).lo,
                         (a[:,0]*b[:,1]-a[:,1]*b[:,0]).lo],-1),
               np.stack([(a[:,1]*b[:,2]-a[:,2]*b[:,1]).hi,
                         (a[:,2]*b[:,0]-a[:,0]*b[:,2]).hi,
                         (a[:,0]*b[:,1]-a[:,1]*b[:,0]).hi],-1))


def radius_box(v,a):
    lo=v.lo.min(1);hi=v.hi.max(1)
    closest=np.where(lo>0,lo,np.where(hi<0,hi,0.))
    speed=np.maximum(0.,np.linalg.norm(closest,axis=-1)-RESERVE)
    maxima=np.zeros(len(speed))
    for i in range(v.lo.shape[1]):
        for j in range(a.lo.shape[1]):
            q=cross(v[:,i],a[:,j])
            maxima=np.maximum(maxima,np.linalg.norm(np.maximum(abs(q.lo),abs(q.hi)),axis=-1)+RESERVE)
    r=np.divide(speed**3,maxima,out=np.full(len(speed),np.inf),where=maxima>0)
    r[speed==0]=0.
    return float(r.min()),float(speed.min())


class Bending:
    def __init__(self,enclosures,depth=3):
        self.e=enclosures
        v=enclosures.V.copy();a=2*np.diff(v,axis=1)
        for _ in range(depth):v=split_coefficients(v);a=split_coefficients(a)
        self.v,self.a=v,a
        self.vdir=v@enclosures.D;self.adir=a@enclosures.D
        self.depth=depth

    def check(self,name,certificate):
        rectangle=certificate['rectangle_deg'];amplitude=certificate['midpoint_amplitude_mm']
        width=certificate['amplitude_deviation_bound_mm'];amp=Box(amplitude-width,amplitude+width)
        v=self.e.mapped_controls(name,rectangle,self.v.reshape(-1,6))
        a=self.e.mapped_controls(name,rectangle,self.a.reshape(-1,6))
        v=Box(v.lo.reshape(self.vdir.shape),v.hi.reshape(self.vdir.shape))+amp*self.vdir
        a=Box(a.lo.reshape(self.adir.shape),a.hi.reshape(self.adir.shape))+amp*self.adir
        polynomial,speed=radius_box(v,a)
        sv=certificate['_stub_velocity_box']
        sa=2*(sv[1:]-sv[:-1])
        # Further parameter subdivision preserves the original derivative scale.
        for _ in range(self.depth):
            vlo=split_coefficients(sv.lo[None]);vhi=split_coefficients(sv.hi[None])
            alo=split_coefficients(sa.lo[None]);ahi=split_coefficients(sa.hi[None])
            sv=Box(vlo,vhi);sa=Box(alo,ahi)
            break
        # The short stub needs only one subdivision; if the bounds are too
        # loose the angle rectangle is split, never the required radius relaxed.
        stub,stub_speed=radius_box(sv,sa)
        factor=(1-self.e.ey)**3/(1+self.e.ey)**2
        radius=min(polynomial,stub)*factor-.0001
        return dict(status='PASS' if radius>=MINIMUM_RADIUS[name] and min(speed,stub_speed)>0 else 'BLOCKED',
            radius_lower_mm=max(0.,radius),required_radius_mm=MINIMUM_RADIUS[name],
            polynomial_radius_lower_mm=polynomial,stub_radius_lower_mm=stub,
            derivative_nonzero=min(speed,stub_speed)>0,polynomial_parameter_cells=len(self.v),
            operator_radius_factor=factor,numeric_radius_reserve_mm=.0001)


def clean(row):return {k:v for k,v in row.items() if not k.startswith('_')}


def main():
    started=time.time();enclosure=PowerEnclosures();bending=Bending(enclosure)
    pilot='--pilot' in sys.argv
    roots_only='--roots-only' in sys.argv
    names=NAMES
    planned=[(-5.,0.,-5.,0.),(0.,5.,0.,2.5),(-1.,0.,-1.,0.),(-.1,0.,-.1,0.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    rows=[];failures=[];attempts=[];visited=0
    for name in names:
        for base in planned:
            todo=[(base,0)]
            while todo:
                rectangle,depth=todo.pop();visited+=1
                cert=enclosure.certificate(name,rectangle)
                bend=bending.check(name,cert) if cert['status']=='PASS' and not roots_only else None
                good=cert['status']=='PASS' and (roots_only or bend['status']=='PASS')
                if good:
                    row=clean(cert);row['continuous_bending']=bend;row['source_key_rectangle_deg']=list(base)
                    rows.append(row);continue
                failed=dict(wire=name,rectangle_deg=list(rectangle),depth=depth,
                            root=clean(cert),continuous_bending=bend)
                if pilot:
                    attempts.append(failed);continue
                if depth>=22:
                    failures.append(failed);break
                ylo,yhi,plo,phi=rectangle
                # Compare independently tightened one-axis bounds. Yaw is
                # nearly a coherent rotation, so angle widths alone are a poor
                # guide to the source field's actual enclosure uncertainty.
                if (yhi-ylo)<1e-6:axis=1
                elif (phi-plo)<1e-6:axis=0
                else:
                    ym=(ylo+yhi)/2;pm=(plo+phi)/2
                    choices=[(ym,yhi,plo,phi),(ylo,yhi,pm,phi)]
                    scores=[]
                    for choice in choices:
                        c,s=enclosure.inputs(name,*choice)
                        velocity=enclosure.mapped_controls(name,choice,enclosure.Q)
                        scores.append(float(enclosure.weights@np.linalg.norm(velocity.hi-velocity.lo,axis=1))+
                                      float(np.linalg.norm(s.hi-s.lo)))
                    axis=int(np.argmin(scores))
                if axis==0:
                    mid=(ylo+yhi)/2
                    todo.extend([((mid,yhi,plo,phi),depth+1),((ylo,mid,plo,phi),depth+1)])
                else:
                    mid=(plo+phi)/2
                    todo.extend([((ylo,yhi,mid,phi),depth+1),((ylo,yhi,plo,mid),depth+1)])
                if visited%100==0:
                    print('POWER_CONTINUITY_PROGRESS',name,visited,len(rows),round(time.time()-started,1),flush=True)
            if failures:break
        print('POWER_CONTINUITY_WIRE',name,len(rows),len(failures),round(time.time()-started,1),flush=True)
        if failures:break
    enclosure.sources[str(Path(__file__))]=sha(Path(__file__))
    enclosure.unchanged()
    if not pilot and not failures:
        for name in names:
            for base in planned:
                cells=[r['rectangle_deg'] for r in rows if r['wire']==name and r['source_key_rectangle_deg']==list(base)]
                area=sum((r[1]-r[0])*(r[3]-r[2]) for r in cells)
                assert abs(area-(base[1]-base[0])*(base[3]-base[2]))<1e-8
                assert all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in cells)
                # Binary partition construction provides disjoint interiors;
                # area plus containment checks catch missing/duplicate leaves.
    status='PASS' if not failures and (not pilot or len(rows)==len(names)*len(planned)) else 'BLOCKED'
    report=dict(status=status,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Three power/CC numerical upper length roots and cubic bends over both head angles; not clearance or physical wiring',
        mode='pilot' if pilot else 'roots_only' if roots_only else 'complete_math',
        yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],sources=enclosure.sources,
        names=names,source_key_rectangles=len(planned),accepted_rectangles=len(rows),visited_rectangles=visited,
        rows=rows,failures=failures,unresolved_pilot_rectangles=attempts,
        reference_root_bracket_mm=[-1,1],functional='Positive Gauss64 weights on the actual cubic Hermite conversion and stub',
        root_range_and_uniqueness='PASS' if status=='PASS' else 'BLOCKED',
        continuous_power_bending='PASS' if status=='PASS' and not roots_only else 'NOT_TESTED',
        continuous_CAM_bending='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    file='pilot_math.json' if pilot else 'power_root_verification.json' if roots_only else 'power_math_verification.json'
    (HERE/file).write_text(json.dumps(report,indent=2)+'\n')
    print('POWER_CONTINUITY_TERMINAL',status,len(rows),len(failures),round(report['elapsed_s'],2),flush=True)


if __name__=='__main__':main()
