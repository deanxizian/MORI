"""Complete pairwise AABB separation with a proved centre-sphere exclusion.

Each whole closed curve cell lies inside its AABB, and the AABB lies inside
the sphere at its centre with half-diagonal radius. Excluded B centres are
farther than ra_i+max(rb)+wire_radii+target+2*reserve. All other box pairs are
evaluated explicitly. Returned bounds are capped at the target because the
excluded-pair proof certifies the target, not the actual global minimum.
"""
import numpy as np
from scipy.spatial import cKDTree


def score(alo,ahi,blo,bhi,radius_sum,required=.3,numeric=.0001,chunk=128):
    alo,ahi,blo,bhi = [np.asarray(v,float) for v in [alo,ahi,blo,bhi]]
    assert alo.shape==ahi.shape and blo.shape==bhi.shape
    assert np.all(alo<=ahi) and np.all(blo<=bhi)
    a = (alo+ahi)/2
    b = (blo+bhi)/2
    ra = np.linalg.norm((ahi-alo)/2,axis=1)
    rb = np.linalg.norm((bhi-blo)/2,axis=1)
    tree = cKDTree(b)
    lower = np.full(len(a),required)
    candidate_pairs = 0
    for start in range(0,len(a),chunk):
        finish = min(start+chunk,len(a))
        candidates = tree.query_ball_point(a[start:finish],
            ra[start:finish]+float(rb.max())+radius_sum+required+2*numeric,
            workers=1,return_sorted=False)
        counts = np.array([len(c) for c in candidates],dtype=np.int64)
        candidate_pairs+=int(counts.sum())
        if counts.sum()==0:
            continue
        ai = np.repeat(np.arange(start,finish),counts)
        bj = np.concatenate([np.asarray(c,dtype=np.int64) for c in candidates])
        components = np.maximum(np.maximum(blo[bj]-ahi[ai],alo[ai]-bhi[bj]),0.)
        bound = np.linalg.norm(components,axis=1)-radius_sum-numeric
        np.minimum.at(lower,ai,bound)
    return dict(lower=lower,gap_lower_mm=float(lower.min()),
                exclusion_sphere_queries=len(a),candidate_pairs_checked=candidate_pairs)
