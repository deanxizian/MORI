"""Per-canonical-piece speed upper bounds without translation inflation.

Standard circle Hermite cubics with |h|<=.1 have endpoint derivative norms rh
and middle derivative norm rh*(3*sinc(h/2)-2*cos(h/2)). The elementary bounds
sinc(q)<=1 and cos(q)>=1-q²/2 give a safe uniform factor1+q²<=1.0025.
The three special body joins use their separate interval velocity controls.
Straight lengths use the same checked positive height/return certificates.
Fixed-tail derivative control polygons are bounded in their own rigid frame.
These are nominal geometric arc bounds, not material stretch or cut lengths.
"""
import math
import numpy as np
from cam_native_envelopes import Box,stacked,magnitude,linear,yaw_box

CIRCLE_FACTOR=1.002500001
RESERVE=1e-8


def speeds(e,name,rectangle,certificate):
    yl,yh,pl,ph=map(float,rectangle);pin=int(name[-1])
    labels=e.layout[name]['labels'];tail_index=e.layout[name]['tail_index']
    start=yaw_box(e.e.ends[name],yl,yh)
    spec=e.f.ctx.fan[pin];anchor=Box(e.f.f.anchors[pin])
    if pin in [1,2]:start=Box(spec['start_mm'])
    first=start+float(spec['lead_mm'])*Box([0.,0.,1.])
    delta=anchor-first;D=magnitude(stacked([delta[0],delta[1],Box(0.)]))
    assert D.lo>14
    data,V,_=e.e.special(name,yl,yh)
    velocity=linear(V,data)
    special=float(np.linalg.norm(np.maximum(abs(velocity.lo),abs(velocity.hi)),axis=1).max())
    endpoint=np.asarray(e.f.ctx.cam[f'pin{pin}'][0],float)
    assert endpoint[0]==float(anchor.lo[0])==float(anchor.hi[0])
    tail_velocity=3*np.diff(e.tail[name],axis=1)
    tail_speed=np.linalg.norm(tail_velocity,axis=2).max(1)
    out=[]
    for index,label in enumerate(labels):
        if index>=tail_index:value=float(tail_speed[index-tail_index])
        elif label=='neck' or pin==3 and label=='fan_lead' or pin==4 and label=='fan_first_0':value=special
        elif label=='fan_lead':value=float(spec['lead_mm'])
        elif label=='fan_middle':value=float(D.hi)-14
        elif label=='fan_return':value=float(np.maximum(abs((anchor-first-Box([0.,0.,14.])).lo[2]),abs((anchor-first-Box([0.,0.,14.])).hi[2])))
        elif label=='loop_lead':value=float(e.f.ctx.loop_spec['lead_mm'])
        elif label=='height':value=float(certificate['height_upper_mm'])
        elif label=='down':value=float(certificate['return_upper_mm'])
        elif label.startswith('coupling_'):value=7.5*max(abs(pl),abs(ph))*math.pi/180/5*CIRCLE_FACTOR
        elif label.startswith(('fan_first_','fan_second_','pitch_shift_first_','pitch_shift_second_','top_return_')):value=7*math.pi/32*CIRCLE_FACTOR
        else:raise AssertionError((name,label))
        assert value>=0,(name,label,value)
        out.append(value+RESERVE)
    return np.asarray(out,float)


def arc_upper(densities,i,j,rectangle):
    ta,tb,ua,ub=rectangle
    if i==j:return float(densities[i])*(max(tb,ub)-min(ta,ua))
    assert i<j
    return float(densities[i])*(1-ta)+float(densities[i+1:j].sum())+float(densities[j])*ub
