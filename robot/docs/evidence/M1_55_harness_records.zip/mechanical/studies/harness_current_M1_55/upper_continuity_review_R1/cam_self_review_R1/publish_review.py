"""Publish only the completed fixed-tail remote-self proof and its audit."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE = Path(__file__).resolve().parent
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p:json.loads(Path(p).read_text())


def main():
    proof = read(HERE/'fixed_tail_verification.json')
    audit = read(HERE/'fixed_tail_coverage_verification.json')
    assert proof['status']==audit['status']=='PASS'
    assert audit['whole_parameter_cells']==64000
    sources = dict(proof['sources'])
    sources.update(audit['sources'])
    for p in [Path(__file__),HERE/'fixed_tail_verification.json',HERE/'fixed_tail_coverage_verification.json']:
        sources[str(p)] = sha(p)
    assert all(sha(p)==h for p,h in sources.items())
    table = '\n'.join(f"<tr><td>{html.escape(r['wire'])}</td><td>{r['parameter_cells']:,}</td>"
                       f"<td>{r['whole_tail_arc_upper_mm']:.6f}</td><td>PASS</td></tr>" for r in proof['rows'])
    page = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM 固定尾线自身检查</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;max-width:920px;margin:40px auto;padding:0 22px;color:#232c30}}table{{border-collapse:collapse;width:100%}}th,td{{padding:10px;border:1px solid #ccd3d6;text-align:left}}a{{color:#20526c}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #6b767a}}</style>
<h1>CAM 头内固定尾线：自身接近检查</h1>
<p class="scope">PROTOTYPE / UNVALIDATED · 独立容量参考，尚未进入主模型或视频。这里只检查四条固定尾线；活动段、上下接续、实际端子和带线闭壳仍未完成。</p>
<p>四条尾线的非局部自身间隙检查 PASS。它们在理想俯仰坐标系内保持固定，因此结果覆盖偏航 −60°～+60°、俯仰 −20°～+25°。每条130段三次曲线、16,000个闭参数区间，共64,000个区间，独立覆盖和源文件核对 PASS。</p>
<table><thead><tr><th>参考线路</th><th>完整参数区间</th><th>固定尾线弧长保守上界 / mm</th><th>自身间隙</th></tr></thead><tbody>{table}</tbody></table>
<p>0.3 mm 是保守证明下界的目标，不能当作实际最小距离。只排除整段弧长上界不超过5 mm的局部相邻段；当前尾线的三次曲线弯曲半径已另检达到6.9342 mm要求。其余所有曲线参数对均通过完整区间包络或有证明的空间排除；稠密矩阵实现核对包括268,861个非局部盒对。</p>
<p>这不是实物弯折寿命、线材选型、插头配合或制造放行。原主模型、装配视频与846个硬件工程文件保持。</p>
<p><a href="fixed_tail_verification.json">自身检查结果</a> · <a href="fixed_tail_coverage_verification.json">参数覆盖与源核对</a> · <a href="self_box_crosscheck.json">独立算法核对</a> · <a href="commands.json">实际执行命令</a> · <a href="../index.html">已知上段检查总览</a></p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# M1.55 CAM fixed-tail remote-self review

Four unchanged head-local fixed-tail references: PASS in the ideal common
pitch frame, with 130 cubic pieces and16,000 closed parameter cells each.
Independent parameter coverage/source audit: PASS,64,000 total cells.

This proof is tail-only. Moving lower self, own prefix, actual materials and
connectors, wired insertion and shell closure remain NOT_TESTED / BLOCKED.
No geometry, hardware source, main model or animation is adopted or changed.

Remote pairs exclude only cells whose entire conservative arc upper bound is
<=5 mm. Current tail curvature is checked separately against R6.9342 mm.
Spatial pruning uses a proved centre-sphere exclusion; eligible inside pairs
use complete AABB distances. A target-capped lower bound is not the actual
minimum gap. The independent dense kernel probes cover268,861 remote pairs.

Run commands and logs are retained alongside the proof and its coverage audit.
''')
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources=sources,files=files,CAM_fixed_tail_remote_self='PASS',fixed_tail_references=4,
        whole_parameter_cells=64000,required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,
        moving_lower_self='NOT_TESTED',own_prefix='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FIXED_SELF_PUBLICATION_PASS',len(files),len(sources),flush=True)


if __name__=='__main__':
    main()
