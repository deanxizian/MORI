"""Closed prefix/upper parameter products; exclude only proven local arcs."""
from fan_geometry import half,bound


def refine(e,a,b,da,db,joins,i,j,radius_sum,own,max_depth=16):
    pending = [(a,b,(0.,1.,0.,1.),0)]
    accepted = []
    visited = 0
    while pending:
        ca,cb,rectangle,depth = pending.pop()
        visited += 1
        if own:
            arc = e.arc_upper(da,db,joins,i,j,rectangle)
            if arc<=5.:
                accepted.append(dict(parameter_rectangle=list(rectangle),method='local_arc',arc_upper_mm=arc))
                continue
        gap = max(bound(x,y,radius_sum) for x,y in zip(ca,cb))
        if gap>=.3:
            accepted.append(dict(parameter_rectangle=list(rectangle),method='complete_hull',gap_lower_mm=gap))
            continue
        if depth>=max_depth:
            return dict(status='BLOCKED',visited=visited,unresolved_parameter_rectangle=list(rectangle),
                        gap_lower_mm=gap,arc_upper_mm=arc if own else None)
        ta,tb,ua,ub = rectangle
        if da[i]*(tb-ta)>=db[j]*(ub-ua):
            children = [half(c) for c in ca]
            left,right = [c[0] for c in children],[c[1] for c in children]
            t = (ta+tb)/2
            pending.extend([(left,cb,(ta,t,ua,ub),depth+1),(right,cb,(t,tb,ua,ub),depth+1)])
        else:
            children = [half(c) for c in cb]
            left,right = [c[0] for c in children],[c[1] for c in children]
            u = (ua+ub)/2
            pending.extend([(ca,left,(ta,tb,ua,u),depth+1),(ca,right,(ta,tb,u,ub),depth+1)])
    return dict(status='PASS',visited=visited,accepted=accepted)
