"""Screen unchanged CAM construction with the derivative-only bending checker."""
from pathlib import Path
import datetime,json,sys,time
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=[str(HERE),'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',str(PARENT/'upper_motion_family_R1')]
import cam_family
from cam_family import CAMFamily,NAMES,sha
from stable_bending import radius_bound


def main():
    started=time.time();f=CAMFamily();rows=[];failures=[]
    # Runtime diagnostic override changes a pure checker, never the constructor.
    cam_family.radius_bound=radius_bound
    pitches=[0.,-.1,.1,-.001,.001]
    pitches+=[s*10.**(-k) for k in range(4,13) for s in [-1,1]]
    for y in [0.,-37.2,21.1]:
        for p in pitches:
            for name in NAMES:
                controls,info=f.upper(name,y,p)
                raw,_,_=f.construct(int(name[-1]),y,p,info['height_mm'])
                if controls is not None:assert np.array_equal(controls,raw)
                row=dict(wire=name,pose_deg=[y,p],controls_sha256=__import__('hashlib').sha256(raw.tobytes()).hexdigest(),**info)
                rows.append(row)
                if row['status']!='PASS':failures.append(row)
            print('CAM_DIRECT_DERIVATIVE_POSE',y,p,len(rows),len(failures),flush=True)
    f.ctx.record([Path(__file__),HERE/'stable_bending.py',PARENT/'upper_motion_family_R1/cam_family.py'])
    f.unchanged()
    out=dict(status='PASS' if not failures else 'BLOCKED',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Finite preserved-construction numerical screen; no all-angle CAM qualification',sources=f.sources,
             rows=rows,failures=failures,curve_pose_checks=len(rows),pitches=pitches,yaws=[0.,-37.2,21.1],
             checker_overridden_in_process=True,curve_constructor_changed=False,
             continuous_CAM_math='NOT_TESTED',actual_material='BLOCKED',full_harness='BLOCKED',
             main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'small_angles_direct_derivative.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_DIRECT_DERIVATIVE_TERMINAL',out['status'],len(rows),len(failures),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
