"""Run the unchanged cross-check with exact NumPy scalar JSON serialization.

The initial full run completed its checks but did not produce a report because
its source-parent index was a NumPy integer. This process-local serialization
adapter changes neither the comparisons nor their geometry and thresholds.
"""
from pathlib import Path
import datetime
import importlib.util
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from cam_native_envelopes import sha


def scalar(value):
    if isinstance(value,np.generic):
        return value.item()
    raise TypeError(f'Unsupported report type: {type(value).__name__}')


def main():
    spec=importlib.util.spec_from_file_location('mori_cam_interval_source_crosscheck',HERE/'check_envelopes.py')
    source=importlib.util.module_from_spec(spec);spec.loader.exec_module(source)
    guarded={str(p):sha(p) for p in [Path(__file__),HERE/'check_envelopes.py',HERE/'cam_native_envelopes.py']}
    original=json.dumps
    def serialize(value,*args,**kwargs):
        kwargs.setdefault('default',scalar)
        return original(value,*args,**kwargs)
    source.json.dumps=serialize
    source.main()
    assert all(sha(p)==h for p,h in guarded.items())
    path=HERE/('envelope_pilot_crosscheck.json' if '--pilot' in sys.argv else 'envelope_crosscheck.json')
    report=json.loads(path.read_text())
    assert report['status']=='PASS'
    report['sources'].update(guarded)
    report.update(execution_driver=str(Path(__file__)),serialization='NumPy scalar.item; exact integer/float values',
                  driver_recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    path.write_text(original(report,indent=2)+'\n')
    print('CAM_ENVELOPE_SERIALIZED_TERMINAL',report['mode'],report['direct_source_pose_comparisons'],
          report['tiny_angle_source_comparisons'],report['closed_parameter_samples_compared'],flush=True)


if __name__=='__main__':
    main()
