"""Reuse the complete mathematical parent covers without widening root claims.

For an angular box, every intersecting parent's closed root range participates
in the union. This remains a conservative root range over the whole box.
All source partitions and proofs remain frozen and separately hash-guarded.
"""
from pathlib import Path
import json
import numpy as np
from cross_envelopes import CAM_NAMES, POWER_NAMES, sha

ROOT = Path(__file__).resolve().parent.parent


class RootCovers:
    def __init__(self, enclosures):
        self.e = enclosures
        self.cam = enclosures.cam.parents
        path = ROOT/'power_math_verification.json'
        proof = json.loads(path.read_text())
        assert proof['status'] == 'PASS'
        assert all(sha(p) == h for p,h in proof['sources'].items())
        self.power = {n:[r for r in proof['rows'] if r['wire']==n] for n in POWER_NAMES}
        self.parents = self.cam | self.power
        self.bounds = {n:np.array([r['rectangle_deg'] for r in rows]) for n,rows in self.parents.items()}
        self.sources = {str(Path(__file__)):sha(Path(__file__)), str(path):sha(path)}
        assert all(r['status']=='PASS' for rows in self.parents.values() for r in rows)

    def indices(self, name, rectangle):
        yl,yh,pl,ph = rectangle
        bounds = self.bounds[name]
        indices = np.flatnonzero((bounds[:,0]<yh)&(bounds[:,1]>yl)&(bounds[:,2]<ph)&(bounds[:,3]>pl))
        assert len(indices)
        return [int(i) for i in indices]

    def certificate(self, name, rectangle):
        indices = self.indices(name, rectangle)
        rows = [self.parents[name][i] for i in indices]
        if name in CAM_NAMES:
            values = dict(height_lower_mm=min(r['height_lower_mm'] for r in rows),
                          height_upper_mm=max(r['height_upper_mm'] for r in rows),
                          return_lower_mm=min(r['return_lower_mm'] for r in rows),
                          return_upper_mm=max(r['return_upper_mm'] for r in rows))
        else:
            lo = min(r['midpoint_amplitude_mm']-r['amplitude_deviation_bound_mm'] for r in rows)
            hi = max(r['midpoint_amplitude_mm']+r['amplitude_deviation_bound_mm'] for r in rows)
            values = dict(midpoint_amplitude_mm=(lo+hi)/2,
                          amplitude_deviation_bound_mm=(hi-lo)/2+1e-9)
        return dict(status='PASS', wire=name, rectangle_deg=list(rectangle),
                    parent_indices=indices, method='guarded_parent_union', **values)

    def unchanged(self):
        assert all(sha(p) == h for p,h in self.sources.items())
