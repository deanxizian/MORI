"""Fan-only and all mixed/loop upper remote-self references, closed parameters.

The existing tail-only proof is separate. Fan-only is yaw-dependent and
pitch-independent; mixed/loop products use the complete mathematical2D cover.
Local pairs are omitted only with a complete arc upper bound<=5mm, backed by
the guarded existing all-angle curvature proof. All other products use hulls
or exhaustive closed-parameter refinement, never only sampled points.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
HERE=Path(__file__).resolve().parent;MATH=HERE.parent
NATIVE=MATH/'cam_native_clearance_review_R1';PEER=MATH/'cam_peer_review_R1'
sys.path[:0]=[str(NATIVE),str(PEER)]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,RADII,sha
from fan_geometry import matrix
from arc_speed_bounds import speeds
from self_hulls import refine


def clip(r,w):
    b=(max(r[0],w[0]),min(r[1],w[1]),max(r[2],w[2]),min(r[3],w[3]))
    return b if b[0]<b[1] and b[2]<b[3] else None


def main():
    started=time.time();pilot='--pilot' in sys.argv
    region=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--region=')),'mixed')
    assert region in ['fan','mixed'];e=NativeCAMEnvelopes()
    cross_path=HERE/'arc_bound_crosscheck.json';cross=json.loads(cross_path.read_text())
    assert cross['status']=='PASS' and cross['minimum_speed_upper_reserve_mm']>=0
    assert all(sha(p)==h for p,h in cross['sources'].items())
    source=dict(e.sources)
    for p in [Path(__file__),HERE/'arc_speed_bounds.py',HERE/'self_hulls.py',PEER/'fan_geometry.py',cross_path,
              PEER/'fan_independence_verification.json',MATH/'cam_math_review_R1/nominal_math_verification.json']:
        source[str(p)]=sha(p)
    nominal=json.loads((MATH/'cam_math_review_R1/nominal_math_verification.json').read_text())
    assert nominal['status']=='PASS' and nominal['circle_minimum_radius_lower_mm']>=6.9342
    windows=[(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else None
    failures=[];results=[];visited=0
    for name in NAMES:
        layout=e.layout[name];count=len(layout['labels']);fan=layout['labels'].index('pitch_shift_first_0');tail=layout['tail_index']
        ai,bi=np.indices((count,count));upper=bi>=ai
        ff=(ai<fan)&(bi<fan);tt=(ai>=tail)&(bi>=tail)
        mask=upper&(ff if region=='fan' else ~(ff|tt))
        if region=='fan':
            ranges=[(-60.,-50.,0.,0.),(-10.,0.,0.,0.),(50.,60.,0.,0.)] if pilot else [(float(y),float(y+10),0.,0.) for y in range(-60,60,10)]
            bases=[dict(rectangle_deg=list(r),source_parent_index=None) for r in ranges]
        else:
            bases=[]
            for index,parent in enumerate(e.parents[name]):
                for window in windows or [parent['rectangle_deg']]:
                    r=clip(parent['rectangle_deg'],window)
                    if r:bases.append(dict(rectangle_deg=list(r),source_parent_index=index))
        accepted=[]
        for base in bases:
            seed=tuple(base['rectangle_deg']);pending=[(seed,0,None)]
            while pending:
                rectangle,depth,certificate=pending.pop();visited+=1
                if certificate is None:
                    certificate=(e.parents[name][base['source_parent_index']] if depth==0 and region=='mixed'
                                 else e.certificate(name,rectangle))
                h=Box(certificate['height_lower_mm'],certificate['height_upper_mm'])
                groups=['yaw'] if region=='fan' else ['yaw','pitch']
                boxes=[e.controls(name,rectangle,h,g)[0] for g in groups]
                density=speeds(e,name,rectangle,certificate);prefix=np.r_[0.,np.cumsum(density)]
                # Piece i..j complete arc maximum, including both full cells.
                arc=prefix[bi+1]-prefix[ai]
                gaps=np.maximum.reduce([matrix(c,c,2*RADII[name]) for c in boxes])
                local=mask&(arc<=5.)
                separated=mask&~local&(gaps>=.3)
                unresolved=np.argwhere(mask&~local&~separated)
                details=[];ok=True
                for i,j in unresolved:
                    checked=refine([c[int(i)] for c in boxes],[c[int(j)] for c in boxes],
                                   density,int(i),int(j),RADII[name])
                    if checked['status']!='PASS':ok=False;break
                    details.append(dict(pieces=[int(i),int(j)],parameter_rectangles=checked['accepted'],
                                        visited_parameter_boxes=checked['visited']))
                if ok:
                    accepted.append(dict(rectangle_deg=list(rectangle),base_rectangle_deg=list(seed),
                        source_parent_index=base['source_parent_index'],status='PASS',
                        complete_piece_pairs=int(mask.sum()),coarse_local_pairs=int(local.sum()),
                        coarse_separated_pairs=int(separated.sum()),refined_piece_pairs=unresolved.tolist(),
                        parameter_refinements=details,required_gap_mm=.3,local_arc_exclusion_upper_mm=5.))
                elif depth>=16:
                    failures.append(dict(wire=name,rectangle_deg=list(rectangle),unresolved_pieces=[int(i),int(j)],
                                         details=checked,reason='Undecided interval remote-self/arc cover'));break
                else:
                    yl,yh,pl,ph=rectangle;y,p=(yl+yh)/2,(pl+ph)/2
                    if region=='fan' or (yh-yl)/10>(ph-pl):
                        pending.extend([((yl,y,pl,ph),depth+1,None),((y,yh,pl,ph),depth+1,None)])
                    else:pending.extend([((yl,yh,pl,p),depth+1,None),((yl,yh,p,ph),depth+1,None)])
                if visited%50==0:print('CAM_SELF_REGION_PROGRESS',region,name,visited,len(accepted),round(time.time()-started,1),flush=True)
            if failures:break
        results.append(dict(wire=name,status='PASS' if not failures else 'BLOCKED',source_bases=bases,intervals=accepted))
        print('CAM_SELF_REGION_WIRE',region,name,results[-1]['status'],len(accepted),round(time.time()-started,1),flush=True)
        if failures:break
    e.unchanged();assert all(sha(p)==h for p,h in source.items())
    out=dict(status='PASS' if len(results)==4 and not failures else 'BLOCKED',region=region,
        mode='pilot' if pilot else 'all_angles',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources=source,results=results,failures=failures,pilot_windows=windows,
        scope='Complete-parameter nominal upper self region only; own body prefix and fixed-tail category separate',
        required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,local_radius_requirement_mm=6.9342,
        full_CAM_self='NOT_TESTED',own_prefix='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
        elapsed_s=time.time()-started)
    target=f'{region}_'+('pilot_verification.json' if pilot else 'verification.json')
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_SELF_REGION_TERMINAL',region,out['status'],visited,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
