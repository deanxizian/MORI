"""Independent dense AABB-pair comparison for the exclusion algorithm."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0,'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
from box_distance import score
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    rng = np.random.default_rng(20261010)
    rows = []
    pairs = 0
    for seed in range(12):
        a = rng.uniform(-10,10,(137,3))
        b = rng.uniform(-10,10,(701,3))
        ar = rng.uniform(0,.3,a.shape)
        br = rng.uniform(0,.3,b.shape)
        if seed%3==0:
            b[0] = [30,30,30]
            br[0] = [31,31,31]
        elif seed%3==1:
            b[:,0]+=30
        alo,ahi,blo,bhi = a-ar,a+ar,b-br,b+br
        output = score(alo,ahi,blo,bhi,.6)
        components = np.maximum(np.maximum(blo[None]-ahi[:,None],alo[:,None]-bhi[None]),0.)
        exact = np.linalg.norm(components,axis=2)-.6-.0001
        expected = np.minimum(exact.min(1),.3)
        error = float(np.max(abs(output['lower']-expected)))
        assert error<1e-12,(seed,error)
        pairs+=len(a)*len(b)
        rows.append(dict(seed=seed,dense_pairs=len(a)*len(b),maximum_absolute_difference_mm=error,
                         candidate_pairs_checked=output['candidate_pairs_checked'],status='PASS'))
    source = [Path(__file__),HERE/'box_distance.py']
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Finite implementation checks against independent complete dense AABB pair distances; not route clearance',
        sources={str(p):sha(p) for p in source},rows=rows,dense_pairs_compared=pairs,
        whole_CAM_clearance='NOT_TESTED',main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'box_distance_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_BOX_DISTANCE_CHECK_PASS',len(rows),pairs,flush=True)


if __name__=='__main__':
    main()
