"""Combine the three exhaustive piece-product covers of six CAM pairs.

Fan/fan is yaw-only because its guarded construction is pitch-independent.
Fixed tail/tail is constant in the common pitch frame. All other products
use the existing648 mathematical yaw/pitch parents and complete cubic hulls.
This combined scope is the four nominal CAM uppers, not all seven uppers,
the body-prefix joins, real wire materials or full wired assembly.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
NAMES=['CAM_1','CAM_2','CAM_3','CAM_4']


def main():
    paths=[HERE/'fan_verification.json',HERE/'fan_coverage_verification.json',
           HERE/'fan_independence_verification.json',HERE/'remaining_hull_verification.json',
           HERE/'remaining_hull_coverage_verification.json',HERE/'pilot_adaptive_verification.json',
           HERE/'pilot_adaptive_coverage_verification.json']
    reports=[read(p) for p in paths]
    assert all(r['status']=='PASS' and all(sha(p)==h for p,h in r['sources'].items()) for r in reports)
    fan,fan_audit,independence,mixed,mixed_audit,pilot,pilot_audit=reports
    assert fan['mode']==fan_audit['mode']=='all_yaw' and independence['all_pitch_independence']=='PASS'
    assert mixed_audit['pair_angular_rows']==3888 and mixed_audit['source_math_parent_rectangles']==648
    assert pilot['mode']==pilot_audit['mode']=='pilot'
    counts=dict(CAM_1=238,CAM_2=238,CAM_3=237,CAM_4=237)
    cuts=fan['fan_piece_counts']
    assert cuts==dict(CAM_1=37,CAM_2=37,CAM_3=36,CAM_4=36)
    pairs=list(itertools.combinations(NAMES,2));rows=[]
    assert [tuple(r['wires']) for r in pilot['fixed_tail_pairs']]==pairs
    for a,b in pairs:
        fixed=next(r for r in pilot['fixed_tail_pairs'] if r['wires']==[a,b])
        assert fixed['status']=='PASS' and fixed['group']=='pitch' and fixed['gap_lower_mm']>=.3
        total=counts[a]*counts[b];fan_products=cuts[a]*cuts[b];tail_products=130*130
        remaining=total-fan_products-tail_products
        assert remaining>0
        rows.append(dict(wires=[a,b],status='PASS',complete_cubic_piece_products=total,
                         fan_fan_products=fan_products,fixed_tail_tail_products=tail_products,
                         all_remaining_products=remaining))
    sources={}
    for r in reports:
        for p,h in r['sources'].items():
            assert p not in sources or sources[p]==h
            sources[p]=h
    for p in [Path(__file__),*paths]:sources[str(p)]=sha(p)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Six full four-CAM-upper nominal mutual pairs; all piece-product categories and both angular parameters covered',
        sources=sources,results=rows,unordered_pairs=6,fan_accepted_yaw_intervals=fan_audit['accepted_yaw_intervals'],
        fan_parameter_refinement_rectangles=fan_audit['accepted_parameter_rectangles'],
        mixed_parent_rectangles=648,mixed_pair_angular_rows=3888,
        fixed_tail_closed_parameter_cells_per_reference=16000,
        required_gap_mm=.3,minimum_certified_gap_lower_mm=min(
            fan_audit['minimum_certified_gap_lower_mm'],mixed_audit['minimum_certified_gap_lower_mm'],
            min(r['gap_lower_mm'] for r in pilot['fixed_tail_pairs'])),
        yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],frame='Ideal consistent nominal Rz(yaw)Rx(pitch)',
        continuous_nominal_CAM_mutual='PASS',CAM_power_cross_pairs='NOT_TESTED',
        moving_self='NOT_TESTED',own_prefix='NOT_TESTED',actual_material_and_endpoints='BLOCKED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'combined_peer_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_MUTUAL_COMBINED_PASS',6,out['fan_accepted_yaw_intervals'],3888,flush=True)


if __name__=='__main__':main()
