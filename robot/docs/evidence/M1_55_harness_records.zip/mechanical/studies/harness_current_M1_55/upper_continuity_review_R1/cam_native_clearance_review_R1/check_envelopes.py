"""Cross-check new interval controls against the retained80-digit constructor.

Finite probes diagnose implementation errors. Complete coverage later follows
from analytic control boxes and the closed Bernstein subinterval operators,
not from treating these finite samples as a full movement proof.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,ideal_matrix,sha,basis


def canonical(e,name,yaw,pitch,actual,group):
    source=actual.copy()
    if group!='body':
        inverse=np.linalg.inv(ideal_matrix(e.center,yaw,pitch if group=='pitch' else 0.))
        source=source@inverse[:3,:3].T+inverse[:3,3]
    result=[];cursor=0
    labels=e.layout[name]['labels']
    for label in labels:
        if label=='fan_lead' and e.f.ctx.fan[int(name[-1])]['lead_mm']==0:
            point=source[cursor-1,-1] if cursor else source[0,0]
            result.append(np.broadcast_to(point,(4,3)))
        elif label.startswith('coupling_') and pitch==0:
            result.append(np.broadcast_to(source[cursor,0],(4,3)))
        else:
            result.append(source[cursor]);cursor+=1
    assert cursor==len(source),(name,yaw,pitch,cursor,len(source))
    return np.array(result)


def excess(value,box):
    return float(np.maximum(box.lo-value,value-box.hi).max())


def main():
    started=time.time();e=NativeCAMEnvelopes();pilot='--pilot' in sys.argv
    rows=[];near=[];maximum=-float('inf');parameter_samples=0
    for name in NAMES:
        parents=e.parents[name]
        indices=[len(parents)//2] if pilot else list(np.unique(np.linspace(0,len(parents)-1,6,dtype=int)))
        for index in indices:
            cert=parents[index];yl,yh,pl,ph=cert['rectangle_deg']
            points=[((yl+yh)/2,(pl+ph)/2)] if pilot else [(yl,pl),(yh,ph),((yl+yh)/2,(pl+ph)/2)]
            boxes={g:e.controls(name,(yl,yh,pl,ph),Box(cert['height_lower_mm'],cert['height_upper_mm']),g)[0]
                   for g in ['body','yaw','pitch']}
            cells={g:e.point_boxes(name,(yl,yh,pl,ph),cert,g) for g in boxes}
            for y,p in points:
                _,actual,_,math=e.f.upper(name,y,p)
                assert math['status']=='PASS'
                checked={}
                for group in boxes:
                    source=canonical(e,name,y,p,actual,group)
                    full_error=excess(source,boxes[group]);assert full_error<=1e-8,(name,y,p,group,full_error)
                    samples=[]
                    for i,M in enumerate(e.operators[name]):
                        count=len(M);a=np.arange(count)/count;b=(np.arange(count)+1)/count
                        local=basis(a,3)@source[i]
                        midpoint=basis((a+b)/2,3)@source[i]
                        end=basis(b,3)@source[i]
                        samples.append(np.stack([local,midpoint,end],axis=1))
                    samples=np.concatenate(samples)
                    cell_error=float(np.maximum(cells[group].lo[:,None]-samples,samples-cells[group].hi[:,None]).max())
                    assert cell_error<=1e-8,(name,y,p,group,cell_error)
                    parameter_samples+=len(samples)*3
                    checked[group]=dict(control_box_excess_mm=full_error,closed_cell_probe_excess_mm=cell_error)
                    maximum=max(maximum,full_error,cell_error)
                rows.append(dict(wire=name,source_parent_index=index,rectangle_deg=cert['rectangle_deg'],pose_deg=[y,p],
                                 status='PASS',groups=checked))
        tiny_poses=[(0.,0.),(21.1,-1e-12),(21.1,1e-12)] if pilot else [
            (y,p) for y in [0.,21.1] for p in [0.,-1e-5,1e-5,-1e-8,1e-8,-1e-12,1e-12]]
        for y,p in tiny_poses:
            _,actual,_,math=e.f.upper(name,y,p);assert math['status']=='PASS'
            c,_,_,_=e.controls(name,(y,y,p,p),Box(math['height_mm']),'yaw')
            source=canonical(e,name,y,p,actual,'yaw');error=excess(source,c)
            assert error<=1e-8,(name,y,p,error)
            maximum=max(maximum,error)
            near.append(dict(wire=name,pose_deg=[y,p],actual_source_pieces=len(actual),canonical_pieces=len(source),
                             maximum_control_box_excess_mm=error,status='PASS'))
        print('CAM_NATIVE_ENVELOPE_WIRE',name,len(rows),len(near),round(time.time()-started,1),flush=True)
    e.unchanged()
    sources=dict(e.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    out=dict(status='PASS',mode='pilot' if pilot else 'full_crosscheck',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Finite retained high-precision source construction and interval-implementation probes only; no full native clearance proof',
             sources=sources,rows=rows,tiny_angle_rows=near,direct_source_pose_comparisons=len(rows),
             tiny_angle_source_comparisons=len(near),closed_parameter_samples_compared=parameter_samples,
             parameter_cells_per_reference={name:len(e.layout[name]['parameter_cells']) for name in NAMES},
             canonical_pieces_per_reference={name:len(e.layout[name]['labels']) for name in NAMES},
             maximum_positive_excess_mm=max(0.,maximum),numeric_control_reserve_mm=1e-8,
             native_frame='Ideal nominal Rz(yaw)Rx(pitch) about current head centre',
             full_native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',remote_self='NOT_TESTED',
             actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
             animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/('envelope_pilot_crosscheck.json' if pilot else 'envelope_crosscheck.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_NATIVE_ENVELOPE_TERMINAL',len(rows),len(near),parameter_samples,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
