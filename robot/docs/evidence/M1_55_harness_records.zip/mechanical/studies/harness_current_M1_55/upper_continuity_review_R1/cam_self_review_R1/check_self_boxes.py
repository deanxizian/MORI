"""Check remote AABB self distances against a separate dense pair matrix."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import numpy as np
HERE = Path(__file__).resolve().parent
sys.path.insert(0,'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
from self_box_distance import score
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    rng = np.random.default_rng(20261010)
    rows = []
    count = 0
    for seed in range(16):
        centers = rng.uniform(-10,10,(211,3))
        radii = rng.uniform(.001,.05,centers.shape)
        if seed%4==0:
            centers[0] = [30,30,30]
            radii[0] = [31,31,31]
        lo,hi = centers-radii,centers+radii
        arc = np.r_[0.,np.cumsum(rng.uniform(.05,.3,len(lo)))]
        actual = score(lo,hi,arc,.5778)
        ai,bi = np.triu_indices(len(lo),1)
        keep = arc[bi+1]-arc[ai]>5.
        ai,bi = ai[keep],bi[keep]
        delta = np.maximum(np.maximum(lo[bi]-hi[ai],lo[ai]-hi[bi]),0.)
        expected = min(.3,float((np.linalg.norm(delta,axis=1)-2*.5778-.0001).min()))
        assert abs(actual['gap_lower_mm']-expected)<1e-12,(seed,actual,expected)
        count+=len(ai)
        rows.append(dict(seed=seed,status='PASS',dense_remote_pairs=len(ai),
                         absolute_difference_mm=abs(actual['gap_lower_mm']-expected)))
    sources = {str(p):sha(p) for p in [Path(__file__),HERE/'self_box_distance.py']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Finite remote-box algorithm implementation probes, not a cable motion proof',
        sources=sources,rows=rows,dense_remote_pairs_compared=count,
        main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'self_box_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_SELF_BOX_ALGORITHM_PASS',len(rows),count,flush=True)


if __name__=='__main__':
    main()
