"""Compose all 21 unordered mutual pairs of the seven known nominal uppers."""
from pathlib import Path
import datetime
import hashlib
import itertools
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
CAM = ['CAM_1','CAM_2','CAM_3','CAM_4']
POWER = ['P_J18_1','P_J18_2','CC_allocation']


def main():
    paths = [ROOT/'cam_peer_review_R1/combined_peer_coverage_verification.json',
             ROOT/'power_peer_review_R1/peer_coverage_verification.json',
             HERE/'cross_coverage_verification.json']
    reports = [read(p) for p in paths]
    sources = {}
    for report in reports:
        assert report['status']=='PASS' and report['required_gap_mm']==.3
        for p,h in report['sources'].items():
            assert sha(p)==h and (p not in sources or sources[p]==h)
            sources[p] = h
    cam,power,cross = reports
    assert cam['continuous_nominal_CAM_mutual']=='PASS' and cam['unordered_pairs']==6
    assert power['mode']==cross['mode']=='all_angles'
    assert power['unordered_pairs']==3 and cross['unordered_cross_pairs']==12
    rows = []
    for category,report,key in [('CAM_CAM',cam,'results'),('power_power',power,'pair_counts'),('CAM_power',cross,'results')]:
        for row in report[key]:
            assert row.get('status','PASS')=='PASS'
            rows.append(dict(wires=row['wires'],category=category,status='PASS'))
    actual = [tuple(sorted(r['wires'])) for r in rows]
    expected = {tuple(sorted(pair)) for pair in itertools.combinations([*CAM,*POWER],2)}
    assert len(actual)==len(set(actual))==21 and set(actual)==expected
    for p in [Path(__file__),*paths]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Complete unordered mutual pairs of the seven known nominal upper references only; not complete harness fit',
               sources=sources,results=rows,references=7,unordered_pairs=21,
               category_pair_counts=dict(CAM_CAM=6,power_power=3,CAM_power=12),
               yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],required_gap_mm=.3,
               minimum_certified_gap_lower_mm=min(r['minimum_certified_gap_lower_mm'] for r in reports),
               known_upper_continuous_mutual='PASS',own_prefix='NOT_TESTED',power_remote_self='NOT_TESTED',
               missing_actual_upper_endpoint_references=5,full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'complete_upper_mutual_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('KNOWN_UPPER_MUTUAL_COMBINED_PASS',7,21,flush=True)


if __name__ == '__main__':
    main()
