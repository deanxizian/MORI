"""Independent coverage, recorded curve/root and derivative readback audit."""
from pathlib import Path
import datetime,json,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PROJECT=HERE.parents[4]
sys.path[:0]=[str(HERE),str(MATH)]
from nominal_cam import Q,W,B,sha,NAMES


def coverage(rows,domain):
    boxes=[r['rectangle_deg'] for r in rows]
    assert all(domain[0]<=b[0]<b[1]<=domain[1] and domain[2]<=b[2]<b[3]<=domain[3] for b in boxes)
    edges=sorted({x for b in boxes for x in b[:2]})
    assert edges[0]==domain[0] and edges[-1]==domain[1]
    for yl,yh in zip(edges[:-1],edges[1:]):
        mid=(yl+yh)/2;strips=sorted(b[2:] for b in boxes if b[0]<mid<b[1])
        assert strips and strips[0][0]==domain[2] and strips[-1][1]==domain[3]
        assert all(a[1]==b[0] for a,b in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    started=time.time();proof_path=HERE/'nominal_math_verification.json';grid_path=HERE/'nominal_half_grid_verification.json'
    proof=json.loads(proof_path.read_text());grid=json.loads(grid_path.read_text())
    pilot=json.loads((HERE/'nominal_pilot_verification.json').read_text())
    assert proof['status']==grid['status']==pilot['status']=='PASS'
    assert grid['curve_pose_checks']==1900 and len(grid['planned_poses'])==475
    assert len({tuple(p) for p in grid['planned_poses']})==475
    assert pilot['curve_pose_checks']==144
    for r in [proof,grid,pilot]:assert all(sha(p)==h for p,h in r['sources'].items())
    arrays_path=HERE/'nominal_half_grid_curves.npz';assert sha(arrays_path)==grid['arrays_sha256']
    arrays=np.load(arrays_path);sources=dict(proof['sources']);sources.update(grid['sources']);sources.update(pilot['sources'])
    checked=0;maximum_length_error=0.;maximum_derivative_quantization=0.;slabs=0
    for name in NAMES:
        bends=sorted((r for r in proof['bending_intervals'] if r['wire']==name),key=lambda r:r['yaw_interval_deg'][0])
        assert bends[0]['yaw_interval_deg'][0]==-60 and bends[-1]['yaw_interval_deg'][1]==60
        assert all(a['yaw_interval_deg'][1]==b['yaw_interval_deg'][0] for a,b in zip(bends[:-1],bends[1:]))
        assert all(r['status']=='PASS' and r['radius_lower_mm']>=6.9342 and r['minimum_speed']>0 for r in bends)
        assert proof['tail_bending'][name]['radius_lower_mm']>=6.9342
        root_rows=[r for r in proof['length_rectangles'] if r['wire']==name]
        slabs+=coverage(root_rows,[-60,60,-20,25])
        assert all(r['numeric_length_height_derivative']==2 and min(r['height_lower_mm'],r['return_lower_mm'])>=.5 for r in root_rows)
        for row in [r for r in grid['rows'] if r['wire']==name]:
            y,p=row['pose_deg'];key=f'{name}_y{y:g}_p{p:g}'
            c=arrays[key+'_controls'];v=arrays[key+'_derivatives'];L=arrays[key+'_lengths']
            assert c.shape[1:]==(4,3) and v.shape==(len(c),3,3) and np.all(L>0)
            fresh=np.linalg.norm(np.einsum('qi,nij->nqj',B,v),axis=-1)@W
            length_error=float(abs(fresh-L).max());maximum_length_error=max(maximum_length_error,length_error)
            assert length_error<1e-10
            derivative_error=float(np.linalg.norm(3*np.diff(c,axis=1)-v,axis=-1).max())
            maximum_derivative_quantization=max(maximum_derivative_quantization,derivative_error)
            assert derivative_error<1e-10
            candidates=[r for r in root_rows if r['rectangle_deg'][0]<=y<=r['rectangle_deg'][1] and r['rectangle_deg'][2]<=p<=r['rectangle_deg'][3]]
            assert candidates and any(r['height_lower_mm']-1e-8<=row['height_mm']<=r['height_upper_mm']+1e-8 for r in candidates),(name,y,p,row['height_mm'])
            assert row['body_endpoint_exact'] and abs(row['length_residual_mm'])<1e-8
            assert row['saved_curve_parameter_sample_difference_mm']<.0005
            checked+=1
    assert checked==1900 and proof['circle_minimum_radius_lower_mm']>=6.9342
    baseline=json.loads((PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json').read_text())
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    for path in [Path(__file__),proof_path,grid_path,HERE/'nominal_pilot_verification.json',arrays_path]:sources[str(path)]=sha(path)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
             scope='Four nominal CAM math-family coverage and1900 saved-curve/height/derivative readbacks; not native clearance or physical wire qualification',
             source_blend_sha256=sha(PROJECT/'mechanical/mori_v1_2.blend'),source_video_sha256=sha(PROJECT/'mechanical/animation/MORI_assembly.mp4'),
             saved_curve_readbacks=checked,independent_y_slab_checks=slabs,bending_yaw_intervals=len(proof['bending_intervals']),
             positive_length_rectangles=len(proof['length_rectangles']),maximum_length_readback_error_mm=maximum_length_error,
             maximum_preview_derivative_quantization_mm=maximum_derivative_quantization,
             maximum_saved_parameter_sample_difference_mm=max(r['saved_curve_parameter_sample_difference_mm'] for r in grid['rows']),
             minimum_positive_height_lower_mm=min(r['height_lower_mm'] for r in proof['length_rectangles']),
             minimum_positive_return_lower_mm=min(r['return_lower_mm'] for r in proof['length_rectangles']),
             protected_hardware_files=846,full_harness='BLOCKED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
             main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'nominal_math_readback.json').write_text(json.dumps(out,indent=2)+'\n')
    print('NOMINAL_CAM_READBACK_PASS',checked,slabs,846,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
