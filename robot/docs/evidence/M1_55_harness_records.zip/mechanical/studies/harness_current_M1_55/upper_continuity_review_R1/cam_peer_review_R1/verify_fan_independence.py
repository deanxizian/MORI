"""Source dependency audit of the pre-pitch fan region in the yaw frame.

The proof does not extrapolate the finite independence probes. It reads the
guarded construction: before the first pitch sine term, no prefix expression
loads pitch/height/sign. The only later control-list mutation changes the
last coupling piece, and the yaw branch leaves the lower controls untouched.
"""
from pathlib import Path
import ast
import datetime
import hashlib
import json
HERE=Path(__file__).resolve().parent
source=HERE.parent/'cam_native_clearance_review_R1/cam_native_envelopes.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    tree=ast.parse(source.read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='NativeCAMEnvelopes')
    function=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='controls')
    def assigned(node,name):
        return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
    start=next(i for i,n in enumerate(function.body) if assigned(n,'start'))
    end=next(i for i,n in enumerate(function.body) if assigned(n,'sine'))
    assert end>start
    prefix=function.body[start:end]
    loads={n.id for item in prefix for n in ast.walk(item) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Load)}
    assert not loads.intersection({'pl','ph','height','sign'}),loads
    assert any(isinstance(n,ast.Constant) and n.value=='loop_lead' for item in prefix for n in ast.walk(item))
    suffix=function.body[end:]
    mutations=[]
    for item in suffix:
        for n in ast.walk(item):
            if isinstance(n,ast.Subscript) and isinstance(n.ctx,ast.Store) and isinstance(n.value,ast.Name) and n.value.id=='controls':
                assert isinstance(n.slice,ast.UnaryOp) and isinstance(n.slice.op,ast.USub)
                assert isinstance(n.slice.operand,ast.Constant) and n.slice.operand.value==1
                mutations.append(n.lineno)
    assert len(mutations)==1
    branch=next(n for n in function.body if isinstance(n,ast.If) and
                isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Name) and n.test.left.id=='group')
    assert branch.test.comparators[0].value=='body'
    pitch_branch=branch.orelse[0]
    assert isinstance(pitch_branch,ast.If) and pitch_branch.test.comparators[0].value=='pitch'
    yaw_else=pitch_branch.orelse
    assert len(yaw_else)==1 and assigned(yaw_else[0],'tail_controls')
    assert isinstance(yaw_else[0].value,ast.Name) and yaw_else[0].value.id=='tail_yaw'
    assert all(not (isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store) and n.id=='lower_controls')
               for item in yaw_else for n in ast.walk(item))
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Guarded source dependency audit of the complete fan region in the ideal yaw frame',
        sources={str(p):sha(p) for p in [Path(__file__),source]},
        prefix_source_lines=[function.body[start].lineno,function.body[end-1].end_lineno],
        forbidden_prefix_loads=['pl','ph','height','sign'],later_mutations=mutations,
        later_mutation_scope='Last coupling piece only, after fan prefix',
        yaw_branch_lower_controls_preserved=True,all_pitch_independence='PASS',
        main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'fan_independence_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FAN_INDEPENDENCE_SOURCE_PASS',out['prefix_source_lines'],mutations,flush=True)


if __name__=='__main__':main()
