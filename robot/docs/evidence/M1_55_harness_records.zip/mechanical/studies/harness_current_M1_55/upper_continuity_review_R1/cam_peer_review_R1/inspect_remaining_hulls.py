"""Read-only diagnostic of full cubic control-hull AABB pair bounds.

This uses the same guarded CAM control enclosures and no curve samples. A
passing whole-piece hull pair certifies all of its two curve parameters;
unresolved hulls require refinement and are not a collision finding.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/'cam_native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,Box,RADII,sha


def main():
    e=NativeCAMEnvelopes()
    selected=[0,len(e.parents[NAMES[0]])//2,len(e.parents[NAMES[0]])-1]
    rows=[]
    for index in selected:
        rectangle=e.parents[NAMES[0]][index]['rectangle_deg']
        enclosures={}
        for name in NAMES:
            c=e.parents[name][index]
            h=Box(c['height_lower_mm'],c['height_upper_mm'])
            for group in ['yaw','pitch']:
                box=e.controls(name,rectangle,h,group)[0]
                enclosures[name,group]=box.lo.min(1),box.hi.max(1)
        for pair in itertools.combinations(NAMES,2):
            bounds=[]
            for group in ['yaw','pitch']:
                al,ah=enclosures[pair[0],group];bl,bh=enclosures[pair[1],group]
                delta=np.maximum(np.maximum(bl[None]-ah[:,None],al[:,None]-bh[None]),0.)
                lower=np.linalg.norm(delta,axis=2)-sum(RADII[n] for n in pair)-.0001
                lower[e.layout[pair[0]]['tail_index']:,e.layout[pair[1]]['tail_index']:]=np.inf
                af=e.layout[pair[0]]['labels'].index('pitch_shift_first_0')
                bf=e.layout[pair[1]]['labels'].index('pitch_shift_first_0')
                lower[:af,:bf]=np.inf
                i,j=np.unravel_index(np.argmin(lower),lower.shape)
                bounds.append(dict(group=group,gap_lower_mm=float(lower.min()),
                    unresolved_piece_pairs=int(np.count_nonzero(lower<.3)),
                    worst_pieces=[int(i),int(j)],
                    worst_labels=[e.layout[n]['labels'][k] for n,k in zip(pair,[i,j])]))
            row=dict(wires=list(pair),source_math_parent_index=index,rectangle_deg=rectangle,
                     status='PASS' if any(b['gap_lower_mm']>=.3 for b in bounds) else 'BLOCKED',frames=bounds)
            rows.append(row)
            print('CAM_REMAINING_HULL_DIAGNOSTIC',list(pair),rectangle,bounds,flush=True)
    e.unchanged()
    sources=dict(e.sources);sources[str(Path(__file__))]=sha(Path(__file__))
    (HERE/'remaining_hull_diagnostic.json').write_text(json.dumps(dict(
        status='PASS',scope='Selected rest/rest and fan/rest hull diagnostics; fan/fan and fixed-tail pairs omitted for separate proof; not full angular coverage',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,rows=rows,
        all_angle_peer='NOT_TESTED',main_changed=False,hardware_changed=False,manufacturing_release=False),indent=2)+'\n')


if __name__=='__main__':main()
