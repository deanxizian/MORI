"""Remote self separation of closed AABBs with conservative arc exclusions.

An entire pair is local only if the sum of its closed parameter-cell arc
upper bounds is <=5 mm. Other pairs are checked with complete AABB distances
or excluded by their enclosing centre spheres. Skipping duplicate unordered
pairs does not skip a distinct geometric pair.
"""
import numpy as np
from scipy.spatial import cKDTree


def score(lo,hi,arc_upper,radius,required=.3,numeric=.0001,chunk=128):
    lo,hi,arc_upper = [np.asarray(v,float) for v in [lo,hi,arc_upper]]
    assert lo.shape==hi.shape and np.all(lo<=hi)
    assert arc_upper.shape==(len(lo)+1,) and np.all(np.diff(arc_upper)>0)
    centers = (lo+hi)/2
    radii = np.linalg.norm((hi-lo)/2,axis=1)
    tree = cKDTree(centers)
    lower = required
    all_candidates = eligible_pairs = 0
    witness = None
    for start in range(0,len(lo),chunk):
        finish = min(start+chunk,len(lo))
        candidates = tree.query_ball_point(centers[start:finish],
            radii[start:finish]+float(radii.max())+2*radius+required+2*numeric,
            workers=1,return_sorted=False)
        counts = np.array([len(c) for c in candidates],dtype=np.int64)
        all_candidates+=int(counts.sum())
        ai = np.repeat(np.arange(start,finish),counts)
        bi = np.concatenate([np.asarray(c,dtype=np.int64) for c in candidates])
        keep = (bi>ai)&(arc_upper[bi+1]-arc_upper[ai]>5.)
        ai,bi = ai[keep],bi[keep]
        eligible_pairs+=len(ai)
        if not len(ai):
            continue
        delta = np.maximum(np.maximum(lo[bi]-hi[ai],lo[ai]-hi[bi]),0.)
        bounds = np.linalg.norm(delta,axis=1)-2*radius-numeric
        index = int(np.argmin(bounds))
        if bounds[index]<lower:
            lower = float(bounds[index])
            witness = dict(parameter_cells=[int(ai[index]),int(bi[index])],
                           enclosing_arc_upper_mm=float(arc_upper[bi[index]+1]-arc_upper[ai[index]]))
    return dict(status='PASS' if lower>=required else 'BLOCKED',gap_lower_mm=lower,
                sphere_candidate_pairs=all_candidates,remote_box_pairs_checked=eligible_pairs,
                witness=witness,local_arc_exclusion_upper_mm=5.,numeric_reserve_mm=numeric)
