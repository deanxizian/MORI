"""Publish the completed cross-group proof and complete seven-upper pair scope."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    audit = read(HERE/'cross_coverage_verification.json')
    combined = read(HERE/'complete_upper_mutual_verification.json')
    assert audit['status']==combined['status']=='PASS' and audit['mode']=='all_angles'
    assert audit['unordered_cross_pairs']==12 and combined['unordered_pairs']==21
    sources = audit['sources'] | combined['sources']
    for p in [Path(__file__),HERE/'cross_coverage_verification.json',
              HERE/'complete_upper_mutual_verification.json',HERE/'commands.json']:
        sources[str(p)] = sha(p)
    assert all(sha(p)==h for p,h in sources.items())
    table = ''.join(f"<tr><td>{r['wires'][0]} ↔ {r['wires'][1]}</td><td>{r['angular_rectangles']}</td><td>PASS</td></tr>" for r in audit['results'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 CAM与电源／CC跨组检查</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:36px auto;padding:0 22px;color:#243039}}table{{border-collapse:collapse;width:100%;font-size:14px}}th,td{{padding:9px;border:1px solid #ccd3d6;text-align:left}}a{{color:#20526c}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #6b767a}}</style>
<h1>CAM与电源／CC：12组跨组间隙检查</h1>
<p class="scope">PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED · 独立容量参考，尚未进入主模型或视频。完整线束 BLOCKED。</p>
<p>12组跨组间隙覆盖名义偏航 −60°～+60°、俯仰 −20°～+25°及完整闭曲线参数，PASS。独立核对{audit['angular_rectangles']:,}个角度区间；需要参数细分的223组三次段组合另有{audit['parameter_refinement_rectangles']:,}个二维参数区间，全部覆盖无遗漏。目标仍为0.3 mm。</p>
<table><thead><tr><th>配对</th><th>通过的角度区间</th><th>状态</th></tr></thead><tbody>{table}</tbody></table>
<p>完整三次控制包络在共同偏航／俯仰坐标系内比较，区间根范围来自已有完整数学分区的所有相交父区间。只有必要处重新收紧根范围；原曲线、打印件、硬件和接口均未移动。另有105个原构造姿态、210次完整控制包络实现核对。初版过宽试探窗口无法给出有效根包络的记录已保留；它不是碰撞结论。</p>
<p>结合此前6组CAM内部配对和3组电源／CC配对，7条已知上段的全部21组互线组合已完整核对通过。三个类别无重复或遗漏；0.3 mm为保守证明目标，不是实测最小线距。</p>
<p>剩余：上下段接续、电源／CC自身接近、5条缺真实端点的线路、实际材料／裁线、完整端接／夹持／应力释放、带线装入和闭壳。理想名义框架与线径容量参考不代表实际线材、插头、弯折寿命或制造放行；主模型、视频和846个硬件文件保持。</p>
<p><a href="cross_verification.json">跨组检查结果</a> · <a href="cross_coverage_verification.json">独立角度及参数覆盖</a> · <a href="complete_upper_mutual_verification.json">7条上段全部21组配对</a> · <a href="envelope_crosscheck.json">原曲线包络实现核对</a> · <a href="commands.json">实际命令</a> · <a href="../cam_peer_review_R1/index.html">6组CAM内部配对</a> · <a href="../power_peer_review_R1/index.html">3组电源／CC配对</a> · <a href="../index.html">上段研究总览</a></p></html>''')
    (HERE/'README.md').write_text('''# M1.55 CAM-power/CC cross-group review

All 12 nominal upper cross-group pairs PASS over yaw -60..60 and pitch
-20..25 degrees with full closed cubic parameters. Independent root-parent
union, angular and parameter coverage audit: PASS. Complete control boxes
have 105 independent original-construction poses / 210 frame comparisons.

Together with 6 CAM-CAM and 3 power-power pairs, the seven known nominal
uppers have all 21 mutual combinations covered, without duplicates or gaps.
The target remains 0.3 mm. Bounds are not physical measured minimum gaps.

Own-prefix joins, three power/CC remote-self checks, five unknown upper
endpoints, real materials/cut lengths/terminals/restraints, and full wired
assembly/shell closure remain unresolved. Full harness BLOCKED. No geometry,
hardware, main model or animation adoption; manufacturing_release=false.

The initial wide-window diagnostic stopped because a requested root range
was not certified. Its exact source and log are retained; no collision or
curve defect was inferred and no geometry/threshold was changed.
''')
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in ['delivery.json','publication_verification.json']}
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               sources=sources,files=files,CAM_power_cross_pairs='PASS',unordered_cross_pairs=12,
               cross_angular_rectangles=audit['angular_rectangles'],
               cross_parameter_refinement_rectangles=audit['parameter_refinement_rectangles'],
               known_upper_continuous_mutual='PASS',known_upper_references=7,known_upper_unordered_pairs=21,
               required_gap_mm=.3,minimum_certified_cross_gap_lower_mm=audit['minimum_certified_gap_lower_mm'],
               own_prefix='NOT_TESTED',power_remote_self='NOT_TESTED',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_POWER_CROSS_PUBLICATION_PASS',len(files),len(sources),12,21,flush=True)


if __name__ == '__main__':
    main()
