"""Verify nominal CAM published source/file/served-byte preservation."""
from pathlib import Path
import datetime,hashlib,json,re
from urllib.parse import urlsplit,unquote,quote
from urllib.request import urlopen
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    d=json.loads((HERE/'delivery.json').read_text())
    assert d['status']=='PASS' and d['continuous_nominal_CAM_root_and_bending']=='PASS' and d['full_harness']=='BLOCKED'
    assert d['saved_curve_readbacks']==1900 and d['positive_length_rectangles']==2592
    assert all(sha(p)==h for p,h in d['sources'].items())
    assert all(sha(HERE/p)==h for p,h in d['files'].items())
    archive=json.loads((HERE/'initial_tail_sum_error/source_archive_receipt.json').read_text())
    assert all(sha(r['archived'])==r['sha256'] for r in archive['files'])
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')==d['source_blend_sha256']
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')==d['source_video_sha256']
    links=[]
    for link in ['index.html']+re.findall(r'href="([^"]+)"',(HERE/'index.html').read_text()):
        parsed=urlsplit(link)
        if parsed.scheme or not parsed.path:continue
        p=(HERE/unquote(parsed.path)).resolve();assert p.is_file() and p.is_relative_to(PROJECT)
        url='http://127.0.0.1:58202/'+quote(str(p.relative_to(PROJECT)))
        with urlopen(url,timeout=10) as response:data=response.read()
        assert hashlib.sha256(data).hexdigest()==sha(p)
        links.append(str(p.relative_to(PROJECT)))
    result=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                delivery_sha256=sha(HERE/'delivery.json'),files_checked=len(d['files']),sources_checked=len(d['sources']),
                served_links=links,served_bytes_equal=True,main_changed=False,hardware_changed=False,animation_changed=False,
                full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
    (HERE/'publication_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('NOMINAL_CAM_PUBLICATION_VERIFIED',len(d['files']),len(d['sources']),len(links),flush=True)


if __name__=='__main__':main()
