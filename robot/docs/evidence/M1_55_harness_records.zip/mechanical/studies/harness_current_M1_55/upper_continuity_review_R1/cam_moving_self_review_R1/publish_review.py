"""Publish the independently audited four-CAM-upper remote-self scope."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    path = HERE/'combined_self_verification.json'
    audit_path = HERE/'combined_self_coverage_verification.json'
    proof, audit = read(path), read(audit_path)
    assert proof['status'] == audit['status'] == 'PASS'
    assert audit['continuous_nominal_CAM_upper_remote_self'] == 'PASS' and audit['references'] == 4
    sources = proof['sources'] | audit['sources']
    for p in [Path(__file__), path, audit_path, HERE/'commands.json']:
        sources[str(p)] = sha(p)
    assert all(sha(p) == h for p, h in sources.items())
    table = ''.join(f"<tr><td>{r['wire']}</td><td>{r['cubic_pieces']}</td><td>PASS</td></tr>" for r in audit['results'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 CAM 上段自身接近检查</title>
<style>body{{font:16px/1.65 system-ui,sans-serif;max-width:940px;margin:40px auto;padding:0 22px;color:#243039}}table{{border-collapse:collapse;width:100%}}th,td{{padding:10px;border:1px solid #ccd3d6;text-align:left}}a{{color:#20526c}}.scope{{padding:16px;background:#f3f4f2;border-left:4px solid #6b767a}}</style>
<h1>四条 CAM 上段：完整自身接近检查</h1>
<p class="scope">PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED · 独立容量参考，尚未进入主模型或视频。完整线束 BLOCKED。</p>
<p>四条名义 CAM 上段的非局部自身间隙检查 PASS，覆盖偏航 −60°～+60°、俯仰 −20°～+25°及全部闭曲线参数。扇出、余量圈、活动接续和固定尾线均纳入；同一条线与身体前段的接续另列，仍未完成。</p>
<table><thead><tr><th>参考线路</th><th>完整三次段数量</th><th>上段非局部自身间隙</th></tr></thead><tbody>{table}</tbody></table>
<p>三类不重叠的完整组合独立枚举：扇出自身覆盖48个偏航区间，其他活动组合覆盖2,592个二维角度区间，固定尾线覆盖64,000个闭参数区间。需要细分的组合另经{audit['parameter_refinement_rectangles']:,}个完整二维参数区间核对。源依赖审查支持扇出对俯仰独立，尾线在理想俯仰坐标系内固定。</p>
<p>仅在整个参数区间的弧长上界≤5 mm时排除局部相邻段；其余组合达到原0.3 mm保守间隙目标。弧长上界使用导数控制包络，局部曲率另有全角度R6.9342 mm要求检查。数值保守下界不是实测最小距离，理想名义旋转不等于原浮点助手全范围舍入或实际线材寿命资格。</p>
<p>仍未完成：CAM与电源／CC的12组配对、上下段接续、电源／CC自身接近、五条缺真实端点的线路、材料／裁线、端接／应力释放、完整带线装入及闭壳。主模型、视频和846个硬件工程文件保持；manufacturing_release=false。</p>
<p><a href="combined_self_verification.json">合并检查结果</a> · <a href="combined_self_coverage_verification.json">独立完整分类核对</a> · <a href="fan_coverage_verification.json">扇出覆盖</a> · <a href="mixed_coverage_verification.json">活动组合覆盖</a> · <a href="arc_bound_crosscheck.json">弧长上界实现核对</a> · <a href="commands.json">实际命令</a> · <a href="../cam_self_review_R1/index.html">固定尾线证据</a> · <a href="../index.html">上段研究总览</a></p></html>''')
    (HERE/'README.md').write_text('''# M1.55 complete nominal CAM upper remote-self review

Four nominal CAM uppers: PASS over yaw -60..60 and pitch -20..25 degrees,
with complete closed curve-parameter coverage. Three exhaustive disjoint
unordered piece categories compose the result: fan/fan (48 yaw rows), fixed
tail/tail (64,000 closed cells), and all remaining products (2,592 angular
rows). Independent category enumeration and source guards: PASS.

Remote-self excludes only entire parameter rectangles whose conservative
arc upper is <=5 mm. The separate full-angle curvature evidence is guarded
against R6.9342 mm. The distance target stays 0.3 mm; it is not a measured
minimum. Ideal nominal frames and unselected wire allocations are retained.

Own body-prefix joins, 12 CAM-power/CC pairs, three power remote-self proofs,
five missing upper endpoints, actual materials/cut lengths/connectors,
strain relief and complete wired assembly/shell closure remain unresolved.
Full harness BLOCKED; no main model, hardware or animation adoption;
manufacturing_release=false. Commands and terminal logs are retained.
''')
    files = {str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in ['delivery.json', 'publication_verification.json']}
    out = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               sources=sources, files=files, continuous_nominal_CAM_upper_remote_self='PASS',
               references=4, fan_angular_rectangles=48, mixed_angular_rectangles=2592,
               parameter_refinement_rectangles=audit['parameter_refinement_rectangles'],
               fixed_tail_closed_parameter_cells=64000, required_gap_mm=.3,
               local_arc_exclusion_upper_mm=5., own_prefix='NOT_TESTED', CAM_power_cross_pairs='NOT_TESTED',
               full_harness='BLOCKED', main_changed=False, hardware_changed=False,
               animation_changed=False, manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(out, indent=2)+'\n')
    print('CAM_UPPER_SELF_PUBLICATION_PASS', len(files), len(sources), flush=True)


if __name__ == '__main__':
    main()
