"""Publish verified nominal CAM progress with complete remaining boundaries."""
from pathlib import Path
import datetime,hashlib,json
HERE=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    proof=read(HERE/'nominal_math_verification.json');audit=read(HERE/'nominal_math_readback.json')
    grid=read(HERE/'nominal_half_grid_verification.json');pilot=read(HERE/'nominal_pilot_verification.json')
    precision=read(HERE/'precision_frame_diagnostic.json');diagnosis=read(HERE/'small_angles_direct_derivative.json')
    assert proof['status']==audit['status']==grid['status']==pilot['status']==precision['status']=='PASS'
    assert diagnosis['status']=='BLOCKED' and len(diagnosis['failures'])==76
    assert audit['saved_curve_readbacks']==1900 and audit['positive_length_rectangles']==2592
    assert audit['bending_yaw_intervals']==48 and audit['minimum_positive_height_lower_mm']>=.5
    sources={}
    for report in [proof,audit,grid,pilot,precision,diagnosis]:
        for p,h in report['sources'].items():
            assert sha(p)==h,(p,h)
            assert p not in sources or sources[p]==h
            sources[p]=h
    summaries=[]
    for name in ['CAM_1','CAM_2','CAM_3','CAM_4']:
        lengths=[r for r in proof['length_rectangles'] if r['wire']==name]
        bends=[r for r in proof['bending_intervals'] if r['wire']==name]
        summaries.append(dict(wire=name,positive_length_rectangles=len(lengths),bending_yaw_intervals=len(bends),
            radius_lower_mm=min(proof['circle_minimum_radius_lower_mm'],proof['tail_bending'][name]['radius_lower_mm'],min(r['radius_lower_mm'] for r in bends)),
            height_lower_mm=min(r['height_lower_mm'] for r in lengths),return_lower_mm=min(r['return_lower_mm'] for r in lengths)))
    table=''.join(f"<tr><td>{r['wire']}</td><td>{r['positive_length_rectangles']}</td><td>{r['radius_lower_mm']:.6f}</td><td>{r['height_lower_mm']:.6f}</td><td>PASS</td></tr>" for r in summaries)
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 CAM连续数学参考</title><style>body{{font:16px/1.7 system-ui;max-width:1040px;margin:32px auto;padding:0 22px;color:#243641;background:#f5f7f8}}section{{background:white;padding:22px;border:1px solid #d7e0e5;border-radius:9px;margin:22px 0}}table{{width:100%;border-collapse:collapse;font-size:14px}}td,th{{text-align:left;border:1px solid #d7e0e5;padding:10px}}a{{color:#176793}}.status{{color:#945c11;font-weight:700}}</style>
<p><a href="../index.html">上段研究</a> · <a href="../../index.html">线束研究总页</a></p><h1>CAM四根参考：连续长度与弯折</h1>
<p class="status">PLACEHOLDER / ASSUMED · 未采用 · 完整线束BLOCKED</p>
<section><h2>已经完成</h2><p>四条上部容量参考覆盖全偏航−60°～+60°、俯仰−20°～+25°。
48个偏航区间单独包住身体接续处；圆弧三次段使用整段速度／曲率解析界；固定头内尾段单独复核。
2,592个二维区间证明补偿段与回程直段均不少于原0.5mm要求，完整Gauss64参考长度对补偿高度的斜率为2，长度分支唯一。
弯折最小下界约{proof['circle_minimum_radius_lower_mm']:.6f}mm，沿用参考要求6.9342mm。</p>
<table><tr><th>参考线</th><th>长度二维区间</th><th>弯折下界 mm</th><th>补偿高度下界 mm</th><th>数学检查</th></tr>{table}</table>
<p>独立核对完整角度覆盖、1,900条保存曲线的长度／导数／高度回读，846个硬件文件及主模型／视频保持。
475个组合姿态与原保存参考的2,049个参数点另行对照，最大差约{audit['maximum_saved_parameter_sample_difference_mm']:.8f}mm；这是有限参数采样，不是整段差值证明。
身体首端点逐位保持；硬件零位、原风格的扇出／余量圈／头内尾线布局保持。</p></section>
<section><h2>数值构造为什么需要修正</h2><p>更细的原构造检查共276条，76条未通过。
60位高精度对照发现：仅提高坐标精度仍会被原来分别插值的偏航／俯仰／组合变换影响，末端修正会放大极小圆弧的弯折误差。
一致的理想名义Rz(yaw)Rx(pitch)对照消除了这处非组合误差。新参考采用80位构造，并固定可变圆弧的分段数，保持连续几何；没有改变主模型、硬件或打印件。</p>
<p>原失败及诊断全部保留。新结果针对名义连续几何，不证明原Float32／Float64助手的任意角度舍入，也不证明实际线材的动态寿命。</p></section>
<section><h2>还要继续完成</h2><p>新CAM参考的全范围实体、互线、自身接近与完整前段接续间隙尚未闭合。
旧475姿态的间隙结果不直接继承；真实混合线材、接头、固定、裁线图、带线装头和闭壳仍待完成。
三条舵机线与两条喇叭参考还缺实发端点；CAM供电源端待硬件正式交接。</p>
<p>主模型仍M1.55，视频仍M1.55-A1；manufacturing_release=false。</p></section>
<section><h2>可回读证据</h2><p><a href="nominal_math_verification.json">全角度数学区间</a> · <a href="nominal_math_readback.json">独立覆盖与曲线回读</a> ·
<a href="nominal_half_grid_verification.json">475姿态／1,900条参考</a> · <a href="precision_frame_diagnostic.json">高精度框架对照</a> ·
<a href="small_angles_direct_derivative.json">原276条诊断</a> · <a href="commands.json">实际命令与版本</a> · <a href="README.md">范围与复现</a></p></section></html>'''
    native_path=HERE.parent/'cam_native_clearance_review_R1/delivery.json'
    native_verified_path=native_path.parent/'publication_verification.json'
    native=read(native_path);native_verified=read(native_verified_path)
    assert native['status']==native_verified['status']=='PASS'
    assert native['continuous_nominal_CAM_native_clearance']=='PASS'
    assert native_verified['delivery_sha256']==sha(native_path)
    peer_path=HERE.parent/'cam_peer_review_R1/delivery.json'
    peer_verified_path=peer_path.parent/'publication_verification.json'
    peer=read(peer_path);peer_verified=read(peer_verified_path)
    assert peer['status']==peer_verified['status']==peer['continuous_nominal_CAM_mutual']=='PASS'
    assert peer_verified['delivery_sha256']==sha(peer_path) and peer['unordered_pairs']==6
    page=page.replace('新CAM参考的全范围实体、互线、自身接近与完整前段接续间隙尚未闭合。',
        '新CAM参考的全范围实体间隙随后由独立检查完成，<a href="../cam_native_clearance_review_R1/index.html">完整实体间隙与覆盖结果</a>通过原0.3mm目标。四条CAM上段的6组内部互线随后由<a href="../cam_peer_review_R1/index.html">完整配对及分类核对</a>通过；CAM与电源／CC的跨组配对、活动段自身接近与完整前段接续尚未闭合。')
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# CAM连续数学参考：未采用

保持当前身体前段、硬件零位和原扇出／余量圈／头内尾线布局；用一致的名义刚体框架、80位构造和固定的可变圆弧分段修正数值表示。
原分别插值框架、绝对坐标细分及浮点微弧诊断保留。没有修改原源文件、打印件、PCB、主模型或动画。

四条参考的全名义偏航／俯仰弯折与正长度分支通过：48个身体接续偏航区间，2,592个长度二维区间。
圆弧模板角宽≤0.1rad，弯折解析下界≥6.947612mm；两个高度相关的直段均≥0.5mm，因此Gauss64数值参考长度对高度严格线性、斜率2。
固定头内尾段及身体接续三次段另行包住，不仅凭名义圆半径放行。

475个有限姿态／1,900条保存曲线另检；独立回读长度、导数、高度和角度覆盖。
预览位置为Float64，精确构造导数另存，极小圆弧的几何判断不依赖相减后的绝对预览坐标。
与原参考的有限2,049参数点对照不是全段差值证明。原Float32／Float64框架助手全角度舍入未资格化。

新参考的全范围实体间隙随后由[独立实体检查](../cam_native_clearance_review_R1/index.html)通过原0.3mm目标。
本报告自身仍只覆盖数学；其native_clearance=NOT_TESTED是数学执行范围，后续实体证明单独链接。
四条CAM上段的6组内部配对随后由[独立完整互线检查](../cam_peer_review_R1/index.html)通过原0.3mm目标。
本报告peer_clearance=NOT_TESTED仍指数学执行范围；后续配对证明单独链接。
与电源／CC的跨组配对、活动段自身／前段接续、实际材料与端点、应力释放、裁线图、带线装头和闭壳仍未闭合。
PLACEHOLDER / ASSUMED；主模型M1.55、视频M1.55-A1与硬件源保持；manufacturing_release=false。

执行命令、Python／NumPy／SciPy／mpmath版本见 commands.json。
初次数学脚本在求尾段总长时发生标量转换错误，没有执行完整证明；确切脚本和日志保留在 initial_tail_sum_error/，后续正确执行结果单独记录。
''')
    for path in [Path(__file__),HERE/'commands.json',HERE/'nominal_math_verification.json',HERE/'nominal_math_readback.json',HERE/'nominal_half_grid_verification.json',HERE/'precision_frame_diagnostic.json']:
        sources[str(path)]=sha(path)
    sources[str(native_path)]=sha(native_path);sources[str(native_verified_path)]=sha(native_verified_path)
    sources[str(peer_path)]=sha(peer_path);sources[str(peer_verified_path)]=sha(peer_verified_path)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json']}
    receipt=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        scope='Publication of four precision-safe nominal CAM mathematics only; no native/peer or physical wiring release',
        source_blend_sha256=audit['source_blend_sha256'],source_video_sha256=audit['source_video_sha256'],summaries=summaries,
        continuous_nominal_CAM_root_and_bending='PASS',bending_yaw_intervals=48,positive_length_rectangles=2592,
        saved_curve_readbacks=1900,pilot_curve_checks=144,native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        native_status_scope='The mathematical report itself; a separate subsequent complete native proof is linked',
        subsequent_native_clearance='PASS',subsequent_native_delivery_sha256=sha(native_path),
        peer_status_scope='The mathematical report itself; a separate subsequent four-CAM complete mutual proof is linked',
        subsequent_peer_clearance='PASS',subsequent_peer_delivery_sha256=sha(peer_path),
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',classification='PLACEHOLDER',evidence='ASSUMED',
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('NOMINAL_CAM_PUBLISHED',len(files),len(sources),1900,2592,flush=True)


if __name__=='__main__':main()
