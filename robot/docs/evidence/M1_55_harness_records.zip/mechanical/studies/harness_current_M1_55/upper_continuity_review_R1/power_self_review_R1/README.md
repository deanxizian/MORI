# M1.55 power/CC upper remote-self review

Three unchanged nominal power/CC uppers PASS over yaw -60..60 and pitch
-20..25 degrees with complete closed parameters. Each reference has 129
cubic pieces and 8,385 unordered piece pairs. Independent coverage/root
union audit: PASS,418 angular rectangles / 39,687 parameter rectangles.

Local exclusions require a complete <=5 mm arc upper including numerical
join reserves. Other pairs preserve the original 0.3 mm gap target. The
separate all-angle radius requirements remain R5.842 mm (power) and R3.683
mm (CC). Independent source velocity/join probes:45 poses / 17,415 derivative
control vectors. These probes are implementation evidence, not full coverage.

Together with four CAM uppers, all seven known nominal upper remote-self
scopes are now covered. Their 21 mutual combinations are separately covered.
Own body-prefix joins, five missing upper endpoints, actual materials/cut
lengths/terminals/restraints, and full wired assembly/closure remain pending.
Full harness BLOCKED; no main/animation/hardware change or manufacturing
release. Initial local import-path failure is retained separately.
