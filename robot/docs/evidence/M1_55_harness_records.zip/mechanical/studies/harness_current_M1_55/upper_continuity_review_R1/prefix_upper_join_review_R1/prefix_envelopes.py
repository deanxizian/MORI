"""Complete cubic/control-speed covers of the unchanged 12 R3 body prefixes.

The actual 48-control family and its existing complete Gauss64 root partition
are reused. Every B-spline knot span has a fixed four-control Bezier operator.
Taylor bounds act on those operators before taking boxes, retaining coherent
control differences for derivative rows. A common ideal yaw frame replaces
each fixed frame weight w by w-1; its derivative bounds use abs(w-1).
No route, radius allocation, endpoint, hardware or printed solid is changed.
"""
from pathlib import Path
import json
import math
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FRAME = ROOT.parent/'prefix_continuity/frame_family_R3'
sys.path[:0] = [str(ROOT/'cam_power_cross_review_R1'),str(FRAME)]
from cross_envelopes import CrossEnvelopes,Box,sha
from frame_family import rotate,omega,BSpline
from frame_motion_bounds import extrema
from family import smooth_d,smooth_dd
from power_native_envelopes import rotate_box

NUMERIC = 1e-8


class PrefixEnvelopes:
    def __init__(self,cross):
        self.cross = cross
        self.f = cross.power.e.f.ctx.f
        other = cross.cam.f.ctx.f
        assert np.array_equal(self.f.knots,other.knots)
        assert self.f.names==other.names
        assert self.f.radii==other.radii
        for n in self.f.names:
            assert self.f.targets[n]==other.targets[n]
            assert np.array_equal(self.f.frame_weights[n],other.frame_weights[n])
            for y in range(-60,61,10):
                assert np.array_equal(self.f.local_controls[y][n],other.local_controls[y][n])
                assert np.array_equal(self.f.local_directions[y][n],other.local_directions[y][n])
        assert np.array_equal(cross.power.center[:2],np.zeros(2))
        proof_path = FRAME/'continuous_root_inspection.json'
        bending_path = FRAME/'continuous_bend_inspection.json'
        proof = json.loads(proof_path.read_text())
        bend = json.loads(bending_path.read_text())
        assert proof['status']==bend['status']=='PASS' and proof['wire_count']==bend['wire_count']==12
        assert bend['required_radius_mm']==6.865
        assert all(sha(p)==h for r in [proof,bend] for p,h in r['sources'].items())
        self.parents = proof['certificates']
        self.parent_bounds = np.array([r['yaw_interval_deg'] for r in self.parents])
        self.by_wire = [{r['wire']:r for r in p['certificates']} for p in self.parents]
        assert all(set(p)==set(self.f.names) for p in self.by_wire)
        value = BSpline(self.f.knots,np.eye(48),3)
        derivative = value.derivative()
        edges = np.unique(self.f.knots)
        operators = []
        for a,b in zip(edges[:-1],edges[1:]):
            h = (b-a)/3
            operators.append(np.stack([value(a),value(a)+h*derivative(a),value(b)-h*derivative(b),value(b)]))
        self.M = np.array(operators)
        self.edges = edges
        assert self.M.shape==(45,4,48)
        assert np.max(abs(self.M.sum(-1)-1))<1e-12 and self.M.min()>-1e-12
        assert np.array_equal(self.M[:-1,-1],self.M[1:,0])
        self.V = 3*np.diff(self.M,axis=1)
        self.sources = dict(self.f.sources)
        for p in [Path(__file__),proof_path,bending_path,FRAME/'frame_family.py',
                  FRAME/'frame_motion_bounds.py',FRAME.parent/'root_direction_R2/root_motion_bounds.py']:
            self.sources[str(p)] = sha(p)

    def certificate(self,name,lo,hi):
        ids = np.flatnonzero((self.parent_bounds[:,0]<hi)&(self.parent_bounds[:,1]>lo))
        assert len(ids)
        rows = [self.by_wire[int(i)][name] for i in ids]
        assert all(r['status']=='PASS' for r in rows)
        low = min(r['midpoint_amplitude_mm']-r['amplitude_deviation_bound_mm'] for r in rows)
        high = max(r['midpoint_amplitude_mm']+r['amplitude_deviation_bound_mm'] for r in rows)
        mid = (lo+hi)/2
        it = self.f.candidate(name,mid)
        a0 = it['amplitude_mm']
        width = max(abs(low-a0),abs(high-a0))+NUMERIC
        return dict(status='PASS',wire=name,yaw_interval_deg=[lo,hi],midpoint_yaw_deg=mid,
                    midpoint_amplitude_mm=a0,amplitude_deviation_bound_mm=width,
                    parent_indices=[int(i) for i in ids],method='guarded_body_parent_union')

    def frame_data(self,name,lo,hi,certificate,group):
        assert group in ['body','yaw']
        mid = (lo+hi)/2
        it = self.f.candidate(name,mid)
        a0 = certificate['midpoint_amplitude_mm']
        assert a0==it['amplitude_mm']
        c,cy,cyy,d,dy,dyy = it['base']
        actual = it['control']
        first = cy+a0*dy
        if group=='yaw':
            first = rotate(first-omega(actual,np.ones(48)),np.full(48,-mid))
            actual = rotate(actual,np.full(48,-mid))
            d = rotate(d,np.full(48,-mid))
        ka,kb,_ = self.f.segment(mid)
        assert ka<=lo<=hi<=kb
        ulo,uhi = (lo-ka)/10,(hi-ka)/10
        sd = extrema(smooth_d,ulo,uhi,[.5])/10
        sdd = extrema(smooth_dd,ulo,uhi,[(3-math.sqrt(3))/6,(3+math.sqrt(3))/6])/100
        weights = self.f.frame_weights[name]-(1. if group=='yaw' else 0.)
        rate = np.abs(weights)*math.pi/180
        def derivatives(a,b):
            delta = b-a
            xy = np.maximum(np.linalg.norm(a[:,:2],axis=1),np.linalg.norm(b[:,:2],axis=1))
            first_upper = sd*np.linalg.norm(delta,axis=1)+rate*xy+NUMERIC
            second_upper = (sdd*np.linalg.norm(delta,axis=1)
                            +2*rate*sd*np.linalg.norm(delta[:,:2],axis=1)+rate**2*xy+NUMERIC)
            return first_upper,second_upper
        _,C2 = derivatives(self.f.local_controls[ka][name],self.f.local_controls[kb][name])
        D1,D2 = derivatives(self.f.local_directions[ka][name],self.f.local_directions[kb][name])
        return actual,first,C2+abs(a0)*D2,d,D1

    def mapped(self,name,rectangle,certificate,operator,group):
        yl,yh,pl,ph = rectangle
        operator = np.asarray(operator).reshape(-1,48)
        actual,first,second,d,D1 = self.frame_data(name,yl,yh,certificate,group)
        h = (yh-yl)/2
        width = certificate['amplitude_deviation_bound_mm']
        centre = operator@actual
        radius = (h*np.linalg.norm(operator@first,axis=1)+.5*h*h*(abs(operator)@second)
                  +width*(np.linalg.norm(operator@d,axis=1)+h*(abs(operator)@D1))+NUMERIC)
        return centre,radius

    def controls(self,name,rectangle,certificate,group):
        base_group = 'yaw' if group=='pitch' else group
        centre,radius = self.mapped(name,rectangle,certificate,self.M,base_group)
        box = Box(centre-radius[:,None],centre+radius[:,None])
        if group=='pitch':
            yl,yh,pl,ph = rectangle
            box = rotate_box(box-self.cross.power.center,-ph,-pl,'X')+self.cross.power.center
        return Box(box.lo.reshape(45,4,3),box.hi.reshape(45,4,3))

    def speeds(self,name,rectangle,certificate):
        bounds = []
        for group in ['body','yaw']:
            centre,radius = self.mapped(name,rectangle,certificate,self.V,group)
            bounds.append((np.linalg.norm(centre,axis=1)+radius).reshape(45,3).max(1)+NUMERIC)
        result = np.minimum(*bounds)
        assert np.all(result>0)
        return result

    def unchanged(self):
        self.f.unchanged()
        assert all(sha(p)==h for p,h in self.sources.items())
