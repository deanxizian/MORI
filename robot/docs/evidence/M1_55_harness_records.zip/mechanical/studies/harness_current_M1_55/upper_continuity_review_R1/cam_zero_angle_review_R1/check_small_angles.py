"""Check the existing CAM construction at very small nonzero pitch angles.

All native geometry and vendor poses remain unchanged. This is a numerical
construction diagnostic, not a physical cable or supplier length test.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PARENT=MATH.parent
sys.path[:0]=['/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',str(PARENT/'upper_motion_family_R1')]
from cam_family import CAMFamily,NAMES,sha


def main():
    started=time.time();family=CAMFamily();rows=[];failures=[]
    poses=[(0.,p) for p in [0.,-.1,.1,-1e-3,1e-3,-1e-5,1e-5,-1e-7,1e-7,-1e-8,1e-8,-1e-9,1e-9]]
    for y,p in poses:
        for name in NAMES:
            try:
                curve,info=family.upper(name,y,p)
                row=dict(wire=name,pose_deg=[y,p],curve_pieces=None if curve is None else len(curve),**info)
            except Exception as error:
                row=dict(wire=name,pose_deg=[y,p],status='BLOCKED',reason='Construction exception',
                    exception_type=type(error).__name__,exception=str(error))
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
        print('CAM_SMALL_PITCH',y,p,len(rows),len(failures),flush=True)
    family.ctx.record([Path(__file__),PARENT/'upper_motion_family_R1/cam_family.py']);family.unchanged()
    out=dict(status='PASS' if not failures else 'BLOCKED',
        scope='Existing CAM reference construction at a finite set of very small pitch angles; no native or all-angle clearance claim',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=family.sources,
        planned_poses=poses,curve_pose_checks=len(rows),rows=rows,failures=failures,
        continuous_CAM_curve_math='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
        physical_cable_bending='NOT_TESTED',full_harness='BLOCKED',main_changed=False,
        animation_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'small_angle_inspection.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_SMALL_PITCH_TERMINAL',out['status'],len(rows),len(failures),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
