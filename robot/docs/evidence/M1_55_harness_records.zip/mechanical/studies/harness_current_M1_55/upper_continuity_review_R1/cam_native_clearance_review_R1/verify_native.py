"""Independent full CAM parent/refinement coverage and immutable-source audit."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
CAM=HERE.parent/'cam_math_review_R1'
PROJECT=HERE.parents[4]
NAMES=[f'CAM_{i}' for i in range(1,5)]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def coverage(boxes,base):
    base=tuple(base)
    assert boxes and all(base[0]<=b[0]<b[1]<=base[1] and base[2]<=b[2]<b[3]<=base[3] for b in boxes)
    edges=sorted({x for b in boxes for x in b[:2]})
    assert (edges[0],edges[-1])==base[:2]
    for a,b in zip(edges[:-1],edges[1:]):
        middle=(a+b)/2
        strips=sorted(tuple(r[2:]) for r in boxes if r[0]<middle<r[1])
        assert strips and strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(left[1]==right[0] for left,right in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    pilot='--pilot' in sys.argv
    proof_path=HERE/('pilot_native_adaptive_verification.json' if pilot else 'native_verification.json')
    proof=read(proof_path)
    assert proof['status']=='PASS' and proof['mode']==('pilot' if pilot else 'all_angles')
    assert proof['native_parts']==201 and proof['names']==NAMES and proof['required_gap_mm']==.3
    assert proof['native_frame']=='Ideal nominal Rz(yaw)Rx(pitch) about current head centre'
    assert proof['source_float32_all_angle_rounding']=='NOT_TESTED'
    assert not proof['failures'] and not any(proof[k] for k in ['main_changed','hardware_changed','animation_changed','manufacturing_release'])
    assert all(sha(p)==h for p,h in proof['sources'].items())
    cross=read(HERE/'envelope_crosscheck.json')
    assert cross['status']=='PASS' and cross['mode']=='full_crosscheck'
    assert cross['parameter_cells_per_reference']==proof['parameter_cells_per_reference']
    assert cross['canonical_pieces_per_reference']==proof['canonical_pieces_per_reference']
    assert cross['direct_source_pose_comparisons']==72 and cross['tiny_angle_source_comparisons']==56
    assert all(sha(p)==h for p,h in cross['sources'].items())
    math=read(CAM/'nominal_math_verification.json');assert math['status']=='PASS'
    parents={n:[r['rectangle_deg'] for r in math['length_rectangles'] if r['wire']==n] for n in NAMES}
    minimum=float('inf');conditional=float('inf');total=slabs=base_total=0;counts=[];methods=set()
    assert len(proof['results'])==4
    for result,name in zip(proof['results'],NAMES):
        assert result['wire']==name and result['status']=='PASS'
        indices=result['source_math_parent_indices']
        assert len(indices)==len(set(indices))==result['planned_math_rectangles']
        assert all(0<=i<len(parents[name]) for i in indices)
        if not pilot:
            assert indices==list(range(len(parents[name])))
            coverage(parents[name],[-60,60,-20,25])
        rows={i:[] for i in indices}
        assert result['accepted_rectangles']==len(result['intervals'])
        for leaf in result['intervals']:
            i=leaf['source_math_parent_index']
            assert i in rows and leaf['source_math_rectangle_deg']==parents[name][i] and leaf['status']=='PASS'
            rows[i].append(leaf['rectangle_deg'])
            assert len(leaf['rows'])==4 and {r['group'] for r in leaf['rows']}=={'body','yaw','pitch','USB_conditional'}
            for item in leaf['rows']:
                assert item['gap_lower_mm']>=.3
                methods.add(item['method'])
                if item['method']=='complete_cubic_control_AABB_separation':
                    assert item['whole_parameter_cell_motion_bound_mm'] is None and item['reference_pose_deg'] is None
                    assert 0<=item['curve_piece']<proof['canonical_pieces_per_reference'][name]
                else:
                    assert item['method']=='closed_parameter_cell_BVH_distance_and_motion_ball'
                    assert item['whole_parameter_cell_motion_bound_mm']>=0
                    piece,a,b=item['curve_piece_and_parameter_interval']
                    assert piece==int(piece) and 0<=piece<proof['canonical_pieces_per_reference'][name] and 0<=a<b<=1
                if item['group']=='USB_conditional':conditional=min(conditional,item['gap_lower_mm'])
                else:minimum=min(minimum,item['gap_lower_mm'])
        for i,boxes in rows.items():slabs+=coverage(boxes,parents[name][i])
        total+=len(result['intervals']);base_total+=len(indices)
        counts.append(dict(wire=name,source_parents=len(indices),accepted_rectangles=len(result['intervals'])))
    assert minimum==proof['minimum_certified_native_gap_lower_mm']
    assert conditional==proof['minimum_conditional_USB_gap_lower_mm']
    raw_path=Path(proof['core_report_path']);assert sha(raw_path)==proof['core_report_sha256']
    raw=read(raw_path)
    assert raw['results']==proof['results'] and raw['BVH_distance_queries']==proof['BVH_distance_queries']
    assert proof['byte_identical_tail_cache']['actual_BVH_distance_queries']==proof['BVH_distance_queries']
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    blend=PROJECT/'mechanical/mori_v1_2.blend';video=PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(blend)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources=dict(proof['sources'])
    for p in [Path(__file__),proof_path,HERE/'envelope_crosscheck.json',CAM/'nominal_math_verification.json']:
        sources[str(p)]=sha(p)
    out=dict(status='PASS',mode=proof['mode'],recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Independent four CAM native source/refinement coverage and preservation audit; not physical wiring qualification',
             sources=sources,source_math_rectangles=base_total,accepted_rectangles=total,independent_y_slab_checks=slabs,
             per_wire=counts,native_parts=201,required_gap_mm=.3,minimum_certified_native_gap_lower_mm=minimum,
             minimum_conditional_USB_gap_lower_mm=conditional,methods=sorted(methods),
             canonical_zero_angle_slots=proof['canonical_zero_angle_slots'],parameter_cells_per_reference=proof['parameter_cells_per_reference'],
             source_blend_sha256=sha(blend),source_video_sha256=sha(video),protected_hardware_files=846,
             peer_clearance='NOT_TESTED',remote_self='NOT_TESTED',actual_material_and_endpoints='BLOCKED',full_harness='BLOCKED',
             main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/('pilot_native_coverage_verification.json' if pilot else 'native_coverage_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_NATIVE_COVERAGE_PASS',out['mode'],base_total,total,slabs,846,flush=True)


if __name__=='__main__':
    main()
