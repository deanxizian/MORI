"""Independent complete angular coverage/source audit for mixed/loop pairs.

No proof-generator import. The guarded kernel checks entire cubic hull pairs
in ideal yaw/pitch frames. This audit verifies the exact mathematical domain
and six pairs and preserves the explicit fan/fan and fixed-tail exclusions.
It is not a second execution of the distance matrices or a full-CAM release.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
NAMES=['CAM_1','CAM_2','CAM_3','CAM_4']


def coverage(boxes):
    assert all(-60<=b[0]<b[1]<=60 and -20<=b[2]<b[3]<=25 for b in boxes)
    edges=sorted({v for b in boxes for v in b[:2]})
    assert edges[0]==-60 and edges[-1]==60
    for a,b in zip(edges[:-1],edges[1:]):
        y=(a+b)/2
        strips=sorted(r[2:] for r in boxes if r[0]<y<r[1])
        assert strips[0][0]==-20 and strips[-1][1]==25
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    path=HERE/'remaining_hull_verification.json'
    proof=read(path)
    assert proof['status']==proof['rest_and_mixed_piece_pairs']=='PASS'
    assert proof['complete_CAM_mutual']==proof['fan_fan_full_yaw']=='NOT_TESTED'
    assert proof['full_harness']=='BLOCKED' and proof['required_gap_mm']==.3
    assert all(sha(p)==h for p,h in proof['sources'].items())
    math_path=HERE.parent/'cam_math_review_R1/nominal_math_verification.json'
    math=read(math_path)
    assert math['status']=='PASS' and all(sha(p)==h for p,h in math['sources'].items())
    parents={n:[tuple(r['rectangle_deg']) for r in math['length_rectangles'] if r['wire']==n] for n in NAMES}
    assert all(parents[n]==parents[NAMES[0]] for n in NAMES)
    assert len(parents[NAMES[0]])==proof['source_math_parent_rectangles']==648
    slabs=coverage(parents[NAMES[0]])
    expected=list(itertools.combinations(NAMES,2))
    assert len(proof['rows'])==3888
    for i,rectangle in enumerate(parents[NAMES[0]]):
        rows=proof['rows'][i*6:(i+1)*6]
        assert [tuple(r['wires']) for r in rows]==expected
        for row in rows:
            assert row['status']=='PASS' and row['source_math_parent_index']==i
            assert tuple(row['rectangle_deg'])==rectangle
            assert row['combined_frame_gap_lower_mm']>=.3
            assert [r['group'] for r in row['frames']]==['yaw','pitch']
            assert row['combined_frame_gap_lower_mm']>=max(r['gap_lower_mm'] for r in row['frames'])
            assert all(r['unresolved_piece_pairs']>=0 for r in row['frames'])
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items()
               if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources=dict(proof['sources'])
    for p in [Path(__file__),path,math_path]:sources[str(p)]=sha(p)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Independent full mathematical angular partition and six mixed/loop pair covers, with guarded complete-cubic hull kernel',
        sources=sources,source_math_parent_rectangles=648,pair_angular_rows=3888,
        independent_y_slab_checks=slabs,required_gap_mm=.3,
        minimum_certified_gap_lower_mm=min(r['combined_frame_gap_lower_mm'] for r in proof['rows']),
        rest_and_mixed_piece_pairs='PASS',excluded_piece_categories=['fan/fan','fixed_tail/fixed_tail'],
        fan_fan_full_yaw='NOT_TESTED',complete_CAM_mutual='NOT_TESTED',full_harness='BLOCKED',
        protected_hardware_files=846,main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    (HERE/'remaining_hull_coverage_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_REST_HULL_COVERAGE_PASS',648,3888,slabs,846,flush=True)


if __name__=='__main__':main()
