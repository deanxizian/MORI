"""Separate coordinate rounding from the current noncompositional frames.

Only the existing CAM construction is reproduced for numerical diagnosis.
The second mode uses ideal nominal rigid rotations with the same zero datums.
Neither mode changes the main model, hardware, or existing source files.
"""
from pathlib import Path
import datetime,json,sys,time
import numpy as np

HERE=Path(__file__).resolve().parent;PARENT=HERE.parent.parent
sys.path[:0]=['/Users/dean/.cache/codex-runtimes/mori-harness-mpmath',
             '/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',str(PARENT/'upper_motion_family_R1')]
import mpmath as mp
from cam_family import CAMFamily,BSpline,sha

mp.mp.dps=60


def vector(a):return mp.matrix([mp.mpf(float(x)) for x in a])
def norm(a):return mp.sqrt(sum(x*x for x in a))
def unit(a):return a/norm(a)
def matrix(a):return mp.matrix([[mp.mpf(float(x)) for x in row] for row in a])
def cross(a,b):return mp.matrix([a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]])


def nominal(center,yaw,pitch):
    y,p=mp.mpf(float(yaw))*mp.pi/180,mp.mpf(float(pitch))*mp.pi/180
    cy,sy,cp,sp=mp.cos(y),mp.sin(y),mp.cos(p),mp.sin(p)
    R=mp.matrix([[cy,-sy*cp,sy*sp],[sy,cy*cp,-cy*sp],[0,sp,cp]])
    return R,center-R*center


class Builder:
    def __init__(self):self.controls=[];self.kinds=[]
    @property
    def end(self):return self.controls[-1][-1]
    def add(self,c,kind):
        c=[mp.matrix(q) for q in c]
        if self.controls:
            delta=self.end-c[0];assert norm(delta)<mp.mpf('1e-5')
            c[0]+=delta;c[1]+=delta
        self.controls.append(c);self.kinds.append(kind)
    def line(self,a,b):
        if norm(b-a)>mp.mpf('1e-9'):self.add([a,(2*a+b)/3,(a+2*b)/3,b],'line')
    def arc(self,center,u,v,r,start,end):
        if abs(end-start)<mp.mpf('1e-10'):return
        steps=int(mp.ceil(abs(end-start)/mp.mpf('.1')))
        for i in range(steps):
            a=start+(end-start)*i/steps;b=start+(end-start)*(i+1)/steps
            point=lambda q:center+r*(mp.cos(q)*u+mp.sin(q)*v)
            tangent=lambda q:r*(-mp.sin(q)*u+mp.cos(q)*v)
            h=(b-a)/3;p,q=point(a),point(b)
            self.add([p,p+h*tangent(a),q-h*tangent(b),q],'circle_Hermite')
    def shift(self,start,xy,r):
        delta=mp.matrix([xy[0]-start[0],xy[1]-start[1],0]);D=norm(delta)
        if D<mp.mpf('1e-9'):return
        axis=delta/D;up=mp.matrix([0,0,1])
        angle=mp.acos(1-D/(2*r)) if D<2*r else mp.pi/2
        self.arc(start+r*axis,-axis,up,r,0,angle)
        middle=mp.matrix(self.end);self.line(middle,middle+max(mp.mpf(0),D-2*r)*axis)
        middle=mp.matrix(self.end)
        self.arc(middle-r*mp.cos(angle)*axis+r*mp.sin(angle)*up,axis,-up,r,angle,0)
    def append(self,other,R,T):
        for c,kind in zip(other.controls,other.kinds):self.add([R*p+T for p in c],kind)


def construct(f,pin,yaw,pitch,height,mode):
    name=f'CAM_{pin}';source=f.ctx.f.candidate(name,yaw)['control']
    start=vector(source[-1]);incoming=vector(BSpline(f.ctx.f.knots,source,3).derivative()(1.))
    center=vector(f.carrier.center)
    def frame(y,p):
        if mode=='ideal_nominal':return nominal(center,y,p)
        M=matrix(f.carrier.transform(y,p));return M[:3,:3],M[:3,3]
    Ay,Ty=frame(yaw,0);Ap,Tp=frame(0,pitch);At,Tt=frame(yaw,pitch)
    spec=f.ctx.fan[pin];fan_start=vector(spec['start_mm']);finish=Ay*fan_start+Ty
    result=Builder()
    if abs(finish[2]-start[2])>mp.mpf('1e-8'):
        L=norm(finish-start);out=Ay*mp.matrix([0,0,1])
        result.add([start,start+unit(incoming)*L/3,finish-unit(out)*L/3,finish],'neck_Hermite')
        local_start=fan_start
    else:local_start=Ay**-1*(start-Ty)
    local=Builder();first=local_start+mp.matrix([0,0,mp.mpf(float(spec['lead_mm']))])
    local.line(local_start,first);anchor=vector(f.anchors[pin])
    local.shift(first,anchor[:2],mp.mpf(float(spec['radius_mm'])));local.line(local.end,anchor)
    first=anchor+mp.matrix([0,0,mp.mpf(float(f.ctx.loop_spec['lead_mm']))]);local.line(anchor,first)
    tail=f.ctx.cam[f'pin{pin}'];endpoint=vector(tail[0])-mp.matrix([0,0,15])
    b=Ap*endpoint+Tp;angle=mp.mpf(float(pitch))*mp.pi/180;s,c=mp.sin(angle),mp.cos(angle)
    sign=1 if pitch>=0 else -1;tangent=mp.matrix([0,s,-c]);terminal=mp.mpf(float(f.ctx.loop_spec['terminal_straight_mm']))
    d=b-terminal*tangent;lower=d-mp.matrix([0,sign*mp.mpf('7.5')*(1-c),-mp.mpf('7.5')*abs(s)])
    local.shift(first,[b[0],lower[1]+14],mp.mpf(7));top=local.end+mp.matrix([0,0,mp.mpf(float(height))])
    local.line(local.end,top);local.arc(top+mp.matrix([0,-7,0]),mp.matrix([0,1,0]),mp.matrix([0,0,1]),mp.mpf(7),0,mp.pi)
    local.line(local.end,lower);local.arc(lower+mp.matrix([0,sign*mp.mpf('7.5'),0]),mp.matrix([0,-sign,0]),mp.matrix([0,0,-1]),mp.mpf('7.5'),0,abs(angle))
    result.append(local,Ay,Ty);index=len(result.controls)-1
    pre=[mp.matrix(q) for q in result.controls[index]]
    upper=Builder()
    for controls,kind in zip(f.tail_builders[pin].controls,f.tail_builders[pin].kinds):upper.add([vector(q) for q in controls],kind)
    first_ctrl=[At*q+Tt for q in upper.controls[0]]
    correction=norm(result.end-first_ctrl[0]);last=result.controls[-1]
    last[3]=first_ctrl[0];last[2]=last[3]-unit(first_ctrl[1]-first_ctrl[0])*norm(last[3]-last[2])
    post=[mp.matrix(q) for q in result.controls[index]]
    result.append(upper,At,Tt)
    first=result.controls[0];span=norm(first[1]-first[0]);first[0]=start;first[1]=start+unit(incoming)*span
    outgoing=At*mp.matrix([-1,0,0]);last=result.controls[-1];span=norm(last[-1]-last[-2])
    last[-1]=At*vector(tail[-1])+Tt;last[-2]=last[-1]-unit(outgoing)*span
    composition_rotation=Ay*Ap-At;composition_translation=Ay*Tp+Ty-Tt
    return result,dict(piece_index=index,piece_kind=result.kinds[index],pre=pre,post=post,
        correction_mm=float(correction),frame_composition_rotation_max=float(max(abs(x) for x in composition_rotation)),
        frame_composition_translation_max_mm=float(max(abs(x) for x in composition_translation)))


def radius(c,depth=7):
    v=[3*(b-a) for a,b in zip(c[:-1],c[1:])];a=[2*(q-p) for p,q in zip(v[:-1],v[1:])]
    def split(q):
        levels=[q]
        while len(levels[-1])>1:levels.append([(p+r)/2 for p,r in zip(levels[-1][:-1],levels[-1][1:])])
        return [r[0] for r in levels],[r[-1] for r in levels[::-1]]
    queue=[(v,a)]
    for _ in range(depth):
        fresh=[]
        for v,a in queue:
            lv,rv=split(v);la,ra=split(a);fresh.extend([(lv,la),(rv,ra)])
        queue=fresh
    minimum=mp.inf
    for v,a in queue:
        lo=[min(q[i] for q in v) for i in range(3)];hi=[max(q[i] for q in v) for i in range(3)]
        speed=mp.sqrt(sum((l if l>0 else h if h<0 else 0)**2 for l,h in zip(lo,hi)))
        bound=max(norm(cross(q,r)) for q in v for r in a)
        R=speed**3/bound if bound else mp.inf
        minimum=min(minimum,R)
    return max(0,float(minimum)-.0001)


def main():
    started=time.time();f=CAMFamily();rows=[]
    source=HERE/'small_angles_direct_derivative.json';d=json.loads(source.read_text())
    assert d['status']=='BLOCKED' and all(sha(p)==h for p,h in d['sources'].items())
    selected=[next(r for r in d['rows'] if r['wire']=='CAM_1' and r['pose_deg']==[y,p])
              for y in [0.,-37.2,21.1] for p in [-1e-5,1e-5,-1e-6,1e-6,-1e-7,1e-7,-1e-8,1e-8]]
    for r in selected:
        y,p=r['pose_deg']
        for mode in ['current_frames','ideal_nominal']:
            result,info=construct(f,1,y,p,r['height_mm'],mode)
            before=radius(info['pre']);after=radius(info['post'])
            raw,_,_=f.construct(1,y,p,r['height_mm'])
            fresh=np.array([[[float(x) for x in q] for q in c] for c in result.controls])
            diff=float(np.linalg.norm(raw-fresh,axis=-1).max()) if raw.shape==fresh.shape else None
            row=dict(pose_deg=[y,p],mode=mode,decimal_digits=mp.mp.dps,
                     radius_before_endpoint_repair_mm=before,radius_after_endpoint_repair_mm=after,
                     source_control_count=len(raw),precision_control_count=len(fresh),
                     maximum_source_control_difference_mm=diff,
                     **{k:v for k,v in info.items() if k not in ['pre','post']})
            rows.append(row);print('CAM_PRECISION_FRAME',y,p,mode,before,after,info['correction_mm'],flush=True)
    f.ctx.record([Path(__file__),source,HERE/'stable_bending.py'])
    f.unchanged()
    out=dict(status='PASS',scope='High precision diagnostic of small coupling arcs and source frame composition; not full route qualification',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=f.sources,
             mpmath_version=mp.__version__,decimal_digits=mp.mp.dps,rows=rows,
             all_angle_CAM_math='NOT_TESTED',main_changed=False,hardware_changed=False,animation_changed=False,
             manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'precision_frame_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_PRECISION_FRAME_TERMINAL',len(rows),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
