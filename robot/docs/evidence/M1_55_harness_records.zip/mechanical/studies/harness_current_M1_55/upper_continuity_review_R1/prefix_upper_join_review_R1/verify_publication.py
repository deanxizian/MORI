"""Verify retained source/files and current served bytes for the join scope."""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import itertools
import json
import urllib.request

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self,tag,attrs):
        for key,value in attrs:
            if key=='href':
                self.links.append(value)


def main():
    path = HERE/'delivery.json'
    delivery = read(path)
    assert delivery['status']==delivery['continuous_own_prefix']==delivery['continuous_other_prefix']=='PASS'
    assert delivery['prefix_upper_comparisons']==84 and delivery['own_prefix_pairs']==7 and delivery['other_prefix_pairs']==77
    assert delivery['prefix_references']==12 and delivery['known_upper_references']==7
    assert delivery['actual_transitions']==delivery['full_harness']=='BLOCKED' and not delivery['manufacturing_release']
    assert all(sha(p)==h for p,h in delivery['sources'].items())
    assert all(sha(HERE/p)==h for p,h in delivery['files'].items())
    proof = read(HERE/'join_coverage_verification.json')
    names = list(read(HERE/'prefix_envelope_crosscheck.json')['prefix_radii_mm'])
    uppers = ['CAM_1','CAM_2','CAM_3','CAM_4','P_J18_1','P_J18_2','CC_allocation']
    rows = proof['results']
    assert [(r['prefix'],r['upper']) for r in rows]==list(itertools.product(names,uppers))
    assert sum(r['own_prefix'] for r in rows)==7 and all(r['status']=='PASS' for r in rows)
    page = (HERE/'index.html').read_text()
    assert '尚未进入主模型或视频' in page and '五条缺实际端点' in page
    parser = Links()
    parser.feed(page)
    served = []
    for p in [HERE/'index.html',*((HERE/link).resolve() for link in parser.links)]:
        assert p.is_file()
        relative = p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+relative,timeout=10) as response:
            assert response.read()==p.read_bytes(),relative
        served.append(dict(path=relative,sha256=sha(p)))
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               delivery_sha256=sha(path),verified_files=len(delivery['files']),verified_sources=len(delivery['sources']),
               served_links=len(served),served=served,prefix_upper_comparisons=84,own_prefix_pairs=7,other_prefix_pairs=77,
               continuous_own_prefix='PASS',continuous_other_prefix='PASS',full_harness='BLOCKED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_UPPER_PUBLICATION_VERIFIED',len(delivery['files']),len(served),84,flush=True)


if __name__=='__main__':
    main()
