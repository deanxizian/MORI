"""Independently audit full native angular and parameter coverage and sources."""
from pathlib import Path
import datetime
import hashlib
import json

HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def cover(rows,base):
    cells=[r['rectangle_deg'] for r in rows]
    assert cells and all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in cells)
    edges=sorted({x for r in cells for x in r[:2]})
    assert edges[0]==base[0] and edges[-1]==base[1]
    for left,right in zip(edges[:-1],edges[1:]):
        mid=(left+right)/2
        active=sorted(r[2:] for r in cells if r[0]<mid<r[1])
        assert active and active[0][0]==base[2] and active[-1][1]==base[3]
        assert all(abs(a[1]-b[0])<1e-12 for a,b in zip(active[:-1],active[1:]))
    return len(edges)-1


def main():
    native_path=HERE/'native_verification.json';report=read(native_path)
    assert report['status']=='PASS' and report['mode']=='all_angles' and report['native_parts']==201
    assert report['required_gap_mm']==.3 and report['parameter_cells_per_reference']==9216
    assert report['native_frame']=='Ideal nominal Rz(yaw)Rx(pitch) about current head centre'
    assert report['source_float32_all_angle_rounding']=='NOT_TESTED'
    assert not report['main_changed'] and not report['hardware_changed'] and not report['manufacturing_release']
    assert all(sha(p)==h for p,h in report['sources'].items())
    math=read(MATH/'power_math_verification.json');assert math['status']=='PASS'
    assert report['names']==math['names']==['P_J18_1','P_J18_2','CC_allocation']
    assert report['yaw_range_deg']==[-60,60] and report['pitch_range_deg']==[-20,25]
    total=0;strips=0;counts={};minimum=float('inf');conditional_minimum=float('inf')
    assert len(report['results'])==3
    for result in report['results']:
        name=result['wire'];assert result['status']=='PASS'
        parents=[r['rectangle_deg'] for r in math['rows'] if r['wire']==name]
        assert result['planned_math_rectangles']==len(parents)
        leaves=result['intervals'];assert len(leaves)==result['accepted_rectangles']
        by_parent={tuple(p):[] for p in parents}
        for leaf in leaves:
            assert leaf['status']=='PASS' and tuple(leaf['source_math_rectangle_deg']) in by_parent
            by_parent[tuple(leaf['source_math_rectangle_deg'])].append(leaf)
            assert {r['group'] for r in leaf['rows']}=={'body','yaw','pitch','USB_conditional'} and len(leaf['rows'])==4
            for row in leaf['rows']:
                assert row['gap_lower_mm']>=.3
                assert row['whole_parameter_cell_motion_bound_mm']>=0
                if row['group']=='USB_conditional':conditional_minimum=min(conditional_minimum,row['gap_lower_mm'])
                else:minimum=min(minimum,row['gap_lower_mm'])
        assert set(by_parent)=={tuple(r) for r in parents}
        for parent,rows in by_parent.items():strips+=cover(rows,parent)
        counts[name]=len(leaves);total+=len(leaves)
    assert abs(minimum-report['minimum_certified_native_gap_lower_mm'])<1e-12
    cross=read(HERE/'envelope_crosscheck.json')
    assert cross['status']=='PASS' and cross['parameter_cells_per_reference']==9216
    assert cross['poly_steps']==64 and cross['stub_steps']==1024
    # Uniform subintervals cover the stub once and each of the128 cubics once.
    # The source-guarded restrictions use four controls for each closed interval.
    parameter_cells=cross['stub_steps']+128*cross['poly_steps'];assert parameter_cells==9216
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={n:h for n,h in baseline['protected_hardware'].items() if '__pycache__' not in n and Path(n).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
    sources=dict(report['sources'])
    for p in [Path(__file__),native_path,MATH/'power_math_verification.json',HERE/'envelope_crosscheck.json']:
        sources[str(p)]=sha(p)
    result=dict(status='PASS',scope='Three full-angle native geometric reference proofs, exact source/file preservation and independent partition coverage; not physical wiring',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        full_native_angular_rectangles=total,per_wire_rectangles=counts,independent_y_slab_checks=strips,
        whole_curve_parameter_cells=parameter_cells,minimum_certified_native_gap_lower_mm=minimum,
        minimum_conditional_USB_gap_lower_mm=conditional_minimum,required_gap_mm=.3,
        native_frame=report['native_frame'],source_float32_all_angle_rounding='NOT_TESTED',
        actual_USB_geometry='BLOCKED',peer_clearance='NOT_TESTED',CAM_upper='NOT_TESTED',full_harness='BLOCKED',
        source_blend_sha256=sha(PROJECT/'mechanical/mori_v1_2.blend'),
        source_video_sha256=sha(PROJECT/'mechanical/animation/MORI_assembly.mp4'),
        protected_hardware_files=846,main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False)
    (HERE/'native_coverage_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('POWER_NATIVE_COVERAGE_PASS',total,strips,parameter_cells,846,flush=True)


if __name__=='__main__':main()
