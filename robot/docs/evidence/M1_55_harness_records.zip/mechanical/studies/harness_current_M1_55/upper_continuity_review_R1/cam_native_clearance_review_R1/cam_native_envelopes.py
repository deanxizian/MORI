"""Complete-parameter boxes for the precision-safe nominal CAM reference.

Use the same body join, fan, pitch return, and fixed head-local tail. Fixed
canonical slots retain zero-length leads and zero-pitch coupling arcs as
degenerate points, so the native cover does not omit a zero-angle transition.
All frames here are ideal nominal Rz(yaw)Rx(pitch), not the old interpolated
floating frame helper or a physical cable/connector qualification.
"""
from pathlib import Path
import json
import math
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
MATH = HERE.parent
CAM = MATH/'cam_math_review_R1'
sys.path[:0] = [str(CAM),str(MATH),str(MATH/'native_clearance_review_R1')]
from certify_nominal_math import Enclosures
from nominal_cam import NAMES,sha
from power_enclosures import Box,stacked,magnitude,unit_box,yaw_box,trigonometric_box,linear,basis
from power_native_envelopes import rotate_box,ideal_matrix,restrictions
from piecewise_geometry import RADII

NUMERIC = 1e-8
UP = Box([0.,0.,1.])
Y = Box([0.,1.,0.])


def trig(function,angle):
    return trigonometric_box(function,float(angle.lo),float(angle.hi))


def line(a,b):
    return stacked([a,(2*a+b)/3,(a+2*b)/3,b])


def arc(center,u,v,r,start,end,n):
    start=start if isinstance(start,Box) else Box(start)
    end=end if isinstance(end,Box) else Box(end)
    h=(end-start)/(3*n)
    rows=[]
    for i in range(n):
        a=start+(end-start)*(i/n)
        b=start+(end-start)*((i+1)/n)
        ca,sa=trig(math.cos,a),trig(math.sin,a)
        cb,sb=trig(math.cos,b),trig(math.sin,b)
        p=center+r*(ca*u+sa*v)
        q=center+r*(cb*u+sb*v)
        da=r*(-sa*u+ca*v)
        db=r*(-sb*u+cb*v)
        rows.append(stacked([p,p+h*da,q-h*db,q]))
    return rows


def rotate_controls(controls,lo,hi,axis,center):
    shape=controls.lo.shape
    flat=Box(controls.lo.reshape(-1,3),controls.hi.reshape(-1,3))-center
    out=rotate_box(flat,lo,hi,axis)+center
    return Box(out.lo.reshape(shape),out.hi.reshape(shape))


class NativeCAMEnvelopes:
    def __init__(self,arc_steps=64,line_steps=1024):
        self.e=Enclosures()
        self.f=self.e.f
        self.center=self.f.center
        self.arc_steps=arc_steps
        self.line_steps=line_steps
        self.sources=dict(self.f.sources)
        for p in [Path(__file__),CAM/'certify_nominal_math.py',MATH/'power_enclosures.py',
                  MATH/'native_clearance_review_R1/power_native_envelopes.py',
                  CAM/'nominal_math_verification.json',CAM/'nominal_math_readback.json']:
            self.sources[str(p)]=sha(p)
        proof=json.loads((CAM/'nominal_math_verification.json').read_text())
        assert proof['status']=='PASS' and proof['nominal_frame']=='Ideal consistent Rz(yaw)Rx(pitch)'
        assert all(sha(p)==h for p,h in proof['sources'].items())
        self.parents={name:[r for r in proof['length_rectangles'] if r['wire']==name] for name in NAMES}
        saved=json.loads((CAM/'nominal_half_grid_verification.json').read_text())
        assert saved['status']=='PASS' and saved['curve_pose_checks']==1900
        self.saved_heights={(r['wire'],*r['pose_deg']):r['height_mm'] for r in saved['rows']}
        self.sources[str(CAM/'nominal_half_grid_verification.json')]=sha(CAM/'nominal_half_grid_verification.json')
        self.tail={}
        self.layout={}
        self.operators={}
        for pin in range(1,5):
            name=f'CAM_{pin}'
            c=np.array(self.f.f.tail_builders[pin].controls,float)
            assert np.array_equal(c[0,1]-c[0,0],np.array([0.,0.,c[0,1,2]-c[0,0,2]]))
            assert c[0,1,2]<c[0,0,2]
            finish=np.array(self.f.ctx.cam[f'pin{pin}'][-1],float)
            c[-1,-2]=finish-np.array([-1.,0.,0.])*np.linalg.norm(finish-c[-1,-2])
            c[-1,-1]=finish
            self.tail[name]=c
            controls,kinds,labels,tail_index=self.controls(name,(0.,0.,0.,0.),Box(self.saved_heights[name,0.,0.]),'yaw')
            cells=[];operators=[]
            for index,kind in enumerate(kinds):
                steps=line_steps if kind in ['line','neck_Hermite'] else arc_steps
                edges=np.linspace(0.,1.,steps+1);intervals=np.c_[edges[:-1],edges[1:]]
                operators.append(restrictions(np.eye(4),intervals))
                cells.extend((index,float(a),float(b)) for a,b in intervals)
            self.layout[name]=dict(kinds=kinds,labels=labels,tail_index=tail_index,
                                   parameter_cells=np.array(cells,float))
            self.operators[name]=operators

    def certificate(self,name,rectangle):
        yl,yh,pl,ph=rectangle
        special=self.e.special_metrics(name,yl,yh)
        result=self.e.length_branch(name,yl,yh,pl,ph,special)
        assert min(result['height_lower_mm'],result['return_lower_mm'])>=.5
        return dict(status='PASS',rectangle_deg=list(rectangle),**result)

    def controls(self,name,rectangle,height,group):
        yl,yh,pl,ph=map(float,rectangle)
        assert pl*ph>=0 and group in ['body','yaw','pitch']
        sign=1. if pl>=0 else -1.
        pin=int(name[-1]);spec=self.f.ctx.fan[pin]
        start=yaw_box(self.e.ends[name],yl,yh)
        incoming=self.e.incoming(name,yl,yh)
        controls=[];kinds=[];labels=[]
        def add(control,kind,label):
            controls.append(control);kinds.append(kind);labels.append(label)
        def add_arc(center,u,v,r,a,b,n,label):
            for i,c in enumerate(arc(center,u,v,r,a,b,n)):
                add(c,'circle_Hermite',f'{label}_{i}')
        if pin in [1,2]:
            finish=Box(spec['start_mm']);L=magnitude(finish-start)
            add(stacked([start,start+incoming*L/3,finish-UP*L/3,finish]),'neck_Hermite','neck')
            local_start=finish
        else:
            local_start=start
        lead=float(spec['lead_mm'])
        first=local_start+lead*UP
        leading=line(local_start,first)
        if pin==3:
            leading=stacked([local_start,local_start+incoming*lead/3,leading[2],leading[3]])
        add(leading,'line','fan_lead')
        anchor=Box(self.f.f.anchors[pin])
        delta=anchor-first
        delta=stacked([delta[0],delta[1],Box(0.)])
        D=magnitude(delta);assert D.lo>14
        axis=delta/Box(D.lo,D.hi)
        r=float(spec['radius_mm']);assert r==7.
        first_fan_index=len(controls)
        add_arc(first+r*axis,-axis,UP,r,0.,math.pi/2,16,'fan_first')
        if pin==4:
            c=controls[first_fan_index]
            controls[first_fan_index]=stacked([c[0],c[0]+incoming*(r*math.pi/32/3),c[2],c[3]])
        middle_start=first+r*axis+r*UP
        middle_end=first+delta-r*axis+r*UP
        add(line(middle_start,middle_end),'line','fan_middle')
        add_arc(middle_end+r*UP,axis,-UP,r,math.pi/2,0.,16,'fan_second')
        fan_end=stacked([anchor[0],anchor[1],first[2]+2*r])
        add(line(fan_end,anchor),'line','fan_return')
        begin=anchor+float(self.f.ctx.loop_spec['lead_mm'])*UP
        add(line(anchor,begin),'line','loop_lead')

        sine=trigonometric_box(math.sin,math.radians(pl),math.radians(ph))
        cosine=trigonometric_box(math.cos,math.radians(pl),math.radians(ph))
        endpoint=np.array(self.f.ctx.cam[f'pin{pin}'][0],float)-np.array([0.,0.,15.])
        relative=endpoint-self.center
        b=stacked([Box(endpoint[0]),relative[1]*cosine-relative[2]*sine+self.center[1],
                   relative[1]*sine+relative[2]*cosine+self.center[2]])
        terminal=float(self.f.ctx.loop_spec['terminal_straight_mm']);assert terminal==15.
        tangent=stacked([Box(0.),sine,-cosine])
        d=b-terminal*tangent
        lower=d-stacked([Box(0.),sign*7.5*(1-cosine),-7.5*sign*sine])
        shift_distance=lower[1]+14-anchor[1]
        assert 0<shift_distance.lo<=shift_distance.hi<14
        cosa=1-shift_distance/14
        alpha=Box(math.acos(float(cosa.hi))-NUMERIC,math.acos(float(cosa.lo))+NUMERIC)
        sina=trig(math.sin,alpha)
        add_arc(begin+7*Y,-Y,UP,7.,0.,alpha,16,'pitch_shift_first')
        second_center=begin+7*(1-2*cosa)*Y+14*sina*UP
        add_arc(second_center,Y,-UP,7.,alpha,0.,16,'pitch_shift_second')
        shifted=stacked([anchor[0],lower[1]+14,begin[2]+14*sina])
        top=shifted+height*UP
        add(line(shifted,top),'line','height')
        add_arc(top-7*Y,Y,UP,7.,0.,math.pi,32,'top_return')
        down_start=top-14*Y
        add(line(down_start,lower),'line','down')
        angle=Box(min(abs(math.radians(pl)),abs(math.radians(ph))),
                  max(abs(math.radians(pl)),abs(math.radians(ph))))
        add_arc(lower+sign*7.5*Y,-sign*Y,-UP,7.5,0.,angle,5,'coupling')
        # The original high-precision endpoint/tangent repair has this exact
        # ideal-frame limit, including at pitch zero. No small arc is dropped.
        tail=Box(self.tail[name])
        tail_yaw=rotate_controls(tail,pl,ph,'X',self.center)
        end=tail_yaw[0,0]
        c=controls[-1]
        controls[-1]=stacked([c[0],c[1],end-(7.5/15)*angle*tangent,end])
        lower_controls=stacked(controls)
        if group=='body':
            lower_controls=rotate_controls(lower_controls,yl,yh,'Z',self.center)
            tail_controls=rotate_controls(tail_yaw,yl,yh,'Z',self.center)
        elif group=='pitch':
            lower_controls=rotate_controls(lower_controls,-ph,-pl,'X',self.center)
            tail_controls=tail
        else:
            tail_controls=tail_yaw
        all_controls=Box(np.concatenate([lower_controls.lo,tail_controls.lo])-NUMERIC,
                         np.concatenate([lower_controls.hi,tail_controls.hi])+NUMERIC)
        tail_index=len(kinds)
        kinds.extend(self.f.f.tail_builders[pin].kinds)
        labels.extend(f'tail_{i}' for i in range(len(tail.lo)))
        return all_controls,kinds,labels,tail_index

    def point_boxes(self,name,rectangle,certificate,group):
        height=Box(certificate['height_lower_mm'],certificate['height_upper_mm'])
        c,_,_,_=self.controls(name,rectangle,height,group)
        lo=[];hi=[]
        for i,M in enumerate(self.operators[name]):
            mapped=linear(M.reshape(-1,4),c[i])
            lo.append(mapped.lo.reshape(-1,4,3).min(1))
            hi.append(mapped.hi.reshape(-1,4,3).max(1))
        return Box(np.concatenate(lo),np.concatenate(hi))

    def reference(self,name,yaw,pitch):
        key=name,float(yaw),float(pitch)
        if key in self.saved_heights:
            height=self.saved_heights[key]
        else:
            _,_,_,row=self.f.upper(name,yaw,pitch)
            assert row['status']=='PASS'
            height=row['height_mm']
        controls={};points={}
        for group in ['body','yaw','pitch']:
            c,_,_,_=self.controls(name,(yaw,yaw,pitch,pitch),Box(height),group)
            midpoint=(c.lo+c.hi)/2
            samples=[]
            for i,M in enumerate(self.operators[name]):
                # M contains the four controls of each restricted interval.
                # Its midpoint is evaluated directly in Bernstein coordinates.
                intervals=self.layout[name]['parameter_cells']
                count=len(M);steps=np.arange(count,dtype=float)
                t=(steps+.5)/count
                samples.append(basis(t,3)@midpoint[i])
            controls[group]=midpoint
            points[group]=np.concatenate(samples)
        return dict(points=points,controls=controls,height_mm=height,yaw_deg=yaw,pitch_deg=pitch)

    def motion(self,name,rectangle,certificate,reference,group):
        box=self.point_boxes(name,rectangle,certificate,group)
        p=reference['points'][group]
        return np.linalg.norm(np.maximum(abs(box.lo-p),abs(box.hi-p)),axis=1)+NUMERIC

    def unchanged(self):
        self.f.unchanged()
        assert all(sha(p)==h for p,h in self.sources.items())
