"""Independent complete-angle, root-union and closed-parameter coverage audit.

The numeric generator, arc helper and self refinement are not imported.
Mathematical parent coverage and every reported union are rebuilt directly
from retained source records. This audit does not qualify physical wiring.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
NAMES = ['P_J18_1','P_J18_2','CC_allocation']


def coverage_2d(boxes,base):
    assert boxes and all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in boxes)
    edges = sorted({x for r in boxes for x in r[:2]})
    assert edges[0]==base[0] and edges[-1]==base[1]
    for a,b in zip(edges[:-1],edges[1:]):
        middle = (a+b)/2
        strips = sorted(r[2:4] for r in boxes if r[0]<middle<r[1])
        assert strips and strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    pilot = '--pilot' in sys.argv
    path = HERE/('pilot_verification.json' if pilot else 'self_verification.json')
    proof = read(path)
    assert proof['status']=='PASS' and not proof['failures']
    assert proof['mode']==('pilot' if pilot else 'all_angles')
    assert proof['canonical_cubic_pieces_per_reference']==129
    assert proof['required_gap_mm']==.3 and proof['local_arc_exclusion_upper_mm']==5.
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    assert all(sha(p)==h for p,h in proof['sources'].items())
    math_path = ROOT/'power_math_verification.json'
    math = read(math_path)
    assert math['status']=='PASS' and all(sha(p)==h for p,h in math['sources'].items())
    parents = {n:[r for r in math['rows'] if r['wire']==n] for n in NAMES}
    radius = {}
    for name,rows in parents.items():
        coverage_2d([r['rectangle_deg'] for r in rows],(-60.,60.,-20.,25.))
        requirements = {r['continuous_bending']['required_radius_mm'] for r in rows}
        assert len(requirements)==1
        radius[name] = next(iter(requirements))
        assert all(r['status']=='PASS' and r['continuous_bending']['status']=='PASS'
                   and r['continuous_bending']['radius_lower_mm']>=radius[name]
                   and r['continuous_bending']['derivative_nonzero'] for r in rows)
    assert proof['radius_requirements_mm']==radius
    expected_bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    assert proof['bases']==[list(r) for r in expected_bases]
    assert [r['wire'] for r in proof['results']]==NAMES
    totals = dict(angular_rectangles=0,refined_piece_pairs=0,parameter_rectangles=0,
                  local_parameter_rectangles=0,hull_parameter_rectangles=0,
                  parent_union_certificates=0,fresh_root_certificates=0)
    summaries = []
    for result in proof['results']:
        name = result['wire']
        assert result['status']=='PASS'
        expected = {base:[] for base in expected_bases}
        for row in result['intervals']:
            r,base = tuple(row['rectangle_deg']),tuple(row['base_rectangle_deg'])
            assert base in expected and row['status']=='PASS'
            expected[base].append(r)
            c = row['root_certificate']
            assert c['wire']==name and c['rectangle_deg']==list(r) and c['status']=='PASS'
            if c['method']=='guarded_parent_union':
                indices = [i for i,q in enumerate(parents[name])
                           if q['rectangle_deg'][0]<r[1] and q['rectangle_deg'][1]>r[0]
                           and q['rectangle_deg'][2]<r[3] and q['rectangle_deg'][3]>r[2]]
                assert indices and c['parent_indices']==indices
                source = [parents[name][i] for i in indices]
                lo = min(q['midpoint_amplitude_mm']-q['amplitude_deviation_bound_mm'] for q in source)
                hi = max(q['midpoint_amplitude_mm']+q['amplitude_deviation_bound_mm'] for q in source)
                assert c['midpoint_amplitude_mm']==(lo+hi)/2
                assert c['amplitude_deviation_bound_mm']==(hi-lo)/2+1e-9
                totals['parent_union_certificates'] += 1
            else:
                assert c['method']=='fresh_guarded_root'
                assert c['root_derivative_lower']>0 and c['global_unit_bracket_derivative_lower']>0
                assert 0<c['amplitude_deviation_bound_mm']<1
                assert abs(c['midpoint_amplitude_mm'])+c['amplitude_deviation_bound_mm']<1
                totals['fresh_root_certificates'] += 1
            pairs = [tuple(p) for p in row['refined_piece_pairs']]
            assert len(pairs)==len(set(pairs)) and all(0<=i<=j<129 for i,j in pairs)
            assert row['complete_unordered_piece_pairs']==129*130//2==8385
            assert row['coarse_local_pairs']+row['coarse_separated_pairs']+len(pairs)==8385
            assert row['required_gap_mm']==.3 and row['local_arc_exclusion_upper_mm']==5.
            assert [tuple(q['pieces']) for q in row['parameter_refinements']]==pairs
            for detail in row['parameter_refinements']:
                cells = detail['parameter_rectangles']
                coverage_2d([q['parameter_rectangle'] for q in cells],(0.,1.,0.,1.))
                for q in cells:
                    assert q['method'] in ['local_arc','complete_hull']
                    if q['method']=='local_arc':
                        assert 0<=q['arc_upper_mm']<=5.
                        totals['local_parameter_rectangles'] += 1
                    else:
                        assert q['gap_lower_mm']>=.3
                        totals['hull_parameter_rectangles'] += 1
                totals['parameter_rectangles'] += len(cells)
            totals['refined_piece_pairs'] += len(pairs)
            totals['angular_rectangles'] += 1
        for base,boxes in expected.items():
            coverage_2d(boxes,base)
        summaries.append(dict(wire=name,status='PASS',canonical_cubic_pieces=129,
                              complete_unordered_piece_pairs=8385,angular_rectangles=len(result['intervals'])))
    speed_path = HERE/'speed_bound_crosscheck.json'
    speed = read(speed_path)
    assert speed['status']=='PASS' and speed['source_pose_comparisons']==45
    assert speed['derivative_control_vectors']==17415
    assert speed['minimum_speed_upper_reserve_mm']>=0 and speed['minimum_join_upper_reserve_mm']>=0
    assert all(sha(p)==h for p,h in speed['sources'].items())
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = proof['sources'] | speed['sources']
    for p in [Path(__file__),path,math_path,speed_path]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               mode=proof['mode'],scope='Independent full angular/parameter power-upper self covers and source-root unions',
               sources=sources,results=summaries,references=3,**totals,required_gap_mm=.3,
               local_arc_exclusion_upper_mm=5.,radius_requirements_mm=radius,
               power_upper_remote_self='PASS' if not pilot else 'NOT_TESTED',own_prefix='NOT_TESTED',
               full_harness='BLOCKED',protected_hardware_files=846,
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    target = 'pilot_coverage_verification.json' if pilot else 'self_coverage_verification.json'
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_SELF_COVERAGE_PASS',proof['mode'],3,totals,846,flush=True)


if __name__ == '__main__':
    main()
