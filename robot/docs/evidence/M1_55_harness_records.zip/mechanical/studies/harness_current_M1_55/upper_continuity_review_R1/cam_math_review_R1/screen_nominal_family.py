"""Preserved-datum finite audit of the precision-safe nominal CAM reference."""
from pathlib import Path
import datetime,hashlib,json,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;PARENT=HERE.parent.parent
sys.path[:0]=[str(HERE)]
from nominal_cam import NominalCAM,NAMES,sha,derivatives
from stable_bending import radius_bound
from piecewise_geometry import evaluate,MINIMUM_RADIUS


def main():
    started=time.time();f=NominalCAM();pilot='--pilot' in sys.argv
    poses=([(y,p) for y in [0.,-37.2,21.1] for p in [-1e-5,1e-5,-1e-6,1e-6,-1e-7,1e-7,-1e-8,1e-8,-1e-12,1e-12,0.]]+
           [(-60.,-20.),(60.,25.),(17.3,12.7)] if pilot else
           [(float(y),float(p)) for y in range(-60,61,5) for p in np.arange(-20,25.01,2.5)])
    source_path=PARENT/'upper_motion_family_R1/cam_half_grid_curves.npz'
    source_report=PARENT/'upper_motion_family_R1/cam_half_grid_inspection.json'
    old=np.load(source_path);old_report=json.loads(source_report.read_text())
    assert old_report['status']=='PASS' and sha(source_path)==old_report['arrays_sha256']
    assert all(sha(p)==h for p,h in old_report['sources'].items())
    rows=[];failures=[];arrays={};samples=np.linspace(0,1,2049)
    for yaw,pitch in poses:
        for name in NAMES:
            precise,c,L,info=f.upper(name,yaw,pitch)
            # A normal-size segment can use the float derivative checker. The
            # tiny coupling uses original precise derivatives, never rounded
            # absolute preview positions. Full-angle theory is a separate gate.
            index=info['coupling_piece_index'];v=derivatives(precise.controls)
            first=float(radius_bound(c[:1])['radius_lower_mm'])
            row=dict(wire=name,pose_deg=[yaw,pitch],curve_pieces=len(c),first_piece_radius_lower_mm=first,**info)
            key=f'{name}_y{yaw:g}_p{pitch:g}'
            if key+'_controls' in old.files:
                a=evaluate(c,L,samples);b=evaluate(old[key+'_controls'],old[key+'_lengths'],samples)
                row['saved_curve_parameter_sample_difference_mm']=float(np.linalg.norm(a-b,axis=1).max())
                assert row['saved_curve_parameter_sample_difference_mm']<.0005,row
            row['status']='PASS' if row['status']=='PASS' and first>=MINIMUM_RADIUS[name] else 'BLOCKED'
            row['required_reference_radius_mm']=MINIMUM_RADIUS[name]
            rows.append(row)
            if row['status']!='PASS':failures.append(row)
            arrays[key+'_controls']=c;arrays[key+'_lengths']=L
            # Retain precise derivatives separately for diagnostic/preview use.
            arrays[key+'_derivatives']=v
        print('NOMINAL_CAM_POSE',yaw,pitch,len(rows),len(failures),round(time.time()-started,1),flush=True)
        if failures:break
    f.ctx.record([Path(__file__),HERE/'stable_bending.py',source_path,source_report]);f.unchanged()
    stem='pilot' if pilot else 'half_grid';np.savez_compressed(HERE/f'nominal_{stem}_curves.npz',**arrays)
    out=dict(status='PASS' if not failures and len(rows)==4*len(poses) else 'BLOCKED',
             scope='Finite precision-safe nominal CAM audit, same zero hardware datums and body prefixes; not all-angle or physical wire release',
             recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=f.sources,
             planned_poses=poses,curve_pose_checks=len(rows),rows=rows,failures=failures,
             arrays_sha256=sha(HERE/f'nominal_{stem}_curves.npz'),decimal_digits=80,
             geometric_construction='Consistent nominal rigid frames and fixed variable-arc subdivisions; same zero ports/fan/loop/tail',
             full_angle_CAM_bending='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
             actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',main_changed=False,
             hardware_changed=False,animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/f'nominal_{stem}_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('NOMINAL_CAM_TERMINAL',out['status'],len(rows),len(failures),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
