"""Independent angular, parameter and unordered-piece region coverage audit."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
HERE=Path(__file__).resolve().parent;MATH=HERE.parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
NAMES=['CAM_1','CAM_2','CAM_3','CAM_4']
COUNTS=dict(CAM_1=238,CAM_2=238,CAM_3=237,CAM_4=237)
FANS=dict(CAM_1=37,CAM_2=37,CAM_3=36,CAM_4=36)


def coverage_2d(boxes,base):
    assert boxes and all(base[0]<=r[0]<r[1]<=base[1] and base[2]<=r[2]<r[3]<=base[3] for r in boxes)
    edges=sorted({x for r in boxes for x in r[:2]});assert edges[0]==base[0] and edges[-1]==base[1]
    for a,b in zip(edges[:-1],edges[1:]):
        middle=(a+b)/2;strips=sorted(r[2:4] for r in boxes if r[0]<middle<r[1])
        assert strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    pilot='--pilot' in sys.argv
    region=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--region=')),'mixed')
    assert region in ['fan','mixed']
    path=HERE/(region+('_pilot_verification.json' if pilot else '_verification.json'))
    proof=read(path);assert proof['status']=='PASS' and proof['region']==region and not proof['failures']
    assert proof['mode']==('pilot' if pilot else 'all_angles')
    assert proof['required_gap_mm']==.3 and proof['local_arc_exclusion_upper_mm']==5.
    assert all(sha(p)==h for p,h in proof['sources'].items())
    math_path=MATH/'cam_math_review_R1/nominal_math_verification.json';math=read(math_path)
    assert math['status']=='PASS' and all(sha(p)==h for p,h in math['sources'].items())
    parents={n:[r['rectangle_deg'] for r in math['length_rectangles'] if r['wire']==n] for n in NAMES}
    assert [r['wire'] for r in proof['results']]==NAMES
    totals=dict(angular_rectangles=0,refined_piece_pairs=0,parameter_rectangles=0,local_parameter_rectangles=0,hull_parameter_rectangles=0)
    checked=[]
    for result in proof['results']:
        name=result['wire'];count=COUNTS[name];fan=FANS[name];tail=count-130
        pairs={(i,j) for i in range(count) for j in range(i,count)
               if (i<fan and j<fan) if region=='fan'} if region=='fan' else {
               (i,j) for i in range(count) for j in range(i,count) if not(i<fan and j<fan) and not(i>=tail and j>=tail)}
        # Reconstruct every requested parent clip without generator imports.
        if region=='fan':
            ys=[(-60.,-50.),(-10.,0.),(50.,60.)] if pilot else [(float(y),float(y+10)) for y in range(-60,60,10)]
            expected={(None,(y,z,0.,0.)):[] for y,z in ys}
        else:
            expected={}
            windows=proof['pilot_windows'] if pilot else [[-60.,60.,-20.,25.]]
            assert len(parents[name])==648
            coverage_2d(parents[name],(-60.,60.,-20.,25.))
            for index,parent in enumerate(parents[name]):
                for window in windows:
                    r=(max(parent[0],window[0]),min(parent[1],window[1]),max(parent[2],window[2]),min(parent[3],window[3]))
                    if r[0]<r[1] and r[2]<r[3]:expected[index,r]=[]
        assert result['source_bases']==[dict(rectangle_deg=list(r),source_parent_index=i) for i,r in expected]
        for row in result['intervals']:
            base=tuple(row['base_rectangle_deg']);key=row['source_parent_index'],base
            assert key in expected and row['status']=='PASS'
            expected[key].append(tuple(row['rectangle_deg']))
            assert row['complete_piece_pairs']==len(pairs)
            refined=[tuple(p) for p in row['refined_piece_pairs']]
            assert len(refined)==len(set(refined)) and set(refined)<=pairs
            assert row['coarse_local_pairs']+row['coarse_separated_pairs']+len(refined)==len(pairs)
            assert [tuple(r['pieces']) for r in row['parameter_refinements']]==refined
            for refinement in row['parameter_refinements']:
                boxes=[]
                for cell in refinement['parameter_rectangles']:
                    boxes.append(cell['parameter_rectangle'])
                    assert cell['method'] in ['local_arc','complete_hull']
                    if cell['method']=='local_arc':
                        assert 0<=cell['arc_upper_mm']<=5.;totals['local_parameter_rectangles']+=1
                    else:
                        assert cell['gap_lower_mm']>=.3;totals['hull_parameter_rectangles']+=1
                coverage_2d(boxes,(0.,1.,0.,1.))
                totals['parameter_rectangles']+=len(boxes)
            totals['refined_piece_pairs']+=len(refined);totals['angular_rectangles']+=1
        for (_,base),boxes in expected.items():
            if region=='fan':
                assert all(r[2:]==(0.,0.) for r in boxes)
                spans=sorted(r[:2] for r in boxes)
                assert spans and spans[0][0]==base[0] and spans[-1][1]==base[1]
                assert all(a[1]==b[0] for a,b in zip(spans[:-1],spans[1:]))
            else:coverage_2d(boxes,base)
        checked.append(dict(wire=name,source_bases=len(expected),angular_rectangles=len(result['intervals']),complete_piece_pairs_per_rectangle=len(pairs)))
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources=proof['sources']
    for p in [Path(__file__),path,math_path]:sources[str(p)]=sha(p)
    out=dict(status='PASS',region=region,mode=proof['mode'],recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Independent complete angular and two-parameter self-region covers; local exclusion remains bound by5mm arc upper',
        sources=sources,wire_counts=checked,**totals,required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,
        full_CAM_self='NOT_TESTED',own_prefix='NOT_TESTED',full_harness='BLOCKED',protected_hardware_files=846,
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    target=region+('_pilot_coverage_verification.json' if pilot else '_coverage_verification.json')
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_SELF_REGION_COVERAGE_PASS',region,proof['mode'],totals,846,flush=True)


if __name__=='__main__':main()
