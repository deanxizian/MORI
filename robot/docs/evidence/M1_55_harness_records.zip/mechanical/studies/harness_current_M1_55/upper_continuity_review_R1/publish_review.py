"""Publish verified reference mathematics/native gaps; retain the full open scope."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    proof=read(HERE/'power_math_verification.json')
    check=read(HERE/'power_math_readback.json')
    numeric=read(HERE/'endpoint_numeric_reserve.json')
    native=read(HERE/'native_clearance_review_R1/native_verification.json')
    native_check=read(HERE/'native_clearance_review_R1/native_coverage_verification.json')
    small=read(HERE/'cam_zero_angle_review_R1/small_angle_inspection.json')
    origin=read(HERE/'cam_zero_angle_review_R1/origin_precision_diagnostic.json')
    cam=read(HERE/'cam_math_review_R1/delivery.json')
    cam_check=read(HERE/'cam_math_review_R1/publication_verification.json')
    peer=read(HERE/'power_peer_review_R1/delivery.json')
    peer_check=read(HERE/'power_peer_review_R1/publication_verification.json')
    cam_native=read(HERE/'cam_native_clearance_review_R1/delivery.json')
    cam_native_check=read(HERE/'cam_native_clearance_review_R1/publication_verification.json')
    cam_self=read(HERE/'cam_self_review_R1/delivery.json')
    cam_self_check=read(HERE/'cam_self_review_R1/publication_verification.json')
    cam_peer=read(HERE/'cam_peer_review_R1/delivery.json')
    cam_peer_check=read(HERE/'cam_peer_review_R1/publication_verification.json')
    cam_upper_self=read(HERE/'cam_moving_self_review_R1/delivery.json')
    cam_upper_self_check=read(HERE/'cam_moving_self_review_R1/publication_verification.json')
    cam_power_cross=read(HERE/'cam_power_cross_review_R1/delivery.json')
    cam_power_cross_check=read(HERE/'cam_power_cross_review_R1/publication_verification.json')
    power_self=read(HERE/'power_self_review_R1/delivery.json')
    power_self_check=read(HERE/'power_self_review_R1/publication_verification.json')
    joins=read(HERE/'prefix_upper_join_review_R1/delivery.json')
    joins_check=read(HERE/'prefix_upper_join_review_R1/publication_verification.json')
    assert joins['status']==joins_check['status']==joins['continuous_own_prefix']==joins['continuous_other_prefix']=='PASS'
    assert joins['prefix_upper_comparisons']==84 and joins['own_prefix_pairs']==7 and joins['other_prefix_pairs']==77
    assert joins_check['delivery_sha256']==sha(HERE/'prefix_upper_join_review_R1/delivery.json')
    assert power_self['status']==power_self_check['status']==power_self['power_upper_remote_self']=='PASS'
    assert power_self['power_references']==3 and power_self['known_upper_continuous_remote_self']=='PASS'
    assert power_self_check['delivery_sha256']==sha(HERE/'power_self_review_R1/delivery.json')
    assert cam_power_cross['status']==cam_power_cross_check['status']==cam_power_cross['CAM_power_cross_pairs']=='PASS'
    assert cam_power_cross['unordered_cross_pairs']==12 and cam_power_cross['known_upper_unordered_pairs']==21
    assert cam_power_cross_check['delivery_sha256']==sha(HERE/'cam_power_cross_review_R1/delivery.json')
    assert cam_upper_self['status']==cam_upper_self_check['status']==cam_upper_self['continuous_nominal_CAM_upper_remote_self']=='PASS'
    assert cam_upper_self['references']==4 and cam_upper_self['own_prefix']=='NOT_TESTED'
    assert cam_upper_self_check['delivery_sha256']==sha(HERE/'cam_moving_self_review_R1/delivery.json')
    assert cam_peer['status']==cam_peer_check['status']==cam_peer['continuous_nominal_CAM_mutual']=='PASS'
    assert cam_peer['unordered_pairs']==6 and cam_peer['CAM_power_cross_pairs']=='NOT_TESTED'
    assert cam_peer_check['delivery_sha256']==sha(HERE/'cam_peer_review_R1/delivery.json')
    assert cam_self['status']==cam_self_check['status']==cam_self['CAM_fixed_tail_remote_self']=='PASS'
    assert cam_self['whole_parameter_cells']==64000 and cam_self['moving_lower_self']=='NOT_TESTED'
    assert cam_self_check['delivery_sha256']==sha(HERE/'cam_self_review_R1/delivery.json')
    assert cam_native['status']==cam_native_check['status']=='PASS'
    assert cam_native['continuous_nominal_CAM_native_clearance']=='PASS' and cam_native['source_math_rectangles']==2592
    assert cam_native_check['delivery_sha256']==sha(HERE/'cam_native_clearance_review_R1/delivery.json')
    assert cam['status']==cam_check['status']==peer['status']==peer_check['status']=='PASS'
    assert cam['continuous_nominal_CAM_root_and_bending']=='PASS'
    assert peer['continuous_power_peer_clearance']=='PASS' and peer['unordered_pairs']==3
    assert cam_check['delivery_sha256']==sha(HERE/'cam_math_review_R1/delivery.json')
    assert peer_check['delivery_sha256']==sha(HERE/'power_peer_review_R1/delivery.json')
    assert proof['status']==check['status']==numeric['status']==native['status']==native_check['status']==origin['status']=='PASS'
    assert native['mode']=='all_angles' and native['native_parts']==201
    assert native_check['full_native_angular_rectangles']==19068
    assert native['source_float32_all_angle_rounding']=='NOT_TESTED'
    assert small['status']=='BLOCKED' and len(small['failures'])==len(origin['rows'])==8
    assert {(r['wire'],tuple(r['pose_deg'])) for r in small['failures']}=={(r['wire'],tuple(r['pose_deg'])) for r in origin['rows']}
    assert all(r['controls_unchanged'] and r['per_piece_origin_check']['radius_lower_mm']>=r['required_reference_radius_mm'] for r in origin['rows'])
    assert proof['mode']=='complete_math' and proof['continuous_power_bending']=='PASS'
    assert check['finite_source_curve_poses']==1425 and check['saved_source_endpoints_exact']
    sources={}
    for report in [proof,check,numeric,native,native_check,small,origin,cam,peer,cam_native,cam_self,cam_peer,cam_upper_self,cam_power_cross,power_self,joins]:
        for p,h in report['sources'].items():
            assert sha(p)==h,(p,h)
            assert p not in sources or sources[p]==h
            sources[p]=h
    summaries=[]
    for name in proof['names']:
        rows=[r for r in proof['rows'] if r['wire']==name]
        summaries.append(dict(wire=name,accepted_rectangles=len(rows),
            yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
            minimum_radius_lower_mm=min(r['continuous_bending']['radius_lower_mm'] for r in rows),
            required_reference_radius_mm=rows[0]['continuous_bending']['required_radius_mm'],
            minimum_global_bracket_derivative=min(r['global_unit_bracket_derivative_lower'] for r in rows)))
    table=''.join('<tr><td>'+html.escape(r['wire'])+'</td><td>'+str(r['accepted_rectangles'])+
                  '</td><td>'+f"{r['minimum_radius_lower_mm']:.6f}"+'</td><td>'+
                  f"{r['required_reference_radius_mm']:.4f}"+'</td><td>PASS</td></tr>' for r in summaries)
    source='<table><thead><tr><th>参考线</th><th>通过的二维角度区间</th><th>弯折半径下界 mm</th><th>参考要求 mm</th><th>长度根／弯折</th></tr></thead><tbody>'+table+'</tbody></table>'
    native_table=''.join('<tr><td>'+html.escape(r['wire'])+'</td><td>'+str(r['accepted_rectangles'])+'</td><td>PASS</td></tr>' for r in native['results'])
    text=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 已知上段连续数学与间隙进度</title><style>
body{{font:16px/1.65 system-ui,sans-serif;max-width:1000px;margin:30px auto;padding:0 22px;color:#23303b;background:#f4f6f8}}
section{{background:white;border:1px solid #d6dde3;border-radius:10px;padding:20px;margin:20px 0}}
table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{border:1px solid #dae1e6;padding:10px;text-align:left}}
a{{color:#175d9c}}.state{{font-weight:700;color:#8c5712}}code{{font-size:.9em}}h1{{font-size:27px}}</style>
<p><a href="../index.html">线束研究总页</a> · <a href="../../reaction_clamp_R2_adoption/index.html">当前主模型</a></p>
<h1>七条已知上段：连续长度、弯折与间隙进度</h1>
<p class="state">PLACEHOLDER / ASSUMED · 独立参考，未采用 · 完整线束 BLOCKED</p>
<section><h2>本次完成的范围</h2><p>覆盖偏航 −60°～+60°、俯仰 −20°～+25°。
长度检查针对现有分段三次曲线的正权重 Gauss64 数值函数；不是供应商裁线长。
在每个二维角度区间内证明补偿量有唯一分支，并用导数控制包络检查整个曲线参数上的弯折。</p>{source}
<p>共 {proof['accepted_rectangles']:,} 个通过区间。独立扫描区间的每个偏航分带，检查俯仰覆盖无重叠、无遗漏。
与原475姿态×3条路线的1,425条保存曲线比较，补偿根重算后的控制点最大差为
{check['maximum_fresh_root_curve_difference_mm']:.3g} mm；所有原保存端点保持逐位一致。
另核对18条非网格姿态与原构造及直接包络。</p></section>
<section><h2>全运动范围的实体间隙</h2><p>三条上部参考与当前201件原生实体之间的全名义偏航／俯仰间隙检查通过。
共19,068个二维角度区间；每条曲线使用9,216个完整闭参数区间的包络，不只检查离散点。
独立按18,095个原数学区间复核覆盖，无重复或遗漏。原0.3mm目标保持，实体间隙下界最小约{native_check['minimum_certified_native_gap_lower_mm']:.8f}mm。</p>
<table><thead><tr><th>参考线</th><th>实体检查二维区间</th><th>状态</th></tr></thead><tbody>{native_table}</tbody></table>
<p>运动采用当前头中心的理想名义 Rz(yaw)Rx(pitch)；不是对原Float32变换助手全角度舍入的证明。
假定USB外形另列条件检查，通过下界最小约{native_check['minimum_conditional_USB_gap_lower_mm']:.6f}mm；完整实发插头／尾线仍BLOCKED。
<a href="native_clearance_review_R1/native_verification.json">完整实体区间证据</a> ·
<a href="native_clearance_review_R1/native_coverage_verification.json">独立覆盖与源核对</a> ·
<a href="native_clearance_review_R1/README.md">范围与方法</a> · <a href="native_clearance_review_R1/commands.json">实际命令</a></p></section>
<section><h2>三组电源／CC互线间隙</h2><p>三组配对的全名义偏航／俯仰间隙检查通过，每条参考仍覆盖9,216个闭参数区间。
独立重建{peer['source_parent_intersections']:,}个源长度根父区间交集，核对{peer['accepted_rectangles']:,}个细分区间的完整覆盖；原0.3mm目标保持。
排除球查询纳入所有可能影响下界的占用球，部分下界保守截断在0.3mm，不能当作实际线距。</p>
<p><a href="power_peer_review_R1/index.html">完整互线检查与方法</a> · <a href="power_peer_review_R1/peer_coverage_verification.json">独立交集及覆盖核对</a></p></section>
<section><h2>三条电源／CC上段完整自身检查</h2><p>三条参考的非局部自身间隙覆盖全名义偏航／俯仰及完整闭曲线参数，PASS。每条129段三次曲线、8,385组无序段组合；独立核对{power_self['power_self_angular_rectangles']:,}个角度区间及必要组合的{power_self['power_self_parameter_rectangles']:,}个二维参数区间。仅排除整个参数区间弧长上界≤5mm的局部相邻段，包含端点恢复的连接余量，原0.3mm目标和既有曲率要求保持。</p>
<p>与四条CAM完整上段结果合并后，7条已知上段的全部非局部自身检查已齐全；7条全部21组互线另检通过。身体前段与上段接续随后另检通过，见下方完整接续范围；真实材料、端接和完整带线装配仍未完成。</p><p><a href="power_self_review_R1/index.html">电源／CC自身及7条上段自身汇总</a></p></section>
<section><h2>四条CAM名义参考的全范围长度与弯折</h2><p>四条参考已完成名义偏航−60°～+60°、俯仰−20°～+25°的正数值长度分支及完整弯折检查：48个身体接续偏航区间、2,592个长度二维区间。
另有475个有限姿态／1,900条曲线独立回读通过。身体接续点、硬件零位及原扇出／余量圈／头内尾线布局保持。
采用一致名义刚体框架、80位构造及固定可变圆弧分段，解决原插值框架不严格复合和微小圆弧构造的数值问题。
这不是原浮点曲线数组逐位一致的证明；旧有限间隙结果不自动继承到这版参考。</p>
<p>新CAM参考与当前201件模型的全范围实体间隙随后独立通过：2,592个源数学区间、{cam_native['accepted_rectangles']:,}个细分区间，
每条完整闭参数区间均覆盖，零长度引线／零俯仰圆弧保留退化点槽。原0.3mm目标保持，最小实体下界约{cam_native['minimum_certified_native_gap_lower_mm']:.8f}mm。
假定USB外形条件检查分开列出；真实插头与材料仍未资格化。前段接续及跨组配对随后完成，见下方。</p>
<p>四条CAM上段的6组内部配对随后通过全偏航／俯仰和完整参数检查：扇出段{cam_peer['fan_accepted_yaw_intervals']}个偏航区间、
{cam_peer['fan_parameter_refinement_rectangles']:,}个参数细分区间，其他组合648个角度父区间、3,888条配对记录；固定尾线完整区间另检。
三个互不重叠类别独立枚举，覆盖所有三次段组合。保守0.3mm目标保持。</p>
<p><a href="cam_peer_review_R1/index.html">CAM全范围内部配对及完整分类核对</a></p>
<p>CAM与电源／CC的12组跨组配对随后覆盖完整名义偏航／俯仰及闭曲线参数，通过原0.3mm目标。独立核对{cam_power_cross['cross_angular_rectangles']:,}个角度区间，必要组合另有{cam_power_cross['cross_parameter_refinement_rectangles']:,}个完整二维参数区间。结合6组CAM内部配对和3组电源／CC配对，7条已知上段全部21组互线组合无重复、无遗漏，PASS。</p>
<p><a href="cam_power_cross_review_R1/index.html">CAM与电源跨组及7条全部21组配对</a></p>
<p>四条头内固定尾线的非局部自身检查随后通过：每条130段三次曲线、16,000个闭参数区间，共64,000个区间。
理想俯仰坐标系内固定，覆盖全名义偏航／俯仰；只排除整段弧长上界≤5mm的局部相邻段，当前尾线曲率另检。
保守0.3mm下界不能当作实际最小线距；随后已完成活动段自身及上段内部接续检查。</p>
<p><a href="cam_self_review_R1/index.html">CAM固定尾线自身检查及范围</a></p>
<p>四条完整CAM上段的非局部自身检查随后独立通过：扇出48个偏航区间、其他活动组合2,592个二维角度区间，与固定尾线合并后独立枚举全部不重叠三次段组合。需要细分的组合覆盖{cam_upper_self['parameter_refinement_rectangles']:,}个二维参数区间；只排除完整弧长上界≤5mm的局部相邻段。原0.3mm目标及另检曲率要求保持；同一条线与身体前段的接续随后另检完成。</p>
<p><a href="cam_moving_self_review_R1/index.html">CAM完整上段自身检查与独立分类核对</a></p>
<p><a href="cam_native_clearance_review_R1/index.html">CAM全范围实体间隙及独立覆盖</a> · <a href="cam_math_review_R1/index.html">CAM数学检查及精度诊断</a> ·
<a href="cam_math_review_R1/nominal_math_readback.json">独立覆盖与曲线回读</a></p></section>
<section><h2>身体前段与七条上段的完整接续</h2><p>12条身体／颈部前段与7条已知上段的84组比较，覆盖全名义偏航／俯仰及完整闭曲线参数，PASS：7组同一线路接续的非局部自身接近、77组其他前段互线。独立核对{joins['prefix_upper_angular_rectangles']:,}个角度区间及必要组合{joins['prefix_upper_parameter_rectangles']:,}个二维参数区间，原0.3mm目标保持。</p>
<p>两侧各使用源线径参考，CAM身体段半径0.565mm、头内上段0.3302mm；实际材料和粗细线接续不由该参考定义。仅同一根线允许完整弧长上界≤5mm的局部排除，并计入数值连接余量。180个原身体曲线姿态、540次包络核对及105个原上段端点／切向／速度核对另检通过。</p>
<p><a href="prefix_upper_join_review_R1/index.html">完整84组接续与跨线检查</a> · <a href="prefix_upper_join_review_R1/join_coverage_verification.json">独立完整覆盖</a></p></section>
<section><h2>历史CAM极小角度诊断</h2><p>原检查在俯仰±0.00001°的四条CAM参考上产生异常保守曲率值。
对相同八条曲线，先将每个三次段平移到自身起点再细分，弯折下界检查通过；原控制点逐位保持。
这八个样本的异常定位到绝对坐标细分精度。后续更广检查还发现原框架复合和微弧构造问题，完整诊断与名义数学参考见上方新CAM检查；八个样本不能代表其全部数值问题。</p>
<p><a href="cam_zero_angle_review_R1/small_angle_inspection.json">原异常记录</a> ·
<a href="cam_zero_angle_review_R1/origin_precision_diagnostic.json">同曲线局部坐标诊断</a> ·
<a href="cam_zero_angle_review_R1/README.md">范围说明</a></p></section>
<section><h2>仍未完成的范围</h2><p>七条已知上段与身体前段的名义接续已完成。七条已知上段的全部21组互线及全部非局部自身检查也已单列通过；旧475姿态结果只属于原参考。
三条头舵机总线及两条喇叭线缺实际出口／接头信息。
实际材料、完整端接、应力释放、供应商线长、带线装头与闭壳仍未完成。</p>
<p>主模型M1.55、装配动画M1.55-A1与846个硬件文件保持。没有改动采购几何、打印件或PCB，manufacturing_release=false。</p></section>
<section><h2>原始证据</h2><p><a href="power_math_verification.json">完整区间数学检查</a> ·
<a href="power_math_readback.json">独立覆盖与曲线回读</a> · <a href="certify_power_math.log">实际执行日志</a> ·
<a href="endpoint_numeric_reserve.json">原端点修正的数值预留核对</a> ·
<a href="README.md">范围说明</a> · <a href="commands.json">工具版本与执行命令</a> ·
<a href="initial_triangle_bound/pilot_math.json">初版宽包络记录</a> ·
<a href="gradient_pilot_before_solver_update/source_archive_receipt.json">后续试探源字节保留</a></p></section></html>'''
    (HERE/'index.html').write_text(text)
    (HERE/'README.md').write_text(f'''# M1.55 上部电源与CC连续数学参考，未采用

P_J18_1、P_J18_2、CC_allocation 的全偏航／俯仰数值长度根及三次曲率检查通过。
二维角度区间共 {proof['accepted_rectangles']} 个；独立偏航分带覆盖与1,425条保存曲线对照通过。
原保存端点逐位保持；新根参考与保存控制点最大差 {check['maximum_fresh_root_curve_difference_mm']:.12g} mm。

三条参考与当前201实体的全名义偏航／俯仰间隙另经19,068个二维区间检查，通过原0.3mm目标。
独立复核完整数学父区间及9,216个闭曲线参数区间覆盖。运动采用理想名义旋转，
原Float32助手全角度舍入未资格化，实发USB外形仍未知。曲率标准沿用几何参考，未资格化实际线材。
三组电源／CC全范围互线间隙通过；源父区间交集及细分覆盖另经独立审计。
四条CAM新名义参考的全范围数值长度与弯折通过；原身体接续点及硬件零位保持，
但一致名义框架与80位构造不等于原浮点数组逐位一致。新参考与当前201件模型的全范围实体间隙随后独立通过；
2,592个数学父区间和完整曲线参数均覆盖。四条CAM内部6组互线及完整上段非局部自身检查随后通过；与电源／CC的12组跨组配对也已补齐，7条已知上段全部21组互线完整覆盖。身体前段接续随后另检完成，真实插头及材料仍未知。
原八个极小角度样本诊断保留为历史；更广检查发现框架复合及微弧构造问题，新参考已单列。
电源／CC完整上段自身随后通过；与CAM合并后，7条已知上段的全部非局部自身检查齐全。身体前段与上段的84组接续／跨线随后另检通过：7组自身接续和77组其他前段，{joins['prefix_upper_angular_rectangles']}个角度区间／{joins['prefix_upper_parameter_rectangles']}个参数区间独立核对。五条缺完整端点的线路仍未闭合。
材料、配对端接、固定、供应商制作图、带线装头与闭壳仍未完成。
主模型、视频与846个硬件文件保持；候选未采用；manufacturing_release=false。

初版宽包络的 BLOCKED 是数学包络不能判定，不是实物碰撞结论。
保留早期脚本／日志与实际源哈希，最终结果只使用当前全域检查及独立回读。
''')
    for p in [Path(__file__),HERE/'power_math_verification.json',HERE/'power_math_readback.json',
              HERE/'endpoint_numeric_reserve.json',HERE/'commands.json',
              HERE/'native_clearance_review_R1/native_verification.json',
              HERE/'native_clearance_review_R1/native_coverage_verification.json',
              HERE/'native_clearance_review_R1/commands.json',
              HERE/'cam_zero_angle_review_R1/small_angle_inspection.json',
              HERE/'cam_zero_angle_review_R1/origin_precision_diagnostic.json',
              HERE/'cam_zero_angle_review_R1/commands.json',
              HERE/'cam_math_review_R1/delivery.json',HERE/'cam_math_review_R1/publication_verification.json',
              HERE/'power_peer_review_R1/delivery.json',HERE/'power_peer_review_R1/publication_verification.json',
              HERE/'cam_native_clearance_review_R1/delivery.json',HERE/'cam_native_clearance_review_R1/publication_verification.json',
              HERE/'cam_self_review_R1/delivery.json',HERE/'cam_self_review_R1/publication_verification.json',
              HERE/'cam_peer_review_R1/delivery.json',HERE/'cam_peer_review_R1/publication_verification.json',
              HERE/'cam_moving_self_review_R1/delivery.json',HERE/'cam_moving_self_review_R1/publication_verification.json',
              HERE/'cam_power_cross_review_R1/delivery.json',HERE/'cam_power_cross_review_R1/publication_verification.json',
              HERE/'power_self_review_R1/delivery.json',HERE/'power_self_review_R1/publication_verification.json',
              HERE/'prefix_upper_join_review_R1/delivery.json',HERE/'prefix_upper_join_review_R1/publication_verification.json']:
        sources[str(p)]=sha(p)
    files={str(p.relative_to(HERE)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ['delivery.json','publication_verification.json','current_status_update.json']}
    receipt=dict(status='PASS',scope='Seven nominal reference math/native proofs, three power pair proofs and scoped diagnostics; not physical wiring',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,files=files,
        source_blend_sha256=check['source_blend_sha256'],source_video_sha256=check['source_video_sha256'],
        continuous_power_root_and_bending='PASS',accepted_rectangles=proof['accepted_rectangles'],summaries=summaries,
        saved_source_curve_poses=1425,offgrid_source_comparisons=18,
        continuous_native_clearance='PASS',continuous_peer_clearance='PASS',
        power_peer_angular_rectangles=peer['accepted_rectangles'],power_peer_source_intersections=peer['source_parent_intersections'],
        power_peer_unordered_pairs=3,power_continuous_remote_self='PASS',
        power_self_angular_rectangles=power_self['power_self_angular_rectangles'],
        power_self_parameter_rectangles=power_self['power_self_parameter_rectangles'],
        known_upper_continuous_remote_self='PASS',known_upper_remote_self_references=7,
        native_angular_rectangles=19068,native_parts=201,whole_parameter_cells=9216,
        native_frame=native['native_frame'],source_float32_all_angle_rounding='NOT_TESTED',
        minimum_certified_native_gap_lower_mm=native_check['minimum_certified_native_gap_lower_mm'],
        CAM_tiny_angle_origin_diagnostic='PASS',CAM_tiny_angle_diagnosed_samples=8,
        continuous_CAM_math='PASS',CAM_math_scope='New consistent nominal frame and80-digit construction; old sampled gaps not inherited',
        CAM_positive_length_rectangles=2592,CAM_bending_yaw_intervals=48,CAM_saved_curve_readbacks=1900,
        CAM_continuous_native_clearance='PASS',CAM_native_angular_rectangles=cam_native['accepted_rectangles'],
        CAM_native_source_math_rectangles=2592,CAM_whole_parameter_cells=cam_native['parameter_cells_per_reference'],
        CAM_minimum_certified_native_gap_lower_mm=cam_native['minimum_certified_native_gap_lower_mm'],
        CAM_continuous_peer_clearance='PASS',CAM_peer_unordered_pairs=6,
        CAM_peer_fan_yaw_intervals=cam_peer['fan_accepted_yaw_intervals'],
        CAM_peer_fan_parameter_rectangles=cam_peer['fan_parameter_refinement_rectangles'],
        CAM_peer_mixed_angular_rows=3888,CAM_power_cross_pairs='PASS',CAM_power_cross_unordered_pairs=12,
        CAM_power_cross_angular_rectangles=cam_power_cross['cross_angular_rectangles'],
        CAM_power_cross_parameter_refinement_rectangles=cam_power_cross['cross_parameter_refinement_rectangles'],
        known_upper_continuous_mutual='PASS',known_upper_unordered_pairs=21,known_upper_native_references=7,
        CAM_fixed_tail_remote_self='PASS',CAM_fixed_tail_self_parameter_cells=64000,
        CAM_moving_lower_self='PASS',CAM_continuous_upper_remote_self='PASS',CAM_own_prefix='PASS',
        known_continuous_own_prefix='PASS',known_continuous_other_prefix='PASS',
        prefix_upper_comparisons=84,own_prefix_pairs=7,other_prefix_pairs=77,
        prefix_upper_angular_rectangles=joins['prefix_upper_angular_rectangles'],
        prefix_upper_parameter_rectangles=joins['prefix_upper_parameter_rectangles'],
        CAM_self_fan_angular_rectangles=48,CAM_self_mixed_angular_rectangles=2592,
        CAM_self_parameter_refinement_rectangles=cam_upper_self['parameter_refinement_rectangles'],
        unpublished_research_directories=[],
        actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',
        main_changed=False,animation_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('UPPER_POWER_MATH_PUBLISHED',len(files),len(sources),proof['accepted_rectangles'],flush=True)


if __name__=='__main__':main()
