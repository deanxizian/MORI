"""Guarded power-upper controls and coherent per-cubic arc-speed bounds.

Polynomial derivative controls are enclosed by applying 3*diff(H) to the
coherent source six-control family before taking interval boxes. The same
ideal yaw frame and documented operator/affine residual bounds are used as
the existing native-control proof. Convexity bounds the norm of every
quadratic derivative by the maximum norm of its three control vectors.

The neck stub uses the already guarded local velocity controls and the
source yaw matrix's singular-value upper 1+ey. The separately certified
Float64 endpoint-repair component bound is included in derivative and join
reserves. These are nominal mathematical bounds, not supplier cut lengths.
"""
from pathlib import Path
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT/'native_clearance_review_R1'),str(ROOT)]
from power_native_envelopes import NativeEnvelopes, NAMES, Box, rotate_box, sha
from power_enclosures import magnitude

NUMERIC = 1e-8


class PowerSelfEnvelopes:
    def __init__(self):
        self.e = NativeEnvelopes(poly_steps=1,stub_steps=1)
        proof_path = ROOT/'power_math_verification.json'
        endpoint_path = ROOT/'endpoint_numeric_reserve.json'
        proof = json.loads(proof_path.read_text())
        endpoint = json.loads(endpoint_path.read_text())
        assert proof['status']==endpoint['status']=='PASS'
        assert all(sha(p)==h for p,h in endpoint['sources'].items())
        self.parents = {n:[r for r in proof['rows'] if r['wire']==n] for n in NAMES}
        self.bounds = {n:np.array([r['rectangle_deg'] for r in rows]) for n,rows in self.parents.items()}
        self.repair = {r['wire']:r['endpoint_repair_component_bound_mm'] for r in endpoint['rows']}
        self.radius_requirements = {}
        for n,rows in self.parents.items():
            assert all(r['status']=='PASS' and r['continuous_bending']['status']=='PASS'
                       and r['continuous_bending']['derivative_nonzero'] for r in rows)
            requirements = {r['continuous_bending']['required_radius_mm'] for r in rows}
            assert len(requirements)==1
            required = next(iter(requirements))
            assert min(r['continuous_bending']['radius_lower_mm'] for r in rows)>=required
            self.radius_requirements[n] = required
        H = self.e.e.H
        assert H.shape==(128,4,6) and len(self.e.parameter_cells)==129
        assert np.array_equal(H[:-1,-1],H[1:,0])
        self.V = 3*np.diff(H,axis=1)
        self.sources = dict(self.e.sources)
        for p in [Path(__file__),proof_path,endpoint_path]:
            self.sources[str(p)] = sha(p)

    def certificate(self,name,rectangle):
        yl,yh,pl,ph = rectangle
        bounds = self.bounds[name]
        indices = np.flatnonzero((bounds[:,0]<yh)&(bounds[:,1]>yl)&(bounds[:,2]<ph)&(bounds[:,3]>pl))
        assert len(indices)
        rows = [self.parents[name][i] for i in indices]
        lo = min(r['midpoint_amplitude_mm']-r['amplitude_deviation_bound_mm'] for r in rows)
        hi = max(r['midpoint_amplitude_mm']+r['amplitude_deviation_bound_mm'] for r in rows)
        return dict(status='PASS',wire=name,rectangle_deg=list(rectangle),
                    parent_indices=[int(i) for i in indices],method='guarded_parent_union',
                    midpoint_amplitude_mm=(lo+hi)/2,amplitude_deviation_bound_mm=(hi-lo)/2+1e-9)

    def controls(self,name,rectangle,certificate,group):
        a = self.e.stub_boxes(name,rectangle,group)
        b = self.e.polynomial_boxes(name,rectangle,certificate,group)
        return Box(np.concatenate([a.lo,b.lo]),np.concatenate([a.hi,b.hi]))

    def speeds(self,name,rectangle,certificate):
        operator = self.V.reshape(-1,6)
        F,K,first,last,total = self.e.split_local(name,rectangle,operator)
        a,w = certificate['midpoint_amplitude_mm'],certificate['amplitude_deviation_bound_mm']
        F = F+Box(a-w,a+w)*(operator@self.e.e.D)
        yl,yh,pl,ph = rectangle
        velocity = F+rotate_box(K,pl,ph,'X')+total[:,None]*self.e.center
        # The linear-operator source residual bounds apply to derivative rows
        # as well as position rows; the common centre cancels in exact rows.
        error = (self.e.e.ey*magnitude(F).hi+self.e.e.et*np.linalg.norm(K,axis=1)
                 +self.e.e.ty*abs(first)+self.e.e.tt*abs(last)
                 +6*self.repair[name]+NUMERIC)
        velocity = velocity+Box(-error[:,None],error[:,None])
        polynomial = magnitude(velocity).hi.reshape(128,3).max(1)
        _,stub = self.e.e.inputs(name,*rectangle)
        stub_speed = float(magnitude(stub).hi.max())*(1+self.e.e.ey)+NUMERIC
        result = np.r_[stub_speed,polynomial]+NUMERIC
        assert result.shape==(129,) and np.all(result>0)
        return result

    def join_upper(self,name):
        # Converted polynomial neighbours use identical source endpoint
        # operators. Only explicit Float64 endpoint restoration needs a
        # reserve; including it on every join is conservative.
        value = 4*np.sqrt(3)*self.repair[name]+NUMERIC
        return np.full(128,value,dtype=float)

    def unchanged(self):
        self.e.unchanged()
        assert all(sha(p)==h for p,h in self.sources.items())


def arc_upper(densities,joins,i,j,rectangle):
    ta,tb,ua,ub = rectangle
    if i==j:
        return float(densities[i])*(max(tb,ub)-min(ta,ua))
    assert i<j
    return (float(densities[i])*(1-ta)+float(densities[i+1:j].sum())
            +float(densities[j])*ub+float(joins[i:j].sum()))
