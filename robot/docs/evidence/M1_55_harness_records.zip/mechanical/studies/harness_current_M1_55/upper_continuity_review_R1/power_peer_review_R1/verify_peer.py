"""Independent root-partition intersection and pair-clearance coverage audit.

The checker does not import the proof generator or its intersection routine.
It reconstructs intersections using a yaw sweep and pitch interval merge,
then checks all refinement leaves against every reconstructed source base.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys

HERE = Path(__file__).resolve().parent
MATH = HERE.parent
PROJECT = HERE.parents[4]
NAMES = ['P_J18_1', 'P_J18_2', 'CC_allocation']
DOMAIN = (-60, 60, -20, 25)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def coverage(boxes, base):
    assert boxes
    assert all(base[0] <= b[0] < b[1] <= base[1] and
               base[2] <= b[2] < b[3] <= base[3] for b in boxes)
    edges = sorted({x for b in boxes for x in b[:2]})
    assert (edges[0], edges[-1]) == base[:2]
    for left, right in zip(edges[:-1], edges[1:]):
        mid = (left + right) / 2
        strips = sorted(b[2:] for b in boxes if b[0] < mid < b[1])
        assert strips and strips[0][0] == base[2] and strips[-1][1] == base[3]
        assert all(a[1] == b[0] for a, b in zip(strips[:-1], strips[1:])), strips
    return len(edges) - 1


def independent_intersections(left_rows, right_rows, windows):
    left = [tuple(r['rectangle_deg']) for r in left_rows]
    right = [tuple(r['rectangle_deg']) for r in right_rows]
    coverage(left, DOMAIN)
    coverage(right, DOMAIN)
    edges = sorted({v for b in left + right for v in b[:2]})
    discovered = {}
    for yl, yh in zip(edges[:-1], edges[1:]):
        y = (yl + yh) / 2
        a = sorted((b[2], b[3], i) for i, b in enumerate(left) if b[0] < y < b[1])
        b = sorted((r[2], r[3], i) for i, r in enumerate(right) if r[0] < y < r[1])
        ai = bi = 0
        while ai < len(a) and bi < len(b):
            al, ah, ia = a[ai]
            bl, bh, ib = b[bi]
            if max(al, bl) < min(ah, bh):
                la, rb = left[ia], right[ib]
                base = (max(la[0], rb[0]), min(la[1], rb[1]), max(al, bl), min(ah, bh))
                assert base[0] <= yl < yh <= base[1]
                if (ia, ib) in discovered:
                    assert discovered[ia, ib] == base
                discovered[ia, ib] = base
            if ah <= bh:
                ai += 1
            if bh <= ah:
                bi += 1
        assert ai == len(a) and bi == len(b)
    result = {}
    for (ia, ib), base in discovered.items():
        for w in windows:
            clipped = (max(base[0], w[0]), min(base[1], w[1]),
                       max(base[2], w[2]), min(base[3], w[3]))
            if clipped[0] < clipped[1] and clipped[2] < clipped[3]:
                result[ia, ib, clipped] = []
    return result


def main():
    pilot = '--pilot' in sys.argv
    path = HERE / ('math_cover_pilot_verification.json' if pilot else 'peer_verification.json')
    proof = read(path)
    assert proof['status'] == 'PASS' and proof['mode'] == ('pilot' if pilot else 'all_angles')
    assert proof['required_gap_mm'] == .3 and proof['query_numeric_reserve_mm'] == .0001
    assert proof['parameter_cells_per_reference'] == 9216 and not proof['failures']
    assert proof['yaw_range_deg'] == [-60, 60] and proof['pitch_range_deg'] == [-20, 25]
    assert proof['nearest_neighbours_per_initial_field_query'] == 1
    assert proof['reference_anchor_policy'].startswith('Exact rectangle midpoint')
    assert not any(proof[k] for k in ['main_changed', 'hardware_changed', 'animation_changed', 'manufacturing_release'])
    assert all(sha(p) == h for p, h in proof['sources'].items())
    raw_path = Path(proof['core_report_path'])
    assert sha(raw_path) == proof['core_report_sha256']
    raw = read(raw_path)
    for key in ['results', 'failures', 'mode', 'required_gap_mm', 'minimum_certified_gap_lower_mm',
                'visited_rectangles', 'new_root_enclosures']:
        assert raw[key] == proof[key], key
    assert raw['anchor_distance_queries'] == proof['anchor_query_allocation_units_in_core']
    assert proof['anchor_distance_queries'] == proof['fields_created'] * 9216
    assert proof['anchor_query_allocation_units_in_core'] == proof['anchor_distance_queries'] * 64
    math_path = MATH / 'power_math_verification.json'
    math = read(math_path)
    assert math['status'] == 'PASS' and math['names'] == NAMES
    assert all(sha(p) == h for p, h in math['sources'].items())
    parents = {n: [r for r in math['rows'] if r['wire'] == n] for n in NAMES}
    windows = [tuple(w) for w in proof['pilot_windows']] if pilot else [DOMAIN]
    assert len(proof['results']) == 3
    pairs = [tuple(r['wires']) for r in proof['results']]
    assert pairs == list(itertools.combinations(NAMES, 2))
    counts = []
    total_bases = total_leaves = strips = 0
    minimum = float('inf')
    groups = set()
    for result in proof['results']:
        assert result['status'] == 'PASS'
        a, b = result['wires']
        expected = independent_intersections(parents[a], parents[b], windows)
        assert result['source_parent_intersections'] == len(expected)
        assert result['accepted_rectangles'] == len(result['intervals'])
        for leaf in result['intervals']:
            ia, ib = leaf['source_math_parent_indices']
            base = tuple(leaf['base_rectangle_deg'])
            assert (ia, ib, base) in expected
            rectangle = tuple(leaf['rectangle_deg'])
            expected[ia, ib, base].append(rectangle)
            assert leaf['status'] == 'PASS' and leaf['gap_lower_mm'] >= .3
            assert leaf['anchor_point_surface_gap_mm'] >= .3
            assert leaf['group'] in ['yaw', 'pitch']
            assert leaf['reference_pose_deg'] == [(rectangle[0]+rectangle[1])/2,
                                                  (rectangle[2]+rectangle[3])/2]
            assert all(r >= 0 for r in leaf['maximum_complete_parameter_radius_mm'])
            assert 0 <= leaf['exclusion_sphere_queries'] <= 9216
            assert leaf['candidate_pairs_checked'] >= 0
            if leaf['root_ranges_reused']:
                assert rectangle == base
            minimum = min(minimum, leaf['gap_lower_mm'])
            groups.add(leaf['group'])
        for (_, _, base), boxes in expected.items():
            strips += coverage(boxes, base)
        counts.append(dict(wires=[a,b],source_parent_intersections=len(expected),
                           accepted_rectangles=len(result['intervals'])))
        total_bases += len(expected)
        total_leaves += len(result['intervals'])
    assert minimum == proof['minimum_certified_gap_lower_mm']
    crossed = []
    for name in ['parameter_ball_crosscheck.json', 'weighted_single_crosscheck.json']:
        q = HERE / name
        test = read(q)
        assert test['status'] == 'PASS'
        assert all(sha(p) == h for p, h in test['sources'].items())
        crossed.append(q)
    baseline = read(PROJECT / 'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT/p) == h for p,h in protected.items())
    blend = PROJECT / 'mechanical/mori_v1_2.blend'
    video = PROJECT / 'mechanical/animation/MORI_assembly.mp4'
    assert sha(blend) == '3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video) == '9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = dict(proof['sources'])
    for q in [Path(__file__), path, math_path, *crossed]:
        sources[str(q)] = sha(q)
    out = dict(status='PASS',mode=proof['mode'],recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='Independent full source-partition intersections and leaf coverage; guarded pair geometry proof, not physical wiring',
               sources=sources,unordered_pairs=3,pair_counts=counts,source_parent_intersections=total_bases,
               accepted_rectangles=total_leaves,independent_y_slab_checks=strips,common_frames=sorted(groups),
               parameter_cells_per_reference=9216,minimum_certified_gap_lower_mm=minimum,required_gap_mm=.3,
               anchor_distance_queries=proof['anchor_distance_queries'],fields_created=proof['fields_created'],
               anchor_query_allocation_units_in_core=proof['anchor_query_allocation_units_in_core'],
               core_raw_scope_note='The inherited raw scope string names yaw; per-leaf groups and this audit include yaw and pitch.',
               source_blend_sha256=sha(blend),source_video_sha256=sha(video),protected_hardware_files=846,
               remote_self='NOT_TESTED',CAM_upper='NOT_TESTED',full_harness='BLOCKED',main_changed=False,
               hardware_changed=False,animation_changed=False,manufacturing_release=False)
    target = HERE / ('pilot_coverage_verification.json' if pilot else 'peer_coverage_verification.json')
    target.write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PEER_COVERAGE_PASS',out['mode'],total_bases,total_leaves,strips,846,flush=True)


if __name__ == '__main__':
    main()
