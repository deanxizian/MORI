"""Independent original-source velocity and join probes of the new arc bounds.

These samples check implementation; complete-angle clearance follows only
from the interval derivative and parameter proofs, not finite probes.
"""
from pathlib import Path
import datetime
import json
import time
import numpy as np
from power_self_envelopes import PowerSelfEnvelopes,NAMES,sha

HERE = Path(__file__).resolve().parent


def main():
    started = time.time()
    e = PowerSelfEnvelopes()
    windows = [(-60.,-50.,-20.,-15.),(-10.,0.,0.,5.),(50.,60.,20.,25.)]
    rows = []
    minimum_speed_reserve = float('inf')
    minimum_join_reserve = float('inf')
    for name in NAMES:
        for rectangle in windows:
            certificate = e.certificate(name,rectangle)
            density = e.speeds(name,rectangle,certificate)
            joins = e.join_upper(name)
            yl,yh,pl,ph = rectangle
            for y,p in [(yl,pl),(yh,ph),(yl,ph),(yh,pl),((yl+yh)/2,(pl+ph)/2)]:
                source,metrics = e.e.e.f.upper(name,y,p)
                assert source is not None
                derivative_controls = 3*np.diff(source,axis=1)
                maximum_speed = np.linalg.norm(derivative_controls,axis=2).max(1)
                speed_reserve = float((density-maximum_speed).min())
                jumps = np.linalg.norm(source[:-1,-1]-source[1:,0],axis=1)
                join_reserve = float((joins-jumps).min())
                assert speed_reserve>=0 and join_reserve>=0,(name,rectangle,y,p,speed_reserve,join_reserve)
                minimum_speed_reserve = min(minimum_speed_reserve,speed_reserve)
                minimum_join_reserve = min(minimum_join_reserve,join_reserve)
                rows.append(dict(wire=name,rectangle_deg=list(rectangle),pose_deg=[y,p],status='PASS',
                                 cubic_pieces=len(source),minimum_speed_upper_reserve_mm=speed_reserve,
                                 maximum_source_join_jump_mm=float(jumps.max()),minimum_join_upper_reserve_mm=join_reserve))
        print('POWER_SELF_SPEED_WIRE',name,len(rows),round(time.time()-started,1),flush=True)
    e.unchanged()
    sources = dict(e.sources)
    sources[str(Path(__file__))] = sha(Path(__file__))
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               scope='45 independent original-construction velocity/join probes only; not a continuous self-clearance proof',
               sources=sources,rows=rows,source_pose_comparisons=45,derivative_control_vectors=45*129*3,
               minimum_speed_upper_reserve_mm=minimum_speed_reserve,
               minimum_join_upper_reserve_mm=minimum_join_reserve,
               radius_requirements_mm=e.radius_requirements,remote_self='NOT_TESTED',
               full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
               manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'speed_bound_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_SELF_SPEED_PASS',45,out['derivative_control_vectors'],round(out['elapsed_s'],1),flush=True)


if __name__ == '__main__':
    main()
