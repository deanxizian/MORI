"""Independent mathematical-parent and six-pair leaf coverage audit.

This checker does not import the generator, its clipping routine, or the
clearance algorithm. It verifies their guarded source chain and reconstructs
each required closed angular rectangle from the retained mathematical report.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys

HERE = Path(__file__).resolve().parent
MATH = HERE.parent
PROJECT = HERE.parents[4]
NAMES = ['CAM_1','CAM_2','CAM_3','CAM_4']
DOMAIN = (-60.,60.,-20.,25.)
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p:json.loads(Path(p).read_text())


def coverage(boxes,base):
    assert boxes
    assert all(base[0]<=b[0]<b[1]<=base[1] and
               base[2]<=b[2]<b[3]<=base[3] for b in boxes)
    edges = sorted({v for b in boxes for v in b[:2]})
    assert (edges[0],edges[-1])==base[:2]
    for left,right in zip(edges[:-1],edges[1:]):
        center = (left+right)/2
        strips = sorted(b[2:] for b in boxes if b[0]<center<b[1])
        assert strips and strips[0][0]==base[2] and strips[-1][1]==base[3]
        assert all(a[1]==b[0] for a,b in zip(strips[:-1],strips[1:])),strips
    return len(edges)-1


def main():
    pilot = '--pilot' in sys.argv
    adaptive = '--adaptive' in sys.argv
    pilot_name = 'pilot_adaptive_verification.json' if adaptive else 'pilot_verification.json'
    path = HERE/(pilot_name if pilot else 'peer_verification.json')
    proof = read(path)
    assert proof['status']=='PASS' and proof['mode']==('pilot' if pilot else 'all_angles')
    assert not proof['failures']
    assert proof['required_gap_mm']==.3 and proof['query_numeric_reserve_mm']==.0001
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    expected_cells = dict(CAM_1=29632,CAM_2=29632,CAM_3=28608,CAM_4=28608)
    assert proof['parameter_cells_per_reference']==expected_cells
    assert proof['nearest_neighbours_per_initial_field_query']==1
    assert proof['reference_anchor_policy']=='Exact rectangle midpoint'
    assert not any(proof[k] for k in ['main_changed','hardware_changed','animation_changed','manufacturing_release'])
    assert all(sha(p)==h for p,h in proof['sources'].items())
    math_path = MATH/'cam_math_review_R1/nominal_math_verification.json'
    math = read(math_path)
    assert math['status']=='PASS' and all(sha(p)==h for p,h in math['sources'].items())
    parents = {n:[r for r in math['length_rectangles'] if r['wire']==n] for n in NAMES}
    parent_boxes = [tuple(r['rectangle_deg']) for r in parents[NAMES[0]]]
    assert len(parent_boxes)==648
    coverage(parent_boxes,DOMAIN)
    assert all([tuple(r['rectangle_deg']) for r in parents[n]]==parent_boxes for n in NAMES)
    windows = [tuple(w) for w in proof['pilot_windows']] if pilot else [DOMAIN]
    expected = {}
    for index,box in enumerate(parent_boxes):
        for window in windows:
            clipped = (max(box[0],window[0]),min(box[1],window[1]),
                       max(box[2],window[2]),min(box[3],window[3]))
            if clipped[0]<clipped[1] and clipped[2]<clipped[3]:
                assert (index,clipped) not in expected
                expected[index,clipped] = []
    assert proof['source_parent_rectangles']==[
        dict(source_math_parent_index=index,rectangle_deg=list(box)) for index,box in expected]
    assert [tuple(r['wires']) for r in proof['results']]==list(itertools.combinations(NAMES,2))
    assert [tuple(r['wires']) for r in proof['fixed_tail_pairs']]==list(itertools.combinations(NAMES,2))
    assert all(r['status']=='PASS' and r['gap_lower_mm']>=.3 and r['group']=='pitch'
               for r in proof['fixed_tail_pairs'])
    assert all(0<proof['variable_prefix_parameter_cells'][n]<expected_cells[n] for n in NAMES)
    assert all(r['candidate_pairs_checked']>=0 and r['exclusion_sphere_queries']>0
               for r in proof['fixed_tail_pairs'])
    minimum = float('inf')
    total_leaves = total_strips = 0
    pair_counts = []
    frames = set()
    for result in proof['results']:
        assert result['status']=='PASS' and result['accepted_rectangles']==len(result['intervals'])
        required = {key:[] for key in expected}
        for row in result['intervals']:
            index = row['source_math_parent_index']
            base = tuple(row['base_rectangle_deg'])
            rectangle = tuple(row['rectangle_deg'])
            assert (index,base) in required
            required[index,base].append(rectangle)
            assert row['status']=='PASS' and row['gap_lower_mm']>=.3
            assert row['anchor_point_surface_gap_mm']>=.3 and row['fixed_tail_reused']
            assert row['reference_pose_deg']==[(rectangle[0]+rectangle[1])/2,
                                               (rectangle[2]+rectangle[3])/2]
            assert [q['kinds'] for q in row['subgroups']]==[
                ['lower','lower'],['lower','tail'],['tail','lower']]
            fixed = next(q for q in proof['fixed_tail_pairs'] if q['wires']==result['wires'])
            assert row['gap_lower_mm']==min([q['gap_lower_mm'] for q in row['subgroups']]+[fixed['gap_lower_mm']])
            for q in row['subgroups']:
                assert q['status']=='PASS' and q['gap_lower_mm']>=.3
                assert q['group'] in ['yaw','pitch']
                assert q['reference_pose_deg']==row['reference_pose_deg']
                assert q['anchor_point_surface_gap_mm']>=.3
                assert all(r>=0 for r in q['maximum_complete_parameter_radius_mm'])
                count = proof['variable_prefix_parameter_cells'][result['wires'][0]]
                if q['kinds'][0]=='tail':
                    count = expected_cells[result['wires'][0]]-count
                assert 0<=q['worst_parameter_cell_index']<count
                assert 0<=q['exclusion_sphere_queries']<=count
                assert q['candidate_pairs_checked']>=0
                frames.add(q['group'])
            if row['root_ranges_reused']:
                assert rectangle==base
            minimum = min(minimum,row['gap_lower_mm'])
        strips = sum(coverage(boxes,base) for (_,base),boxes in required.items())
        total_strips+=strips
        total_leaves+=len(result['intervals'])
        pair_counts.append(dict(wires=result['wires'],source_parent_rectangles=len(required),
                                accepted_rectangles=len(result['intervals']),y_slab_checks=strips))
    assert minimum==proof['minimum_certified_gap_lower_mm']
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p:h for p,h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    blend = PROJECT/'mechanical/mori_v1_2.blend'
    video = PROJECT/'mechanical/animation/MORI_assembly.mp4'
    assert sha(blend)=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(video)=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources = dict(proof['sources'])
    for p in [Path(__file__),path,math_path]:
        sources[str(p)] = sha(p)
    out = dict(status='PASS',mode=proof['mode'],
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        scope='Independent exact parent partition and all six CAM mutual leaf covers; not physical wiring',
        unordered_pairs=6,source_parent_rectangles=len(expected),
        pair_counts=pair_counts,accepted_pair_rectangles=total_leaves,
        independent_y_slab_checks=total_strips,common_frames=sorted(frames),
        parameter_cells_per_reference=expected_cells,
        variable_prefix_parameter_cells=proof['variable_prefix_parameter_cells'],
        fixed_tail_pairs=proof['fixed_tail_pairs'],
        minimum_certified_gap_lower_mm=minimum,required_gap_mm=.3,
        protected_hardware_files=846,source_blend_sha256=sha(blend),source_video_sha256=sha(video),
        remote_self='NOT_TESTED',own_prefix='NOT_TESTED',other_upper_pairs='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    target_name = 'pilot_adaptive_coverage_verification.json' if adaptive else 'pilot_coverage_verification.json'
    target = HERE/(target_name if pilot else 'peer_coverage_verification.json')
    target.write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_PEER_COVERAGE_PASS',out['mode'],len(expected),total_leaves,total_strips,846,flush=True)


if __name__=='__main__':
    main()
