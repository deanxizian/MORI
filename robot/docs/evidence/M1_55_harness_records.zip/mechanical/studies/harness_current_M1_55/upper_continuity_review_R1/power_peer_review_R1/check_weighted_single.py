"""Independent exact-all-pair checks for the one-neighbour query policy."""
from pathlib import Path
import datetime,hashlib,json,sys
import numpy as np
sys.path.insert(0,'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313')
from weighted_peer import field,score
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    rng=np.random.default_rng(551174);rows=[];pairs=0
    for case in range(15):
        a=rng.normal(size=(250,3));b=rng.normal(size=(400,3))+[case%4*2,0,0]
        ra=rng.uniform(0,.4,len(a));rb=rng.uniform(0,1.8,len(b));rsum=.2
        if case==14:
            a=np.zeros((1,3));b=np.array([[1.5,0,0],[2.5,0,0]])
            ra=np.array([.04]);rb=np.array([0.,2.1]);rsum=.1
        value=score(field(a,b,k=1),ra,rb,rsum)
        exact=(np.linalg.norm(a[:,None]-b[None,:],axis=-1)-ra[:,None]-rb[None,:]-rsum-.0001).min(1)
        assert np.max(value['lower']-exact)<=1e-10
        if value['gap_lower_mm']>=.3:assert exact.min()>=.3
        if case==14:assert value['exclusion_sphere_queries']==1 and value['gap_lower_mm']<.3
        rows.append(dict(case=case,status='PASS',exact_gap_min_mm=float(exact.min()),gap_lower_mm=value['gap_lower_mm'],
                         maximum_lower_minus_exact_mm=float(np.max(value['lower']-exact)),
                         exclusion_sphere_queries=value['exclusion_sphere_queries'],candidate_pairs_checked=value['candidate_pairs_checked']))
        pairs+=len(a)*len(b)
    result=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                scope='One-neighbour exact-all-pair algorithm checks, including a distant high-radius centre; not route clearance',
                sources={str(p):sha(p) for p in [Path(__file__),HERE/'weighted_peer.py']},rows=rows,exact_pairs_compared=pairs,
                main_changed=False,hardware_changed=False,manufacturing_release=False)
    (HERE/'weighted_single_crosscheck.json').write_text(json.dumps(result,indent=2)+'\n')
    print('WEIGHTED_SINGLE_BRUTE_PASS',len(rows),pairs,flush=True)


if __name__=='__main__':main()
