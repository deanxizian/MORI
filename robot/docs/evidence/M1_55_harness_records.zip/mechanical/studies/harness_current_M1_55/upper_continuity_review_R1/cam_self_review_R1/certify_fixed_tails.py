"""Remote-self checks of all four unchanged head-local CAM fixed tails.

Tail-only geometry is invariant under the consistent ideal pitch frame. This
does not check the flexible fan/return, its own prefix, or upper/lower joins.
Local <=5mm arc pairs have a separately checked conservative cubic curvature
bound; all other pairs use complete closed parameter-cell boxes.
"""
from pathlib import Path
import datetime
import json
import sys
import time
import numpy as np
HERE = Path(__file__).resolve().parent
MATH = HERE.parent
NATIVE = MATH/'cam_native_clearance_review_R1'
sys.path[:0] = [str(NATIVE),
               '/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313']
from cam_native_envelopes import NativeCAMEnvelopes,NAMES,RADII,Box,linear,sha
from stable_bending import radius_bound
from self_box_distance import score


def main():
    started = time.time()
    e = NativeCAMEnvelopes()
    cross_path = HERE/'self_box_crosscheck.json'
    cross = json.loads(cross_path.read_text())
    assert cross['status']=='PASS' and all(sha(p)==h for p,h in cross['sources'].items())
    sources = dict(e.sources)
    for p in [Path(__file__),HERE/'self_box_distance.py',cross_path,NATIVE/'envelope_crosscheck.json']:
        sources[str(p)] = sha(p)
    envelope_cross = json.loads((NATIVE/'envelope_crosscheck.json').read_text())
    assert envelope_cross['status']=='PASS' and all(sha(p)==h for p,h in envelope_cross['sources'].items())
    rows = []
    for name in NAMES:
        height = e.saved_heights[name,0.,0.]
        certificate = dict(height_lower_mm=height,height_upper_mm=height)
        box = e.point_boxes(name,(0.,0.,0.,0.),certificate,'pitch')
        tail_index = e.layout[name]['tail_index']
        start = int(np.count_nonzero(e.layout[name]['parameter_cells'][:,0]<tail_index))
        controls = Box(e.tail[name]-1e-8,e.tail[name]+1e-8)
        arc_cells = []
        for i,operator in enumerate(e.operators[name][tail_index:]):
            difference = operator[:,1:]-operator[:,:-1]
            d = linear(difference.reshape(-1,4),controls[i])
            maximum = np.maximum(abs(d.lo),abs(d.hi)).reshape(-1,3,3)
            lengths = np.linalg.norm(maximum,axis=2).sum(1)+1e-9
            arc_cells.append(lengths)
        arc_cells = np.concatenate(arc_cells)
        arc_upper = np.r_[0.,np.cumsum(arc_cells)]
        assert len(arc_upper)==len(box.lo[start:])+1 and np.all(np.diff(arc_upper)>0)
        bending = radius_bound(e.tail[name])
        # Tail geometric curvature and tube radius use the same nominal data.
        assert bending['radius_lower_mm']>=6.9342
        checked = score(box.lo[start:],box.hi[start:],arc_upper,RADII[name])
        rows.append(dict(wire=name,tail_first_piece=tail_index,parameter_cells=len(arc_cells),
                         reference_radius_mm=RADII[name],whole_tail_arc_upper_mm=float(arc_upper[-1]),
                         local_curvature=bending,**checked))
        print('CAM_FIXED_TAIL_SELF',name,checked['status'],len(arc_cells),
              checked['remote_box_pairs_checked'],round(time.time()-started,1),flush=True)
    e.unchanged()
    assert all(sha(p)==h for p,h in sources.items())
    out = dict(status='PASS' if all(r['status']=='PASS' for r in rows) else 'BLOCKED',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
        scope='Four head-local fixed-tail remote-self references only; flexible/own-prefix self incomplete',
        rows=rows,yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
        invariant_frame='Ideal common pitch frame; no approximate transform interpolation',
        required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,local_radius_requirement_mm=6.9342,
        minimum_certified_gap_lower_mm=min(r['gap_lower_mm'] for r in rows),
        moving_lower_self='NOT_TESTED',own_prefix='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'fixed_tail_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FIXED_TAIL_SELF_TERMINAL',out['status'],len(rows),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
