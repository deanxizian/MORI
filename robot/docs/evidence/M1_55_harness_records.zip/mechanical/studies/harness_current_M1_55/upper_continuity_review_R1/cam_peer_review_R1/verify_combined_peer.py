"""Independent enumeration of the complete six-pair piece products.

Read the retained canonical layout and component audits without importing the
combiner. Every piece pair belongs to exactly one of fan/fan, fixed tail/tail,
or the full two-angle mixed cover. These exhaustive, disjoint categories
prove the assembled nominal upper-pair scope; physical wiring stays blocked.
"""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys
import numpy as np
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[4]
sys.path[:0]=[str(HERE.parent/'cam_native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes,NAMES
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())


def main():
    path=HERE/'combined_peer_verification.json';proof=read(path)
    assert proof['status']==proof['continuous_nominal_CAM_mutual']=='PASS'
    assert all(sha(p)==h for p,h in proof['sources'].items())
    fan=read(HERE/'fan_coverage_verification.json')
    mixed=read(HERE/'remaining_hull_coverage_verification.json')
    pilot=read(HERE/'pilot_adaptive_coverage_verification.json')
    for report in [fan,mixed,pilot]:
        assert report['status']=='PASS' and all(sha(p)==h for p,h in report['sources'].items())
    assert fan['mode']=='all_yaw' and mixed['pair_angular_rows']==3888
    assert proof['unordered_pairs']==6 and proof['required_gap_mm']==.3
    assert proof['yaw_range_deg']==[-60,60] and proof['pitch_range_deg']==[-20,25]
    assert proof['CAM_power_cross_pairs']==proof['moving_self']==proof['own_prefix']=='NOT_TESTED'
    e=NativeCAMEnvelopes();enumerated=[]
    assert [tuple(r['wires']) for r in proof['results']]==list(itertools.combinations(NAMES,2))
    for row in proof['results']:
        a,b=row['wires']
        na,nb=[len(e.layout[n]['labels']) for n in [a,b]]
        fa,fb=[e.layout[n]['labels'].index('pitch_shift_first_0') for n in [a,b]]
        ta,tb=[e.layout[n]['tail_index'] for n in [a,b]]
        assert na-ta==nb-tb==130
        ai,bi=np.indices((na,nb))
        ff=(ai<fa)&(bi<fb);tt=(ai>=ta)&(bi>=tb)
        assert not np.any(ff&tt)
        mixed_mask=~(ff|tt)
        assert np.all(ff.astype(int)+tt.astype(int)+mixed_mask.astype(int)==1)
        expected=dict(complete_cubic_piece_products=na*nb,fan_fan_products=int(ff.sum()),
                      fixed_tail_tail_products=int(tt.sum()),all_remaining_products=int(mixed_mask.sum()))
        assert all(row[k]==v for k,v in expected.items())
        # Closed-cell count of the static tail proof is drawn from the same
        # actual canonical partition, including all endpoints.
        assert all(np.count_nonzero(e.layout[n]['parameter_cells'][:,0]>=e.layout[n]['tail_index'])==16000 for n in [a,b])
        enumerated.append(dict(wires=[a,b],status='PASS',**expected))
    e.unchanged()
    minimum=min(fan['minimum_certified_gap_lower_mm'],mixed['minimum_certified_gap_lower_mm'],
                min(r['gap_lower_mm'] for r in pilot['fixed_tail_pairs']))
    assert minimum==proof['minimum_certified_gap_lower_mm'] and minimum>=.3
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    sources=proof['sources']|e.sources
    for p in [Path(__file__),path,HERE/'fan_coverage_verification.json',
              HERE/'remaining_hull_coverage_verification.json',HERE/'pilot_adaptive_coverage_verification.json']:
        sources[str(p)]=sha(p)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Independent exhaustive/disjoint six CAM-upper piece-product enumeration and guarded component angular/parameter proofs',
        sources=sources,results=enumerated,unordered_pairs=6,minimum_certified_gap_lower_mm=minimum,
        required_gap_mm=.3,fan_accepted_yaw_intervals=fan['accepted_yaw_intervals'],
        fan_parameter_refinement_rectangles=fan['accepted_parameter_rectangles'],
        mixed_pair_angular_rows=3888,continuous_nominal_CAM_mutual='PASS',
        CAM_power_cross_pairs='NOT_TESTED',moving_self='NOT_TESTED',own_prefix='NOT_TESTED',
        full_harness='BLOCKED',protected_hardware_files=846,main_changed=False,
        hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'combined_peer_coverage_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_MUTUAL_COMBINED_COVERAGE_PASS',6,fan['accepted_yaw_intervals'],3888,846,flush=True)


if __name__=='__main__':main()
