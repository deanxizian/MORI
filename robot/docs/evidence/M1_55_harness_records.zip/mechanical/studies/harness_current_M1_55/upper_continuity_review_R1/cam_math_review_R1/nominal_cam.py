"""Precision-safe CAM reference with consistent nominal rigid frames.

Keep the same body prefix, zero port datums, fan, loops, and head-local tail.
Only the reference's numeric representation changes: consistent RzRx frames,
80-digit construction, and fixed subdivisions for variable-angle arcs.
This is an unadopted capacity reference, never a purchased component change.
"""
from pathlib import Path
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE)]
import precision_frame_diagnostic as geometry
from precision_frame_diagnostic import mp,norm,unit,vector
from cam_family import CAMFamily,NAMES,sha
mp.mp.dps=80


class FixedBuilder(geometry.Builder):
    def line(self,a,b):
        # Only arithmetic-level zero seams are omitted, not short pitch arcs.
        if norm(b-a)>mp.mpf('1e-48'):self.add([a,(2*a+b)/3,(a+2*b)/3,b],'line')

    def arc(self,center,u,v,r,start,end):
        if start==end:return
        steps=5 if r==mp.mpf('7.5') else 32 if abs(end-start)>mp.pi/2 else 16
        assert abs(end-start)/steps<=mp.mpf('.1')
        for i in range(steps):
            a=start+(end-start)*i/steps;b=start+(end-start)*(i+1)/steps
            point=lambda q:center+r*(mp.cos(q)*u+mp.sin(q)*v)
            tangent=lambda q:r*(-mp.sin(q)*u+mp.cos(q)*v)
            h=(b-a)/3;p,q=point(a),point(b)
            self.add([p,p+h*tangent(a),q-h*tangent(b),q],'circle_Hermite')


# Scoped to this importing Python process. The original helper/source stays
# unchanged and is retained as the preceding diagnostic's hashed evidence.
geometry.Builder=FixedBuilder


def derivatives(controls):
    return np.array([[[float(x) for x in 3*(b-a)] for a,b in zip(c[:-1],c[1:])] for c in controls])


Q,W=np.polynomial.legendre.leggauss(64);Q=(Q+1)/2;W=W/2
B=np.c_[(1-Q)**2,2*Q*(1-Q),Q*Q]


def lengths(controls):
    v=derivatives(controls)
    return np.linalg.norm(np.einsum('qi,nij->nqj',B,v),axis=-1)@W


def joins(controls,incoming,outgoing):
    left=[unit(c[-1]-c[-2]) for c in controls]
    right=[unit(c[1]-c[0]) for c in controls]
    return dict(internal_position_error_mm=float(max(norm(a[-1]-b[0]) for a,b in zip(controls[:-1],controls[1:]))),
        internal_tangent_unit_error=float(max(norm(a-b) for a,b in zip(left[:-1],right[1:]))),
        end_tangent_unit_error=float(max(norm(right[0]-unit(incoming)),norm(left[-1]-unit(outgoing)))))


class NominalCAM:
    def __init__(self):
        self.original=CAMFamily();self.f=self.original;self.ctx=self.f.ctx;self.center=self.f.carrier.center
        self.targets=self.f.targets
        self.ctx.record([Path(__file__),HERE/'precision_frame_diagnostic.py'])

    @property
    def sources(self):return self.f.sources

    def construct(self,name,yaw,pitch,height):
        return geometry.construct(self.f,int(name[-1]),yaw,pitch,height,'ideal_nominal')

    def upper(self,name,yaw,pitch):
        c,details=self.construct(name,yaw,pitch,1.)
        body=self.ctx.f.targets[name];baseline=float(lengths(c.controls).sum())
        height=1.+(self.targets[name]-body-baseline)/2
        assert height>=.5,(name,yaw,pitch,height)
        for _ in range(3):
            c,details=self.construct(name,yaw,pitch,height);L=lengths(c.controls)
            residual=body+float(L.sum())-self.targets[name]
            if abs(residual)<1e-10:break
            height-=residual/2
        lower=self.ctx.f.candidate(name,yaw)['control']
        from cam_family import BSpline
        incoming=vector(BSpline(self.ctx.f.knots,lower,3).derivative()(1.))
        At,_=geometry.nominal(vector(self.center),yaw,pitch);outgoing=At*mp.matrix([-1,0,0])
        metrics=joins(c.controls,incoming,outgoing)
        ok=abs(residual)<1e-8 and metrics['internal_position_error_mm']<1e-10 and metrics['internal_tangent_unit_error']<1e-8 and metrics['end_tangent_unit_error']<1e-8
        numeric=np.array([[[float(x) for x in q] for q in row] for row in c.controls])
        assert np.array_equal(numeric[0,0],lower[-1])
        return c,numeric,L,dict(status='PASS' if ok else 'BLOCKED',height_mm=height,length_residual_mm=residual,
             full_numeric_reference_mm=body+float(L.sum()),target_full_numeric_reference_mm=self.targets[name],
             source_seam_correction_mm=details['correction_mm'],coupling_piece_index=details['piece_index'],
             nominal_frame='Ideal consistent Rz(yaw)Rx(pitch)',decimal_digits=mp.mp.dps,
             body_endpoint_exact=True,**metrics,supplier_cut_length=None)

    def unchanged(self):self.f.unchanged()
