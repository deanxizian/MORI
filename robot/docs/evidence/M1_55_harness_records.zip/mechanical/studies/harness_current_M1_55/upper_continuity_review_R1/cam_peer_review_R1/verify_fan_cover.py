"""Independent yaw and complete two-parameter fan hull coverage audit."""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import sys
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
NAMES=['CAM_1','CAM_2','CAM_3','CAM_4']


def coverage_2d(boxes):
    assert boxes and all(0<=r[0]<r[1]<=1 and 0<=r[2]<r[3]<=1 for r in boxes)
    edges=sorted({x for r in boxes for x in r[:2]});assert edges[0]==0 and edges[-1]==1
    for a,b in zip(edges[:-1],edges[1:]):
        center=(a+b)/2;strips=sorted(r[2:4] for r in boxes if r[0]<center<r[1])
        assert strips[0][0]==0 and strips[-1][1]==1
        assert all(p[1]==q[0] for p,q in zip(strips[:-1],strips[1:]))
    return len(edges)-1


def main():
    pilot='--pilot' in sys.argv
    path=HERE/('fan_pilot_verification.json' if pilot else 'fan_verification.json')
    proof=read(path);cross=read(HERE/'fan_geometry_crosscheck.json')
    assert proof['status']==cross['status']=='PASS' and not proof['failures']
    assert proof['mode']==('pilot' if pilot else 'all_yaw')
    assert proof['required_gap_mm']==.3 and proof['numeric_reserve_mm']==.0001
    assert proof['fan_piece_counts']==dict(CAM_1=37,CAM_2=37,CAM_3=36,CAM_4=36)
    assert all(sha(p)==h for r in [proof,cross] for p,h in r['sources'].items())
    assert len(proof['independence_probes'])==60 and all(r['status']=='PASS' for r in proof['independence_probes'])
    assert [tuple(r['wires']) for r in proof['results']]==list(itertools.combinations(NAMES,2))
    angular_count=parameter_count=parameter_slabs=0;minimum=float('inf')
    windows=proof['pilot_windows'] if pilot else [[-60.,60.]]
    for result in proof['results']:
        assert result['status']=='PASS'
        spans=[]
        for row in result['intervals']:
            assert row['status']=='PASS' and row['gap_lower_mm']>=.3
            assert row['whole_cubic_piece_pairs']==proof['fan_piece_counts'][result['wires'][0]]*proof['fan_piece_counts'][result['wires'][1]]
            pairs=[tuple(p) for p in row['coarse_unresolved_pieces']]
            assert len(pairs)==len(set(pairs))
            assert [tuple(p['pieces']) for p in row['parameter_refinements']]==pairs
            assert row['coarse_accepted_piece_pairs']+len(pairs)==row['whole_cubic_piece_pairs']
            for a,b in pairs:
                assert 0<=a<proof['fan_piece_counts'][result['wires'][0]] and 0<=b<proof['fan_piece_counts'][result['wires'][1]]
            for fine in row['parameter_refinements']:
                assert fine['gap_lower_mm']==min(r[-1] for r in fine['parameter_rectangles'])
                assert all(r[-1]>=.3 for r in fine['parameter_rectangles'])
                parameter_slabs+=coverage_2d(fine['parameter_rectangles'])
                parameter_count+=len(fine['parameter_rectangles'])
            minimum=min(minimum,row['gap_lower_mm']);spans.append(row['yaw_interval_deg']);angular_count+=1
        for lo,hi in windows:
            selected=sorted(r for r in spans if lo<=r[0]<r[1]<=hi)
            assert selected and selected[0][0]==lo and selected[-1][1]==hi
            assert all(a[1]==b[0] for a,b in zip(selected[:-1],selected[1:]))
        assert sum(r[1]-r[0] for r in spans)==sum(r[1]-r[0] for r in windows)
    baseline=read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected={p:h for p,h in baseline['protected_hardware'].items() if '__pycache__' not in p and Path(p).name!='.DS_Store'}
    assert len(protected)==846 and all(sha(PROJECT/p)==h for p,h in protected.items())
    assert sha(PROJECT/'mechanical/mori_v1_2.blend')=='3587b9139f2969df22a0b11826ebb41091fbbe6997c28a30e7d1287848e5c9da'
    assert sha(PROJECT/'mechanical/animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
    sources=proof['sources']|cross['sources']
    for p in [Path(__file__),path,HERE/'fan_geometry_crosscheck.json']:sources[str(p)]=sha(p)
    out=dict(status='PASS',mode=proof['mode'],recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Independent exact yaw and all two-parameter refinements for six fan/fan pairs, with guarded source dependency on yaw only',
        sources=sources,unordered_pairs=6,accepted_yaw_intervals=angular_count,
        accepted_parameter_rectangles=parameter_count,parameter_y_slab_checks=parameter_slabs,
        required_gap_mm=.3,minimum_certified_gap_lower_mm=minimum,
        complete_CAM_mutual='NOT_TESTED',full_harness='BLOCKED',protected_hardware_files=846,
        main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/('fan_pilot_coverage_verification.json' if pilot else 'fan_coverage_verification.json')).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_FAN_COVERAGE_PASS',proof['mode'],angular_count,parameter_count,parameter_slabs,846,flush=True)


if __name__=='__main__':main()
