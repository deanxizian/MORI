"""Verify source guards, scoped six-pair publication and local served bytes."""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import json
import urllib.request
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[4]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        self.links.extend(v for k,v in attrs if k=='href')


def main():
    path=HERE/'delivery.json';d=json.loads(path.read_text())
    assert d['status']==d['continuous_nominal_CAM_mutual']=='PASS' and d['unordered_pairs']==6
    assert d['CAM_power_cross_pairs']==d['moving_self']==d['own_prefix']=='NOT_TESTED'
    assert d['full_harness']=='BLOCKED'
    assert all(sha(p)==h for p,h in d['sources'].items())
    assert all(sha(HERE/p)==h for p,h in d['files'].items())
    text=(HERE/'index.html').read_text();assert '尚未进入主模型或视频' in text and '12组配对仍NOT_TESTED' in text
    parser=Links();parser.feed(text);served=[]
    for p in [HERE/'index.html',*((HERE/link).resolve() for link in parser.links)]:
        assert p.is_file();relative=p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+relative,timeout=10) as response:data=response.read()
        assert data==p.read_bytes(),relative
        served.append(dict(path=relative,sha256=sha(p)))
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        delivery_sha256=sha(path),verified_files=len(d['files']),verified_sources=len(d['sources']),
        served_links=len(served),served=served,continuous_nominal_CAM_mutual='PASS',
        CAM_power_cross_pairs='NOT_TESTED',moving_self='NOT_TESTED',own_prefix='NOT_TESTED',
        full_harness='BLOCKED',main_changed=False,hardware_changed=False,
        animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_MUTUAL_PUBLICATION_VERIFIED',len(d['files']),len(d['sources']),len(served),flush=True)


if __name__=='__main__':main()
