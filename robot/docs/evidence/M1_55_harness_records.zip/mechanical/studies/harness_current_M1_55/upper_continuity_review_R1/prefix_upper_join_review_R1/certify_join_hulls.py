"""Seven own-prefix and 77 other-prefix nominal full-parameter comparisons.

All four cubic controls enclose the complete curve parameter, not samples.
Every accepted angular rectangle retains both yaw and pitch coverage.
Different source allocations are used on the two sides of every join.
Unknown upper endpoints, actual splices/materials and wired closure excluded.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
from join_envelopes import JoinEnvelopes,UPPER_NAMES,RADII,sha
from fan_geometry import matrix
from join_hull_refinement import refine


def main():
    started = time.time()
    pilot = '--pilot' in sys.argv
    own_only = '--own-only' in sys.argv
    e = JoinEnvelopes()
    bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    pairs = [(n,n) for n in UPPER_NAMES] if own_only else list(itertools.product(e.prefix_names,UPPER_NAMES))
    results,failures = [],[]
    visited = 0
    for a,b in pairs:
        own = a==b
        accepted = []
        radius_sum = e.prefix.f.radii[a]+RADII[b]
        for base in bases:
            pending = [(base,0)]
            while pending:
                rectangle,depth = pending.pop()
                visited += 1
                yl,yh,pl,ph = rectangle
                ca = e.prefix.certificate(a,yl,yh)
                cb = e.roots.certificate(b,rectangle)
                groups = ['yaw','pitch']
                ac = [e.prefix.controls(a,rectangle,ca,g) for g in groups]
                bc = [e.upper(b,rectangle,cb,g) for g in groups]
                da = e.prefix.speeds(a,rectangle,ca)
                db = e.upper_speeds(b,rectangle,cb)
                joins = e.upper_joins(b)
                lower = np.maximum.reduce([matrix(x,y,radius_sum) for x,y in zip(ac,bc)])
                local = e.combined_arcs(da,db,joins)<=5. if own else np.zeros(lower.shape,dtype=bool)
                separated = ~local&(lower>=.3)
                unresolved = np.argwhere(~local&~separated)
                details = []
                passed = len(unresolved)==0
                checked = None
                if 0<len(unresolved)<=64:
                    passed = True
                    for i,j in unresolved:
                        checked = refine(e,[c[int(i)] for c in ac],[c[int(j)] for c in bc],
                                         da,db,joins,int(i),int(j),radius_sum,own)
                        if checked['status']!='PASS':
                            passed = False
                            break
                        details.append(dict(pieces=[int(i),int(j)],parameter_rectangles=checked['accepted']))
                if passed:
                    values = [float(lower[separated].min())] if np.any(separated) else []
                    values += [c['gap_lower_mm'] for d in details for c in d['parameter_rectangles'] if c['method']=='complete_hull']
                    accepted.append(dict(status='PASS',rectangle_deg=list(rectangle),base_rectangle_deg=list(base),
                                         root_certificates=[ca,cb],complete_piece_products=int(lower.size),
                                         coarse_local_products=int(local.sum()),coarse_separated_products=int(separated.sum()),
                                         refined_piece_products=unresolved.tolist(),parameter_refinements=details,
                                         gap_lower_mm=min(values) if values else None))
                elif depth>=16:
                    failures.append(dict(prefix=a,upper=b,own_prefix=own,rectangle_deg=list(rectangle),depth=depth,
                                         unresolved_piece_products=int(len(unresolved)),details=checked,
                                         worst_pieces=[int(q) for q in np.unravel_index(np.argmin(lower),lower.shape)],
                                         reason='Undecided nominal prefix-upper bound; not a collision finding'))
                    break
                else:
                    y,p = (yl+yh)/2,(pl+ph)/2
                    if (yh-yl)/10>(ph-pl)/5:
                        pending.extend([((yl,y,pl,ph),depth+1),((y,yh,pl,ph),depth+1)])
                    else:
                        pending.extend([((yl,yh,pl,p),depth+1),((yl,yh,p,ph),depth+1)])
                if visited%50==0:
                    print('PREFIX_UPPER_PROGRESS',[a,b],visited,len(accepted),round(time.time()-started,1),flush=True)
            if failures:
                break
        results.append(dict(prefix=a,upper=b,own_prefix=own,status='PASS' if not failures else 'BLOCKED',
                            radius_sum_mm=radius_sum,prefix_radius_mm=e.prefix.f.radii[a],upper_radius_mm=RADII[b],
                            intervals=accepted))
        print('PREFIX_UPPER_PAIR',[a,b],results[-1]['status'],len(accepted),round(time.time()-started,1),flush=True)
        if failures:
            break
    e.unchanged()
    sources = dict(e.sources)
    for p in [Path(__file__),HERE/'join_hull_refinement.py',HERE.parent/'cam_peer_review_R1/fan_geometry.py']:
        sources[str(p)] = sha(p)
    target = ('own_' if own_only else '')+('pilot_verification.json' if pilot else 'join_verification.json')
    out = dict(status='PASS' if len(results)==len(pairs) and not failures else 'BLOCKED',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),mode='pilot' if pilot else 'all_angles',
               sources=sources,results=results,failures=failures,bases=[list(r) for r in bases],
               yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],required_gap_mm=.3,local_arc_exclusion_upper_mm=5.,
               own_only=own_only,expected_pairs=len(pairs),visited_angular_rectangles=visited,
               scope='Nominal 12 body-prefix and seven known upper references only; actual transitions and five unknown upper endpoints excluded',
               full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,
               manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('PREFIX_UPPER_TERMINAL',out['status'],len(results),visited,round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':
    main()
