"""Nominal all-angle bending/positive linear length branch of four CAM uppers.

Circle Hermite pieces use a uniform analytic speed/curvature lemma for h<=.1.
The four body joins are separately enclosed over the coherent yaw-key family.
Length includes each actual Gauss64 body join, the fixed head-local tail, and
bounded circle/straight contributions. Both height-dependent straights must
stay positive, so the complete reference length has slope exactly two.
The scope is nominal mathematical reference geometry, not physical cable or
the original noncompositional float32/float64 frame helper.
"""
from pathlib import Path
import datetime,json,math,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;MATH=HERE.parent
sys.path[:0]=[str(HERE),str(MATH),str(MATH/'native_clearance_review_R1')]
from nominal_cam import NominalCAM,NAMES,Q,W,B,mp,norm,sha
from stable_bending import split_controls,radius_bound
from power_enclosures import Box,stacked,linear,magnitude,yaw_box,trigonometric_box
from piecewise_geometry import MINIMUM_RADIUS

RESERVE=1e-9


def square(a):
    a=a if isinstance(a,Box) else Box(a)
    near=np.where(a.lo>0,a.lo,np.where(a.hi<0,a.hi,0))
    far=np.maximum(abs(a.lo),abs(a.hi))
    return Box(near*near-RESERVE,far*far+RESERVE)


def sqrt(a):
    assert np.all(a.lo>=-RESERVE)
    return Box(np.sqrt(np.maximum(0,a.lo))-RESERVE,np.sqrt(np.maximum(0,a.hi))+RESERVE)


def cross(a,b):
    rows=[a[...,1]*b[...,2]-a[...,2]*b[...,1],
          a[...,2]*b[...,0]-a[...,0]*b[...,2],a[...,0]*b[...,1]-a[...,1]*b[...,0]]
    return Box(np.stack([r.lo for r in rows],axis=-1),np.stack([r.hi for r in rows],axis=-1))


def restricted_operators(n,depth=7):
    c=np.eye(n)[None]
    for _ in range(depth):c=split_controls(c)
    return c


VO=restricted_operators(3);AO=restricted_operators(2)


class Enclosures:
    def __init__(self):
        self.f=NominalCAM();self.body=self.f.ctx.f
        assert all(np.array_equal(self.body.frame_weights[n][-2:],np.ones(2)) for n in NAMES)
        assert all(np.max(abs(self.body.directions[y][n][-2:]))==0 for n in NAMES for y in range(-60,61,10))
        self.ends={n:{y:self.body.local_controls[y][n][-1] for y in range(-60,61,10)} for n in NAMES}
        self.directions={n:{y:self.body.local_controls[y][n][-1]-self.body.local_controls[y][n][-2] for y in range(-60,61,10)} for n in NAMES}
        self.tail={};self.tail_bending={}
        for pin in range(1,5):
            n=f'CAM_{pin}';c=np.array(self.f.f.tail_builders[pin].controls)
            velocity=3*np.diff(c,axis=1)
            self.tail[n]=float((np.linalg.norm(np.einsum('qi,nij->nqj',B,velocity),axis=-1)@W).sum())
            self.tail_bending[n]=radius_bound(c)
        h=mp.mpf('.1');q=h/2
        # cos(q)>=1-h²/8, D1_y<=1+h²/4, and
        # max normalized acceleration<=h*sqrt(1+h²/4).
        self.circle_radius_ratio=float((1-h*h/8)**3/(1+h*h/4)**mp.mpf('1.5'))
        # |v/(rh)|²=1+u*C(q)+36*u²*(sinc(q)-cos(q))²,
        # u=t(1-t), |C(q)|<=16q⁴/15, z<=q²/3.
        self.eta=Box(float(mp.sqrt(1-4*q**4/15))-1e-12,
                     float(mp.sqrt(1+q**4/4))+1e-12)

    def incoming(self,name,yl,yh):
        d=yaw_box(self.directions[name],yl,yh);assert d.lo[2]>0
        relative=stacked([d[0]/d[2],d[1]/d[2],Box(1)])
        length=magnitude(relative)
        return relative/Box(max(1.,float(length.lo)),float(length.hi))

    def special(self,name,yl,yh):
        pin=int(name[-1]);start=yaw_box(self.ends[name],yl,yh);u=self.incoming(name,yl,yh);up=Box([0.,0.,1.])
        if pin in [1,2]:
            delta=Box(self.f.ctx.fan[pin]['start_mm'])-start;L=magnitude(delta)
            data=stacked([u*L,delta,up*L]);V=np.array([[1,0,0],[-1,3,-1],[0,0,1]],float)
            return data,V,dict(type='neck_Hermite',nominal_first_length_mm=None,start=start)
        if pin==3:
            return stacked([u,up]),np.array([[1,0],[-1,2],[0,1]],float),dict(type='one_mm_lead',nominal_first_length_mm=1.,start=start)
        anchor=Box(self.f.f.anchors[pin]);d=anchor-start;d=stacked([d[0],d[1],Box(0.)]);D=magnitude(d)
        assert D.lo>14
        axis=d/Box(D.lo,D.hi);r=7.;h=float(mp.pi/32);s,c=math.sin(h),math.cos(h);versin=2*math.sin(h/2)**2
        data=stacked([u,axis,up]);V=np.array([[r*h,0,0],[-r*h,3*r*versin-r*h*s,3*r*s-r*h*c],[0,r*h*s,r*h*c]])
        return data,V,dict(type='first_fan_circle',nominal_first_length_mm=r*h,start=start)

    def special_metrics(self,name,yl,yh):
        data,V,details=self.special(name,yl,yh);A=2*np.diff(V,axis=0)
        v=linear((VO@V).reshape(-1,V.shape[1]),data)
        a=linear((AO@A).reshape(-1,V.shape[1]),data)
        v=Box(v.lo.reshape(-1,3,3),v.hi.reshape(-1,3,3))
        a=Box(a.lo.reshape(-1,2,3),a.hi.reshape(-1,2,3))
        near=np.where(v.lo>0,v.lo,np.where(v.hi<0,v.hi,0))
        speed=np.linalg.norm(near,axis=-1).min(1)-RESERVE
        bound=magnitude(cross(Box(v.lo[:,:,None],v.hi[:,:,None]),Box(a.lo[:,None],a.hi[:,None]))).hi.max((1,2))
        radius=np.divide(speed**3,bound,out=np.full(len(speed),np.inf),where=bound>0)
        radius[speed<=0]=0
        velocity=linear(B@V,data);length=magnitude(velocity)
        L=Box(float(W@length.lo)-RESERVE,float(W@length.hi)+RESERVE)
        return dict(radius_lower_mm=max(0.,float(radius.min())-.0001),minimum_speed=float(speed.min()),
                    type=details['type'],length=L,start=details['start'],nominal_first_length_mm=details['nominal_first_length_mm'])

    def fan_length(self,name,yl,yh,special):
        pin=int(name[-1]);start=(Box(self.f.ctx.fan[pin]['start_mm']) if pin in [1,2] else special['start'])
        anchor=Box(self.f.f.anchors[pin]);delta=anchor-start
        D=magnitude(stacked([delta[0],delta[1],Box(0.)]));assert D.lo>14
        # Two radius7 quarter arcs, their horizontal middle and final vertical.
        arc=Box(7*math.pi)*self.eta
        base=arc+D-28+anchor[2]-start[2]
        if pin in [1,2]:base=base+special['length']
        elif pin==3:base=base+special['length']-1.
        else:base=base+special['length']-Box(special['nominal_first_length_mm'])*self.eta
        return base

    def length_branch(self,name,yl,yh,pl,ph,special):
        assert pl*ph>=0 # each interval lies on one side of zero
        pin=int(name[-1]);sign=1. if pl>=0 else -1.
        sin=trigonometric_box(math.sin,math.radians(pl),math.radians(ph))
        cos=trigonometric_box(math.cos,math.radians(pl),math.radians(ph))
        abs_sin=sign*sin
        tail=self.f.ctx.cam[f'pin{pin}'];endpoint=tail[0]-[0,0,15.]
        center=self.f.center;local=endpoint-center;terminal=self.f.ctx.loop_spec['terminal_straight_mm']
        by=local[1]*cos-local[2]*sin+center[1]
        bz=local[1]*sin+local[2]*cos+center[2]
        lower_y=by-terminal*sin-sign*7.5*(1-cos)
        lower_z=bz+terminal*cos+7.5*abs_sin
        anchor=self.f.f.anchors[pin];D=lower_y+14-anchor[1]
        assert 0<D.lo<=D.hi<14
        C=1-D/14
        angle=Box(math.acos(float(C.hi))-RESERVE,math.acos(float(C.lo))+RESERVE)
        shift_z=anchor[2]+self.f.ctx.loop_spec['lead_mm']+14*sqrt(1-square(C))
        down=shift_z-lower_z
        pitch=Box(min(abs(math.radians(pl)),abs(math.radians(ph))),max(abs(math.radians(pl)),abs(math.radians(ph))))
        fan=self.fan_length(name,yl,yh,special)
        constant=fan+self.f.ctx.loop_spec['lead_mm']+Box(14)*angle*self.eta+Box(7*math.pi)*self.eta+down+Box(7.5)*pitch*self.eta+Box(self.tail[name]-RESERVE,self.tail[name]+RESERVE)+self.body.targets[name]
        height=(self.f.targets[name]-constant)/2
        return dict(height_lower_mm=float(height.lo),height_upper_mm=float(height.hi),
                    return_lower_mm=float((down+height).lo),return_upper_mm=float((down+height).hi),
                    numeric_length_height_derivative=2.,fan_length_interval_mm=[float(fan.lo),float(fan.hi)])


def main():
    started=time.time();e=Enclosures();bending=[];lengths=[];failures=[]
    circle=7*e.circle_radius_ratio-.0001
    assert circle>=max(MINIMUM_RADIUS[n] for n in NAMES)
    for name in NAMES:
        assert e.tail_bending[name]['radius_lower_mm']>=MINIMUM_RADIUS[name]
        for y in range(-60,60,10):
            todo=[(float(y),float(y+10),0)]
            while todo:
                yl,yh,depth=todo.pop();m=e.special_metrics(name,yl,yh)
                if m['radius_lower_mm']>=MINIMUM_RADIUS[name]:
                    bending.append(dict(wire=name,yaw_interval_deg=[yl,yh],radius_lower_mm=m['radius_lower_mm'],
                                        minimum_speed=m['minimum_speed'],type=m['type'],status='PASS'))
                elif depth<15:
                    mid=(yl+yh)/2;todo.extend([(yl,mid,depth+1),(mid,yh,depth+1)])
                else:failures.append(dict(kind='special_bending',wire=name,yaw_interval_deg=[yl,yh],radius_lower_mm=m['radius_lower_mm']))
            for p in range(-20,25):
                todo=[(float(y),float(y+10),float(p),float(p+1),0)]
                while todo:
                    yl,yh,pl,ph,depth=todo.pop();special=e.special_metrics(name,yl,yh)
                    r=e.length_branch(name,yl,yh,pl,ph,special)
                    if min(r['height_lower_mm'],r['return_lower_mm'])>=.5:
                        lengths.append(dict(wire=name,rectangle_deg=[yl,yh,pl,ph],status='PASS',**r))
                    elif depth<15:
                        pm=(pl+ph)/2;todo.extend([(yl,yh,pl,pm,depth+1),(yl,yh,pm,ph,depth+1)])
                    else:failures.append(dict(kind='positive_straights',wire=name,rectangle_deg=[yl,yh,pl,ph],**r))
        print('NOMINAL_CAM_MATH_WIRE',name,len(bending),len(lengths),len(failures),round(time.time()-started,1),flush=True)
        if failures:break
    e.f.ctx.record([Path(__file__),HERE/'stable_bending.py',MATH/'power_enclosures.py'])
    e.f.unchanged()
    out=dict(status='PASS' if not failures else 'BLOCKED',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             scope='Four nominal CAM upper mathematical families: complete-angle bending and positive Gauss64 linear length branch; not native gaps or physical materials',
             sources=e.f.sources,bending_intervals=bending,length_rectangles=lengths,failures=failures,
             circle_minimum_radius_lower_mm=circle,circle_maximum_piece_angle_rad=.1,
             circle_Gauss_length_ratio=[float(e.eta.lo),float(e.eta.hi)],tail_bending=e.tail_bending,
             yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],nominal_frame='Ideal consistent Rz(yaw)Rx(pitch)',
             floating_helper_all_angle_rounding='NOT_TESTED',native_clearance='NOT_TESTED',peer_clearance='NOT_TESTED',
             actual_material_and_cut_lengths='BLOCKED',full_harness='BLOCKED',main_changed=False,hardware_changed=False,
             animation_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'nominal_math_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('NOMINAL_CAM_MATH_TERMINAL',out['status'],len(bending),len(lengths),len(failures),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
