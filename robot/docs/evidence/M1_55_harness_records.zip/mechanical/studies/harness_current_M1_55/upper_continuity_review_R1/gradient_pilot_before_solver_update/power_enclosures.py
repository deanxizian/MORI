"""Two-angle enclosures of the existing power/CC numerical reference family.

The covered functional is the positive-weight Gauss64 sum on the actual
Hermite cubics, including the neck stub. It is not a physical cut length.
No hardware, native geometry or existing research input is changed.
"""
from pathlib import Path
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
PARENT=HERE.parent
sys.path[:0]=['/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',
             str(PARENT/'upper_motion_family_R1')]
from power_family import PowerFamily,interp,cell
from piecewise_geometry import BSpline,unit,MINIMUM_RADIUS,sha
from match_bundle import convert,basis

NAMES=['P_J18_1','P_J18_2','CC_allocation']
RESERVE=1e-9


class Box:
    __array_priority__=1000
    def __init__(self,lo,hi=None):
        self.lo=np.asarray(lo,float)
        self.hi=np.asarray(lo if hi is None else hi,float)
        assert np.all(self.lo<=self.hi)

    def __getitem__(self,key):return Box(self.lo[key],self.hi[key])

    def __add__(self,other):
        other=asbox(other)
        return Box(np.nextafter(self.lo+other.lo,-np.inf),np.nextafter(self.hi+other.hi,np.inf))

    __radd__=__add__

    def __neg__(self):return Box(-self.hi,-self.lo)
    def __sub__(self,other):return self+-asbox(other)
    def __rsub__(self,other):return asbox(other)+-self

    def __mul__(self,other):
        other=asbox(other)
        products=np.stack(np.broadcast_arrays(self.lo*other.lo,self.lo*other.hi,
                                               self.hi*other.lo,self.hi*other.hi))
        return Box(np.nextafter(products.min(0),-np.inf),np.nextafter(products.max(0),np.inf))

    __rmul__=__mul__

    def __truediv__(self,other):
        other=asbox(other)
        assert np.all((other.lo>0)|(other.hi<0))
        return self*Box(np.nextafter(1/other.hi,-np.inf),np.nextafter(1/other.lo,np.inf))


def asbox(value):return value if isinstance(value,Box) else Box(value)


def stacked(values):
    values=[asbox(v) for v in values]
    return Box(np.stack([v.lo for v in values]),np.stack([v.hi for v in values]))


def linear(matrix,value):
    value=asbox(value);positive=np.maximum(matrix,0.);negative=np.minimum(matrix,0.)
    return Box(positive@value.lo+negative@value.hi-RESERVE,
               positive@value.hi+negative@value.lo+RESERVE)


def magnitude(value):
    value=asbox(value)
    near=np.where(value.lo>0,value.lo,np.where(value.hi<0,value.hi,0.))
    far=np.maximum(abs(value.lo),abs(value.hi))
    return Box(np.maximum(0.,np.linalg.norm(near,axis=-1)-RESERVE),
               np.linalg.norm(far,axis=-1)+RESERVE)


def unit_box(value):
    value=asbox(value);length=magnitude(value)
    assert np.all(length.lo>0)
    return value/Box(length.lo[...,None],length.hi[...,None])


def dot(a,b):
    product=asbox(a)*asbox(b)
    return Box(product.lo.sum(-1)-RESERVE,product.hi.sum(-1)+RESERVE)


def interpolation_box(values,ylo,yhi,plo,phi):
    # The quintic smooth weight is monotone. Within one source-key rectangle,
    # the interpolation is multi-affine in its two weights, so each component
    # reaches its extrema at one of these four rectangle corners.
    a,b,_=cell((ylo+yhi)/2,-60,60,10)
    c,d,_=cell((plo+phi)/2,-20,25,5)
    assert a-1e-10<=ylo<=yhi<=b+1e-10
    assert c-1e-10<=plo<=phi<=d+1e-10
    samples=np.stack([interp(values,y,p) for y in [ylo,yhi] for p in [plo,phi]])
    return Box(samples.min(0)-RESERVE,samples.max(0)+RESERVE)


def yaw_box(values,ylo,yhi):
    # values are the coherent last-control/difference values in the yaw frame.
    a,b,u=cell((ylo+yhi)/2,-60,60,10)
    assert a-1e-10<=ylo<=yhi<=b+1e-10
    from family import smooth
    samples=np.stack([(1-smooth((y-a)/10))*values[a]+smooth((y-a)/10)*values[b]
                      for y in [ylo,yhi]])
    return Box(samples.min(0)-RESERVE,samples.max(0)+RESERVE)


def trigonometric_box(function,lo,hi):
    points=[lo,hi]
    for k in range(-4,5):
        critical=k*math.pi/2
        if lo<=critical<=hi:points.append(critical)
    values=[function(x) for x in points]
    return Box(min(values)-RESERVE,max(values)+RESERVE)


class PowerEnclosures:
    def __init__(self):
        self.f=PowerFamily();self.center=self.f.center
        self.sources=dict(self.f.sources)
        self.sources[str(Path(__file__))]=sha(Path(__file__))
        self.sources[str(PARENT/'upper_motion_family_R1/power_family.py')]=sha(PARENT/'upper_motion_family_R1/power_family.py')
        self.sources[str(PARENT/'bundle_length_match_R1/match_bundle.py')]=sha(PARENT/'bundle_length_match_R1/match_bundle.py')
        q,w=np.polynomial.legendre.leggauss(64);q=(q+1)/2;self.weights=np.tile(w/2,128)
        self.q=q;self.stub_weights=w/2
        self.H=convert(np.eye(6))
        self.V=3*np.diff(self.H,axis=1)
        self.Q=np.einsum('qj,ijk->iqk',basis(q,2),self.V).reshape(-1,6)
        self.B2=basis(q,2)
        self.D=np.zeros((6,3));self.D[2,2]=1.;self.D[3,2]=.5
        self.va=self.Q@self.D
        assert np.array_equal(self.center[:2],np.zeros(2))
        zero_keys=[self.f.frame_residual[y,0] for y in range(-60,61,10)]
        all_keys=list(self.f.frame_residual.values())
        self.ey=max(np.linalg.norm(e[:3,:3],2) for e in zero_keys)+RESERVE
        self.et=max(np.linalg.norm(e[:3,:3],2) for e in all_keys)+RESERVE
        self.ty=max(np.linalg.norm(e[:3,:3]@self.center+e[:3,3]) for e in zero_keys)+RESERVE
        self.tt=max(np.linalg.norm(e[:3,:3]@self.center+e[:3,3]) for e in all_keys)+RESERVE
        assert self.ey<1e-5 and self.et<1e-5
        family=self.f.ctx.f
        assert all(np.max(abs(family.directions[y][n][-2:]))==0 for n in NAMES for y in range(-60,61,10))
        assert all(np.array_equal(family.frame_weights[n][-2:],np.ones(2)) for n in NAMES)
        self.end_keys={n:{y:family.local_controls[y][n][-1].copy() for y in range(-60,61,10)} for n in NAMES}
        self.direction_keys={n:{y:np.diff(family.local_controls[y][n][-2:],axis=0)[0] for y in range(-60,61,10)} for n in NAMES}

    def prepare(self,name,yaw,pitch):
        c=interp(self.f.controls[name],yaw,pitch)
        my=self.f.transform(yaw,0);mt=self.f.transform(yaw,pitch)
        local_frame=np.linalg.inv(my)@mt
        c[4:]=self.f.end_canonical[name]@local_frame[:3,:3].T+local_frame[:3,3]+interp(self.f.end_residual[name],yaw,pitch)
        lower=self.f.ctx.f.candidate(name,yaw)['control']
        start=lower[-1];incoming=BSpline(self.f.ctx.f.knots,lower,3).derivative()(1.)
        finish=c[0]@my[:3,:3].T+my[:3,3]
        direction=my[:3,:3]@(c[1]-c[0]);length=np.linalg.norm(finish-start)
        prefix=np.array([start,start+unit(incoming)*length/3,finish-unit(direction)*length/3,finish])
        inverse=np.linalg.inv(my)
        local_prefix=prefix@inverse[:3,:3].T+inverse[:3,3]
        stub_velocity=self.B2@(3*np.diff(prefix,axis=0))
        stub_length=float(self.stub_weights@np.linalg.norm(stub_velocity,axis=1))
        return dict(control=c,matrix=my,prefix=prefix,local_prefix=local_prefix,
                    stub_length=stub_length,target=self.f.targets[name]-self.f.ctx.f.targets[name])

    def value(self,pre,amplitude):
        v=self.Q@(pre['control']+amplitude*self.D)
        A=pre['matrix'][:3,:3];world=v@A.T;move=self.va@A.T
        speed=np.linalg.norm(world,axis=1)
        return (pre['stub_length']+float(self.weights@speed),
                float(self.weights@(np.sum(world*move,axis=1)/speed)))

    def root(self,pre):
        lo,hi=-1.,1.;flo=self.value(pre,lo)[0]-pre['target'];fhi=self.value(pre,hi)[0]-pre['target']
        if not flo<0<fhi:return None
        for _ in range(44):
            mid=(lo+hi)/2;residual=self.value(pre,mid)[0]-pre['target']
            if residual<0:lo=mid
            else:hi=mid
        amplitude=(lo+hi)/2
        return amplitude,self.value(pre,amplitude)[0]-pre['target']

    def inputs(self,name,ylo,yhi,plo,phi):
        c=interpolation_box(self.f.controls[name],ylo,yhi,plo,phi)
        p0,p1=map(math.radians,[plo,phi])
        sin=trigonometric_box(math.sin,p0,p1);cos=trigonometric_box(math.cos,p0,p1)
        ends=self.f.end_canonical[name]-self.center
        rows=[]
        for point in ends:
            rows.append(stacked([Box(point[0]),point[1]*cos-point[2]*sin,
                                 point[1]*sin+point[2]*cos])+self.center)
        ends_box=stacked(rows)
        # inv(A_y)A_t differs from Rx by this operator bound. Centre residuals
        # cover the affine term without multiplying absolute world coordinates.
        correction=(self.ey+self.et)/(1-self.ey)*np.linalg.norm(ends,axis=1)+(self.ty+self.tt)/(1-self.ey)+RESERVE
        ends_box=ends_box+Box(-correction[:,None],correction[:,None])
        ends_box=ends_box+interpolation_box(self.f.end_residual[name],ylo,yhi,plo,phi)
        c=Box(np.concatenate([c.lo[:4],ends_box.lo]),np.concatenate([c.hi[:4],ends_box.hi]))
        start=yaw_box(self.end_keys[name],ylo,yhi)
        start_error=(self.ey*magnitude(start-self.center).hi+self.ty)/(1-self.ey)+RESERVE
        start=start+Box(-start_error,start_error)
        incoming=unit_box(yaw_box(self.direction_keys[name],ylo,yhi))
        incoming_error=self.ey/(1-self.ey)+RESERVE
        incoming=incoming+Box(-incoming_error,incoming_error)
        delta=c[0]-start;length=magnitude(delta)*Box(1-self.ey,1+self.ey)
        source=c[1]-c[0];source_length=magnitude(source)*Box(1-self.ey,1+self.ey)
        outgoing=source/source_length
        v0=incoming*length;v2=outgoing*length
        stub=stacked([v0,3*delta-v0-v2,v2])
        return c,stub

    def mapped_controls(self,name,rectangle,operator,ideal=False):
        """Enclose a coherent linear combination before boxing its controls.

        Common translations and head rotations cancel in derivative rows.
        Taking independent point boxes first would discard these correlations.
        """
        ylo,yhi,plo,phi=rectangle
        operator=np.asarray(operator,float).reshape(-1,6)
        samples=[]
        for y in [ylo,yhi]:
            for p in [plo,phi]:
                base=interp(self.f.controls[name],y,p)-self.center
                base[4:]=interp(self.f.end_residual[name],y,p)
                samples.append(operator@base)
        samples=np.stack(samples)
        result=Box(samples.min(0)-RESERVE,samples.max(0)+RESERVE)
        ends=operator[:,4:]@(self.f.end_canonical[name]-self.center)
        p0,p1=map(math.radians,[plo,phi])
        sin=trigonometric_box(math.sin,p0,p1);cos=trigonometric_box(math.cos,p0,p1)
        rotated=stacked([Box(ends[:,0]),ends[:,1]*cos-ends[:,2]*sin,
                        ends[:,1]*sin+ends[:,2]*cos])
        rotated=Box(rotated.lo.T,rotated.hi.T)
        matrix_error=(self.ey+self.et)/(1-self.ey)
        shift_error=(self.ty+self.tt)/(1-self.ey)
        error=matrix_error*np.linalg.norm(ends,axis=1)+shift_error*abs(operator[:,4:].sum(1))+RESERVE
        answer=result+rotated+operator.sum(1)[:,None]*self.center
        return answer if ideal else answer+Box(-error[:,None],error[:,None])

    def mapped_derivative(self,name,rectangle,operator,axis):
        ylo,yhi,plo,phi=rectangle;operator=np.asarray(operator,float).reshape(-1,6)
        ya,yb,_=cell((ylo+yhi)/2,-60,60,10)
        pa,pb,_=cell((plo+phi)/2,-20,25,5)
        from family import smooth,smooth_d
        def key(y,p):
            c=self.f.controls[name][y,p].copy()-self.center
            c[4:]=self.f.end_residual[name][y,p]
            return operator@c
        if axis==0:
            differences=[(1-smooth((p-pa)/5))*(key(yb,pa)-key(ya,pa))+
                         smooth((p-pa)/5)*(key(yb,pb)-key(ya,pb)) for p in [plo,phi]]
            ulo,uhi=(ylo-ya)/10,(yhi-ya)/10;step=10.
        else:
            differences=[(1-smooth((y-ya)/10))*(key(ya,pb)-key(ya,pa))+
                         smooth((y-ya)/10)*(key(yb,pb)-key(yb,pa)) for y in [ylo,yhi]]
            ulo,uhi=(plo-pa)/5,(phi-pa)/5;step=5.
        ds=[smooth_d(u)/step for u in [ulo,uhi]+([.5] if ulo<=.5<=uhi else [])]
        differences=np.stack(differences)
        answer=Box(differences.min(0)-RESERVE,differences.max(0)+RESERVE)*Box(min(ds)-RESERVE,max(ds)+RESERVE)
        if axis==1:
            ends=operator[:,4:]@(self.f.end_canonical[name]-self.center)
            sin=trigonometric_box(math.sin,math.radians(plo),math.radians(phi))
            cos=trigonometric_box(math.cos,math.radians(plo),math.radians(phi))
            turn=stacked([Box(np.zeros(len(operator))),-ends[:,1]*sin-ends[:,2]*cos,
                          ends[:,1]*cos-ends[:,2]*sin])*(math.pi/180)
            answer=answer+Box(turn.lo.T,turn.hi.T)
        return answer

    def ideal_stub(self,name,rectangle,axis=None):
        ylo,yhi,plo,phi=rectangle
        c0=self.mapped_controls(name,rectangle,np.eye(6)[0:1],ideal=True)[0]
        source=self.mapped_controls(name,rectangle,np.array([[-1.,1,0,0,0,0]]),ideal=True)[0]
        start=yaw_box(self.end_keys[name],ylo,yhi)
        incoming_raw=yaw_box(self.direction_keys[name],ylo,yhi)
        incoming=unit_box(incoming_raw);outgoing=unit_box(source)
        delta=c0-start;length=magnitude(delta)
        v0=incoming*length;v2=outgoing*length
        velocity=stacked([v0,3*delta-v0-v2,v2])
        if axis is None:return velocity
        c0d=self.mapped_derivative(name,rectangle,np.eye(6)[0:1],axis)[0]
        sourced=self.mapped_derivative(name,rectangle,np.array([[-1.,1,0,0,0,0]]),axis)[0]
        from family import smooth_d
        if axis==0:
            ya,yb,_=cell((ylo+yhi)/2,-60,60,10)
            ulo,uhi=(ylo-ya)/10,(yhi-ya)/10
            ds=[smooth_d(u)/10 for u in [ulo,uhi]+([.5] if ulo<=.5<=uhi else [])]
            ds=Box(min(ds)-RESERVE,max(ds)+RESERVE)
            sd=(self.end_keys[name][yb]-self.end_keys[name][ya])*ds
            ind=(self.direction_keys[name][yb]-self.direction_keys[name][ya])*ds
        else:sd=Box(np.zeros(3));ind=Box(np.zeros(3))
        deltad=c0d-sd;lengthd=dot(delta,deltad)/length
        def normalized_derivative(vector,derivative):
            norm=magnitude(vector)
            return derivative/norm-vector*dot(vector,derivative)/(norm*norm*norm)
        incomingd=normalized_derivative(incoming_raw,ind)
        outgoingd=normalized_derivative(source,sourced)
        v0d=incomingd*length+incoming*lengthd
        v2d=outgoingd*length+outgoing*lengthd
        return stacked([v0d,3*deltad-v0d-v2d,v2d])

    def functional_change(self,name,rectangle,amplitude):
        ylo,yhi,plo,phi=rectangle;mid=((ylo+yhi)/2,(plo+phi)/2)
        point=(mid[0],mid[0],mid[1],mid[1])
        vb=self.mapped_controls(name,rectangle,self.Q,ideal=True)+amplitude*self.va
        vm=self.mapped_controls(name,point,self.Q,ideal=True)+amplitude*self.va
        vmid=(vm.lo+vm.hi)/2;speed=np.linalg.norm(vmid,axis=1)
        dv=np.linalg.norm(np.maximum(abs(vb.lo-vmid),abs(vb.hi-vmid)),axis=1)+RESERVE
        sb=linear(self.B2,self.ideal_stub(name,rectangle))
        sm=linear(self.B2,self.ideal_stub(name,point));smid=(sm.lo+sm.hi)/2
        sspeed=np.linalg.norm(smid,axis=1)
        sdv=np.linalg.norm(np.maximum(abs(sb.lo-smid),abs(sb.hi-smid)),axis=1)+RESERVE
        partial=[]
        for axis in range(2):
            db=self.mapped_derivative(name,rectangle,self.Q,axis)
            dm=self.mapped_derivative(name,point,self.Q,axis);dmid=(dm.lo+dm.hi)/2
            ddelta=np.linalg.norm(np.maximum(abs(db.lo-dmid),abs(db.hi-dmid)),axis=1)+RESERVE
            sdb=linear(self.B2,self.ideal_stub(name,rectangle,axis))
            sdm=linear(self.B2,self.ideal_stub(name,point,axis));sdmid=(sdm.lo+sdm.hi)/2
            sddelta=np.linalg.norm(np.maximum(abs(sdb.lo-sdmid),abs(sdb.hi-sdmid)),axis=1)+RESERVE
            derivative=float(self.weights@(np.sum(vmid*dmid,axis=1)/speed)+
                             self.stub_weights@(np.sum(smid*sdmid,axis=1)/sspeed))
            remainder=float(self.weights@(2*dv/speed*np.linalg.norm(dmid,axis=1)+ddelta)+
                            self.stub_weights@(2*sdv/sspeed*np.linalg.norm(sdmid,axis=1)+sddelta))+RESERVE
            partial.append(abs(derivative)+remainder)
        # Uniform actual-versus-ideal error: both transforms are within the
        # recorded source roundoff bounds; no angle derivative of roundoff is
        # omitted from a supposed exact orthogonal model.
        ends=self.Q[:,4:]@(self.f.end_canonical[name]-self.center)
        end_error=(self.ey+self.et)/(1-self.ey)*np.linalg.norm(ends,axis=1)+\
                  (self.ty+self.tt)/(1-self.ey)*abs(self.Q[:,4:].sum(1))+RESERVE
        vupper=np.linalg.norm(np.maximum(abs(vb.lo),abs(vb.hi)),axis=1)
        polynomial_error=float(self.weights@((1+self.ey)*math.sqrt(3)*end_error+self.ey*vupper))+RESERVE
        source_start=yaw_box(self.end_keys[name],ylo,yhi)
        start_error=(self.ey*magnitude(source_start-self.center).hi+self.ty)/(1-self.ey)+RESERVE
        delta=self.mapped_controls(name,rectangle,np.eye(6)[0:1],ideal=True)[0]-source_start
        L=magnitude(delta).hi
        Lerror=self.ey*L+(1+self.ey)*start_error+RESERVE
        endpoint_velocity_error=self.ey/(1-self.ey)*(L+Lerror)+Lerror+RESERVE
        velocity_error=3*start_error+2*endpoint_velocity_error+RESERVE
        stub_upper=float(magnitude(self.ideal_stub(name,rectangle)).hi.max())
        stub_error=(1+self.ey)*velocity_error+self.ey*stub_upper+RESERVE
        error=polynomial_error+stub_error
        return (partial[0]*(yhi-ylo)/2+partial[1]*(phi-plo)/2+2*error+RESERVE,
                dict(partial_bounds_mm_per_deg=partial,uniform_roundoff_functional_error_mm=float(error)))

    def certificate(self,name,rectangle):
        ylo,yhi,plo,phi=rectangle;ym=(ylo+yhi)/2;pm=(plo+phi)/2
        pre=self.prepare(name,ym,pm);result=self.root(pre)
        if result is None:return dict(status='BLOCKED',reason='midpoint_root_not_bracketed')
        amplitude,residual=result;c,stub=self.inputs(name,*rectangle)
        c_at_mid=pre['control']+amplitude*self.D
        velocity=self.Q@c_at_mid;speed=np.linalg.norm(velocity,axis=1)
        vb=self.mapped_controls(name,rectangle,self.Q)+amplitude*self.va
        displacement=np.linalg.norm(np.maximum(abs(vb.lo-velocity),abs(vb.hi-velocity)),axis=1)+RESERVE
        smid=self.B2@(3*np.diff(pre['local_prefix'],axis=0))
        sb=linear(self.B2,stub)
        sdis=np.linalg.norm(np.maximum(abs(sb.lo-smid),abs(sb.hi-smid)),axis=1)+RESERVE
        # Orthogonal yaw cancels from length. The convex interpolation of source
        # roundoff matrices is retained through its singular-value reserve.
        functional_change=float(self.weights@displacement+self.stub_weights@sdis)
        functional_change=(1+self.ey)*functional_change+2*self.ey*(float(self.weights@speed)+float(self.stub_weights@np.linalg.norm(smid,axis=1)))+RESERVE
        gradient_change,gradient_details=self.functional_change(name,rectangle,amplitude)
        triangle_change=functional_change
        functional_change=min(functional_change,gradient_change)
        va_norm=np.linalg.norm(self.va,axis=1)
        g0=float(self.weights@(np.sum(velocity*self.va,axis=1)/speed))
        transform_derivative_error=(3*self.ey+self.ey**2)/(1-self.ey)*float(self.weights@va_norm)+RESERVE
        def derivative_lower(width):
            dv=displacement+width*va_norm
            return (g0-float(self.weights@(2*dv/speed*va_norm))-transform_derivative_error,
                    float(np.min(speed-dv))*(1-self.ey)-RESERVE)
        global_g,global_speed=derivative_lower(1+abs(amplitude))
        if global_g<=0 or global_speed<=0:
            return dict(status='BLOCKED',reason='global_root_branch',derivative_lower=global_g,speed_lower=global_speed)
        width=max(1e-6,(functional_change+abs(residual)+RESERVE)/global_g*1.01)
        if width+abs(amplitude)>=1:
            return dict(status='BLOCKED',reason='root_bracket_width',amplitude_mm=amplitude,width_mm=width)
        actual_g,speed_lower=derivative_lower(width)
        demand=(functional_change+abs(residual)+RESERVE)/actual_g
        if demand>width:
            return dict(status='BLOCKED',reason='root_width',demand_mm=demand,width_mm=width)
        return dict(status='PASS',wire=name,rectangle_deg=list(rectangle),midpoint_deg=[ym,pm],
            midpoint_amplitude_mm=amplitude,amplitude_deviation_bound_mm=width,
            root_derivative_lower=actual_g,global_unit_bracket_derivative_lower=global_g,
            speed_lower=speed_lower,midpoint_Gauss64_residual_mm=residual,
            fixed_amplitude_functional_change_bound_mm=functional_change,
            triangle_change_bound_mm=triangle_change,gradient_change_bound_mm=gradient_change,
            functional_gradient_details=gradient_details,
            operator_roundoff_bound=self.ey,affine_center_roundoff_mm=self.ty,
            _pre=pre,_control_box=c+Box(amplitude-width,amplitude+width)*self.D,
            _stub_velocity_box=stub)

    def unchanged(self):
        self.f.unchanged()
        assert all(sha(p)==h for p,h in self.sources.items())
