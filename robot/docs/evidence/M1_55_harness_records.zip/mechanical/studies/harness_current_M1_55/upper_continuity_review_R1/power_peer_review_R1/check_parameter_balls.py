"""Compare faster complete-cell balls to actual source restricted controls.

Finite probes detect implementation errors; the complete-cell radius follows
from the source midpoint boxes and the whole-piece quadratic speed hull.
"""
from pathlib import Path
import datetime,json,sys,time
import numpy as np
HERE=Path(__file__).resolve().parent;MATH=HERE.parent
sys.path[:0]=[str(HERE),'/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313',
             str(MATH/'native_clearance_review_R1'),str(MATH)]
from power_native_envelopes import NativeEnvelopes,NAMES,sha,restrictions,ideal_matrix
from parameter_balls import movement


def main():
    started=time.time();e=NativeEnvelopes();proof=json.loads((MATH/'power_math_verification.json').read_text())
    rows=[];excess=0.
    for name in NAMES:
        certificates=[r for r in proof['rows'] if r['wire']==name]
        for index in np.linspace(0,len(certificates)-1,8,dtype=int):
            certificate=certificates[index];r=certificate['rectangle_deg'];yl,yh,pl,ph=r
            anchor=e.reference(name,(yl+yh)/2,(pl+ph)/2);points=e.relative_points(anchor,'yaw')
            balls=movement(e,name,r,certificate,anchor)
            for y,p in [(yl,pl),(yh,ph),(yl,ph),(yh,pl),((yl+yh)/2,(pl+ph)/2)]:
                actual=e.reference(name,y,p);c=actual['controls']
                s=np.linspace(0,1,e.stub_steps+1);si=np.c_[s[:-1],s[1:]]
                u=np.linspace(0,1,e.poly_steps+1);pi=np.c_[u[:-1],u[1:]]
                cells=np.concatenate([restrictions(c[0],si),np.concatenate([restrictions(piece,pi) for piece in c[1:]])])
                inverse=np.linalg.inv(ideal_matrix(e.center,y,0))
                cells=cells@inverse[:3,:3].T+inverse[:3,3]
                residual=np.linalg.norm(cells-points[:,None,:],axis=-1).max(1)-balls
                maximum=float(residual.max());excess=max(excess,maximum)
                assert maximum<=1e-8,(name,r,y,p,maximum)
                rows.append(dict(wire=name,rectangle_deg=r,pose_deg=[y,p],maximum_control_hull_excess_mm=maximum,status='PASS'))
    e.unchanged();sources=dict(e.sources)
    for path in [Path(__file__),HERE/'parameter_balls.py',MATH/'power_math_verification.json']:sources[str(path)]=sha(path)
    out=dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,
             scope='Finite direct source controls diagnose the complete-parameter-ball implementation; not all-angle pair proof',
             rows=rows,direct_control_cell_comparisons=len(rows),parameter_cells_per_curve=len(e.parameter_cells),
             maximum_positive_excess_mm=excess,main_changed=False,hardware_changed=False,animation_changed=False,
             manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'parameter_ball_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POWER_PARAMETER_BALLS_PASS',len(rows),len(e.parameter_cells),round(out['elapsed_s'],1),flush=True)


if __name__=='__main__':main()
