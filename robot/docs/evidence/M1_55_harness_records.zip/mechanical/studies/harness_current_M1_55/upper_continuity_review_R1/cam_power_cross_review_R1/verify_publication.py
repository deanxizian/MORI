"""Verify published sources, all 21 pair identities, and actual served bytes."""
from pathlib import Path
from html.parser import HTMLParser
import datetime
import hashlib
import itertools
import json
import urllib.request

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[4]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self,tag,attrs):
        for key,value in attrs:
            if key=='href':
                self.links.append(value)


def main():
    path = HERE/'delivery.json'
    delivery = read(path)
    assert delivery['status']==delivery['CAM_power_cross_pairs']==delivery['known_upper_continuous_mutual']=='PASS'
    assert delivery['unordered_cross_pairs']==12 and delivery['known_upper_unordered_pairs']==21
    assert delivery['own_prefix']==delivery['power_remote_self']=='NOT_TESTED'
    assert delivery['full_harness']=='BLOCKED' and not delivery['manufacturing_release']
    assert all(sha(p)==h for p,h in delivery['sources'].items())
    assert all(sha(HERE/p)==h for p,h in delivery['files'].items())
    combined = read(HERE/'complete_upper_mutual_verification.json')
    names = ['CAM_1','CAM_2','CAM_3','CAM_4','P_J18_1','P_J18_2','CC_allocation']
    actual = [frozenset(r['wires']) for r in combined['results']]
    expected = {frozenset(pair) for pair in itertools.combinations(names,2)}
    assert len(actual)==len(set(actual))==21 and set(actual)==expected
    assert combined['category_pair_counts']==dict(CAM_CAM=6,power_power=3,CAM_power=12)
    page = (HERE/'index.html').read_text()
    assert '尚未进入主模型或视频' in page and '全部21组' in page
    parser = Links()
    parser.feed(page)
    served = []
    for p in [HERE/'index.html',*((HERE/link).resolve() for link in parser.links)]:
        assert p.is_file()
        relative = p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+relative,timeout=10) as response:
            assert response.read()==p.read_bytes(),relative
        served.append(dict(path=relative,sha256=sha(p)))
    out = dict(status='PASS',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               delivery_sha256=sha(path),verified_files=len(delivery['files']),verified_sources=len(delivery['sources']),
               served_links=len(served),served=served,CAM_power_cross_pairs='PASS',known_upper_continuous_mutual='PASS',
               unordered_cross_pairs=12,known_upper_unordered_pairs=21,own_prefix='NOT_TESTED',power_remote_self='NOT_TESTED',
               full_harness='BLOCKED',main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_POWER_CROSS_PUBLICATION_VERIFIED',len(delivery['files']),len(served),21,flush=True)


if __name__ == '__main__':
    main()
