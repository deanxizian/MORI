"""Bound source endpoint roundoff repairs inside the existing numeric reserve.

The source restores explicit endpoints after a three-term float64 matrix dot.
This gate covers that repair globally, rather than relaxing datum equality.
"""
from pathlib import Path
import datetime
import json
import math
import time
import numpy as np
from power_enclosures import PowerEnclosures,NAMES,RESERVE,sha

HERE=Path(__file__).resolve().parent


def main():
    started=time.time();f=PowerEnclosures()
    unit_roundoff=np.finfo(np.float64).eps/2
    # 64 rounding operations is a conservative budget for both dot evaluation
    # orders, affine addition, subtraction and applying the two endpoint fixes.
    gamma=64*unit_roundoff/(1-64*unit_roundoff)
    rows=[]
    for n in NAMES:
        source_radius=max(np.linalg.norm(c[:4]-f.center,axis=1).max() for c in f.f.controls[n].values())
        end_radius=float(np.linalg.norm(f.f.end_canonical[n]-f.center,axis=1).max())
        end_residual=max(np.linalg.norm(c,axis=1).max() for c in f.f.end_residual[n].values())
        end_error=(f.ey+f.et)/(1-f.ey)*end_radius+(f.ty+f.tt)/(1-f.ey)+RESERVE
        # The root branch is certified inside [-1,1]. Only two interior controls
        # move, by at most 1mm; conversion is a fixed linear map with this L1 norm.
        control_bound=float(np.linalg.norm(f.center)+max(source_radius,end_radius+end_error+end_residual)+1)
        hermite_bound=control_bound*float(abs(f.H).sum(-1).max())
        affine_bound=f.ty+f.ey*np.linalg.norm(f.center)+RESERVE
        world_bound=(1+f.ey)*hermite_bound+affine_bound
        products_bound=3*(1+f.ey)*hermite_bound+affine_bound
        point_repair_per_component=4*gamma*products_bound+RESERVE*unit_roundoff
        velocity_repair_per_component=6*point_repair_per_component
        acceleration_repair_per_component=24*point_repair_per_component
        # Only the first and last polynomial pieces are repaired. Positive
        # Gauss weights sum to one on each of these two pieces.
        functional_repair_bound=12*math.sqrt(3)*point_repair_per_component
        assert world_bound<1024
        assert max(velocity_repair_per_component,acceleration_repair_per_component,functional_repair_bound)<RESERVE
        rows.append(dict(wire=n,root_control_coordinate_bound_mm=control_bound,
            Hermite_L1_operator_norm=float(abs(f.H).sum(-1).max()),
            converted_world_coordinate_bound_mm=world_bound,
            endpoint_repair_component_bound_mm=point_repair_per_component,
            velocity_repair_component_bound_mm=velocity_repair_per_component,
            acceleration_repair_component_bound_mm=acceleration_repair_per_component,
            Gauss64_functional_repair_bound_mm=functional_repair_bound,status='PASS'))
    f.sources[str(Path(__file__))]=sha(Path(__file__))
    proof=HERE/'power_math_verification.json';data=json.loads(proof.read_text())
    assert data['status']=='PASS' and data['reference_root_bracket_mm']==[-1,1]
    f.sources[str(proof)]=sha(proof);f.unchanged()
    out=dict(status='PASS',scope='Float64 source endpoint repair fits the existing curve/functional reserve over the certified branch',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=f.sources,
        float_type='float64',unit_roundoff=unit_roundoff,rounding_operation_budget=64,
        existing_operator_component_and_functional_reserve_mm=RESERVE,rows=rows,
        exact_saved_endpoint_readback='Checked separately; this does not substitute a tolerance for source datum equality',
        main_changed=False,hardware_changed=False,animation_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'endpoint_numeric_reserve.json').write_text(json.dumps(out,indent=2)+'\n')
    print('ENDPOINT_NUMERIC_RESERVE_PASS',max(r['Gauss64_functional_repair_bound_mm'] for r in rows),flush=True)


if __name__=='__main__':main()
