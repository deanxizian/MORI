"""Common-frame complete cubic controls of the unchanged CAM and power uppers.

The existing power enclosure operators are instantiated with one closed
parameter cell per canonical cubic, retaining all four Bernstein controls.
CAM uses the same canonical slots as its guarded full native/self proofs.
This wrapper changes only proof partitioning, never source curves or hardware.
"""
from pathlib import Path
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT/'cam_native_clearance_review_R1'),
               str(ROOT/'native_clearance_review_R1')]
from cam_native_envelopes import NativeCAMEnvelopes, NAMES as CAM_NAMES, Box, RADII, sha
from power_native_envelopes import NativeEnvelopes, NAMES as POWER_NAMES


class CrossEnvelopes:
    def __init__(self):
        self.cam = NativeCAMEnvelopes()
        self.power = NativeEnvelopes(poly_steps=1, stub_steps=1)
        assert np.array_equal(self.cam.center, self.power.center)
        assert len(self.power.parameter_cells) == 129
        self.sources = dict(self.cam.sources)
        for p, h in self.power.sources.items():
            assert p not in self.sources or self.sources[p] == h
            self.sources[p] = h
        self.sources[str(Path(__file__))] = sha(Path(__file__))

    def power_controls(self, name, rectangle, certificate, group):
        stub = self.power.stub_boxes(name, rectangle, group)
        polynomial = self.power.polynomial_boxes(name, rectangle, certificate, group)
        return Box(np.concatenate([stub.lo, polynomial.lo]),
                   np.concatenate([stub.hi, polynomial.hi]))

    def cam_controls(self, name, rectangle, certificate, group):
        height = Box(certificate['height_lower_mm'], certificate['height_upper_mm'])
        return self.cam.controls(name, rectangle, height, group)[0]

    def unchanged(self):
        self.cam.unchanged()
        self.power.unchanged()
        assert all(sha(p) == h for p,h in self.sources.items())
