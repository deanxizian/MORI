"""Full 12 CAM-power/CC pair covers with closed curve parameters and both angles.

Reuse the union of all intersecting verified root ranges, then narrow roots
only when a hull needs refinement. No hardware, curve, gap target or angle
range is changed. An unresolved bound is BLOCKED, never a collision waiver.
"""
from pathlib import Path
import datetime
import itertools
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE),str(HERE.parent/'cam_peer_review_R1')]
from cross_envelopes import CrossEnvelopes, CAM_NAMES, POWER_NAMES, RADII, sha
from source_root_covers import RootCovers
from fan_geometry import matrix
from cross_hull_refinement import refine


def main():
    started = time.time()
    pilot = '--pilot' in sys.argv
    e = CrossEnvelopes()
    covers = RootCovers(e)
    bases = [(-60.,-50.,-20.,-19.),(-10.,0.,0.,.03125),(50.,60.,24.,25.)] if pilot else [
        (float(y),float(y+10),float(p),float(p+5)) for y in range(-60,60,10) for p in range(-20,25,5)]
    results,failures = [],[]
    visited,new_roots = 0,0
    for a,b in itertools.product(CAM_NAMES,POWER_NAMES):
        accepted = []
        for base in bases:
            pending = [(base,0)]
            while pending:
                rectangle,depth = pending.pop()
                visited += 1
                ca,cb = covers.certificate(a,rectangle),covers.certificate(b,rectangle)
                if depth:
                    narrower = e.power.e.certificate(b,rectangle)
                    new_roots += 1
                    if narrower['status']=='PASS':
                        oldlo = cb['midpoint_amplitude_mm']-cb['amplitude_deviation_bound_mm']
                        oldhi = cb['midpoint_amplitude_mm']+cb['amplitude_deviation_bound_mm']
                        newlo = narrower['midpoint_amplitude_mm']-narrower['amplitude_deviation_bound_mm']
                        newhi = narrower['midpoint_amplitude_mm']+narrower['amplitude_deviation_bound_mm']
                        if newhi-newlo < oldhi-oldlo:
                            cb = dict(status='PASS',wire=b,rectangle_deg=list(rectangle),method='fresh_guarded_root',
                                      midpoint_amplitude_mm=narrower['midpoint_amplitude_mm'],
                                      amplitude_deviation_bound_mm=narrower['amplitude_deviation_bound_mm'],
                                      root_derivative_lower=narrower['root_derivative_lower'],
                                      global_unit_bracket_derivative_lower=narrower['global_unit_bracket_derivative_lower'])
                groups = ['yaw','pitch']
                ac = [e.cam_controls(a,rectangle,ca,g) for g in groups]
                bc = [e.power_controls(b,rectangle,cb,g) for g in groups]
                lower = np.maximum.reduce([matrix(x,y,RADII[a]+RADII[b]) for x,y in zip(ac,bc)])
                unresolved = np.argwhere(lower < .3)
                details = []
                passed = len(unresolved)==0
                if 0<len(unresolved)<=64:
                    passed = True
                    for i,j in unresolved:
                        checked = refine([c[int(i)] for c in ac],[c[int(j)] for c in bc],RADII[a]+RADII[b])
                        if checked['status']!='PASS':
                            passed = False
                            break
                        details.append(dict(pieces=[int(i),int(j)],parameter_rectangles=checked['accepted']))
                if passed:
                    minimum = min([float(lower[lower>=.3].min())] if np.any(lower>=.3) else [float('inf')])
                    if details:
                        minimum = min(minimum,min(c['gap_lower_mm'] for d in details for c in d['parameter_rectangles']))
                    accepted.append(dict(status='PASS',rectangle_deg=list(rectangle),base_rectangle_deg=list(base),
                                         root_certificates=[ca,cb],complete_piece_products=int(lower.size),
                                         coarse_separated_products=int(np.count_nonzero(lower>=.3)),
                                         refined_piece_products=unresolved.tolist(),parameter_refinements=details,
                                         gap_lower_mm=minimum))
                elif depth>=16:
                    i,j = np.unravel_index(np.argmin(lower),lower.shape)
                    failures.append(dict(wires=[a,b],rectangle_deg=list(rectangle),depth=depth,
                                         unresolved_piece_products=int(len(unresolved)),worst_pieces=[int(i),int(j)],
                                         gap_lower_mm=float(lower.min()),reason='Undecided full-parameter angular bound'))
                    break
                else:
                    yl,yh,pl,ph = rectangle
                    y,p = (yl+yh)/2,(pl+ph)/2
                    if (yh-yl)/10 > (ph-pl)/5:
                        pending.extend([((yl,y,pl,ph),depth+1),((y,yh,pl,ph),depth+1)])
                    else:
                        pending.extend([((yl,yh,pl,p),depth+1),((yl,yh,p,ph),depth+1)])
                if visited%100==0:
                    print('CAM_POWER_CROSS_PROGRESS',[a,b],visited,len(accepted),new_roots,round(time.time()-started,1),flush=True)
            if failures:
                break
        results.append(dict(wires=[a,b],status='PASS' if not failures else 'BLOCKED',intervals=accepted))
        print('CAM_POWER_CROSS_PAIR',[a,b],results[-1]['status'],len(accepted),round(time.time()-started,1),flush=True)
        if failures:
            break
    e.unchanged()
    covers.unchanged()
    sources = e.sources | covers.sources
    for p in [Path(__file__),HERE/'cross_hull_refinement.py',HERE.parent/'cam_peer_review_R1/fan_geometry.py']:
        sources[str(p)] = sha(p)
    out = dict(status='PASS' if len(results)==12 and not failures else 'BLOCKED',
               recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               mode='pilot' if pilot else 'all_angles', sources=sources, results=results, failures=failures,
               bases=[list(r) for r in bases], required_gap_mm=.3, yaw_range_deg=[-60,60],pitch_range_deg=[-20,25],
               scope='12 nominal CAM-power/CC upper pairs only; complete closed cubic parameters and ideal common frames',
               visited_angular_rectangles=visited,new_root_certificates=new_roots,
               full_harness='BLOCKED',own_prefix='NOT_TESTED',power_remote_self='NOT_TESTED',
               main_changed=False,hardware_changed=False,animation_changed=False,manufacturing_release=False,
               elapsed_s=time.time()-started)
    target = 'pilot_verification.json' if pilot else 'cross_verification.json'
    (HERE/target).write_text(json.dumps(out,indent=2)+'\n')
    print('CAM_POWER_CROSS_TERMINAL',out['status'],len(results),visited,round(out['elapsed_s'],1),flush=True)


if __name__ == '__main__':
    main()
