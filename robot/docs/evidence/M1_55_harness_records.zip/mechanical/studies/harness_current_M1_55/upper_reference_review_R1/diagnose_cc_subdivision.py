"""Separate a subdivided-polyline circumradius from its declared smooth curve.

This is a zero-pose diagnostic of the CC Z200..206 segment only. It does
not certify the rest of the CC tail, material joins or arbitrary poses.
"""
from pathlib import Path
import datetime
import hashlib
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent.parent/'harness_current_M1_54'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def split(ctrl, t=.5):
    row = np.asarray(ctrl, dtype=float)
    left, right = [row[0]], [row[-1]]
    while len(row) > 1:
        row = (1-t)*row[:-1]+t*row[1:]
        left.append(row[0]); right.append(row[-1])
    return np.array(left), np.array(right[::-1])


def evaluate(ctrl, t):
    n = len(ctrl)-1
    return np.array([math.comb(n,j)*t**j*(1-t)**(n-j) for j in range(n+1)]).T@ctrl


def bound_radius(ctrl, depth=10):
    segments = [np.asarray(ctrl)]
    for _ in range(depth):
        segments = [q for c in segments for q in split(c)]
    c = np.asarray(segments)
    n = c.shape[1]-1
    d = n*np.diff(c, axis=1)
    a = (n-1)*np.diff(d, axis=1)
    lo, hi = d.min(1), d.max(1)
    closest = np.where(lo>0, lo, np.where(hi<0, hi, 0))
    speed_lower = np.linalg.norm(closest, axis=1)
    assert np.all(speed_lower>1e-12)
    # Cross products are bounded by positive Bernstein product weights.
    cross_upper = np.linalg.norm(np.cross(d[:,:,None,:], a[:,None,:,:]), axis=-1).max((1,2))
    radius = np.divide(speed_lower**3, cross_upper, out=np.full(len(c),np.inf), where=cross_upper>1e-20)
    return max(0, float(radius.min())-.0001), len(c)


def main():
    inspection_path = HERE/'inspection.json'
    array_path = HERE/'zero_pose_upper_references.npz'
    source_path = PREVIOUS/'cc_thin_reference/adaptive_between_review.json'
    inspection = json.loads(inspection_path.read_text())
    source = json.loads(source_path.read_text())
    assert inspection['status']=='PASS' and all(sha(p)==h for p,h in inspection['sources'].items())
    # That old report also recorded M1.54 native solids. They have since
    # changed deliberately. Accept only its frozen curve/metadata pairing;
    # independently reconstruct that shape, without inheriting native PASS.
    neck_path = PREVIOUS/'cc_thin_reference/adaptive_between_candidate.npz'
    assert source['status']=='PASS' and sha(neck_path)==source['curve_sha256']
    meta = next(r for r in source['meta'] if r['yaw']==0)
    ctrl = np.asarray(meta['controls_yaw_local_mm'])
    assert len(ctrl)==10
    assert np.max(abs(ctrl[:,2]-np.linspace(174,206,10)))<1e-10
    points = np.load(array_path)['CC_allocation']
    local = points[points[:,2]<=206+1e-10]
    t = (local[:,2]-174)/32
    exact = evaluate(ctrl,t)
    deviations = np.linalg.norm(local-exact,axis=1)
    assert deviations.max() <= meta['chord_error_mm']+1e-8
    tail_ctrl = split(ctrl,(200-174)/32)[1]
    lower, cells = bound_radius(tail_ctrl)
    assert lower>source['wire_reference']['static_reference_radius_mm']
    spans = np.diff(local,axis=0)
    steps = np.linalg.norm(spans,axis=1)
    areas = np.linalg.norm(np.cross(spans[:-1],spans[1:]),axis=1)
    ids = np.flatnonzero(areas>1e-11)
    radii = steps[:-1][ids]*steps[1:][ids]*np.linalg.norm(spans[:-1]+spans[1:],axis=1)[ids]/(2*areas[ids])
    j = int(ids[np.argmin(radii)])+1
    result = dict(status='PASS', scope='Zero-pose CC reference Z200..206 only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources={str(p):sha(p) for p in [Path(__file__), inspection_path,array_path,source_path,neck_path]},
        comparison_points=len(local), maximum_saved_chord_to_declared_curve_error_mm=float(deviations.max()),
        original_chord_error_bound_mm=meta['chord_error_mm'],
        subdivision_cells=cells, analytic_radius_lower_bound_mm=lower,
        diagnostic_polyline_three_point_radius_mm=float(radii.min()),
        diagnostic_point_mm=local[j].tolist(),
        conclusion='The small three-point radius occurs at a subdivided saved chord junction; it is not the curvature of the declared smooth polynomial.',
        old_native_PASS_inherited=False,
        continuous_whole_CC_upper='NOT_TESTED', upper_interpose_motion='NOT_TESTED',
        physical_material_and_endpoints='BLOCKED', full_harness='BLOCKED',
        main_changed=False, hardware_changed=False, manufacturing_release=False)
    (HERE/'cc_subdivision_diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CC_SUBDIVISION_DIAGNOSTIC_PASS',json.dumps({k:result[k] for k in [
        'maximum_saved_chord_to_declared_curve_error_mm','analytic_radius_lower_bound_mm',
        'diagnostic_polyline_three_point_radius_mm']}),flush=True)


if __name__=='__main__':
    main()
