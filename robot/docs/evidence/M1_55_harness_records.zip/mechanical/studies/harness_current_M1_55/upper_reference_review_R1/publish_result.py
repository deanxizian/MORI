"""Publish finite upper-reference checks without widening their scope."""
from pathlib import Path
import datetime
import hashlib
import html
import json

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    inspection=read(HERE/'inspection.json')
    cc=read(HERE/'cc_subdivision_diagnostic.json')
    assert inspection['status']==cc['status']=='PASS'
    assert all(sha(p)==h for r in [inspection,cc] for p,h in r['sources'].items())
    assert inspection['poses']==130 and inspection['wire_pose_checks']==910
    assert inspection['native_group_checks']==2730 and len(inspection['missing_upper_references'])==5
    assert inspection['full_harness']=='BLOCKED' and not inspection['main_changed']
    prefix=read(HERE.parent/'prefix_continuity/frame_family_R3/continuous_gaps_R1/progress.json')
    assert prefix['status']=='PASS'
    commands=[]
    for script,runtime,args in [
        ('inspect_static.py','/Applications/Blender.app/Contents/MacOS/Blender', ['-b','mechanical/mori_v1_2.blend','--python']),
        ('diagnose_cc_subdivision.py','/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13', [])]:
        log=HERE/(Path(script).stem+'.log')
        assert 'Traceback (most recent call last)' not in log.read_text()
        commands.append(dict(command=[runtime]+args+[str((HERE/script).relative_to(PROJECT))],
                             cwd=str(PROJECT),log=str(log.relative_to(PROJECT)),log_sha256=sha(log)))
    (HERE/'commands.json').write_text(json.dumps(dict(status='PASS',commands=commands,
        initial_attempt_logs=['diagnose_cc_subdivision_initial_old_native_receipt.log'],
        initial_failure='The old M1.54 report includes changed native-model hashes. Retry verifies its frozen curve pairing and independently reconstructs that curve; old native PASS is not inherited.'),ensure_ascii=False,indent=2)+'\n')
    rows=''.join(f'<tr><td>{html.escape(r["wire"])}</td><td>130</td><td>PASS</td><td>{r["zero_pose"]["length_mm"]:.2f} mm</td></tr>' for r in inspection['summary'])
    progress=dict(status='PASS',scope='Published finite geometry checks of seven unadopted upper references only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sources={str(HERE/n):sha(HERE/n) for n in ['inspection.json','cc_subdivision_diagnostic.json','commands.json']},
        revision='V1.2-M1.55',source_blend_sha256=inspection['sources'][str(MECHANICAL/'mori_v1_2.blend')],
        upper_finite_native_clearance='PASS',available_upper_references=7,missing_upper_references=inspection['missing_upper_references'],
        remaining_work_packages=4,upper_between_pose_motion='NOT_TESTED',upper_continuous_curvature='NOT_TESTED',
        actual_mixed_material_length='BLOCKED',actual_endpoints_and_clamps='BLOCKED',wired_assembly_and_closure='BLOCKED',
        full_harness='BLOCKED',main_changed=False,animation_changed=False,hardware_changed=False,
        new_commit_or_push=False,manufacturing_release=False)
    (HERE/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 上段参考检查与剩余工作</title>
<style>body{{max-width:1050px;margin:35px auto;padding:0 18px 70px;font:16px/1.7 system-ui;color:#243841;background:#f6f8f9}}a{{color:#146885}}table{{width:100%;border-collapse:collapse;background:white}}td,th{{padding:11px;border-bottom:1px solid #d9e1e5;text-align:left;vertical-align:top}}.notice{{padding:18px;background:#fff2d8;border-left:4px solid #bd802b}}</style>
<h1>M1.55 · 上段参考检查</h1><p>2026-10-09 · <strong>已有7条上段的有限姿态实体间隙PASS；完整线束BLOCKED／未采用。</strong></p>
<p class="notice">当前仍剩4类工作：完整上段、整条材料与线长、真实端接与应力释放、带线装配与闭壳。不是只剩实物验证。主模型与动画中的批准结构已同步；本页参考走线尚未进入主模型。</p>
<p><a href="../index.html">线束研究总览</a> · <a href="../prefix_continuity/frame_family_R3/continuous_gaps_R1/index.html">已完成的身体／颈部连续检查</a> · <a href="../../reaction_clamp_R2_adoption/index.html">M1.55采用记录</a> · <a href="../../../mori_v1_2.blend">主模型</a> · <a href="../../../animation/index.html">装配视频</a></p>
<h2>这轮完成了什么</h2><p>7条保留的上段参考与当前201件原生固体重新检查，覆盖13档偏航×10档俯仰，共910条线路姿态、2,730次原生分组检查；原0.3mm间隙目标保持，没有继承旧M1.54实体PASS。另有910次条件USB占位检查通过，占位结果不能确认真实插头配合。</p>
<table><tr><th>参考线路</th><th>姿态数</th><th>实体间隙</th><th>零位上段参考长度</th></tr>{rows}</table>
<p>表中长度从Z200参考切面到假定出线点，不是供应商裁线尺寸。该切面不是已确定的接头或夹持点；姿态间长度变化也不是实际导线伸缩的合格证据。CAM较长上段来自保留的头内余量环和USB绕行设计，裁切与源数组配对已核对，没有擅自删去这些参考环。</p>
<h2>CC的小半径诊断</h2><p>旧折线细分后，三个相邻点给出的半径约{cc['diagnostic_polyline_three_point_radius_mm']:.3f}mm。独立重构其原始9次平滑曲线，Z200～206段的半径保守下界为{cc['analytic_radius_lower_bound_mm']:.3f}mm，保存折线到该曲线最大偏差仅{cc['maximum_saved_chord_to_declared_curve_error_mm']:.8f}mm。因此那一处小半径是细分折线三点算法的假象，不能据此改结构。这里只核对零位这一段，没有扩大为完整CC或全角度曲率PASS。</p>
<h2>还差多少，卡在哪里</h2><table><tr><th>剩余工作</th><th>已有进展</th><th>继续工作的条件</th></tr>
<tr><td>1．完整上段路线</td><td>7条已有参考的130姿态实体间隙通过</td><td>继续上段之间、自接近、接续及中间角度复核；三根舵机与两根喇叭参考缺完整上段，不能虚构真实出线点</td></tr>
<tr><td>2．整条材料与线长</td><td>12条身体／颈部参考前段的公共数值长度及连续几何已通过</td><td>真实厂配SH尾线、压接／接续、第一可弯点和固定／滑移位置确定后，才能冻结全线与裁线图</td></tr>
<tr><td>3．接头和应力释放</td><td>H06厂家压接、穿线后入壳已确认；喇叭150mm含已有插头已记录</td><td>CAM供电源端待硬件正式交接，完整USB插头／尾线和喇叭插头规格尚未确定；不能用占位放行</td></tr>
<tr><td>4．带线装配与闭壳</td><td>批准的裸结构R2装入与模型／动画已同步</td><td>整束及固定点闭合后，复核逐根端子穿入、后装线、头身安装和闭壳，再同步正式线束与动画</td></tr></table>
<p>SC-0090-C001舵盘／花键／锁紧和微雪FPC／FFC按用户决定到货后校准。PA12配合、公差、强度和线束寿命仍需实物验证。没有新增结构方案等待用户批准，也没有采用接头或硬件研究候选。</p>
<p><a href="inspection.json">130姿态原始检查</a> · <a href="cc_subdivision_diagnostic.json">CC曲线重构诊断</a> · <a href="progress.json">范围与进度</a> · <a href="commands.json">实际命令与重试</a> · <a href="README.md">复现说明</a> · <a href="delivery.json">发布哈希</a></p>
<p>PROTOTYPE / UNVALIDATED · 参考线路PLACEHOLDER / ASSUMED · full_harness=BLOCKED · manufacturing_release=false</p></html>'''
    (HERE/'index.html').write_text(page)
    (HERE/'README.md').write_text('''# M1.55 上段参考有限检查：未采用

7条现有上段、13×10个姿态、201件当前原生实体，0.3mm目标PASS。
这是有限姿态检查，没有覆盖连续中间角度、完整线束或真实端接。
三根舵机及两根喇叭参考缺完整上段；未虚构出线点。
CC零位Z200..206的三点小半径是细分折线诊断假象；原平滑曲线单独重构。
不把该局部结果扩为整条CC或动态寿命PASS。

实际命令与日志见commands.json。inspect_static.py通过离线Blender5.2.2 LTS
读取批准M1.55主模型；diagnose_cc_subdivision.py使用自带Python3.13.13与NumPy2.3.4。
旧诊断首次误将M1.54实体哈希作为曲线重构前提，失败日志保留；修正后只接收
冻结曲线与元数据的匹配，重新计算当前形状，不继承旧实体PASS。

正式H06仍AWG28／PH002／PHR-4＋厂家SH尾线。
喇叭150mm含已有插头；实发舵盘及微雪排线按用户安排到货再校准。
本轮没有改主模型、动画、打印件、硬件、正式物料，没有commit/push。
完整线束、真实材料线长、端接／夹持及带线闭壳仍BLOCKED。
''')
    files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file()
           and '__pycache__' not in p.parts and p.name not in [
               'delivery.json','publication_verification.json','running_progress.json','publish_result.log','verify_publication.log']}
    (HERE/'delivery.json').write_text(json.dumps(dict(status='PASS',scope='Upper reference finite-check publication only',
        revision='V1.2-M1.55',source_blend_sha256=progress['source_blend_sha256'],
        upper_finite_native_clearance='PASS',full_harness='BLOCKED',remaining_work_packages=4,
        main_changed=False,animation_changed=False,hardware_changed=False,new_commit_or_push=False,
        manufacturing_release=False,files=files),ensure_ascii=False,indent=2)+'\n')
    print('UPPER_REFERENCE_PUBLISHED',len(files),'files',flush=True)


if __name__=='__main__':
    main()
