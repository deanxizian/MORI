"""Recheck retained upper allocations against saved M1.55, without adoption.

The 13 x 10 stored pose grid is finite. Three-point bend and seam-tangent
measurements are diagnostics, not continuous curve or material certificates.
Missing upper references and physical terminations remain explicitly open.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(PARENT))
from context import Context, ROOT, PROJECT, PREVIOUS, bpy, np, P, rigidtr, clear, clean, transform_points, sha, length

sys.path.insert(0, str(PARENT/'global_bundle_layout'))
from check_upper_seams import upper_tail
HERE = Path(__file__).resolve().parent

YAWS = list(range(-60, 61, 10))
PITCHES = list(range(-20, 26, 5))
EXPECTED = {'P_J18_1', 'P_J18_2', 'CAM_1', 'CAM_2', 'CAM_3', 'CAM_4', 'CC_allocation'}
MISSING = {'P_J9_1', 'P_J9_2', 'P_J9_3', 'SPK_reservation_3', 'SPK_reservation_6'}


def diagnostic(points):
    spans = np.diff(points, axis=0)
    steps = np.linalg.norm(spans, axis=1)
    assert steps.min() > 1e-9
    u, v = spans[:-1], spans[1:]
    areas = np.linalg.norm(np.cross(u, v), axis=1)
    valid = areas > 1e-11
    radii = np.full(len(u), np.inf)
    radii[valid] = (steps[:-1][valid]*steps[1:][valid]
                    * np.linalg.norm(u+v, axis=1)[valid]/(2*areas[valid]))
    i = int(np.argmin(radii))
    return dict(points=len(points), length_mm=length(points), max_segment_mm=float(steps.max()),
                bounds_mm=[points.min(0).tolist(), points.max(0).tolist()],
                min_three_point_radius_mm=float(radii[i]),
                min_radius_vertex=i+1, min_radius_point_mm=points[i+1].tolist(),
                radius_kind='Diagnostic circumradius of adjacent saved chords, not a continuous certificate')


def main():
    started = time.time()
    ctx = Context()
    layout = PARENT/'global_bundle_layout'
    receipt_path = layout/'upper_seam_inspection.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'PASS'
    assert all(sha(p) == h for p, h in receipt['sources'].items())
    assert set(receipt['missing_upper_reference_segments']) == MISSING
    paths = [PREVIOUS/'cc_power_bundle/body_candidate.npz',
             PREVIOUS/'cc_thin_reference/adaptive_between_candidate.npz',
             PREVIOUS/'cc_power_bundle/fixed_length_candidate.npz']
    body = np.load(paths[0])['CC_body']
    necks, uppers = [np.load(p) for p in paths[1:]]
    ctx.record([Path(__file__), layout/'check_upper_seams.py', receipt_path]+paths)
    video = ROOT/'animation/MORI_assembly.mp4'
    ctx.record([video])
    baseline_path = ROOT/'input_assets/M1_55_reaction_entry_baseline.json'
    baseline = json.loads(baseline_path.read_text())
    protected = {n: h for n, h in baseline['protected_hardware'].items()
                 if '__pycache__' not in Path(n).parts and Path(n).name != '.DS_Store'}
    assert len(protected) == 846
    assert all(sha(PROJECT/n) == h for n, h in protected.items())
    ctx.record([baseline_path])
    rows, failures, conditional, joins, missing = [], [], [], [], set()
    zero = {}
    for yaw in YAWS:
        folder = layout/'all_yaws_R3'/f'y{yaw}'
        meta_path = folder/'optimization.json'
        meta = json.loads(meta_path.read_text())
        ctx.record([meta_path])
        seams = {n: np.asarray(r['reference_end_mm']) for n, r in meta['wires'].items()}
        for pitch in PITCHES:
            refs = ctx.refs(yaw, pitch)
            neck, up = necks[f'CC_y{yaw}'], uppers[f'CC_y{yaw}_p{pitch}']
            assert np.linalg.norm(body[-1]-neck[0]) < 1e-8
            assert np.linalg.norm(neck[-1]-up[0]) < 1e-8
            refs = dict(refs)
            refs['CC_allocation'] = dict(p=clean(np.vstack([body, neck[1:], up[1:]])),
                                         radius=.3683, error=.0006)
            tails = {}
            for name, ref in refs.items():
                p = upper_tail(ref['p'], seams[name])
                if len(p) < 2:
                    missing.add(name)
                    continue
                tails[name] = dict(ref, p=p)
            assert set(tails) == EXPECTED
            for name, ref in tails.items():
                p, radius, error = ref['p'], ref['radius'], ref['error']
                details = diagnostic(p)
                native = []
                for group, targets in ctx.groups.items():
                    mat = np.eye(4) if group == 'body' else np.linalg.inv(
                        np.asarray(rigidtr(yaw, pitch if group == 'pitch' else 0)))
                    bad, near = clear(transform_points(p, mat), radius, targets, error=error)
                    row = dict(group=group, status='BLOCKED' if bad else 'PASS',
                               hits=bad, nearest_within_query_AABBs=near)
                    native.append(row)
                    if bad:
                        failures.append(dict(yaw_deg=yaw, pitch_deg=pitch, wire=name, **row))
                local = transform_points(p, np.linalg.inv(np.asarray(rigidtr(yaw, pitch))))
                bad, near = clear(local, radius, ctx.usb, error=error)
                allocation = dict(yaw_deg=yaw, pitch_deg=pitch, wire=name,
                                  status='BLOCKED' if bad else 'PASS', hits=bad,
                                  nearest_within_query_AABBs=near,
                                  scope='Unselected conditional USB allocation only')
                conditional.append(allocation)
                rows.append(dict(yaw_deg=yaw, pitch_deg=pitch, wire=name,
                                 radius_mm=radius, chord_error_allowance_mm=error,
                                 status='PASS' if all(r['status']=='PASS' for r in native) else 'BLOCKED',
                                 native=native, diagnostic=details))
                joins.append(dict(yaw_deg=yaw, pitch_deg=pitch, wire=name,
                                  gap_mm=float(np.linalg.norm(p[0]-seams[name])),
                                  source_seam_mm=seams[name].tolist(),
                                  physical_splice_or_clamp='BLOCKED'))
                if yaw == pitch == 0:
                    zero[name] = p
            print('UPPER_STATIC_POSE', yaw, pitch, 'native_failures', len(failures), flush=True)
        # Save a small progress record without presenting a partial run as PASS.
        (HERE/'running_progress.json').write_text(json.dumps(dict(
            status='NOT_TESTED', completed_yaws=yaw//10+7, wire_pose_checks=len(rows),
            native_failures=len(failures), final_report='inspection.json'), indent=2)+'\n')
    assert missing == MISSING and len(rows) == 910 and len(conditional) == 910
    assert max(r['gap_mm'] for r in joins) < 1e-7
    summaries = []
    for name in sorted(EXPECTED):
        selected = [r for r in rows if r['wire']==name]
        diagnostics = [r['diagnostic'] for r in selected]
        lower = min(diagnostics, key=lambda r:r['min_three_point_radius_mm'])
        summaries.append(dict(wire=name, pose_count=len(selected),
            native_status='PASS' if all(r['status']=='PASS' for r in selected) else 'BLOCKED',
            length_range_mm=[min(r['length_mm'] for r in diagnostics), max(r['length_mm'] for r in diagnostics)],
            zero_pose=next(r['diagnostic'] for r in selected if r['yaw_deg']==r['pitch_deg']==0),
            minimum_three_point_radius_diagnostic=lower,
            continuous_curvature='NOT_TESTED', actual_factory_length='BLOCKED'))
    ctx.unchanged()
    assert all(sha(PROJECT/n) == h for n, h in protected.items())
    np.savez_compressed(HERE/'zero_pose_upper_references.npz', **zero)
    result = dict(status='PASS' if not failures else 'BLOCKED',
        scope='Seven retained upper reference tails against 201 current native solids, finite 13x10 pose grid only',
        recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        revision=P['revision'], sources=ctx.sources, poses=130, checked_upper_wires=7,
        wire_pose_checks=len(rows), native_group_checks=3*len(rows), required_native_gap_mm=.3,
        native_failure_rows=failures, summary=summaries, rows=rows, joins=joins,
        missing_upper_references=sorted(missing), conditional_USB_checks=conditional,
        conditional_USB_status='PASS' if all(r['status']=='PASS' for r in conditional) else 'BLOCKED',
        old_native_PASS_inherited=False, all_stored_seams_preserved=True,
        upper_between_pose_motion='NOT_TESTED', upper_continuous_curvature='NOT_TESTED',
        full_mixed_radius_self_and_peers='NOT_TESTED', actual_endpoints_and_clamps='BLOCKED',
        actual_mixed_material_length='BLOCKED', wired_assembly_and_closure='BLOCKED',
        dynamic_life='NOT_TESTED', full_harness='BLOCKED', manufacturing_release=False,
        protected_hardware_files=len(protected), main_changed=False, animation_changed=False,
        hardware_changed=False, new_commit_or_push=False,
        blender_version=bpy.app.version_string, blender_build_hash=bpy.app.build_hash.decode(),
        python_version=sys.version.split()[0], numpy_version=np.__version__,
        elapsed_s=time.time()-started)
    (HERE/'inspection.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print('UPPER_STATIC_TERMINAL', result['status'], len(rows), len(failures), result['elapsed_s'], flush=True)


if __name__ == '__main__':
    main()
