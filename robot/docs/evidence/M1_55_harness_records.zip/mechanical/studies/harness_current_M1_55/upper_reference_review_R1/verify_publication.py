"""Independent report coverage, local publication and preservation checks."""
from pathlib import Path
import datetime
import hashlib
import itertools
import json
import re
import subprocess
from urllib.parse import urlsplit,unquote
from urllib.request import urlopen,Request

HERE=Path(__file__).resolve().parent
MECHANICAL=HERE.parents[2]
PROJECT=MECHANICAL.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=read(HERE/'delivery.json')
r=read(HERE/'inspection.json')
assert d['status']==r['status']=='PASS' and d['full_harness']=='BLOCKED'
assert all(sha(HERE/n)==h for n,h in d['files'].items())
assert all(sha(p)==h for p,h in r['sources'].items())
names={'P_J18_1','P_J18_2','CAM_1','CAM_2','CAM_3','CAM_4','CC_allocation'}
wanted=set(itertools.product(range(-60,61,10),range(-20,26,5),names))
actual={(x['yaw_deg'],x['pitch_deg'],x['wire']) for x in r['rows']}
assert actual==wanted and len(r['rows'])==910
assert not r['native_failure_rows']
assert sum(len(x['native']) for x in r['rows'])==2730
assert all(x['status']=='PASS' and {z['group'] for z in x['native']}=={'body','yaw','pitch'}
           and all(z['status']=='PASS' and not z['hits'] for z in x['native']) for x in r['rows'])
assert {(x['yaw_deg'],x['pitch_deg'],x['wire']) for x in r['conditional_USB_checks']}==wanted
assert all(x['status']=='PASS' and not x['hits'] for x in r['conditional_USB_checks'])
assert max(x['gap_mm'] for x in r['joins'])<1e-7
cc=read(HERE/'cc_subdivision_diagnostic.json')
assert cc['status']=='PASS' and all(sha(p)==h for p,h in cc['sources'].items())
assert cc['analytic_radius_lower_bound_mm']>10
assert cc['continuous_whole_CC_upper']=='NOT_TESTED'
base=read(MECHANICAL/'input_assets/M1_55_reaction_entry_baseline.json')
protected={n:h for n,h in base['protected_hardware'].items()
           if '__pycache__' not in Path(n).parts and Path(n).name!='.DS_Store'}
assert len(protected)==846 and all(sha(PROJECT/n)==h for n,h in protected.items())
assert sha(MECHANICAL/'mori_v1_2.blend')==d['source_blend_sha256']
assert sha(MECHANICAL/'animation/MORI_assembly.mp4')=='9743c7245280b03f291ca7f3a494e846e25b4b75e3df03258e0799ae054488ca'
links=[]
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    parsed=urlsplit(value)
    if parsed.scheme or not parsed.path:continue
    target=(HERE/unquote(parsed.path)).resolve()
    assert target.is_file() and target.is_relative_to(PROJECT),(value,target)
    url='http://127.0.0.1:58202/'+str(target.relative_to(PROJECT))
    with urlopen(Request(url,method='HEAD'),timeout=10) as response:assert response.status==200
    links.append(str(target.relative_to(PROJECT)))
with urlopen('http://127.0.0.1:58202/'+str((HERE/'index.html').relative_to(PROJECT)),timeout=10) as response:
    assert hashlib.sha256(response.read()).hexdigest()==sha(HERE/'index.html')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
assert head=='a719272b305f6e17fa19bf4687a6826003f16c2b'
result=dict(status='PASS',scope='Report coverage/publication/preservation; finite references only',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),delivery_sha256=sha(HERE/'delivery.json'),
    checked_files=len(d['files']),wire_pose_checks=910,native_group_checks=2730,
    checked_local_links=links,HTTP_HEAD='PASS',HTTP_page_content_sha256='PASS',
    source_blend_sha256=d['source_blend_sha256'],protected_hardware_files=len(protected),
    main_and_animation_unchanged=True,protected_hardware_unchanged=True,Git_HEAD=head,
    full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__)))
(HERE/'publication_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('UPPER_REFERENCE_VERIFIED',len(d['files']),'files',len(links),'links',len(protected),'protected hardware',flush=True)
