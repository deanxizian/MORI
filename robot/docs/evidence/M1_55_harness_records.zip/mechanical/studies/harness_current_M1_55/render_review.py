"""Standalone unadopted cable inspection using exact saved native parts."""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from context import *

ctx=Context();digest=sha(ROOT/'mori_v1_2.blend')
reviews=[HERE/f'body_relayout{suffix}/review.json' for suffix in ['', '_R2','_R3','_R4']]
assert all(p.exists() for p in reviews)
last=json.loads(reviews[-1].read_text());choice=last['accepted'] or last['attempts'][0]['candidate']
path=reviews[-1].parent/choice/'curves.npz';curves=np.load(path)
scene=bpy.data.scenes.new('MORI_M1_55_UNADOPTED_HARNESS_REVIEW');bpy.context.window.scene=scene
scene['source_revision']=P['revision'];scene['main_source_sha256']=digest;scene['manufacturing_release']=False
scene['candidate_status']=last['status'];scene['candidate_selection']='UNSELECTED_CAPACITY_STUDY'
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001;scene.unit_settings.length_unit='MILLIMETERS'
scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1200;scene.render.resolution_y=950;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=False;scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
scene.world=bpy.data.worlds.new('MORI_M155_HARNESS_WORLD');scene.world.color=(.075,.095,.12)
collection=bpy.data.collections.new('MORI_M155_HARNESS_INSPECTION');scene.collection.children.link(collection)
collection['review_owner']='M155_HARNESS_READONLY'
shown=[]
for n in ['Load_Frame','Yaw_Base','Pitch_Yoke','MCU_Carrier','MCU_Motion','Power_Module','Yaw_Reaction_Link','Yaw_Anti_Lift_Keeper']:
    if n not in ctx.ss:continue
    original=ctx.ss[n].o;o=original.copy();o.data=original.data.copy();o.parent=None;o.matrix_world=original.matrix_world.copy()
    o.name='MORI_M155_REVIEW_'+n;o.hide_render=False;o['review_owner']='M155_HARNESS_READONLY';o['mori_owner']='M155_HARNESS_READONLY'
    o['source_object']=original.name;o['export_candidate']=False;collection.objects.link(o);shown.append(n)

def wire(n,p,radius,color,role):
    c=bpy.data.curves.new('MORI_M155_REVIEW_'+n,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=radius;c.bevel_resolution=3
    s=c.splines.new('POLY');s.points.add(len(p)-1)
    s.points.foreach_set('co',np.c_[p,np.ones(len(p))].ravel())
    m=bpy.data.materials.new('MORI_M155_REVIEW_'+n+'_MAT');m.diffuse_color=(*color,1);c.materials.append(m)
    o=bpy.data.objects.new('MORI_M155_REVIEW_'+n,c);collection.objects.link(o)
    o['review_owner']='M155_HARNESS_READONLY';o['category']='PLACEHOLDER';o['data_status']='ASSUMED'
    o['role']='routing_reference';o['export_candidate']=False;o['manufacturing_release']=False;o['model_fidelity']=role
    return o

for pin,color in [(1,(.95,.42,.08)),(2,(.98,.58,.10)),(3,(1.,.74,.14)),(4,(.88,.35,.07))]:
    p=curves[f'CAM_{pin}_y0_p0'];o=wire('H06_BODY_'+str(pin),p,.565,color,'Maximum vendor-documented OD1.13mm on unadopted PH-side candidate; no actual crimp, SH tail or splice model')
    o['OD_capacity_mm']=1.13;o['unselected_wire_candidate']='Tensility 30-02600';o['OD_field_evidence']='VENDOR_DOCUMENTED';o['candidate_path']=str(path.relative_to(PROJECT))
for n,d in ctx.refs(0,0).items():
    if not n.startswith('CAM_'):wire('RETAINED_'+n,d['p'],d['radius'],(.24,.33,.40),'Historical unselected conductor reference retained for clearance comparison')

camera_data=bpy.data.cameras.new('MORI_M155_HARNESS_CAMERA');camera=bpy.data.objects.new('MORI_M155_HARNESS_CAMERA',camera_data);scene.collection.objects.link(camera)
camera_data.type='ORTHO';camera_data.clip_start=.1;camera_data.clip_end=1200;scene.camera=camera
files=[]
for name,loc,target,scale in [('body_neck_overview',(150,-210,255),(0,-14,160),140),
                             ('body_neck_detail',(55,-85,183),(0,-9,149),66)]:
    camera.location=loc;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera_data.ortho_scale=scale
    scene.render.filepath=str(HERE/(name+'.png'));bpy.ops.render.render(write_still=True);files.append(dict(file=name+'.png',sha256=sha(HERE/(name+'.png'))))
ctx.unchanged();assert sha(ROOT/'mori_v1_2.blend')==digest
target=HERE/'harness_M1_55_UNADOPTED_inspection.blend';bpy.ops.wm.save_as_mainfile(filepath=str(target))
assert sha(ROOT/'mori_v1_2.blend')==digest
(HERE/'render_manifest.json').write_text(json.dumps(dict(status='PASS',scope='Rendered inspection only; no route or manufacturing qualification',revision=P['revision'],source_blend_sha256=digest,
    exact_saved_native_meshes=shown,unadopted_candidate=choice,candidate_screen_status=last['status'],files=files,
    inspection_file=target.name,inspection_sha256=sha(target),source_unchanged=True,wire_material_selected=False,main_changed=False,
    full_harness='BLOCKED',manufacturing_release=False,script_sha256=sha(Path(__file__))),ensure_ascii=False,indent=2)+'\n')
print('M155_HARNESS_REVIEW_RENDERED',choice,last['status'],flush=True)
