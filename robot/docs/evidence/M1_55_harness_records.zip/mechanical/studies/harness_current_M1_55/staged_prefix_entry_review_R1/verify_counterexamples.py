"""Independently replay the prelaid-prefix collision witnesses.

Reconstruct all zero-yaw prefix cubics from the unchanged R3 family and use
the separately exported current201 native world meshes. Inscribed sphere
overlaps at exact sampled curve points establish capacity counterexamples.
This verifies the failed preparation, not the remainder of a wired assembly.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import numpy as np

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
PROJECT = HERE.parents[3]
sys.path[:0] = [str(PARENT / 'prefix_continuity/frame_family_R3'),
               str(PROJECT / 'mechanical/scripts/vendor')]
from selected_family import SelectedFamily, BSpline
import manifold3d as manifold

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    started = time.time()
    report_path = HERE / 'prefix_entry_review.json'
    report = read(report_path)
    assert report['status'] == 'BLOCKED' and len(report['rows']) == 12
    assert all(sha(p) == h for p, h in report['sources'].items())
    array_path = HERE / 'zero_prefixes.npz'
    assert sha(array_path) == report['arrays_sha256']
    arrays = np.load(array_path)
    current = PARENT / 'terminal_install_review_R1'
    receipt = read(current / 'current_native_receipt.json')
    native_path = current / 'current_native_parts.npz'
    assert receipt['status'] == 'PASS' and receipt['native_part_count'] == 201
    assert sha(native_path) == receipt['output_sha256']
    assert all(sha(p) == h for p, h in receipt['sources'].items())
    common_sources = set(receipt['sources']) & set(report['sources'])
    assert str(PROJECT / 'mechanical/mori_v1_2.blend') in common_sources
    assert all(receipt['sources'][p] == report['sources'][p] for p in common_sources)
    native = np.load(native_path)
    manifest_path = PROJECT / 'mechanical/animation/manifest.json'
    manifest = read(manifest_path)
    prior = {n for n, stage in manifest['part_stages'].items() if stage < 13}
    assert prior == set(report['moving_native_ids']) | set(report['stationary_prior_native_ids'])
    assert len(prior) == 123 and report['moving_native_count'] == 21
    assert not set(report['moving_native_ids']) & set(report['stationary_prior_native_ids'])
    assert report['stage'] == next(s for s in manifest['stages'] if s['source_step'] == 21)
    assert report['path_segments'][0]['start_translation_mm'] == [130., 0., 64.]
    assert report['path_segments'][0]['end_translation_mm'] == [0., 0., 64.]
    assert report['path_segments'][1]['end_translation_mm'] == [0., 0., 0.]
    assert all(max(r['moving_matrix_error_mm'], r['fixed_matrix_error_mm']) < .00005
               for r in report['actor_matrix_readback'])
    family = SelectedFamily()
    assert set(family.names) == {r['wire'] for r in report['rows']}
    verified = []
    for row in report['rows']:
        name = row['wire']
        spline = BSpline(family.knots, family.candidate(name, 0)['control'], 3)
        derivative = spline.derivative()
        edges = np.unique(family.knots)
        cubics = np.array([[spline(a), spline(a) + derivative(a) * (b-a)/3,
                            spline(b) - derivative(b) * (b-a)/3, spline(b)]
                           for a, b in zip(edges[:-1], edges[1:])])
        discrepancy = float(np.max(abs(cubics - arrays[name + '__controls_mm'])))
        assert discrepancy < 1e-10
        reconstructed = []
        for c in cubics:
            speed = float(np.linalg.norm(3*np.diff(c, axis=0), axis=1).max())
            count = max(1, int(np.ceil(speed/.03)))
            u = np.linspace(0., 1., count+1)[:, None]
            points = ((1-u)**3*c[0] + 3*u*(1-u)**2*c[1] +
                      3*u*u*(1-u)*c[2] + u**3*c[3])
            reconstructed.append(points if not reconstructed else points[1:])
        points = np.concatenate(reconstructed)
        assert np.max(abs(points - arrays[name + '__points_mm'])) < 1e-10
        assert row['radius_capacity_mm'] == family.radii[name]
        assert row['status'] == 'BLOCKED' and row['stationary_prior_parts']['status'] == 'PASS'
        assert row['segments'][0]['status'] == 'PASS'
        coverage = [r['parameter_interval'] for r in row['segments'][0]['accepted_intervals']]
        assert coverage[0][0] == 0. and coverage[-1][1] == 1.
        assert all(a[1] == b[0] for a, b in zip(coverage[:-1], coverage[1:]))
        failure = row['segments'][1]['first_failure']
        assert row['segments'][1]['status'] == 'BLOCKED'
        position = np.array(failure['native_translation_mm'])
        assert np.array_equal(position, [0., 0., 32.])
        local_point = np.array(failure['nearest']['point_mm'])
        world_point = local_point + position
        delta = np.linalg.norm(points-world_point, axis=1)
        index = int(np.argmin(delta))
        assert delta[index] < 1e-10
        n = failure['nearest']['object']
        assert n == 'Pitch_Yoke' and n in report['moving_native_ids']
        target = manifold.Manifold(manifold.Mesh64(native[n+'__vertices_mm'],
                                                  native[n+'__triangles'].astype(np.uint64)))
        assert target.status() == manifold.Error.NoError
        probe = manifold.Manifold.sphere(family.radii[name], 96).translate(local_point.tolist())
        overlap = float((probe ^ target).volume())
        assert overlap > 1e-5, (name, overlap)
        verified.append(dict(wire=name, native=n, native_translation_mm=position.tolist(),
                             curve_sample_index=index, sample_replay_error_mm=float(delta[index]),
                             source_cubic_reconstruction_error_mm=discrepancy,
                             inscribed_sphere_overlap_mm3=overlap,
                             radius_capacity_mm=family.radii[name], status='PASS'))
    family.unchanged()
    sources = {**report['sources'], **receipt['sources'], **family.sources,
               **{str(p): sha(p) for p in [Path(__file__), report_path, array_path,
                                           current/'current_native_receipt.json', native_path, manifest_path]}}
    assert all(sha(p) == h for p, h in sources.items())
    baseline = read(PROJECT/'mechanical/input_assets/M1_55_reaction_entry_baseline.json')
    protected = {p: h for p, h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT/p) == h for p, h in protected.items())
    output = dict(status='PASS', scope='Independent verification of twelve capacity collision counterexamples only',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  sources=sources, verified_collision_witnesses=12, witnesses=verified,
                  source_native_part_count=201, moving_native_parts=21, stationary_prior_native_parts=102,
                  saved_motion_readback_rows=len(report['actor_matrix_readback']),
                  candidate_prelaid_prefix_entry='BLOCKED', temporary_free_ends='NOT_TESTED',
                  actual_full_harness='BLOCKED', protected_hardware_files=846,
                  main_changed=False, hardware_changed=False, animation_changed=False,
                  assembly_order_changed=False, manufacturing_release=False, elapsed_s=time.time()-started)
    (HERE/'counterexample_verification.json').write_text(json.dumps(output, indent=2)+'\n')
    print('PRELAID_PREFIX_COUNTEREXAMPLES_VERIFIED', 12, 21, 102, 846, flush=True)


if __name__ == '__main__':
    main()
