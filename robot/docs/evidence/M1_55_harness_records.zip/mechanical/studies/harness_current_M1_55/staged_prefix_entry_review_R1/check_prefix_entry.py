"""Prelaid capacity prefixes versus the saved M1.55 head-seat entry.

Only the twelve zero-yaw R3 body/neck prefixes are tested. Their Z200 ends
are mathematical cuts, not physical free terminals or a temporary harness.
The actual saved head-seat actor set and FCurves define the motion. No part,
wire reference, assembly order or supplier selection is changed.
"""
from pathlib import Path
import datetime
import json
import sys
import time

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path[:0] = [str(PARENT), str(PARENT / 'prefix_continuity/frame_family_R3'),
               str(PARENT / 'upper_smooth_review_R2'), str(PARENT / 'upper_length_match_R1')]
from context import Context, np, bpy, clear, sha, ROOT, PROJECT
from selected_family import SelectedFamily, BSpline
from piecewise_geometry import pieces
from sample_geometry import sample
from assembly_animation import AP, SCENE_NAME, curves


def descendant(actor, root):
    while actor is not None:
        if actor == root:
            return True
        actor = actor.parent
    return False


def main():
    started = time.time()
    ctx = Context()
    family = SelectedFamily()
    manifest_path = ROOT / 'animation/manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['source_blend_sha256'] == sha(ROOT / 'mori_v1_2.blend')
    stage = next(s for s in manifest['stages'] if s['source_step'] == 21)
    assert stage['index'] == 13
    baseline_matrices = {n: np.asarray(s.o.matrix_world).copy() for n, s in ctx.ss.items()}
    animation_path = ROOT / 'mori_assembly_animation.blend'
    ctx.record([Path(__file__), manifest_path, animation_path, ROOT / 'scripts/assembly_animation.py',
                PARENT / 'upper_length_match_R1/sample_geometry.py',
                PARENT / 'upper_smooth_review_R2/piecewise_geometry.py'])
    bpy.ops.wm.open_mainfile(filepath=str(animation_path))
    scene = bpy.data.scenes[SCENE_NAME]
    bpy.context.window.scene = scene
    actors = {o.name.removeprefix(AP): o for o in scene.objects if o.get('presentation_actor')}
    root = bpy.data.objects[AP + 'Yaw_Group']
    assert root.parent is None
    assert np.max(abs(np.asarray(root.rotation_euler))) < 1e-10
    assert np.array_equal(np.asarray(root.scale), np.ones(3))
    prior = {n for n in ctx.ss if manifest['part_stages'][n] < stage['index']}
    moving = sorted(n for n in prior if descendant(actors[n], root))
    fixed = sorted(prior - set(moving))
    assert {'Pitch_Yoke', 'Yaw_Reaction_Link', 'Yaw_Anti_Lift_Keeper',
            'Yaw_Servo', 'Pitch_Servo'} <= set(moving)
    assert 'CAM_Mainboard' not in prior and 'Pitch_Cradle' not in prior
    assert not {'Body_Front', 'Body_Rear', 'Head_Front', 'Head_Rear'} & prior
    waypoints = [(stage['start'] + 8, [130., 0., 64.]),
                 (stage['start'] + 28, [0., 0., 64.]),
                 (stage['start'] + 62, [0., 0., 0.])]
    channels = {fc.array_index: fc for fc in curves(root) if fc.data_path == 'location'}
    assert set(channels) == {0, 1, 2}
    segments = []
    for (left, a), (right, b) in zip(waypoints[:-1], waypoints[1:]):
        values = []
        for axis in range(3):
            keys = {int(k.co[0]): k for k in channels[axis].keyframe_points}
            ka, kb = keys[left], keys[right]
            assert ka.interpolation == 'LINEAR'
            assert np.max(abs(np.array([ka.co[1], kb.co[1]]) - np.array([a[axis], b[axis]]))) < 1e-5
            assert not any(left < k.co[0] < right for k in channels[axis].keyframe_points)
            values.append([float(ka.co[1]), float(kb.co[1])])
        segments.append(dict(frame_interval=[left, right],
                             start_translation_mm=a, end_translation_mm=b,
                             saved_linear_channels=values))
    matrix_rows = []
    fixed_matrices = None
    for (left, a), (right, b) in zip(waypoints[:-1], waypoints[1:]):
        for u in np.linspace(0., 1., 17):
            frame = left + float(u) * (right - left)
            scene.frame_set(int(frame), subframe=frame % 1)
            bpy.context.view_layer.update()
            expected = np.eye(4)
            expected[:3, 3] = np.array(a) * (1-u) + np.array(b) * u
            actual = {n: np.asarray(actors[n].matrix_world) @ np.linalg.inv(baseline_matrices[n])
                      for n in prior}
            if fixed_matrices is None:
                fixed_matrices = {n: actual[n].copy() for n in fixed}
            e_move = max(float(np.max(abs(actual[n] - expected))) for n in moving)
            e_fixed = max(float(np.max(abs(actual[n] - fixed_matrices[n]))) for n in fixed)
            assert max(e_move, e_fixed) < .00005
            assert all(not actors[n].hide_render for n in prior)
            matrix_rows.append(dict(frame=frame, moving_matrix_error_mm=e_move,
                                    fixed_matrix_error_mm=e_fixed))
    assert max(float(np.max(abs(m - np.eye(4)))) for m in fixed_matrices.values()) < .00005

    # All prior rigid components are retained. The twelve curves are research
    # prefixes in body coordinates and have no claimed head-end attachment.
    all_sources = ctx.sources | family.sources
    arrays = {}
    packs = {}
    for name in family.names:
        controls = pieces(BSpline(family.knots, family.candidate(name, 0)['control'], 3))
        pack = sample(controls, max_step=.03)
        pack['radius'] = family.radii[name]
        packs[name] = pack
        arrays[name + '__controls_mm'] = controls
        arrays[name + '__points_mm'] = pack['points']
        assert np.array_equal(controls[-1, -1], family.candidate(name, 0)['control'][-1])
    array_path = HERE / 'zero_prefixes.npz'
    np.savez_compressed(array_path, **arrays)
    rows = []
    for name, pack in packs.items():
        points = pack['points']
        hits, nearest = clear(points, pack['radius'], {n: ctx.targets[n] for n in fixed},
                              error=pack['error'], gap=.3)
        row = dict(wire=name, radius_capacity_mm=pack['radius'],
                   prefix_endpoint_Z_mm=float(points[-1, 2]),
                   stationary_prior_parts=dict(status='PASS' if not hits else 'BLOCKED',
                                               hits=hits, nearest=nearest),
                   segments=[], status='PASS')
        for index, segment in enumerate(segments):
            a = np.array(segment['start_translation_mm'])
            b = np.array(segment['end_translation_mm'])
            todo = [(0., 1., 0)]
            accepted = []
            failed = None
            while todo:
                lo, hi, depth = todo.pop()
                mid = (lo + hi) / 2
                position = a + (b-a) * mid
                movement = float(np.linalg.norm(b-a) * (hi-lo) / 2)
                targets = {n: ctx.targets[n] for n in moving}
                bad, near = clear(points - position, pack['radius'], targets,
                                  error=pack['error'] + movement, gap=.3)
                if not bad:
                    accepted.append(dict(parameter_interval=[lo, hi],
                                         translation_radius_mm=movement,
                                         gap_lower_bound_mm=near['gap_lower_bound_mm'] if near else None))
                    continue
                # A sampled surface distance below radius+gap is a concrete
                # counterexample to the .3mm clearance target at this pose.
                observed, at_mid = clear(points-position, pack['radius'], targets,
                                         error=pack['error'], gap=.3)
                actual_upper = None
                if at_mid is not None:
                    actual_upper = (at_mid['gap_lower_bound_mm'] + at_mid['half_step_mm']
                                    + at_mid['chord_error_mm'] + .0001)
                inside = any(h.get('inside') for h in observed)
                if inside or (actual_upper is not None and actual_upper < .3) or depth >= 13:
                    failed = dict(parameter_interval=[lo, hi], midpoint=mid,
                                  native_translation_mm=position.tolist(), nearest=at_mid,
                                  sampled_surface_clearance_upper_mm=actual_upper,
                                  inside_native=inside, hits=observed,
                                  counterexample='Inside or sampled surface clearance below .3mm' if
                                  inside or (actual_upper is not None and actual_upper < .3) else
                                  'Unresolved conservative enclosure at depth limit')
                    break
                todo.extend([(mid, hi, depth+1), (lo, mid, depth+1)])
            if failed is None:
                assert accepted[0]['parameter_interval'][0] == 0.
                assert accepted[-1]['parameter_interval'][1] == 1.
                assert all(x['parameter_interval'][1] == y['parameter_interval'][0]
                           for x, y in zip(accepted[:-1], accepted[1:]))
            row['segments'].append(dict(path_segment=index, status='PASS' if failed is None else 'BLOCKED',
                                        accepted_intervals=accepted, first_failure=failed))
            if failed is not None:
                row['status'] = 'BLOCKED'
                break
        if hits:
            row['status'] = 'BLOCKED'
        rows.append(row)
        print('PRELAID_PREFIX_ENTRY', name, row['status'], flush=True)
    scene.frame_set(scene.frame_end)
    bpy.context.view_layer.update()
    end_error = max(float(np.max(abs(np.asarray(actors[n].matrix_world) @
                                    np.linalg.inv(baseline_matrices[n]) - np.eye(4)))) for n in prior)
    assert end_error < .00005
    ctx.unchanged()
    family.unchanged()
    baseline = json.loads((ROOT / 'input_assets/M1_55_reaction_entry_baseline.json').read_text())
    protected = {p: h for p, h in baseline['protected_hardware'].items()
                 if '__pycache__' not in p and Path(p).name != '.DS_Store'}
    assert len(protected) == 846 and all(sha(PROJECT / p) == h for p, h in protected.items())
    result = dict(status='PASS' if all(r['status'] == 'PASS' for r in rows) else 'BLOCKED',
                  scope='Candidate prelaid12 R3 zero-yaw capacity prefixes against the saved head-drive-seat entry; not a complete temporary harness',
                  recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  sources=all_sources, arrays_sha256=sha(array_path),
                  stage=stage, path_segments=segments, actor_matrix_readback=matrix_rows,
                  moving_native_ids=moving, moving_native_count=len(moving),
                  stationary_prior_native_ids=fixed, stationary_prior_native_count=len(fixed),
                  later_native_ids=sorted(set(ctx.ss)-prior), required_gap_mm=.3,
                  rows=rows, final_actor_matrix_error_mm=end_error,
                  protected_hardware_files=846, temporary_free_ends='NOT_TESTED',
                  head_upper_curves='NOT_TESTED', actual_terminals_and_protectors='BLOCKED',
                  soft_reshaping_and_hand_control='NOT_TESTED', full_wired_assembly='BLOCKED',
                  main_changed=False, animation_changed=False, hardware_changed=False,
                  assembly_order_changed=False, manufacturing_release=False,
                  elapsed_s=time.time()-started)
    (HERE / 'prefix_entry_review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print('PRELAID_PREFIX_ENTRY_TERMINAL', result['status'], len(rows), len(moving), len(fixed),
          round(result['elapsed_s'], 2), flush=True)


if __name__ == '__main__':
    main()
