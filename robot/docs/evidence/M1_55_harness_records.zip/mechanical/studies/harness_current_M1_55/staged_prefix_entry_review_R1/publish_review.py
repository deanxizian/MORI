"""Publish the unadopted prelaid-prefix preparation and its counterexamples."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import quote, unquote, urlsplit
import datetime
import hashlib
import json
import subprocess
import sys
import urllib.request

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[3]
NUMERIC = '/Applications/Blender.app/Contents/Resources/5.2/python/bin/python3.13'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        self.links.extend(v for k, v in attrs if k in ['href', 'src'])


def main():
    proof = read(HERE/'prefix_entry_review.json')
    audit = read(HERE/'counterexample_verification.json')
    assert proof['status'] == 'BLOCKED' and audit['status'] == 'PASS'
    assert audit['verified_collision_witnesses'] == 12
    assert audit['moving_native_parts'] == 21 and audit['stationary_prior_native_parts'] == 102
    sources = {**audit['sources'], str(HERE/'counterexample_verification.json'):
               sha(HERE/'counterexample_verification.json'), str(Path(__file__)): sha(Path(__file__))}
    assert all(sha(p) == h for p, h in sources.items())
    for file, marker in [('check_prefix_entry.log', 'PRELAID_PREFIX_ENTRY_TERMINAL BLOCKED 12 21 102'),
                         ('verify_counterexamples.log', 'PRELAID_PREFIX_COUNTEREXAMPLES_VERIFIED 12 21 102 846')]:
        assert marker in (HERE/file).read_text()
        assert 'Traceback (most recent call last)' not in (HERE/file).read_text()
    versions = json.loads(subprocess.check_output([NUMERIC, '-c',
        "import sys,json,importlib.metadata;sys.path[:0]=['"+str(PROJECT/'mechanical/scripts/vendor')+
        "','/Users/dean/.cache/codex-runtimes/mori-harness-scipy-py313'];import numpy,scipy;print(json.dumps(dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__,manifold3d=importlib.metadata.version('manifold3d'))))"], text=True))
    versions['blender'] = subprocess.check_output(['/Applications/Blender.app/Contents/MacOS/Blender',
                                                  '--version'], text=True).splitlines()[0]
    commands = dict(status='PASS', versions=versions, cwd=str(PROJECT), commands=[
        dict(command=['/Applications/Blender.app/Contents/MacOS/Blender', '-b', 'mechanical/mori_v1_2.blend',
                      '--python-exit-code', '1', '--python', str(HERE/'check_prefix_entry.py')],
             log='check_prefix_entry.log', exit_code=0,
             scope='Successful execution records a BLOCKED preparation; no candidate adopted'),
        dict(command=[NUMERIC, str(HERE/'verify_counterexamples.py')],
             log='verify_counterexamples.log', exit_code=0,
             scope='Independent current-native source and twelve collision witnesses'),
        dict(command=[sys.executable, str(Path(__file__))], log='publish_review.log',
             scope='Local publication and served-byte checks')],
        main_changed=False, hardware_changed=False, animation_changed=False,
        assembly_order_changed=False, manufacturing_release=False)
    (HERE/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    rows = ''.join(f"<tr><td>{r['wire']}</td><td>Pitch_Yoke</td><td>{r['inscribed_sphere_overlap_mm3']:.6f} mm³</td><td>BLOCKED</td></tr>"
                   for r in audit['witnesses'])
    (HERE/'index.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M1.55 预铺身体前段与驱动座装入</title><style>body{{font:16px/1.65 system-ui,sans-serif;max-width:980px;margin:32px auto;padding:0 22px;color:#27343b}}table{{width:100%;border-collapse:collapse;margin:20px 0}}td,th{{padding:9px;border:1px solid #cbd3d7;text-align:left}}a{{color:#25566b}}.scope{{padding:16px;background:#f2f3f1;border-left:4px solid #758082}}</style>
<h1>预铺身体前段后，驱动座能否直接下放？</h1>
<p class="scope">候选准备方式 BLOCKED / 未采用。PLACEHOLDER / ASSUMED · PROTOTYPE / UNVALIDATED。仅检查12条R3身体／颈部容量前段，Z200终点是数学切点；没有建成真实临时自由端或完整线束。</p>
<p>保存动画先安装头部驱动座，再安装CAM及俯仰头托。本次从实际动画回读第13阶段：21件驱动座分总成先从X130／Z64横移至X0／Z64，再沿Z下放64mm。此前已装的102件原生实体保留；CAM、俯仰头托、显示结构及前后壳按原顺序稍后安装。</p>
<p>保持12条最终零位参考前段原形预铺时，横移区间完成保守覆盖检查；下放到Z32mm时，全部12条参考都与Pitch_Yoke颈部实体发生容量相交。因此不能用这种准备方式省掉临时整理和穿线步骤。主模型、现有顺序及参考曲线均未修改。</p>
<table><thead><tr><th>参考线段</th><th>相交实体</th><th>独立探针相交体积</th><th>准备方式</th></tr></thead><tbody>{rows}</tbody></table>
<p>独立核对重新构造12条R3零位三次曲线，回读实际曲线点；另用已单独导出的当前201件实体，对每处碰线点执行内接球探针的实体相交。12处证据全部复现。探针半径采用各参考容量半径，不能当作已选定线材或实际连接器尺寸。</p>
<p>原完整已知参考的名义运行姿态检查保持。本次失败针对安装中的特定预铺办法，不证明没有其他装配路径。下一步仍需安排临时自由端／收线形状、配合端子穿入，再检查原位恢复、已有线路让位、实际夹持与闭壳。</p>
<p>实际线材、端子、保护件、软线变形与手部夹持未资格化，完整带线装配BLOCKED；主模型、视频和846个硬件源保持。manufacturing_release=false。</p>
<p><a href="prefix_entry_review.json">保存动画路径与完整诊断</a> · <a href="counterexample_verification.json">独立碰线复现</a> · <a href="commands.json">命令与版本</a> · <a href="README.md">范围说明</a> · <a href="../terminal_install_review_R1/index.html">单枚裸端子容量检查</a> · <a href="../index.html">线束总览</a></p></html>''')
    (HERE/'README.md').write_text('''# Prelaid body prefixes versus saved head-seat insertion

The unadopted preparation keeps twelve R3 zero-yaw capacity prefixes in
their final shapes before the head-drive seat is installed. Z200 endpoints
are mathematical cuts, not true free terminals or a temporary harness.

Saved M1.55-A1 source stage21 / display stage13:21 native moving parts,
102 earlier stationary native parts. Actual actor/linear-channel readback
defines X130,Z64 -> X0,Z64 -> X0,Z0. CAM/cradle/optics/shells are later.
Twelve lateral translation coverings pass this scope, but every prefix has
a Pitch_Yoke capacity collision at Z32. Independent exact-curve-point
reconstruction and inscribed-sphere intersections replay all12 witnesses.

This preparation is BLOCKED and unadopted. No assembly-order/main/model/
animation/hardware change. It does not invalidate the static operational
reference checks or prove other preparations impossible. Temporary free
ends, reshaping, actual terminals/materials, grip and wired closure remain
NOT_TESTED/BLOCKED. manufacturing_release=false;846 hardware files retained.
''')
    files = {str(p.relative_to(HERE)): sha(p) for p in HERE.rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and p.name not in
             ['delivery.json', 'publication_verification.json', 'publish_review.log']}
    delivery = dict(status='PASS', scope='Publication and verified counterexamples only; candidate preparation BLOCKED',
                    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=sources, files=files,
                    prelaid_prefix_entry='BLOCKED', collision_witness_verification='PASS', collision_witnesses=12,
                    moving_native_parts=21, stationary_prior_native_parts=102, current_native_parts=201,
                    actual_temporary_harness='NOT_TESTED', full_wired_assembly='BLOCKED',
                    protected_hardware_files=846, main_changed=False, hardware_changed=False,
                    animation_changed=False, assembly_order_changed=False, manufacturing_release=False)
    (HERE/'delivery.json').write_text(json.dumps(delivery, indent=2)+'\n')
    assert all(sha(p) == h for p, h in sources.items())
    assert all(sha(HERE/p) == h for p, h in files.items())
    parser = Links()
    parser.feed((HERE/'index.html').read_text())
    targets = [HERE/'index.html']
    for link in parser.links:
        u = urlsplit(link)
        if not u.scheme and u.path:
            targets.append((HERE/unquote(u.path)).resolve())
    served = []
    for p in dict.fromkeys(targets):
        relative = p.relative_to(PROJECT).as_posix()
        with urllib.request.urlopen('http://127.0.0.1:58202/'+quote(relative), timeout=10) as response:
            assert response.status == 200 and response.read() == p.read_bytes()
        served.append(dict(path=relative, sha256=sha(p)))
    result = dict(status='PASS', delivery_sha256=sha(HERE/'delivery.json'), verified_sources=len(sources),
                  verified_files=len(files), served_links=len(served), served=served,
                  full_harness='BLOCKED', main_changed=False, hardware_changed=False,
                  animation_changed=False, manufacturing_release=False)
    (HERE/'publication_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print('PRELAID_PREFIX_PUBLICATION_VERIFIED', len(files), len(served), 12, flush=True)


if __name__ == '__main__':
    main()
