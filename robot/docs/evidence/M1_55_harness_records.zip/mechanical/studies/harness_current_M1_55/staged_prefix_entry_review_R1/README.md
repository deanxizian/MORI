# Prelaid body prefixes versus saved head-seat insertion

The unadopted preparation keeps twelve R3 zero-yaw capacity prefixes in
their final shapes before the head-drive seat is installed. Z200 endpoints
are mathematical cuts, not true free terminals or a temporary harness.

Saved M1.55-A1 source stage21 / display stage13:21 native moving parts,
102 earlier stationary native parts. Actual actor/linear-channel readback
defines X130,Z64 -> X0,Z64 -> X0,Z0. CAM/cradle/optics/shells are later.
Twelve lateral translation coverings pass this scope, but every prefix has
a Pitch_Yoke capacity collision at Z32. Independent exact-curve-point
reconstruction and inscribed-sphere intersections replay all12 witnesses.

This preparation is BLOCKED and unadopted. No assembly-order/main/model/
animation/hardware change. It does not invalidate the static operational
reference checks or prove other preparations impossible. Temporary free
ends, reshaping, actual terminals/materials, grip and wired closure remain
NOT_TESTED/BLOCKED. manufacturing_release=false;846 hardware files retained.
