"""Independent current assembly solids plus the unscaled official motor shapes."""
from pathlib import Path
import sys, json, hashlib
H=Path(__file__).resolve().parent
PROJECT=H.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid
from mathutils.bvhtree import BVHTree

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def load():
    V=H.parent/'s288_vendor_fit_M1_58';fit=json.loads((V/'fit_review.json').read_text());src=json.loads((V/'vendor_mesh.json').read_text())
    assert sha(ROOT/'mori_v1_2.blend')==fit['source_model_sha256']
    bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
    for c in COLS.values():c.hide_viewport=False
    assembled();bpy.context.view_layer.update()
    ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
    retired={n for n in ss if n.startswith(('Drive_Motor_','S288_Output_'))}
    targets={n:dict(m=s.m,lo=s.lo,hi=s.hi,object=s.o) for n,s in ss.items() if n not in retired}
    pos=[];neg=[]
    for r in src['free_shells']:
        if not r['closed']:continue
        v=np.array(r['vertices_mm']);f=np.array(r['triangles'],dtype=np.uint64)
        if r['volume_mm3']<0:f=f[:,[0,2,1]]
        m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError
        (pos if r['volume_mm3']>0 else neg).append(m)
    body=manifold.Manifold.batch_boolean(pos,manifold.OpType.Add)
    for m in neg:body=body-m
    for side in ['L','R']:
        m=body.transform(np.array(fit['cases'][side+'_inboard']['matrix'])[:3,:]);mesh=m.to_mesh64();v=np.array(mesh.vert_properties[:,:3])
        targets['Vendor_S288_'+side]=dict(m=m,lo=v.min(0),hi=v.max(0),object=None)
    return targets,ss,fit,src

def collisions(m,targets,skip=()):
    mesh=m.to_mesh64();v=np.array(mesh.vert_properties[:,:3]);lo=v.min(0);hi=v.max(0);out=[]
    for n,t in targets.items():
        if n in skip or np.any(hi<t['lo']) or np.any(lo>t['hi']):continue
        vol=(m^t['m']).volume()
        if vol>1e-5:out.append(dict(part=n,overlap_mm3=vol))
    return sorted(out,key=lambda x:-x['overlap_mm3'])

def protected():
    before=json.loads((H/'protected_before.json').read_text())
    changed=[n for n,h in before.items() if sha(PROJECT/n)!=h]
    assert not changed,changed
    return dict(status='PASS',unchanged_files=len(before),changed=[])
