import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import full,tube
targets,ss,fit,src=load();rows=[]
for c in full(0,0):
    m=tube(c['points'],c['tangents'])
    for hit in collisions(m,targets):
        cut=(m^targets[hit['part']]['m']).to_mesh64();v=np.array(cut.vert_properties[:,:3])
        rows.append(dict(wire=c['wire'],**hit,bounds=[v.min(0).tolist(),v.max(0).tolist()]))
(H/'initial_collision_locations.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2),flush=True)
# Exact centre X=0 sections show the current closed wall and brace locations.
sections=[]
for n in ['Drive_Bridge','Motor_Retainer','Body_Front','Body_Rear']:
    m=targets[n]['m'].rotate([0,90,0])
    polygons=m.slice(0).to_polygons()
    sections.append(dict(part=n,plane='world X=0; polygon coordinates transformed [Z,Y]',polygons=[np.array(q).tolist() for q in polygons]))
(H/'mid_sections.json').write_text(json.dumps(sections,indent=2)+'\n')
