"""Finite alternative assembly with constant-length nominal wires held above the beam."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from context import *
from check_top_beam import curves, controller_exit_stubs, roof_cuts
from route_geometry import tube

targets,ss,fit,src=load()
for region in roof_cuts():
    targets['Drive_Bridge']['m']=targets['Drive_Bridge']['m']-region
fixed={n:t for n,t in targets.items() if n in ['Motor_Retainer','Vendor_S288_L','Vendor_S288_R']
       or n.startswith(('Motor_Retainer_Pad_','Wheel_Axle_','Wheel_Bearing_','Wheel_Spacer_','Wheel_Output_Screw_'))}
moving=['Drive_Bridge']+[n for n in targets if n.startswith('Motor_Top_Pad_')]
bad=[];soft=[];tiny=[];wire_bad=[];lengths=[]
for dz in np.linspace(20,0,41):
    cs=curves(lift=float(dz));stubs=controller_exit_stubs(lift=float(dz))
    wm={f'U04_wire_{i}':tube(c['points'],c['tangents']) for i,c in enumerate(cs)}
    wm.update({f'U03_stub_{i}':tube(c['points'],c['tangents']) for i,c in enumerate(stubs)})
    wt={n:dict(m=m,lo=np.array(m.bounding_box()[:3]),hi=np.array(m.bounding_box()[3:])) for n,m in wm.items()}
    lengths.append(dict(translation_z_mm=float(dz),U04_each_length_mm=[c['length_mm'] for c in cs]))
    shifted={n:dict(targets[n],m=targets[n]['m'].translate([0,0,float(dz)]),
                    lo=targets[n]['lo']+np.array([0,0,dz]),hi=targets[n]['hi']+np.array([0,0,dz]))
             for n in moving}
    for n,t in shifted.items():
        for hit in collisions(t['m'],fixed):
            row=dict(translation_z_mm=float(dz),moving=n,**hit)
            if n.startswith('Motor_Top_Pad_') and hit['part'].startswith('Vendor_S288_'):soft.append(row)
            elif hit['overlap_mm3']<=P['validation']['collision_volume_tolerance_mm3']:tiny.append(row)
            else:bad.append(row)
        for hit in collisions(t['m'],wt):bad.append(dict(translation_z_mm=float(dz),moving=n,**hit))
    for n,m in wm.items():
        for hit in collisions(m,fixed):wire_bad.append(dict(translation_z_mm=float(dz),wire=n,**hit))
    keys=list(wm)
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            vol=(wm[a]^wm[b]).volume()
            if vol>1e-5:wire_bad.append(dict(translation_z_mm=float(dz),wires=[a,b],overlap_mm3=vol))
    if len(bad)+len(wire_bad)>20:break

cs=curves();stubs=controller_exit_stubs()
wt={}
for prefix,items in [('U04',cs),('U03_stub',stubs)]:
    for i,c in enumerate(items):
        m=tube(c['points'],c['tangents']);wt[f'{prefix}_{i}']=dict(m=m,
            lo=np.array(m.bounding_box()[:3]),hi=np.array(m.bounding_box()[3:]))
bolts=[]
for n,t in targets.items():
    if not n.startswith('Wheel_Cap_Clamp_Screw_'):continue
    hits=[]
    for dz in np.linspace(-34,0,69):
        for hit in collisions(t['m'].translate([0,0,float(dz)]),wt):
            hits.append(dict(translation_z_mm=float(dz),**hit))
    bolts.append(dict(part=n,samples=69,status='FAIL' if hits else 'PASS',hits=hits))
front=['Body_Front','Frame_Insert_0','Frame_Insert_1','Speaker','Speaker_Gasket',
       'Speaker_Insert_-1','Speaker_Insert_1','Speaker_Screw_-1','Speaker_Screw_1']
rear=['Body_Rear','Frame_Insert_2','Frame_Insert_3']+list(P['dc_inlet_trial']['reference_ids'])+list(P['ups_rear_controls']['reference_ids'])
shells=[]
for side,direction,names in [('front',1,front),('rear',-1,rear)]:
    hits=[]
    for distance in np.linspace(0,220,275):
        for name in list(dict.fromkeys(names)):
            t=targets[name];shift=np.array([0,direction*distance,0])
            if all(np.any(t['hi']+shift<w['lo']) or np.any(t['lo']+shift>w['hi']) for w in wt.values()):continue
            for hit in collisions(t['m'].translate(shift),wt):
                hits.append(dict(distance_mm=float(distance),moving=name,**hit))
        if len(hits)>20:break
    shells.append(dict(side=side,samples=275,status='FAIL' if hits else 'PASS',hits=hits))
status='FAIL' if bad or wire_bad or any(r['status']=='FAIL' for r in bolts+shells) else 'PASS'
out=dict(status=status,scope='Finite geometry with U04 variable shape at constant190mm length and short U03 stubs only',
         bridge_drop_mm=20,position_samples=41,step_mm=.5,moving=moving,
         frame_UPS_and_shells_not_fitted_during_drop=True,
         plan='Hold nominal top loops20mm higher initially; lower them with the beam while broadening each coil. Exact human handling is not tested.',
         failures=bad,wire_failures=wire_bad,known_soft_contacts=soft,
         below_existing_volume_threshold=tiny,wire_lengths_by_position=lengths,
         cap_bolt_paths=bolts,shell_module_paths=shells,
         actual_plugs_and_crimp='BLOCKED',human_holding='NOT_TESTED',wire_restraints='NOT_TESTED',
         all_other_wires='NOT_TESTED',full_wired_assembly='BLOCKED',physical='NOT_TESTED',
         main_adoption=False,manufacturing_release=False,protected=protected(),
         sources={str(q.relative_to(PROJECT)):sha(q) for q in
                  [Path(__file__),H/'context.py',H/'check_top_beam.py',H/'route_geometry.py',
                   H/'top_beam_check.json',ROOT/'mori_v1_2.blend',PROJECT/'config/geometry.json']})
(H/'top_beam_sequence.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=status,failures=bad[:5],wire_failures=wire_bad[:5],
                      cap_bolts=[r['status'] for r in bolts],shells=[r['status'] for r in shells]),indent=2),flush=True)
