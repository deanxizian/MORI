"""Unadopted bottom-open wire exits in the existing drive end walls."""
from pathlib import Path
import sys, json
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import manifold,np,H

S=dict(width_mm=6.0,front_center_x_mm=2.7,back_center_x_mm=-2.7,
       bottom_mm=41.9,top_mm=61.2,wall_y=[24.7,27.4],
       top_radius_mm=3.0,trial_wire_gap_mm=.2,status='UNADOPTED',
       purpose='Lay pre-plugged leads into a bottom-open slot before the existing cap closes; no plug needs to pass through a closed small hole.')

def cuts():
    out=[];r=S['width_mm']/2
    for sign,x in [(1,S['front_center_x_mm']),(-1,S['back_center_x_mm'])]:
        yc=sign*sum(S['wall_y'])/2;depth=S['wall_y'][1]-S['wall_y'][0]
        # A semicircular roof and two vertical sides, open through the cap seam.
        zc=S['top_mm']-r
        rect=manifold.Manifold.cube([2*r,depth,zc-S['bottom_mm']],True).translate([x,yc,(zc+S['bottom_mm'])/2])
        cyl=manifold.Manifold.cylinder(depth,r,r,96,True).rotate([90,0,0]).translate([x,yc,zc])
        out.append(rect+cyl)
    return out

def candidate(original):
    m=original
    for c in cuts():m=m-c
    assert m.status()==manifold.Error.NoError
    return m

def report(original,modified):
    regions=cuts();removed=original-modified;new=modified-original
    outside=removed
    for c in regions:outside=outside-c
    return dict(parameters=S,removed_volume_mm3=removed.volume(),added_volume_mm3=new.volume(),
        removed_outside_declared_regions_mm3=outside.volume(),
        retained_roof_ligament_mm=63.5-S['top_mm'],
        current_cap_top_mm=42,wire_exit_becomes_closed_with_cap=True,
        exact_part_change=['Drive_Bridge'],new_printed_parts=0,new_fasteners=0,
        print_strength='NOT_TESTED',full_real_harness='BLOCKED',main_adoption=False)
