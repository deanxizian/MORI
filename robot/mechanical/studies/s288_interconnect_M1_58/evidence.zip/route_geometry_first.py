"""Finite wire-centre candidates; no real crimp, connector or bend qualification."""
from pathlib import Path
import sys,math,json
import numpy as np
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H.parents[2]/'mechanical/scripts/vendor'))
import manifold3d as manifold
sys.path.insert(0,str(H.parent/'s288_plug_space_M1_58'))
from wire_geometry import bent_wire
PORTS=json.loads((H.parent/'s288_plug_space_M1_58/review.json').read_text())['ports']

class Path:
    def __init__(self,start):self.points=[np.array(start,float)];self.tangents=[];self.length=0.;self.radii=[];self.pieces=[]
    def segment(self,points,tangents,length,radius=None,kind='line'):
        points=np.asarray(points);tangents=np.asarray(tangents)
        assert np.linalg.norm(self.points[-1]-points[0])<1e-7,(self.points[-1],points[0])
        if not self.tangents:self.tangents.append(tangents[0])
        else:assert np.linalg.norm(self.tangents[-1]-tangents[0])<1e-6,(self.tangents[-1],tangents[0])
        self.points.extend(points[1:]);self.tangents.extend(tangents[1:]);self.length+=length
        if radius is not None:self.radii.append(radius)
        self.pieces.append(dict(kind=kind,length_mm=float(length),radius_mm=radius))
    def line(self,end):
        a=self.points[-1];b=np.array(end,float);length=np.linalg.norm(b-a)
        assert length>1e-6,length
        t=(b-a)/length;u=np.linspace(0,1,max(2,int(math.ceil(length/.2))+1))
        self.segment(a[None]+u[:,None]*(b-a),np.tile(t,(len(u),1)),length)
    def arc(self,points_fn,tangent_fn,angle,radius):
        u=np.linspace(0,angle,int(math.ceil(angle*radius/.2))+1)
        self.segment(points_fn(u),tangent_fn(u),angle*radius,radius,'circle')

def tail(side,socket,offset):
    port=next(p for p in PORTS if p['side']==side and p['source_socket']==socket)
    _,info=bent_wire(1,1,5,offset,'Y',-1,wire_r=.5)
    local=np.array(info['centerline_mm']);mat=np.array(port['matrix']);origin=np.array(port['local_origin_mm'])
    return (local+origin)@mat[:3,:3].T+mat[:3,3],info

def core(left,right,bottom_z,desired_length,mode):
    x,y,z=left;xx,yy,zz=right;r=6.;front=30.;back=-30.
    p=Path(left);p.line([x,front,z])
    p.arc(lambda q:np.c_[np.full(len(q),x),front+r*np.sin(q),z-r*(1-np.cos(q))],lambda q:np.c_[q*0,np.cos(q),-np.sin(q)],math.pi/2,r)
    p.line([x,front+r,bottom_z+r])
    p.arc(lambda q:np.c_[np.full(len(q),x),front+r-r*(1-np.cos(q)),bottom_z+r-r*np.sin(q)],lambda q:np.c_[q*0,-np.sin(q),-np.cos(q)],math.pi/2,r)
    outside=2*math.pi*r+(front-y)+(yy-back)+(z-bottom_z-2*r)+(zz-bottom_z-2*r)
    bottom_length=desired_length-outside
    if mode=='serpentine':
        rr=3.5;stem=10.;a=(bottom_length-60+(x-xx)-(3*math.pi-8)*rr)/4
        assert a>max(x+rr,-xx+rr),dict(amplitude=a,start_x=x,end_x=xx,mode=mode)
        p.line([x,front-stem,bottom_z]);yc=front-stem
        p.arc(lambda q:np.c_[x+rr*(1-np.cos(q)),yc-rr*np.sin(q),np.full(len(q),bottom_z)],lambda q:np.c_[np.sin(q),-np.cos(q),q*0],math.pi/2,rr)
        yc-=rr;p.line([a,yc,bottom_z])
        p.arc(lambda q:np.c_[a+rr*np.sin(q),yc-rr*(1-np.cos(q)),np.full(len(q),bottom_z)],lambda q:np.c_[np.cos(q),-np.sin(q),q*0],math.pi,rr)
        yc-=2*rr;p.line([-a,yc,bottom_z])
        p.arc(lambda q:np.c_[-a-rr*np.sin(q),yc-rr*(1-np.cos(q)),np.full(len(q),bottom_z)],lambda q:np.c_[-np.cos(q),-np.sin(q),q*0],math.pi,rr)
        yc-=2*rr;p.line([xx-rr,yc,bottom_z])
        p.arc(lambda q:np.c_[xx-rr+rr*np.sin(q),yc-rr*(1-np.cos(q)),np.full(len(q),bottom_z)],lambda q:np.c_[np.cos(q),-np.sin(q),q*0],math.pi/2,rr)
        p.line([xx,back,bottom_z]);extra=dict(mode=mode,amplitude_mm=float(a),circle_radius_mm=rr)
    else:
        # Quartic lateral excursion has zero X derivative at both ends.
        def eval(q,a):
            q=np.asarray(q);dx=xx-x
            xp=x+dx*(3*q*q-2*q**3)+16*a*q*q*(1-q)**2
            v=dx*(6*q-6*q*q)+32*a*q*(1-q)*(1-2*q)
            accel=dx*(6-12*q)+32*a*(1-6*q+6*q*q)
            xyz=np.c_[xp,front-60*q,np.full(len(q),bottom_z)]
            vv=np.c_[v,np.full(len(q),-60.),q*0];tt=vv/np.linalg.norm(vv,axis=1)[:,None]
            return xyz,tt,v,accel
        g,w=np.polynomial.legendre.leggauss(96);g=(g+1)/2;w=w/2
        def length(a):return float(w@np.linalg.norm(np.c_[eval(g,a)[2],np.full(len(g),60)],axis=1))
        lo=0.;hi=50.;assert length(lo)<=bottom_length<=length(hi),(length(lo),bottom_length,length(hi))
        for _ in range(50):
            mid=(lo+hi)/2
            if length(mid)<bottom_length:lo=mid
            else:hi=mid
        a=(lo+hi)/2;q=np.linspace(0,1,1601);xyz,tt,v,accel=eval(q,a)
        rad=np.divide((v*v+3600)**1.5,60*np.abs(accel),out=np.full(len(q),np.inf),where=np.abs(accel)>1e-15)
        p.segment(xyz,tt,length(a),float(rad.min()),'quartic_finite_radius_sample')
        extra=dict(mode=mode,amplitude_mm=a,minimum_radius_finite_sample_mm=float(rad.min()),radius_continuous_proof='NOT_TESTED')
    p.arc(lambda q:np.c_[np.full(len(q),xx),back-r*np.sin(q),bottom_z+r*(1-np.cos(q))],lambda q:np.c_[q*0,-np.cos(q),np.sin(q)],math.pi/2,r)
    p.line([xx,back-r,zz-r])
    p.arc(lambda q:np.c_[np.full(len(q),xx),back-r+r*(1-np.cos(q)),zz-r+r*np.sin(q)],lambda q:np.c_[q*0,np.sin(q),np.cos(q)],math.pi/2,r)
    p.line(right)
    assert abs(p.length-desired_length)<1e-6,(p.length,desired_length)
    return p,extra

def full(left_socket=0,right_socket=0,permutation=(0,1,2),bottom_base=29.5):
    curves=[]
    for i in range(3):
        l,li=tail('L',left_socket,[-2,0,2][i]);r,ri=tail('R',right_socket,[-2,0,2][permutation[i]])
        p,details=core(l[-1],r[-1],bottom_base+i*1.4,190-li['centerline_length_mm']-ri['centerline_length_mm'],'serpentine' if left_socket==right_socket==0 else 'quartic')
        # The tails have no derivative array; finite differences provide normals
        # for the polygonal tube while exact core tangents are retained.
        lt=np.gradient(l,axis=0);lt/=np.linalg.norm(lt,axis=1)[:,None];lt[-1]=[0,1,0]
        rt=np.gradient(r[::-1],axis=0);rt/=np.linalg.norm(rt,axis=1)[:,None];rt[0]=[0,1,0]
        points=np.concatenate([l,np.array(p.points)[1:],r[::-1][1:]])
        tangent=np.concatenate([lt,np.array(p.tangents)[1:],rt[1:]])
        curves.append(dict(points=points,tangents=tangent,wire=i,right_geometric_lane=permutation[i],length_mm=li['centerline_length_mm']+p.length+ri['centerline_length_mm'],minimum_radius_mm=min(li['individual_bend_radius_mm'],ri['individual_bend_radius_mm'],*p.radii),core_pieces=p.pieces,**details))
    return curves

def tube(points,tangents,radius=.5,sides=24):
    points=np.asarray(points);tangents=np.asarray(tangents);normals=[]
    n=np.array([0,0,1.])
    for t in tangents:
        n=n-t*np.dot(n,t)
        if np.linalg.norm(n)<1e-6:n=np.cross(t,[0,1,0])
        n/=np.linalg.norm(n);normals.append(n.copy())
    normals=np.array(normals);binorm=np.cross(tangents,normals);q=np.arange(sides)*2*math.pi/sides
    v=(points[:,None,:]+radius*(np.cos(q)[None,:,None]*normals[:,None,:]+np.sin(q)[None,:,None]*binorm[:,None,:])).reshape(-1,3)
    a=np.arange((len(points)-1)*sides).reshape(-1,sides);b=np.roll(a,-1,axis=1);c=b+sides;d=a+sides
    f=np.concatenate([np.stack([a,b,c],axis=-1).reshape(-1,3),np.stack([a,c,d],axis=-1).reshape(-1,3)])
    last=(len(points)-1)*sides;caps=[[0,j+1,j] for j in range(1,sides-1)]+[[last,last+j,last+j+1] for j in range(1,sides-1)]
    f=np.concatenate([f,np.array(caps)]);m=manifold.Manifold(manifold.Mesh64(v,np.array(f,dtype=np.uint64)))
    assert m.status()==manifold.Error.NoError
    return m
