from pathlib import Path
import json,hashlib
H=Path(__file__).resolve().parent;P=H.parents[2]
r=json.loads((H/'candidate_check.json').read_text());u=json.loads((H/'upper_nominal_check.json').read_text());s=r['structure'];v=json.loads((H/'front_wall_sections.json').read_text())
sequence=json.loads((H/'wired_sequence_check.json').read_text())
assert sequence['nominal_U04_sequence_status']=='PASS'
assert len(r['lower_pair_cases'])==18 and all(x['status']=='PASS' for x in r['lower_pair_cases'])
assert u['nominal_OD1_stub_status']=='PASS'
assert sum(x['status']=='FAIL' for x in r['upper_left_exit_stubs'])==1

def paths(polys,ox,oy):
    return ' '.join('M '+' L '.join(f'{ox+9*x:.3f},{oy+9*y:.3f}' for x,y in q)+' Z' for q in polys)
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1180" height="420" viewBox="0 0 1180 420"><rect width="1180" height="420" fill="#fafbf9"/><g font-family="system-ui,sans-serif" fill="#253337"><text x="35" y="37" font-size="24">前端壁实体剖面对比 · Y=26.05 mm</text>']
for title,polys,ox in [('现有端壁',v['before'],290),('候选：底部开放出线槽',v['candidate'],885)]:
    oy=690
    svg.append(f'<text x="{ox-245}" y="80" font-size="22">{title}</text><path d="{paths(polys,ox,oy)}" fill="#788b8e" fill-rule="evenodd"/>')
    for z in [44.800781268104,60.199218731895]:
        for x in [.7000001072,2.7000001072,4.7000001072]:
            svg.append(f'<circle cx="{ox+9*x}" cy="{oy-9*z}" r="4.5" fill="#d6a34e"/>')
svg.append('<text x="650" y="342" font-size="19">槽宽 8 mm；开至原底盖拼缝，顶部保留连续材料</text><text x="35" y="382" font-size="18">剖面来自实际对比实体。黄色为名义 OD1 线位；只表示出口容量，不代表插头或打印强度通过。</text></g></svg>')
(H/'section_comparison.svg').write_text(''.join(svg))

(H/'index.html').write_text('''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>轮舵机出线槽候选</title><style>*{box-sizing:border-box}body{margin:0;background:#f4f6f3;color:#253337;font:17px/1.75 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:26px 30px 65px}h1{font-size:34px;line-height:1.3}h2{font-size:25px;margin-top:38px}a{color:#126b7a}nav{display:flex;gap:20px;flex-wrap:wrap}.note{padding:12px 20px;border-left:4px solid #ab7c28;background:#f1e7d1}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px}figure{margin:22px 0}img{width:100%;height:auto;display:block}figcaption,small{color:#536569}figcaption{padding-top:8px}table{width:100%;border-collapse:collapse}td,th{text-align:left;vertical-align:top;padding:12px 9px;border-bottom:1px solid #cdd5d4}td:first-child{width:26%}@media(max-width:700px){main{padding:20px 16px}.grid{grid-template-columns:1fr}h1{font-size:28px}}</style></head><body><main>
<nav><a href="../../index.html#s288-vendor">主模型</a><a href="../s288_plug_space_M1_58/index.html">实物线长与线径记录</a><a href="README.md">详细检查记录</a></nav>
<h1>轮舵机出线槽候选</h1><p>M1.58 基准 · 待确认 · 主模型尚未应用</p>
<p class="note"><strong>建议：驱动上座前后端壁各增加一处底部开放的出线槽。</strong><br>槽宽 8 mm，利用原底盖封口，先摆好带插头的线，再从上方合上上座。不增加打印件或螺钉。</p>
<figure><a href="candidate_installed.png"><img src="candidate_installed.png" alt="候选驱动上座，底部开放出线槽与名义190毫米三芯线"></a><figcaption>前端的出线槽。后端有对应出口；黄色是三根导线的名义布置。电机使用原厂 CAD 参考，实际插头外形仍未完整建模。</figcaption></figure>
<h2>为什么需要这处修正</h2><p>已试的完整路线碰到现有前后端壁：插口旁能转弯，但线路继续延伸时被端壁挡住。候选给线路提供出口，并保留原轴承座、所有螺钉孔、顶板及底盖。</p>
<div class="grid"><figure><a href="current_closed_wall.png"><img src="current_closed_wall.png" alt="现有完整端壁"></a><figcaption>当前打印件的端壁。</figcaption></figure><figure><a href="candidate_open_seam.png"><img src="candidate_open_seam.png" alt="底盖移去后的开放出线槽"></a><figcaption>底盖移去后的候选，线可以从拼缝侧放入。名义带线顺序已补查；实际夹持与余线固定仍需复核。</figcaption></figure></div>
<figure><a href="section_comparison.svg"><img src="section_comparison.svg" alt="前端壁实际实体剖面对比"></a><figcaption>槽顶部到上座内顶面还留 2.3 mm，另有原 3 mm 顶板；实际剖面保持连续。打印强度尚未验证。</figcaption></figure>
<h2>约 190 mm 导线放在哪里</h2><p>下口到下口的三芯串接线候选，把余线安排在底盖下方、身体壳内。每根名义中心线均为 190 mm；线径采用你提供的约 1 mm。还需要固定余线，防止实际线材移动。</p>
<figure><a href="candidate_under_cap.png"><img src="candidate_under_cap.png" alt="底盖下方的完整名义导线路线和余线布置"></a><figcaption>身体壳在此隐藏以看清路线；检查包含身体壳实际实体。名义装配顺序已补查，余线实际固定及完整带线装配仍待验证。</figcaption></figure>
<h2>带线组装顺序</h2><ol><li>先在台面摆好两台电机、轴承与底盖，连接下口串接线，整理底部余线。临时支撑与实际固定方式仍待实物。</li><li>驱动上座从上方落下，让底部开放槽沿已有出线合上。101 个名义位置未检出新增硬质干涉；软垫压入仍单独保留待试配。</li><li>从底面装四枚 M3 螺钉，再继续承重板等既有装配步骤。螺钉装入及前后身体壳既有路径未与这根 U04 相交。</li></ol><figure><a href="sequence_from_above.png"><img src="sequence_from_above.png" alt="上座在已有电机、底盖和串接线上方准备落下的静态示意"></a><figcaption>此图把上座上移 22 mm 展示顺序，移位仅用于展示。检查使用原候选实体及已记录的 101 个落下位置。</figcaption></figure><table><thead><tr><th>检查</th><th>结果及范围</th></tr></thead><tbody>
<tr><td>打印件改动</td><td>只切两处声明区域；移除约 766 mm³，仍是一件连续实体。切削区域与轴承、紧固件的距离检查均达到 10 mm 检索上限，未把封顶结果当成精确距离。没有增加零件。</td></tr>
<tr><td>下口完整名义路线</td><td>18 个有限组合未检出实体或线间相交：外伸试值 0 / 0.5 / 1 mm，各配 6 种几何线位配对。不是实际端子针号映射。</td></tr>
<tr><td>选定名义路线间隙</td><td>对当前三角网格，最小零件间隙约 0.50 mm、线间约 0.40 mm；增粗到半径 0.6 / 0.7 mm 的两次包络检查也未相交。局部最小名义弯曲半径 3 mm，实际线材弯折资格待实物。</td></tr>
<tr><td>上口出口</td><td>9 个 OD1 名义短段通过；在假设零外伸、半径增至 0.7 mm 时，一根线碰到舵机自己的模型边缘，失败记录保留。完整主控端路线仍待新载板位置。</td></tr>
<tr><td>名义 U04 装配顺序</td><td>上座落下 101 个位置、4 枚螺钉各 69 个位置、前后壳各 275 个位置检查通过。仅覆盖本根 U04；保留原软垫接触及四处约 0.000022 mm³ 轴承源网格交叠，不等于物理配合通过。</td></tr><tr><td>仍待完成</td><td>真实插头与端子出口、实际弯折要求、余线固定、实际夹持及完整带线拆装、整机所有线束同时存在。完整线束保持 BLOCKED，实物 NOT_TESTED。</td></tr>
</tbody></table>
<p>本候选尚未进入主模型、STL 或视频。局部 <a href="wire_exits_UNADOPTED.blend">Blender 检查文件</a> 便于检查出线槽与路线；完整模型仍是 <a href="../../mori_v1_2.blend">mori_v1_2.blend</a>。</p>
<details><summary>来源与原始结果</summary><p><a href="candidate_check.json">主体检查（包含上口增粗失败）</a> · <a href="upper_nominal_check.json">上口名义短段补查</a> · <a href="escape_parameters.json">两处出线槽参数</a> · <a href="route_check_before_escape.json">原路线碰撞记录</a> · <a href="wired_sequence_check.json">U04 顺序检查（含旧顺序失败）</a> · <a href="commands.json">实际命令和日志</a></p><p>原厂电机来源、两个开放表面与逐字段假设沿用上一轮来源复核。线长、线径为用户约值；插头外伸 0 / 0.5 / 1 mm 和 1 mm 压接直尾均为试值，不是实测。</p></details>
<p><small>PROTOTYPE / UNVALIDATED。本页没有修改电路、引脚或元件选型，未向硬件对话发送指令；不制造、不裁线或上电放行。</small></p></main></body></html>''')

(H/'README.md').write_text('''# 轮舵机串接线与驱动上座出口候选

2026-10-13，主模型 M1.58，**未采用**。只有 Drive_Bridge 两处候选底部开放槽发生实体变化；主模型、20 STL、电子细模及视频等 26 文件 SHA 保持不变。原厂 S288 仍作为独立未采用参考。

## 来源与假设

- 电机来自上一轮原厂 STEP 来源及不缩放的同轴安装变换；保留六正闭合壳减内边界的实体策略，两个开放源表面未参与体积检查。
- 用户导线段约 190 mm，不含两端插头；三芯、单芯绝缘外径约 1 mm。没有误差或压接到导线段端点的精确基准，不能当作裁线尺寸。
- 电机插口基准和 2 mm 行距沿用上一轮目录/外包框容量模型。塑壳外伸 0/0.5/1 mm、压接直尾 1 mm 是假设，不是测量；用户只描述插头几乎全部藏入舵机。
- 下口串接候选每根名义中心线恰为 190 mm。尾弯采用中心半径 5 mm、各线半径 3/5/7 mm；外部竖向过渡半径 4 mm，底部蛇形圆弧 3.5 mm。三根底部中心线高度 32.5/33.9/35.3 mm，几何配对比较六种，不赋予真实电气针号。
- Circle/straight 长度用解析值，quartic 比较族用 96 点 Gauss 数值积分；形状用于原路线的四种插口比较，选定下口候选只用直线和圆弧。圆弧点距约 0.2 mm，管截面 24 段；这是有限多边形实体检查，不是连续间隙或耐弯证明。

## 检查范围与保留失败

原下绕路径碰到端壁和腹部内壁：route_check_before_escape.json 和 initial_collision_locations.json 留存。半圆顶的早期槽使上口增粗线位碰顶，记录在 escape_parameters_semicircle.json / route_check_semicircle.json；最终改为短 R1 顶角、平直顶部的槽。

最终槽宽 8 mm，前后中心 X+2.7/-2.7，Y 壁切削跨度 24.7..27.4 / -27.4..-24.7，Z41.9..61.2。槽从底盖拼缝开放；槽上方端壁至内顶面保留 2.3 mm，原顶板 3 mm 保留。删除量约 765.85 mm³，仅在声明区域内，无增加量；改前改后均一闭合实体。轴承和紧固件切削区间隙结果为 >=10 mm（检索封顶10），不声称精确大于10。

下口-下口 18 个组合（3 个外伸试值 x6配对）名义 OD1 无体积相交；选定原名义配对增粗半径0.6/0.7也未相交。选定网格 min_gap 封顶1 mm检查，零件最小约0.500003、线间约0.4；仅当前离散网格。源本机插口处未知的装配接触不能被当成精确压接出口。

**保留上口失败**：候选主检查里的 nominal_installed_status 为 FAIL，因为其中同时包含9个上口半径0.7的增粗短段，其中一个在假设0外伸时碰自己的电机约0.43 mm³。随后 upper_nominal_check.json 单独检查OD1名义短段，9/9无相交。不能把这个补查说成原增粗检查通过，也不能把所有线束说成通过。

四种上下口的较早完整路线比较里，下口组合通过，其他三种仍碰身体壳；保留 route_check.json。选用下口机械候选，是有限布局选择；真实端子对应仍按厂家线束与硬件针表复核，未改针位。

## 装配与未完成项

开放槽允许底盖未合上时侧放已带插头导线；随后 wired_sequence_check.json 检查了名义替代顺序：底盖/电机/串接线先保持装入位，上座及其上软垫从上方下移50mm，101个位置通过；四螺钉各69位置、前后壳各275位置均未与U04相交。旧“未来余线冻结在装入位、底盖从下方上移”的51位置路线FAIL，保留9个碰撞位置。替代路径有2条已知上软垫接触、4处终点轴承交叠约0.000022mm³，分别保留NOT_TESTED/低于项目既有0.01mm³阈值，没有当作制造配合通过。

人手夹持、台面临时支撑、余线实际固定和全部柔性线束仍未验证。底部余线还未设计固定，完整带线拆装 **BLOCKED**。真实插头详细外形、压接支撑直尾、静态弯曲半径、精确线长、完整U03端点、全部线束并存仍 BLOCKED / NOT_TESTED。不能据静态路线放行供应商裁线。

完整机械载荷、PA12槽壁强度和源模型与实发修订一致性待实物。candidate_check.json中的保护清单保持26个文件不变。hardware文件和合同未编辑；没有向硬件对话发送指令。本候选未更新视频。

## 复现

实际命令与日志在 commands.json。Blender5.2.2 LTS，Python3.13.13，numpy2.3.4，manifold3d3.5.3。

```sh
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py export_context export_context.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py candidate_full_check check_candidate.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py upper_nominal check_upper_nominal.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py render_candidate render_candidate.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py wired_sequence_fixed_reference_lists check_wired_sequence.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py static_sequence render_sequence.py
python3 mechanical/studies/s288_interconnect_M1_58/publish.py
```

初始脚本导入本地 context 失败，工具输出留存 initial_import_failure.log；增加明确脚本路径后成功。命令日志的历史脚本散列不可冒充当前帮助模块版本；first/semicircle 文件保留对应早期几何。当前候选检查源散列见 candidate_check.json/upper_nominal_check.json。

wire_exits_UNADOPTED.blend 仅包含局部驱动上座、底盖、原厂电机和名义线路，是审阅文件；不是完整主模型或可直接制造的总装。
''')
print('Published candidate and explicit failed-check limits')
