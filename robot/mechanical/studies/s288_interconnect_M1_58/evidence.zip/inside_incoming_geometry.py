from pathlib import Path
import sys,math
sys.path.insert(0,str(Path(__file__).resolve().parent))
from route_geometry import tail,Path as WirePath,np

def stubs(protrusion=1):
    out=[]
    for i in range(3):
        points,info=tail('L',1,[-2,0,2][i],protrusion,1)
        points=points.copy();points[-1]=points[-2]+np.array([0,2.,0])
        x,y,z=points[-1];front=20.;r=3.;height=69.2+i*1.4
        p=WirePath(points[-1]);p.line([x,front,z])
        p.arc(lambda q:np.c_[np.full(len(q),x),front+r*np.sin(q),z+r*(1-np.cos(q))],
              lambda q:np.c_[q*0,np.cos(q),np.sin(q)],math.pi/2,r)
        p.line([x,front+r,height-r])
        p.arc(lambda q:np.c_[np.full(len(q),x),front+r+r*(1-np.cos(q)),height-r+r*np.sin(q)],
              lambda q:np.c_[q*0,np.sin(q),np.cos(q)],math.pi/2,r)
        p.line([x,35.5,height])
        tt=np.gradient(points,axis=0);tt/=np.linalg.norm(tt,axis=1)[:,None];tt[-1]=[0,1,0]
        out.append(dict(points=np.concatenate([points,np.array(p.points)[1:]]),
                        tangents=np.concatenate([tt,np.array(p.tangents)[1:]]),
                        stub_length_mm=info['centerline_length_mm']-8+p.length))
    return out
