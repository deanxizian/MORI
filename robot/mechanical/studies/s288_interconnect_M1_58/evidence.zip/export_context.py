import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
targets,ss,fit,src=load()
bounds=[dict(part=n,bounds=[t['lo'].tolist(),t['hi'].tolist()]) for n,t in targets.items() if t['lo'][2]<115 and t['hi'][2]>25]
(H/'bounds.json').write_text(json.dumps(bounds,indent=2)+'\n')
for r in bounds:
    if r['part'] in ['Vendor_S288_L','Vendor_S288_R','Drive_Bridge','Motor_Retainer','Load_Frame','UPS_Module','Body_Front','Body_Rear']:
        print(r,flush=True)
# Combined solid is used only to seed a routing search, not for fit certification.
ms=[t['m'] for t in targets.values() if t['lo'][2]<115 and t['hi'][2]>25]
m=manifold.Manifold.batch_boolean(ms,manifold.OpType.Add);mesh=m.to_mesh64()
np.savez_compressed(H/'routing_obstacles.npz',vertices=mesh.vert_properties[:,:3],triangles=mesh.tri_verts)
(H/'source_receipt.json').write_text(json.dumps(dict(main_sha256=sha(ROOT/'mori_v1_2.blend'),geometry_sha256=sha(PROJECT/'config/geometry.json'),motor_source_sha256=src['source_sha256'],fit_sha256=sha(H.parent/'s288_vendor_fit_M1_58/fit_review.json'),measurement_sha256=sha(ROOT/'procurement/evidence/2026-10-13_S288_lead_measurement.json'),protected=protected(),units='mm',obstacle_scope='Full current rigid parts whose bounds cross Z25..115 plus official motor closed shapes; dock/coupons excluded; 2 source open surfaces excluded'),indent=2)+'\n')
print('EXPORTED_OBSTACLES',len(ms),len(mesh.tri_verts),flush=True)
