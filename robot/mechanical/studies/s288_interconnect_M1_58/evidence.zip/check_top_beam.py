"""Independent top-beam alternative prompted by the user; never adopt geometry."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from context import *
from route_geometry import Path as WirePath, tail, tube
import itertools
import math

def short_tail(side, lane, protrusion, socket=1):
    points, info = tail(side, socket, [-2, 0, 2][lane], protrusion, 1)
    points = points.copy()
    direction = np.array([0, 1 if side == 'L' else -1, 0.])
    points[-1] = points[-2] + 2 * direction
    info = dict(info)
    info['centerline_length_mm'] -= 8
    return points, info

def upper_core(left, right, height, desired):
    x, y, z = left
    xx, yy, zz = right
    front, back, radius, rr, stem = 17., -17., 3., 3.5, 3.
    p = WirePath(left)
    p.line([x, front, z])
    p.arc(lambda q: np.c_[np.full(len(q), x), front+radius*np.sin(q), z+radius*(1-np.cos(q))],
          lambda q: np.c_[q*0, np.cos(q), np.sin(q)], math.pi/2, radius)
    p.line([x, front+radius, height-radius])
    p.arc(lambda q: np.c_[np.full(len(q), x), front+radius-radius*(1-np.cos(q)), height-radius+radius*np.sin(q)],
          lambda q: np.c_[q*0, -np.sin(q), np.cos(q)], math.pi/2, radius)
    outside = 2*math.pi*radius+(front-y)+(yy-back)+(height-z-2*radius)+(height-zz-2*radius)
    top_length = desired-outside
    a = (top_length-(front-back)+(x-xx)-(3*math.pi-8)*rr)/4
    assert a > max(x+rr, -xx+rr)
    p.line([x, front-stem, height])
    yc = front-stem
    p.arc(lambda q: np.c_[x+rr*(1-np.cos(q)), yc-rr*np.sin(q), np.full(len(q), height)],
          lambda q: np.c_[np.sin(q), -np.cos(q), q*0], math.pi/2, rr)
    yc -= rr
    p.line([a, yc, height])
    p.arc(lambda q: np.c_[a+rr*np.sin(q), yc-rr*(1-np.cos(q)), np.full(len(q), height)],
          lambda q: np.c_[np.cos(q), -np.sin(q), q*0], math.pi, rr)
    yc -= 2*rr
    p.line([-a, yc, height])
    p.arc(lambda q: np.c_[-a-rr*np.sin(q), yc-rr*(1-np.cos(q)), np.full(len(q), height)],
          lambda q: np.c_[-np.cos(q), -np.sin(q), q*0], math.pi, rr)
    yc -= 2*rr
    p.line([xx-rr, yc, height])
    p.arc(lambda q: np.c_[xx-rr+rr*np.sin(q), yc-rr*(1-np.cos(q)), np.full(len(q), height)],
          lambda q: np.c_[np.cos(q), -np.sin(q), q*0], math.pi/2, rr)
    p.line([xx, back, height])
    p.arc(lambda q: np.c_[np.full(len(q), xx), back-radius*np.sin(q), height-radius*(1-np.cos(q))],
          lambda q: np.c_[q*0, -np.cos(q), -np.sin(q)], math.pi/2, radius)
    p.line([xx, back-radius, zz+radius])
    p.arc(lambda q: np.c_[np.full(len(q), xx), back-radius+radius*(1-np.cos(q)), zz+radius-radius*np.sin(q)],
          lambda q: np.c_[q*0, np.sin(q), -np.cos(q)], math.pi/2, radius)
    p.line(right)
    assert abs(p.length-desired) < 1e-6, (p.length, desired)
    return p, a

def curves(protrusion=1, permutation=(0, 1, 2), lift=0):
    out=[]
    for i in range(3):
        l, li=short_tail('L', i, protrusion)
        r, ri=short_tail('R', permutation[i], protrusion)
        p, amplitude=upper_core(l[-1], r[-1], 69.2+i*1.4+lift,
                               190-li['centerline_length_mm']-ri['centerline_length_mm'])
        lt=np.gradient(l, axis=0);lt/=np.linalg.norm(lt, axis=1)[:, None];lt[-1]=[0,1,0]
        rt=np.gradient(r[::-1], axis=0);rt/=np.linalg.norm(rt, axis=1)[:, None];rt[0]=[0,1,0]
        out.append(dict(points=np.concatenate([l, np.array(p.points)[1:], r[::-1][1:]]),
                        tangents=np.concatenate([lt, np.array(p.tangents)[1:], rt[1:]]),
                        length_mm=li['centerline_length_mm']+p.length+ri['centerline_length_mm'],
                        amplitude_mm=float(amplitude)))
    return out

def roof_cut(x, y):
    # Open through the existing edge; no closed-hole plug passage claim.
    outline=manifold.CrossSection.square([8,9.9], True).offset(-1).offset(1, manifold.JoinType.Round, 0, 32)
    return outline.extrude(3.2).translate([x,y,63.4])

def roof_cuts():
    return [roof_cut(2.7,22.45),roof_cut(-2.7,-22.45)]

def controller_exit_stubs(protrusion=1, lift=0):
    out=[]
    for i in range(3):
        points, info=short_tail('L', i, protrusion, socket=0)
        x,y,z=points[-1];r=3.;front=20.;height=69.2+i*1.4+lift
        p=WirePath(points[-1]);p.line([x,front,z])
        p.arc(lambda q:np.c_[np.full(len(q),x),front+r*np.sin(q),z+r*(1-np.cos(q))],
              lambda q:np.c_[q*0,np.cos(q),np.sin(q)],math.pi/2,r)
        p.line([x,front+r,height-r])
        p.arc(lambda q:np.c_[np.full(len(q),x),front+r+r*(1-np.cos(q)),height-r+r*np.sin(q)],
              lambda q:np.c_[q*0,np.sin(q),np.cos(q)],math.pi/2,r)
        p.line([x,35.5,height])
        tt=np.gradient(points,axis=0);tt/=np.linalg.norm(tt,axis=1)[:,None];tt[-1]=[0,1,0]
        out.append(dict(points=np.concatenate([points,np.array(p.points)[1:]]),
                        tangents=np.concatenate([tt,np.array(p.tangents)[1:]]),
                        short_stub_length_mm=info['centerline_length_mm']+p.length))
    return out

if __name__=='__main__':
    targets, ss, fit, src=load()
    original=targets['Drive_Bridge']['m']
    cut_regions=roof_cuts()
    changed=original
    for region in cut_regions:changed=changed-region
    assert changed.status()==manifold.Error.NoError
    removed=original-changed;outside=removed
    for region in cut_regions:outside=outside-region
    rows=[];arrays={}
    for protrusion in [0,.5,1]:
        for permutation in itertools.permutations(range(3)):
            cs=curves(protrusion,permutation);ms=[tube(c['points'],c['tangents']) for c in cs]
            hits=[];old_hits=[]
            for i,m in enumerate(ms):
                old_hits.extend(dict(wire=i,**h) for h in collisions(m,targets))
                alt=dict(targets);alt['Drive_Bridge']=dict(targets['Drive_Bridge'],m=changed)
                hits.extend(dict(wire=i,**h) for h in collisions(m,alt))
            peers=[dict(wires=[i,j],overlap_mm3=(ms[i]^ms[j]).volume()) for i in range(3)
                   for j in range(i+1,3) if (ms[i]^ms[j]).volume()>1e-5]
            rows.append(dict(protrusion_trial_mm=protrusion,geometric_lane_pairing=list(permutation),
                             lengths_mm=[c['length_mm'] for c in cs],hits=hits,peer_hits=peers,
                             current_original_hits=old_hits,status='FAIL' if hits or peers else 'PASS'))
    chosen=curves();ms=[tube(c['points'],c['tangents']) for c in chosen]
    alt=dict(targets);alt['Drive_Bridge']=dict(targets['Drive_Bridge'],m=changed)
    margin=[]
    for radius in [.6,.7]:
        inflated=[tube(c['points'],c['tangents'],radius) for c in chosen]
        hits=[dict(wire=i,**h) for i,m in enumerate(inflated) for h in collisions(m,alt)]
        peers=[dict(wires=[i,j],overlap_mm3=(inflated[i]^inflated[j]).volume())
               for i in range(3) for j in range(i+1,3) if (inflated[i]^inflated[j]).volume()>1e-5]
        margin.append(dict(radius_mm=radius,hits=hits,peer_hits=peers,
                           status='FAIL' if hits or peers else 'PASS'))
    gaps=[];stub_rows=[]
    for protrusion in [0,.5,1]:
        refs=[tube(c['points'],c['tangents']) for c in curves(protrusion)]
        stubs=controller_exit_stubs(protrusion)
        for i,c in enumerate(stubs):
            m=tube(c['points'],c['tangents']);hits=collisions(m,alt)
            peers=[dict(U04_wire=j,overlap_mm3=(m^other).volume())
                   for j,other in enumerate(refs) if (m^other).volume()>1e-5]
            stub_rows.append(dict(protrusion_trial_mm=protrusion,wire=i,hits=hits,peer_hits=peers,
                                  status='FAIL' if hits or peers else 'PASS',
                                  short_stub_length_mm=c['short_stub_length_mm']))
    for i,c in enumerate(controller_exit_stubs()):
        arrays['U03_stub_'+str(i)]=c['points'];arrays['U03_stub_tangent_'+str(i)]=c['tangents']
    for i,m in enumerate(ms):
        for name in ['Drive_Bridge','Load_Frame','UPS_Module','Vendor_S288_L','Vendor_S288_R',
                     'Motor_Top_Pad_L','Motor_Top_Pad_R','Body_Front','Body_Rear']:
            gaps.append(dict(wire=i,part=name,gap_mm=m.min_gap(alt[name]['m'],3),search_cap_mm=3))
        arrays['wire_'+str(i)]=chosen[i]['points'];arrays['tangent_'+str(i)]=chosen[i]['tangents']
    np.savez_compressed(H/'top_beam_routes.npz',**arrays)
    report=dict(revision=P['revision'],cases=rows,enlarged_chosen_cases=margin,chosen_gaps=gaps,
                controller_short_stub_cases=stub_rows,
                status='FAIL' if any(x['status']=='FAIL' for x in rows+margin+stub_rows) else 'PASS',
                upper_motor_ports_used=[1,1],electrical_pin_mapping='NOT_CHANGED; actual pin identification remains required',
                roof_trial_openings=dict(size_mm=[8,9.9],centers_xy_mm=[[2.7,22.45],[-2.7,-22.45]],
                                         z_cut_mm=[63.4,66.6],open_at_existing_edge=True,
                                         actual_preplug_installation='NOT_TESTED',main_adoption=False),
                nominal_route_parameters=dict(upper_motor_sockets=[1,1],wire_length_each_mm=190,
                    wire_od_user_approximate_mm=1,protrusion_trial_mm=[0,.5,1],straight_tail_assumed_mm=1,
                    post_tail_assumed_mm=2,tail_center_radius_mm=5,vertical_radius_mm=3,
                    coil_radius_mm=3.5,coil_z_mm=[69.2,70.6,72]),
                removed_mm3=removed.volume(),added_mm3=(changed-original).volume(),
                removed_outside_regions_mm3=outside.volume(),connected_solids_before=len(original.decompose()),
                connected_solids_after=len(changed.decompose()),assembly='NOT_TESTED',
                physical_wire_restraints='NOT_TESTED',full_U03_and_all_harness='BLOCKED',
                strength='NOT_TESTED',main_adoption=False,manufacturing_release=False,
                protected=protected(),sources={str(q.relative_to(PROJECT)):sha(q) for q in
                    [Path(__file__),H/'context.py',H/'route_geometry.py',ROOT/'mori_v1_2.blend',
                     PROJECT/'config/geometry.json',H.parent/'s288_vendor_fit_M1_58/vendor_mesh.json',
                     H.parent/'s288_vendor_fit_M1_58/fit_review.json',
                     H.parent/'s288_plug_space_M1_58/review.json',
                     H.parent/'s288_plug_space_M1_58/wire_geometry.py',
                     ROOT/'procurement/evidence/2026-10-13_S288_lead_measurement.json']})
    (H/'top_beam_check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],cases=len(rows),passed=sum(x['status']=='PASS' for x in rows),
                          chosen_hits=rows[-6]['hits'],margin=margin,stub_passes=sum(x['status']=='PASS' for x in stub_rows),
                          removed_mm3=removed.volume()),indent=2),flush=True)
