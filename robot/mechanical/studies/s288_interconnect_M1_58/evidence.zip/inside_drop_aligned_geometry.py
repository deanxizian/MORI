"""Nominal interconnect entirely within the unmodified printed drive enclosure."""
from pathlib import Path
import sys,math
sys.path.insert(0,str(Path(__file__).resolve().parent))
from route_geometry import Path as WirePath,tail,tube,np

def half(side,lane,wire_index,protrusion,amplitude,double):
    pts,info=tail(side,0,[-2,0,2][lane],protrusion,1)
    pts=pts.copy();sign=1 if side=='L' else -1
    pts[-1]=pts[-2]+np.array([0,sign*.5,0])
    pts[:,:2]*=sign
    info=dict(info);info['centerline_length_mm']-=9.5
    x,y,z=pts[-1];r=3.;front=14.7;B=9.5
    plane=51+1.4*wire_index+(0 if double else 4.5)
    p=WirePath(pts[-1]);p.line([x,front,z])
    p.arc(lambda q:np.c_[np.full(len(q),x),front+r*np.sin(q),z+r*(1-np.cos(q))],
          lambda q:np.c_[q*0,np.cos(q),np.sin(q)],math.pi/2,r)
    y1=front+r
    p.line([x,y1,plane-r])
    p.arc(lambda q:np.c_[np.full(len(q),x),y1+r*(1-np.cos(q)),plane-r+r*np.sin(q)],
          lambda q:np.c_[q*0,np.sin(q),np.cos(q)],math.pi/2,r)
    y2=y1+r
    p.arc(lambda q:np.c_[x+r*(1-np.cos(q)),y2+r*np.sin(q),np.full(len(q),plane)],
          lambda q:np.c_[np.sin(q),np.cos(q),q*0],math.pi/2,r)
    hx=x+r;Y=y2+r
    assert amplitude>max(hx,B)+1e-6,(amplitude,hx,B)
    p.line([amplitude,Y,plane])
    rr=3+.7*wire_index if double else 5.
    p.arc(lambda q:np.c_[amplitude+rr*np.sin(q),Y-rr*(1-np.cos(q)),np.full(len(q),plane)],
          lambda q:np.c_[np.cos(q),-np.sin(q),q*0],math.pi,rr)
    Y-=2*rr
    if double:
        p.line([B,Y,plane])
        p.arc(lambda q:np.c_[B-r*np.sin(q),np.full(len(q),Y),plane+r*(1-np.cos(q))],
              lambda q:np.c_[-np.cos(q),q*0,np.sin(q)],math.pi,r)
        plane+=2*r
        p.line([amplitude,Y,plane])
        p.arc(lambda q:np.c_[amplitude+rr*np.sin(q),Y+rr*(1-np.cos(q)),np.full(len(q),plane)],
              lambda q:np.c_[np.cos(q),np.sin(q),q*0],math.pi,rr)
        Y+=2*rr
        # Lower the returning central channel before the corner so it clears
        # the other, upper factory socket's controller lead. Two radius-3
        # arcs retain horizontal tangent continuity without altering any print.
        start_x=8.;drop=1.5;angle=math.acos(1-drop/(2*r))
        p.line([start_x,Y,plane])
        p.arc(lambda q:np.c_[start_x-r*np.sin(q),np.full(len(q),Y),plane-r*(1-np.cos(q))],
              lambda q:np.c_[-np.cos(q),q*0,-np.sin(q)],angle,r)
        mx=start_x-r*math.sin(angle);mz=plane-r*(1-math.cos(angle))
        p.arc(lambda q:np.c_[mx-r*(math.sin(angle)-np.sin(angle-q)),np.full(len(q),Y),mz-r*(np.cos(angle-q)-math.cos(angle))],
              lambda q:np.c_[-np.cos(angle-q),q*0,-np.sin(angle-q)],angle,r)
        plane-=drop
    p.line([r,Y,plane])
    p.arc(lambda q:np.c_[r-r*np.sin(q),Y-r*(1-np.cos(q)),np.full(len(q),plane)],
          lambda q:np.c_[-np.cos(q),-np.sin(q),q*0],math.pi/2,r)
    tt=np.gradient(pts,axis=0);tt/=np.linalg.norm(tt,axis=1)[:,None];tt[-1]=[0,1,0]
    points=np.concatenate([pts,np.array(p.points)[1:]])
    tangents=np.concatenate([tt,np.array(p.tangents)[1:]])
    core=np.array(p.points);core_tt=np.array(p.tangents)
    points[:,:2]*=sign;tangents[:,:2]*=sign;core[:,:2]*=sign;core_tt[:,:2]*=sign
    return dict(points=points,tangents=tangents,core=core,core_tangents=core_tt,
                length_mm=info['centerline_length_mm']+p.length,
                minimum_radius_mm=min(info['individual_bend_radius_mm'],*p.radii))

def full(protrusion=1,permutation=(0,1,2)):
    out=[]
    for i in range(3):
        def trial(A):
            l=half('L',i,i,protrusion,A,True)
            r=half('R',permutation[i],i,protrusion,A,False)
            distance=np.linalg.norm(r['points'][-1]-l['points'][-1])
            return l,r,l['length_mm']+r['length_mm']+distance
        _,_,length=trial(21)
        A=21+(190-length)/6
        l,r,length=trial(A)
        assert abs(length-190)<1e-6,length
        bridge=WirePath(l['points'][-1]);bridge.line(r['points'][-1])
        pts=np.concatenate([l['points'],np.array(bridge.points)[1:],r['points'][::-1][1:]])
        tt=np.concatenate([l['tangents'],np.array(bridge.tangents)[1:],-r['tangents'][::-1][1:]])
        core=np.concatenate([l['core'],np.array(bridge.points)[1:],r['core'][::-1][1:]])
        core_tt=np.concatenate([l['core_tangents'],np.array(bridge.tangents)[1:],-r['core_tangents'][::-1][1:]])
        out.append(dict(points=pts,tangents=tt,core=core,core_tangents=core_tt,
                        length_mm=length,amplitude_mm=A,
                        minimum_radius_mm=min(l['minimum_radius_mm'],r['minimum_radius_mm'])))
    return out
