"""Finite assembly paths for internal U04 with the original, uncut drive bridge."""
import sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import tube
targets,ss,fit,src=load()
curves=np.load(H/'inside_routes.npz');wires=[tube(curves['wire_'+str(i)],curves['tangent_'+str(i)]) for i in range(3)]
wiretargets={f'U04_wire_{i}':dict(m=m,lo=np.array(m.bounding_box()[:3]),hi=np.array(m.bounding_box()[3:])) for i,m in enumerate(wires)}
started=time.monotonic()

def wire_hits(m):return collisions(m,wiretargets)

# Preserve the first, rejected interpretation: moving the cap upward while
# treating its future underside loops as already fixed in the final position.
rejected=[]
for dz in range(-50,1):
    hit=wire_hits(targets['Motor_Retainer']['m'].translate([0,0,dz]))
    if hit:rejected.append(dict(cap_translation_z_mm=dz,hits=hit))

# Proposed sequence fixes the cap/motors/U04 first, then lowers only the bridge
# and its top pads. Frame, UPS, wheel hubs and shells are installed later.
fixed={n:t for n,t in targets.items() if n in ['Motor_Retainer','Vendor_S288_L','Vendor_S288_R'] or n.startswith(('Motor_Retainer_Pad_','Wheel_Axle_','Wheel_Bearing_','Wheel_Spacer_','Wheel_Output_Screw_'))}
fixed.update(wiretargets)
moving=['Drive_Bridge']+[n for n in targets if n.startswith('Motor_Top_Pad_')]
fail=[];soft=[];tiny=[]
for dz in np.linspace(50,0,101):
    for n in moving:
        m=targets[n]['m'].translate([0,0,float(dz)])
        for hit in collisions(m,fixed):
            row=dict(bridge_translation_z_mm=float(dz),moving=n,**hit)
            if n.startswith('Motor_Top_Pad_') and hit['part'].startswith('Vendor_S288_'):soft.append(row)
            elif hit['overlap_mm3']<=P['validation']['collision_volume_tolerance_mm3']:tiny.append(row)
            else:fail.append(row)
    if len(fail)>20:break
bridge=dict(status='FAIL' if fail else 'PASS',samples=101,step_mm=.5,travel_mm=50,moving=moving,fixed=list(fixed),failures=fail,known_soft_pad_contacts=soft,soft_pad_compression='NOT_TESTED',below_existing_volume_threshold=tiny)
print('BRIDGE_LOWERING',bridge['status'],fail[:3],flush=True)

# Actual saved fasteners enter on the unchanged axes after the bridge settles.
bolt_rows=[]
for n,t in targets.items():
    if not n.startswith('Wheel_Cap_Clamp_Screw_'):continue
    hit=[]
    for dz in np.linspace(-34,0,69):
        hit.extend(dict(translation_z_mm=float(dz),**q) for q in wire_hits(t['m'].translate([0,0,float(dz)])))
    bolt_rows.append(dict(part=n,status='FAIL' if hit else 'PASS',samples=69,hits=hit))

# Only U04 is fixed to the body. This check does not contain speaker/DC/switch
# wiring. Native shell modules may carry those parts but their leads are absent.
shells=[]
front=['Body_Front','Frame_Insert_0','Frame_Insert_1','Speaker','Speaker_Gasket','Speaker_Insert_-1','Speaker_Insert_1','Speaker_Screw_-1','Speaker_Screw_1']
rear=['Body_Rear','Frame_Insert_2','Frame_Insert_3']+list(P['dc_inlet_trial']['reference_ids'])+list(P['ups_rear_controls']['reference_ids'])
for side,direction,names in [('front',1,front),('rear',-1,rear)]:
    names=list(dict.fromkeys(names));assert all(n in targets for n in names),names
    hit=[]
    for distance in np.linspace(0,220,275):
        for n in names:
            t=targets[n];shift=np.array([0,direction*distance,0]);lo=t['lo']+shift;hi=t['hi']+shift
            if all(np.any(hi<w['lo']) or np.any(lo>w['hi']) for w in wiretargets.values()):continue
            for q in wire_hits(t['m'].translate(shift)):
                hit.append(dict(distance_mm=float(distance),moving=n,**q))
        if len(hit)>20:break
    shells.append(dict(module=side,status='FAIL' if hit else 'PASS',samples=275,travel_mm=220,hits=hit,scope='Native shell module against this fixed U04 only; finite existing straight translation'))
    print('SHELL_U04',side,shells[-1]['status'],hit[:3],flush=True)

out=dict(revision=P['revision'],source_main_sha256=sha(ROOT/'mori_v1_2.blend'),cap_upward_comparison=dict(status='FAIL' if rejected else 'PASS',samples=51,hits=rejected,scope='Comparison: original cap straight-up insertion against already installed internal U04'),
    original_bridge_lowering=bridge,printed_changes=[],cap_fasteners_against_U04=bolt_rows,shell_modules_against_U04=shells,
    nominal_U04_sequence_status='FAIL' if fail or any(x['status']!='PASS' for x in bolt_rows+shells) else 'PASS',
    hands_and_bench_support='NOT_TESTED',actual_connector_assembly='BLOCKED',wire_restraints='NOT_TESTED',
    all_other_harnesses='NOT_TESTED',complete_flexible_assembly='BLOCKED',main_adoption=False,manufacturing_release=False,
    physical='NOT_TESTED',protected=protected(),elapsed_s=time.monotonic()-started,
    sources={str(p.relative_to(PROJECT)):sha(p) for p in [Path(__file__),H/'route_geometry.py',H/'inside_routes.npz',ROOT/'mori_v1_2.blend',PROJECT/'config/geometry.json']})
(H/'inside_sequence.json').write_text(json.dumps(out,indent=2)+'\n')
print('INTERNAL_U04_SEQUENCE',out['nominal_U04_sequence_status'],flush=True)
