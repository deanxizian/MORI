import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import full,tube
from escape_candidate import candidate,report
targets,ss,fit,src=load()
before=targets['Drive_Bridge']['m'];modified=candidate(before)
targets['Drive_Bridge']['m']=modified
(H/'escape_parameters.json').write_text(json.dumps(report(before,modified),indent=2)+'\n')
reports=[];arrays={}
for left,right in [(0,0),(0,1),(1,0),(1,1)]:
    curves=full(left,right);ms=[];bad=[]
    for c in curves:
        m=tube(c['points'],c['tangents']);ms.append(m)
        bad.extend(dict(wire=c['wire'],**h) for h in collisions(m,targets))
        arrays[f'L{left}_R{right}_wire{c["wire"]}']=c['points']
    peers=[dict(wires=[i,j],overlap_mm3=(ms[i]^ms[j]).volume()) for i in range(3) for j in range(i+1,3) if (ms[i]^ms[j]).volume()>1e-5]
    rows=[{k:v for k,v in c.items() if k not in ['points','tangents']} for c in curves]
    reports.append(dict(left_socket=left,right_socket=right,status='FAIL' if bad or peers else 'PASS',wires=rows,hits=bad,peer_hits=peers))
    print('ROUTE',left,right,'STATUS',reports[-1]['status'],'HITS',bad,'PEERS',peers,flush=True)
np.savez_compressed(H/'route_candidates.npz',**arrays)
(H/'route_check.json').write_text(json.dumps(dict(revision=P['revision'],main_sha256=sha(ROOT/'mori_v1_2.blend'),routes=reports,wire_od_mm=1,wire_od_evidence='USER_REPORTED_APPROXIMATE',nominal_length_each_mm=190,plug_protrusion_sample_mm=1,source_measurement_sha256=sha(ROOT/'procurement/evidence/2026-10-13_S288_lead_measurement.json'),geometric_lane_to_actual_pin='NOT_IDENTIFIED; no electrical remapping',real_connector_fit='BLOCKED',physical='NOT_TESTED',source_limits='Same official motor closed-shape policy; two open source surfaces excluded. Finite polygonal tubes, not continuous clearance proof.',protected=protected(),main_adoption=False,manufacturing_release=False),indent=2)+'\n')
