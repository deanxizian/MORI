"""Resolve nominal OD1 versus enlarged-clearance tests without waiving the failure."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import tail,tube
from escape_candidate import candidate
targets,ss,fit,src=load();targets['Drive_Bridge']['m']=candidate(targets['Drive_Bridge']['m'])
rows=[]
for pr in [0,.5,1]:
    for i,off in enumerate([-2,0,2]):
        p,info=tail('L',1,off,protrusion=pr);end=p[-1];extension=np.c_[np.full(60,end[0]),np.linspace(end[1],35.5,60),np.full(60,end[2])]
        points=np.concatenate([p,extension[1:]]);t=np.gradient(points,axis=0);t/=np.linalg.norm(t,axis=1)[:,None]
        m=tube(points,t,radius=.5);hit=collisions(m,targets)
        rows.append(dict(protrusion_trial_mm=pr,wire=i,status='FAIL' if hit else 'PASS',hits=hit))
out=dict(rows=rows,nominal_OD1_stub_status='PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL',
    enlarged_radius_0p7_failed_case='Retained in candidate_check.json: upper left wire0 at assumed zero protrusion touches its own motor shape.',
    scope='Short U03 exit stub only; not full controller route, not real connector clearance',protected=protected(),
    sources={str(p.relative_to(PROJECT)):sha(p) for p in [Path(__file__),H/'context.py',H/'route_geometry.py',H/'escape_candidate.py',H/'candidate_check.json']})
(H/'upper_nominal_check.json').write_text(json.dumps(out,indent=2)+'\n');print('UPPER_NOMINAL',out['nominal_OD1_stub_status'],rows,flush=True)
