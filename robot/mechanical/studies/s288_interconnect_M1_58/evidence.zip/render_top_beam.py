"""Static candidate views from the checked top-beam geometry; no main save."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from context import *
from check_top_beam import roof_cuts,curves,controller_exit_stubs
from route_geometry import tube
targets,ss,fit,src=load();old=targets['Drive_Bridge']['m'];new=old
for region in roof_cuts():new=new-region
specs=[]
for name,m,color,cat,evidence in [
    ('TOP_CANDIDATE_Bridge',new,(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('TOP_REFERENCE_Cap',targets['Motor_Retainer']['m'],(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('TOP_REFERENCE_Load_Frame',targets['Load_Frame']['m'],(.58,.62,.64,1),'PRINTABLE','ASSUMED'),
    ('TOP_REFERENCE_UPS',targets['UPS_Module']['m'],(.14,.40,.26,1),'PURCHASED_REFERENCE','VENDOR_DOCUMENTED')]:
    mesh=m.to_mesh64();specs.append((name,mesh.vert_properties[:,:3],mesh.tri_verts,np.eye(4),color,cat,evidence))
for side in ['L','R']:
    for row in src['free_shells']:
        specs.append(('TOP_REF_S288_'+side+'_'+str(row['index']),row['vertices_mm'],row['triangles'],
                      np.array(fit['cases'][side+'_inboard']['matrix']),(.25,.30,.33,1),
                      'PURCHASED_REFERENCE','VENDOR_DOCUMENTED'))
for prefix,items,color in [('U04',curves(),(.95,.56,.12,1)),
                           ('U03_SHORT',controller_exit_stubs(),(.28,.69,.80,1))]:
    for i,c in enumerate(items):
        mesh=tube(c['points'],c['tangents']).to_mesh64()
        specs.append(('TOP_CAPACITY_'+prefix+'_'+str(i),mesh.vert_properties[:,:3],mesh.tri_verts,
                      np.eye(4),color,'PLACEHOLDER','ASSUMED'))
bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene;objs={}
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
for name,v,f,mat,color,category,evidence in specs:
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(np.asarray(v).tolist(),[],np.asarray(f).tolist());mesh.update()
    o=bpy.data.objects.new(name,mesh);sc.collection.objects.link(o);o.matrix_world=Matrix(mat);o.color=color
    o['mori_owner']='s288_top_beam_study';o['category']=category;o['data_status']=evidence;o['unadopted']=True
    if 'S288' in name:o['source_sha256']=src['source_sha256']
    if name.startswith('TOP_CAPACITY_'):o['real_connector_and_wire']='NOT_TESTED'
    objs[name]=o
sc['status']='Independent top-beam alternative; main not adopted; full harness and physical fit unresolved'
sc.render.engine='BLENDER_WORKBENCH';sh=sc.display.shading;sh.light='STUDIO';sh.color_type='OBJECT'
sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True
sh.background_type='WORLD'
if sc.world is None:sc.world=bpy.data.worlds.new('TopBeamReviewWorld')
sc.world.color=(.07,.09,.10)
sc.render.resolution_x=1300;sc.render.resolution_y=900;sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG'
def render(name,eye,target,scale):
    cam=bpy.data.objects.new('TopBeamCamera',bpy.data.cameras.new('TopBeamCamera'));sc.collection.objects.link(cam)
    cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO';cam.data.ortho_scale=scale;sc.camera=cam
    sc.render.filepath=str(H/(name+'.png'));bpy.ops.render.render(write_still=True)
objs['TOP_REFERENCE_UPS'].hide_render=True;objs['TOP_REFERENCE_Load_Frame'].hide_render=True
render('top_beam_installed',(90,110,125),(0,0,58),116)
render('top_beam_front',(0,150,74),(0,0,59),109)
objs['TOP_REFERENCE_UPS'].hide_render=False;objs['TOP_REFERENCE_Load_Frame'].hide_render=False
render('top_beam_below_UPS',(95,120,65),(0,0,72),121)
objs['TOP_REFERENCE_UPS'].hide_render=True;objs['TOP_REFERENCE_Load_Frame'].hide_render=True
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(H/'top_beam_UNADOPTED.blend'),compress=True)
print('TOP_BEAM_LOCAL_MODEL_ONLY',len(objs),flush=True)
