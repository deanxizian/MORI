"""Record actual Blender study commands and logs."""
import sys,subprocess,json,hashlib,datetime
from pathlib import Path
H=Path(__file__).resolve().parent;P=H.parents[2]
stage,filename=sys.argv[1:3];script=H/filename
cmd=['/Applications/Blender.app/Contents/MacOS/Blender','-b']
if '--main' in sys.argv:cmd.append(str(P/'mechanical/mori_v1_2.blend'))
cmd+=['-t','4','--python-exit-code','1','--python',str(script)]
now=lambda:datetime.datetime.now().astimezone().isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
started=now();r=subprocess.run(cmd,cwd=P,capture_output=True,text=True)
(H/(stage+'.log')).write_text(r.stdout+r.stderr)
records=json.loads((H/'commands.json').read_text()) if (H/'commands.json').exists() else []
dependencies={n:sha(H/n) for n in ['context.py','route_geometry.py','escape_candidate.py'] if (H/n).exists()}
records.append(dict(stage=stage,command=cmd,cwd=str(P),started=started,finished=now(),returncode=r.returncode,log=stage+'.log',log_sha256=sha(H/(stage+'.log')),script_sha256=sha(script),dependencies=dependencies))
(H/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
print((r.stdout+r.stderr)[-6000:]);raise SystemExit(r.returncode)
