from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from inside_geometry import full,tube
ms=[tube(c['points'],c['tangents']) for c in full()];rows=[]
for i in range(3):
    for j in range(i+1,3):
        intersect=ms[i]^ms[j]
        for body in intersect.decompose():
            if body.volume()<1e-7:continue
            rows.append(dict(wires=[i,j],volume_mm3=body.volume(),bounds=list(body.bounding_box())))
(H/'inside_first_overlap_locations.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2),flush=True)
