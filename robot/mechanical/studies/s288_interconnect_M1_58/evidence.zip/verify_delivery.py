"""Verify this independent candidate without rebuilding or adopting the main model."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote, quote
from urllib.request import Request, urlopen
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import platform
import sys

H = Path(__file__).resolve().parent
P = H.parents[2]
started = datetime.datetime.now().astimezone().isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((H / name).read_text())

errors = []
before = read('protected_before.json')
changed = [name for name, digest in before.items()
           if not (P / name).is_file() or sha(P / name) != digest]
if changed:
    errors.append({'protected_changed': changed})

reports = {name: read(name) for name in
           ('candidate_check.json', 'upper_nominal_check.json', 'wired_sequence_check.json',
            'top_beam_check.json', 'top_beam_sequence.json',
            'inside_check.json', 'inside_compatibility.json', 'inside_sequence.json')}
source_changes = []
for report, data in reports.items():
    for name, digest in data['sources'].items():
        if not (P / name).is_file() or sha(P / name) != digest:
            source_changes.append({'report': report, 'source': name})
if source_changes:
    errors.append({'check_source_changes': source_changes})

r = reports['candidate_check.json']
u = reports['upper_nominal_check.json']
s = reports['wired_sequence_check.json']
top = reports['top_beam_check.json']
top_sequence = reports['top_beam_sequence.json']
inside = reports['inside_check.json']
inside_compatibility = reports['inside_compatibility.json']
inside_sequence = reports['inside_sequence.json']
claims = {
    'lower_U04_18_nominal_cases': len(r['lower_pair_cases']) == 18 and
        all(x['status'] == 'PASS' for x in r['lower_pair_cases']),
    'lower_U04_two_enlarged_cases': len(r['inflated_chosen_route']) == 2 and
        all(x['status'] == 'PASS' for x in r['inflated_chosen_route']),
    'upper_nine_nominal_stubs': len(u['rows']) == 9 and
        u['nominal_OD1_stub_status'] == 'PASS',
    'upper_enlarged_failure_retained': sum(x['status'] == 'FAIL'
        for x in r['upper_left_exit_stubs']) == 1 and
        r['nominal_installed_status'] == 'FAIL',
    'old_cap_sequence_failure_retained':
        s['rejected_fixed_wire_cap_lift']['status'] == 'FAIL',
    'proposed_U04_sequence': s['nominal_U04_sequence_status'] == 'PASS' and
        s['proposed_bridge_lowering']['samples'] == 101 and
        all(x['status'] == 'PASS' for x in s['cap_fasteners_against_U04']) and
        all(x['status'] == 'PASS' for x in s['shell_modules_against_U04']),
    'single_solid_only_declared_regions':
        r['structure']['connected_solids_before'] == 1 and
        r['structure']['connected_solids_after'] == 1 and
        r['structure']['added_volume_mm3'] == 0 and
        r['structure']['removed_outside_declared_regions_mm3'] == 0,
    'unadopted_no_manufacturing_release': not r['main_adoption'] and
        not s['main_adoption'] and not r['manufacturing_release'] and
        not s['manufacturing_release'],
    'top_beam_nominal_18_and_U03_stubs': top['status'] == 'PASS' and
        len(top['cases']) == 18 and all(x['status'] == 'PASS' for x in top['cases']) and
        len(top['controller_short_stub_cases']) == 9,
    'top_beam_one_solid_declared_regions': top['connected_solids_before'] == 1 and
        top['connected_solids_after'] == 1 and top['added_mm3'] == 0 and
        top['removed_outside_regions_mm3'] == 0,
    'top_beam_nominal_sequence': top_sequence['status'] == 'PASS' and
        top_sequence['position_samples'] == 41 and not top_sequence['failures'] and
        not top_sequence['wire_failures'],
    'top_beam_not_adopted': not top['main_adoption'] and not top['manufacturing_release'] and
        not top_sequence['main_adoption'] and not top_sequence['manufacturing_release'],
    'internal_U04_nominal_and_chosen_enlarged': inside['status'] == 'PASS' and
        len(inside['cases']) == 18 and all(x['status'] == 'PASS' for x in inside['cases']) and
        len(inside['enlarged_chosen_cases']) == 2 and
        all(x['status'] == 'PASS' for x in inside['enlarged_chosen_cases']),
    'internal_prints_unchanged': not inside['printed_changes'] and
        inside['new_parts'] == 0 and inside['new_fasteners'] == 0,
    'internal_controller_stub_coexistence_only': inside_compatibility['status'] == 'PASS' and
        len(inside_compatibility['rows']) == 9 and
        all(not x['U04_hits'] and all(h['part'] == 'Drive_Bridge' for h in x['native_hits'])
            for x in inside_compatibility['rows']) and inside_compatibility['full_U03'] == 'BLOCKED',
    'internal_U04_sequence': inside_sequence['nominal_U04_sequence_status'] == 'PASS' and
        inside_sequence['original_bridge_lowering']['samples'] == 101 and
        not inside_sequence['original_bridge_lowering']['failures'] and
        all(x['status'] == 'PASS' for x in inside_sequence['cap_fasteners_against_U04']) and
        all(x['status'] == 'PASS' for x in inside_sequence['shell_modules_against_U04']),
    'internal_unadopted_and_full_assembly_blocked':
        not inside['main_adoption'] and not inside['manufacturing_release'] and
        not inside_sequence['main_adoption'] and not inside_sequence['manufacturing_release'] and
        inside_sequence['complete_flexible_assembly'] == 'BLOCKED',
}
if not all(claims.values()):
    errors.append({'failed_claims': [k for k, v in claims.items() if not v]})

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.targets = set()
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ('href', 'src') and value:
                p = urlsplit(value)
                if not p.scheme and not p.netloc and p.path:
                    self.targets.add((H / unquote(p.path)).resolve())

parser = Links()
for page in ['index.html', 'top_beam_review.html', 'inside_review.html']:
    parser.feed((H / page).read_text())
missing = [str(p) for p in parser.targets if not p.is_file()]
if missing:
    errors.append({'missing_local_links': missing})

def http_head(path):
    rel = path.relative_to(P).as_posix()
    url = 'http://127.0.0.1:58202/' + quote(rel, safe='/')
    try:
        with urlopen(Request(url, method='HEAD'), timeout=6) as response:
            return {'path': rel, 'status': response.status}
    except Exception as exc:
        return {'path': rel, 'error': str(exc)}

with ThreadPoolExecutor(max_workers=4) as pool:
    http = list(pool.map(http_head, sorted(parser.targets | {H / 'index.html', H / 'top_beam_review.html', H / 'inside_review.html'})))
if any(x.get('status') != 200 for x in http):
    errors.append({'http_failures': [x for x in http if x.get('status') != 200]})

report = {
    'status': 'FAIL' if errors else 'PASS',
    'scope': 'Delivery integrity only; no physical or full-harness qualification',
    'protected_files': len(before), 'protected_changed': changed,
    'check_source_changes': source_changes,
    'claims_verified': claims, 'local_links_missing': missing,
    'http_heads': http,
    'candidate_aggregate_status': r['nominal_installed_status'],
    'internal_U04_nominal_status': inside['status'],
    'internal_complete_flexible_assembly': inside_sequence['complete_flexible_assembly'],
    'full_real_harness': r['structure']['full_real_harness'],
    'print_strength': r['structure']['print_strength'],
    'main_adoption': False, 'manufacturing_release': False,
    'errors': errors,
}
(H / 'final_delivery_verification.json').write_text(json.dumps(report, indent=2) + '\n')
message = json.dumps({'status': report['status'], 'protected_files': len(before),
                     'source_changes': len(source_changes), 'local_links': len(parser.targets),
                     'http_heads': len(http), 'candidate_aggregate': r['nominal_installed_status']})
(H / 'final_delivery_verify.log').write_text(message + '\n')
commands = read('commands.json')
commands.append({
    'stage': 'final_delivery_integrity',
    'command': [sys.executable, str(Path(__file__).resolve())],
    'cwd': str(Path.cwd()), 'python_version': platform.python_version(),
    'started': started, 'finished': datetime.datetime.now().astimezone().isoformat(),
    'returncode': 1 if errors else 0,
    'script_sha256': sha(Path(__file__).resolve()),
    'log': 'final_delivery_verify.log', 'log_sha256': sha(H / 'final_delivery_verify.log'),
})
(H / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
if not errors:
    files = {p.relative_to(H).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in sorted(H.rglob('*')) if p.is_file() and
             '__pycache__' not in p.parts and p.name != 'delivery.json'}
    (H / 'delivery.json').write_text(json.dumps({
        'revision': 'V1.2-M1.58-independent-S288-routing-studies',
        'main_adoption': False, 'manufacturing_release': False,
        'created': datetime.datetime.now().astimezone().isoformat(), 'files': files,
    }, indent=2) + '\n')
print(message)
raise SystemExit(1 if errors else 0)
