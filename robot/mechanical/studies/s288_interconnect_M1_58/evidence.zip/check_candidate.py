import sys,itertools,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import full,tube,tail
from escape_candidate import candidate,report,cuts
targets,ss,fit,src=load();original=targets['Drive_Bridge']['m'];targets['Drive_Bridge']['m']=candidate(original)
structure=report(original,targets['Drive_Bridge']['m']);structure['connected_solids_before']=len(original.decompose());structure['connected_solids_after']=len(targets['Drive_Bridge']['m'].decompose())
assert structure['added_volume_mm3']<1e-8 and structure['removed_outside_declared_regions_mm3']<1e-8
assert structure['connected_solids_after']==structure['connected_solids_before']==1
slots=manifold.Manifold.batch_boolean(cuts(),manifold.OpType.Add)
fastener_gaps=[]
for n,t in targets.items():
    if n.startswith(('Wheel_Cap_Clamp_','Drive_L_','Drive_R_','Wheel_Output_Screw_','Wheel_Bearing_')):
        gap=slots.min_gap(t['m'],10)
        fastener_gaps.append(dict(part=n,gap_mm=float(gap),search_cap_mm=10))
assert min(x['gap_mm'] for x in fastener_gaps)>5
structure['fastener_and_bearing_gap_samples']=fastener_gaps
rows=[];arrays={};started=time.monotonic()
for protrusion,perm in itertools.product([0,.5,1],itertools.permutations(range(3))):
    curves=full(0,0,perm,protrusion=protrusion);ms=[];bad=[]
    for c in curves:
        m=tube(c['points'],c['tangents']);ms.append(m)
        bad.extend(dict(wire=c['wire'],**h) for h in collisions(m,targets))
    peer=[dict(wires=[i,j],volume_mm3=(ms[i]^ms[j]).volume()) for i in range(3) for j in range(i+1,3) if (ms[i]^ms[j]).volume()>1e-5]
    row=dict(left_socket=0,right_socket=0,protrusion_trial_mm=protrusion,geometric_lane_pairing=list(perm),wire_lengths_mm=[c['length_mm'] for c in curves],minimum_radius_mm=min(c['minimum_radius_mm'] for c in curves),status='FAIL' if bad or peer else 'PASS',hits=bad,peer_hits=peer)
    rows.append(row)
    print('LOWER_PAIR',protrusion,perm,row['status'],bad,peer,flush=True)
    if protrusion==1 and perm==(0,1,2):
        chosen=curves
        for c in curves:arrays['wire_'+str(c['wire'])]=c['points'];arrays['tangent_'+str(c['wire'])]=c['tangents']
np.savez_compressed(H/'chosen_installed_routes.npz',**arrays)
clearance=[]
for radius in [.6,.7]:
    ms=[tube(c['points'],c['tangents'],radius=radius) for c in chosen]
    hit=[dict(wire=i,**h) for i,m in enumerate(ms) for h in collisions(m,targets)]
    peer=[dict(wires=[i,j],volume_mm3=(ms[i]^ms[j]).volume()) for i in range(3) for j in range(i+1,3) if (ms[i]^ms[j]).volume()>1e-5]
    clearance.append(dict(radius_mm=radius,status='FAIL' if hit or peer else 'PASS',hits=hit,peer_hits=peer))
    print('INFLATED_RADIUS',radius,clearance[-1],flush=True)
native_gaps=[];ms=[tube(c['points'],c['tangents']) for c in chosen]
for i,m in enumerate(ms):
    for n in ['Body_Front','Body_Rear','Drive_Bridge','Motor_Retainer','Vendor_S288_L','Vendor_S288_R']:
        native_gaps.append(dict(wire=i,part=n,gap_mm=float(m.min_gap(targets[n]['m'],1)),search_cap_mm=1))
peer_gaps=[dict(wires=[i,j],gap_mm=float(ms[i].min_gap(ms[j],1)),search_cap_mm=1) for i in range(3) for j in range(i+1,3)]
# The upper left connector may feed the controller. Only check its exit stub;
# the new controller endpoint and cable length have not been frozen.
upper=[]
for pr in [0,.5,1]:
    for i,off in enumerate([-2,0,2]):
        p,info=tail('L',1,off,protrusion=pr);end=p[-1];extension=np.c_[np.full(60,end[0]),np.linspace(end[1],35.5,60),np.full(60,end[2])]
        points=np.concatenate([p,extension[1:]]);t=np.gradient(points,axis=0);t/=np.linalg.norm(t,axis=1)[:,None]
        m=tube(points,t,radius=.7);hit=collisions(m,targets)
        upper.append(dict(protrusion_trial_mm=pr,wire=i,status='FAIL' if hit else 'PASS',hits=hit,endpoint_mm=points[-1].tolist(),scope='U03 upper-left outlet only, not complete controller cable'))
summary=dict(revision=P['revision'],main_sha256=sha(ROOT/'mori_v1_2.blend'),structure=structure,lower_pair_cases=rows,
    inflated_chosen_route=clearance,chosen_native_gaps=native_gaps,chosen_peer_gaps=peer_gaps,upper_left_exit_stubs=upper,
    nominal_installed_status='PASS' if all(x['status']=='PASS' for x in rows+clearance+upper) else 'FAIL',
    lower_pair_geometric_lane_mapping_scope='All six pairings screened; does not identify real terminal numbers or change electrical wiring',
    nominal_wire_od_mm=1,wire_od_evidence='USER_REPORTED_APPROXIMATE',nominal_each_wire_length_mm=190,
    original_lead_length_scope='User reports wire segment excluding housings; no exact tolerance, crimp-end datum or all-lead equality confirmed',
    physical_bend_radius='NOT_TESTED',real_connector='BLOCKED',restraints='NOT_TESTED',wired_cap_assembly='NOT_TESTED',
    formal_U03_route='BLOCKED pending actual controller endpoint',main_adoption=False,manufacturing_release=False,
    protected=protected(),elapsed_seconds=time.monotonic()-started,
    sources={str(p.relative_to(PROJECT)):sha(p) for p in [Path(__file__),H/'context.py',H/'route_geometry.py',H/'escape_candidate.py',ROOT/'mori_v1_2.blend',PROJECT/'config/geometry.json',H.parent/'s288_vendor_fit_M1_58/vendor_mesh.json',H.parent/'s288_plug_space_M1_58/review.json',ROOT/'procurement/evidence/2026-10-13_S288_lead_measurement.json']})
(H/'candidate_check.json').write_text(json.dumps(summary,indent=2)+'\n')
print('CANDIDATE',summary['nominal_installed_status'],'MIN_NATIVE_GAP',min(x['gap_mm'] for x in native_gaps),'MIN_PEER_GAP',min(x['gap_mm'] for x in peer_gaps),flush=True)
