import sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from route_geometry import tube
from escape_candidate import candidate,S
targets,ss,fit,src=load();old=targets['Drive_Bridge']['m'];new=candidate(old)
arrays=np.load(H/'chosen_installed_routes.npz');specs=[]
for name,m,color,category,status in [
    ('COMPARE_Original_Bridge',old,(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('CANDIDATE_Drive_Bridge',new,(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('REFERENCE_Motor_Retainer',targets['Motor_Retainer']['m'],(.38,.44,.46,1),'PRINTABLE','ASSUMED')]:
    mesh=m.to_mesh64();specs.append((name,mesh.vert_properties[:,:3],mesh.tri_verts,np.eye(4),color,category,status))
for side in ['L','R']:
    for row in src['free_shells']:
        specs.append(('REF_S288_'+side+'_'+str(row['index']),row['vertices_mm'],row['triangles'],np.array(fit['cases'][side+'_inboard']['matrix']),(.25,.30,.33,1),'PURCHASED_REFERENCE','VENDOR_DOCUMENTED'))
for i in range(3):
    m=tube(arrays['wire_'+str(i)],arrays['tangent_'+str(i)]);mesh=m.to_mesh64()
    specs.append(('CAPACITY_Wire_'+str(i),mesh.vert_properties[:,:3],mesh.tri_verts,np.eye(4),(.95,.56,.12,1),'PLACEHOLDER','ASSUMED'))
bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene;objects={}
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
for name,v,f,mat,color,category,status in specs:
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(np.asarray(v).tolist(),[],np.asarray(f).tolist());mesh.update()
    o=bpy.data.objects.new(name,mesh);sc.collection.objects.link(o);o.matrix_world=Matrix(mat);o.color=color
    o['mori_owner']='s288_interconnect_study';o['category']=category;o['data_status']=status;o['unadopted']=True
    if name.startswith('REF_'):o['source_sha256']=src['source_sha256']
    if name.startswith('CAPACITY_'):o['nominal_length_mm']=190;o['wire_od_approximate_user_mm']=1;o['physical_bend_and_crimp']='NOT_TESTED'
    objects[name]=o
sc['status']='Independent unadopted wire-exit and nominal190mm route candidate. Not full assembly or manufacturing-qualified.'
sc.render.engine='BLENDER_WORKBENCH';sh=sc.display.shading;sh.light='STUDIO';sh.color_type='OBJECT';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True
sc.render.resolution_x=1300;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
def render(name,eye,target,scale):
    cam=bpy.data.objects.new('StudyCamera',bpy.data.cameras.new('StudyCamera'));sc.collection.objects.link(cam)
    cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;sc.camera=cam
    sc.render.filepath=str(H/(name+'.png'));bpy.ops.render.render(write_still=True)
    return cam
original=objects['COMPARE_Original_Bridge'];changed=objects['CANDIDATE_Drive_Bridge'];cap=objects['REFERENCE_Motor_Retainer']
changed.hide_render=True
for n,o in objects.items():
    if n.startswith('CAPACITY_'):o.hide_render=True
render('current_closed_wall',(90,110,90),(0,0,52),110)
original.hide_render=True;changed.hide_render=False
for n,o in objects.items():
    if n.startswith('CAPACITY_'):o.hide_render=False
render('candidate_installed',(90,110,90),(0,0,52),110)
render('candidate_under_cap',(90,110,-30),(0,0,45),106)
cap.hide_render=True
render('candidate_open_seam',(60,110,75),(0,4,52),95)
cap.hide_render=False
sc['slot_width_mm']=S['width_mm'];sc['no_extra_printed_parts']=True
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(H/'wire_exits_UNADOPTED.blend'),compress=True)
print('STATIC_VIEWS_AND_LOCAL_BLEND',len(objects),flush=True)
# Section polygons are computed from the exact compared triangulated solids.
def rings(m):
    return [np.asarray(q).tolist() for q in m.rotate([90,0,0]).slice(26.05).to_polygons()]
sections=dict(plane_world_y_mm=26.05,coordinates='X and minus Z',before=rings(old),candidate=rings(new))
(H/'front_wall_sections.json').write_text(json.dumps(sections,indent=2)+'\n')
