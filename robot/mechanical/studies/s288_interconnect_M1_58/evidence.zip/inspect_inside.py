"""Read-only cavity sections with motor interior conservatively excluded."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
targets,ss,fit,src=load()
rows=[]
box=manifold.CrossSection.square([91,48.6],True)
for z in [44.800781268104,51,57]:
    blocked=manifold.CrossSection()
    for name,t in targets.items():
        if t['lo'][2]>z or t['hi'][2]<z:continue
        if name.startswith('Vendor_S288_'):
            # Do not mistake enclosed motor/gear voids for usable wire space.
            section=manifold.CrossSection.square((t['hi']-t['lo'])[:2].tolist(),True)
            section=section.translate(((t['lo']+t['hi'])[:2]/2).tolist())
        else:section=t['m'].slice(z)
        blocked=blocked+section
    free=box-blocked
    rows.append(dict(z_mm=z,free_area_mm2=free.area(),free_rings=[np.asarray(q).tolist() for q in free.to_polygons()]))
(H/'inside_sections.json').write_text(json.dumps(dict(rows=rows,box_xy_mm=[91,48.6],
    units='mm',motor_policy='Filled source AABBs for cavity screening; actual port tails reviewed separately',
    main_adoption=False,protected=protected()),indent=2)+'\n')
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="960" viewBox="0 0 1200 960"><rect width="1200" height="960" fill="#f5f7f3"/><g font-family="system-ui,sans-serif" fill="#253337"><text x="28" y="38" font-size="24">电机打印座内部空间：原横梁和底盖均未开槽</text>']
for i,row in enumerate(rows):
    ox,oy,k=595,205+i*290,5
    svg.append(f'<text x="32" y="{oy-108}" font-size="20">Z={row["z_mm"]:.2f} mm，绿色为可用截面</text>')
    svg.append(f'<rect x="{ox-45.5*k}" y="{oy-24.3*k}" width="{91*k}" height="{48.6*k}" fill="#b8c0bd"/>')
    paths=[]
    for ring in row['free_rings']:
        paths.append('M '+' L '.join(f'{ox+k*x:.3f},{oy-k*y:.3f}' for x,y in ring)+' Z')
    svg.append('<path d="'+' '.join(paths)+'" fill="#b4d9c7" fill-rule="evenodd"/>')
    for x,y in [(-4.3,9.155),(4.3,-9.155)]:
        svg.append(f'<circle cx="{ox+k*x}" cy="{oy-k*y}" r="5" fill="#b48122"/>')
svg.append('<text x="28" y="937" font-size="17">不利用舵机壳内封闭空间。黄色是插口基准投影，不代表实际插头。此图仅是当前模型截面。</text></g></svg>')
(H/'inside_sections.svg').write_text(''.join(svg))
print(json.dumps([dict(z_mm=r['z_mm'],free_area_mm2=r['free_area_mm2']) for r in rows]),flush=True)
