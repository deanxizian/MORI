"""Static candidate views from the checked top-beam geometry; no main save."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from context import *
from inside_geometry import full
from route_geometry import tube
targets,ss,fit,src=load();new=targets['Drive_Bridge']['m']
specs=[]
for name,m,color,cat,evidence in [
    ('INTERNAL_CANDIDATE_Bridge',new,(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('INTERNAL_REFERENCE_Cap',targets['Motor_Retainer']['m'],(.38,.44,.46,1),'PRINTABLE','ASSUMED'),
    ('INTERNAL_REFERENCE_Load_Frame',targets['Load_Frame']['m'],(.58,.62,.64,1),'PRINTABLE','ASSUMED'),
    ('INTERNAL_REFERENCE_UPS',targets['UPS_Module']['m'],(.14,.40,.26,1),'PURCHASED_REFERENCE','VENDOR_DOCUMENTED')]:
    mesh=m.to_mesh64();specs.append((name,mesh.vert_properties[:,:3],mesh.tri_verts,np.eye(4),color,cat,evidence))
for side in ['L','R']:
    for row in src['free_shells']:
        specs.append(('INTERNAL_REF_S288_'+side+'_'+str(row['index']),row['vertices_mm'],row['triangles'],
                      np.array(fit['cases'][side+'_inboard']['matrix']),(.25,.30,.33,1),
                      'PURCHASED_REFERENCE','VENDOR_DOCUMENTED'))
for prefix,items,color in [('U04',full(),(.95,.56,.12,1))]:
    for i,c in enumerate(items):
        mesh=tube(c['points'],c['tangents']).to_mesh64()
        specs.append(('INTERNAL_CAPACITY_'+prefix+'_'+str(i),mesh.vert_properties[:,:3],mesh.tri_verts,
                      np.eye(4),color,'PLACEHOLDER','ASSUMED'))
bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene;objs={}
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
for name,v,f,mat,color,category,evidence in specs:
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(np.asarray(v).tolist(),[],np.asarray(f).tolist());mesh.update()
    o=bpy.data.objects.new(name,mesh);sc.collection.objects.link(o);o.matrix_world=Matrix(mat);o.color=color
    o['mori_owner']='s288_internal_interconnect_study';o['category']=category;o['data_status']=evidence;o['unadopted']=True
    if 'S288' in name:o['source_sha256']=src['source_sha256']
    if name.startswith('INTERNAL_CAPACITY_'):o['real_connector_and_wire']='NOT_TESTED'
    objs[name]=o
sc['status']='Independent internal U04 capacity; original prints unchanged; main not adopted; actual plugs and wire restraints unresolved'
sc.render.engine='BLENDER_WORKBENCH';sh=sc.display.shading;sh.light='STUDIO';sh.color_type='OBJECT'
sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True
sh.background_type='WORLD'
if sc.world is None:sc.world=bpy.data.worlds.new('InternalU04ReviewWorld')
sc.world.color=(.07,.09,.10)
sc.render.resolution_x=1300;sc.render.resolution_y=900;sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG'
def render(name,eye,target,scale):
    cam=bpy.data.objects.new('InternalU04Camera',bpy.data.cameras.new('InternalU04Camera'));sc.collection.objects.link(cam)
    cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO';cam.data.ortho_scale=scale;sc.camera=cam
    sc.render.filepath=str(H/(name+'.png'));bpy.ops.render.render(write_still=True)
objs['INTERNAL_REFERENCE_UPS'].hide_render=True;objs['INTERNAL_REFERENCE_Load_Frame'].hide_render=True
render('inside_closed',(100,135,120),(0,0,55),115)
# Bridge visibility is presentation-only. All checks use the complete solid.
objs['INTERNAL_CANDIDATE_Bridge'].hide_render=True
render('inside_open',(60,85,165),(0,0,52),108)
render('inside_plan',(0,2,220),(0,0,53),104)
objs['INTERNAL_CANDIDATE_Bridge'].hide_render=False
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':
        area.spaces.active.region_3d.view_distance=130
        area.spaces.active.region_3d.view_location=Vector((0,0,55))
        area.spaces.active.shading.color_type='OBJECT'
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(H/'inside_U04_UNADOPTED.blend'),compress=True)
print('INTERNAL_U04_LOCAL_MODEL_ONLY',len(objs),flush=True)
