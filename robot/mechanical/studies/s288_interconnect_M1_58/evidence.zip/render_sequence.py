from pathlib import Path
import bpy,sys,json,hashlib
from mathutils import Vector
H=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(H/'wire_exits_UNADOPTED.blend'))
sc=bpy.context.scene;bridge=bpy.data.objects['CANDIDATE_Drive_Bridge']
assert bridge.get('mori_owner')=='s288_interconnect_study'
bridge.location.z=22;bridge['presentation_only_z_translation_mm']=22
cam=bpy.data.objects.new('SequenceReviewCamera',bpy.data.cameras.new('SequenceReviewCamera'));sc.collection.objects.link(cam)
cam.location=(90,110,125);cam.rotation_euler=(Vector((0,0,60))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=119;sc.camera=cam
sc.render.filepath=str(H/'sequence_from_above.png');bpy.ops.render.render(write_still=True)
bridge.location.z=0
print('STATIC_SEQUENCE_PRESENTATION_ONLY; local model and main not saved',flush=True)
