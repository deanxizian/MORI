from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from inside_geometry import full,tube
from inside_incoming_geometry import stubs
targets,ss,fit,src=load();rows=[]
for protrusion in [0,.5,1]:
    refs=[tube(c['points'],c['tangents']) for c in full(protrusion)]
    for i,c in enumerate(stubs(protrusion)):
        m=tube(c['points'],c['tangents']);hits=collisions(m,targets)
        peers=[]
        for j,other in enumerate(refs):
            overlap=m^other
            if overlap.volume()>1e-5:
                peers.append(dict(U04_wire=j,overlap_mm3=overlap.volume(),bounds=list(overlap.bounding_box())))
        rows.append(dict(protrusion_trial_mm=protrusion,wire=i,U04_hits=peers,native_hits=hits,
                         status='FAIL' if peers or any(h['part']!='Drive_Bridge' for h in hits) else 'PASS'))
out=dict(status='FAIL' if any(r['status']=='FAIL' for r in rows) else 'PASS',rows=rows,
         scope='Coexistence with provisional left-upper controller exit stub; unchanged closed roof remains an expected obstacle',
         full_U03='BLOCKED',main_adoption=False,manufacturing_release=False,protected=protected(),
         sources={str(q.relative_to(PROJECT)):sha(q) for q in [Path(__file__),H/'inside_geometry.py',
             H/'inside_incoming_geometry.py',H/'context.py',H/'route_geometry.py',ROOT/'mori_v1_2.blend']})
(H/'inside_compatibility.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2)[:6000],flush=True)
