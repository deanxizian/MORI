"""Publish the independent alternative suggested by the user; no adoption."""
from pathlib import Path
import json
H=Path(__file__).resolve().parent
r=json.loads((H/'top_beam_check.json').read_text())
s=json.loads((H/'top_beam_sequence.json').read_text())
assert r['status']==s['status']=='PASS'
removed=r['removed_mm3']
old=json.loads((H/'candidate_check.json').read_text())['structure']['removed_volume_mm3']
reduction=(1-removed/old)*100

(H/'top_beam_review.html').write_text(f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>上梁出线候选</title><style>*{{box-sizing:border-box}}body{{margin:0;background:#f4f6f3;color:#253337;font:17px/1.75 system-ui,sans-serif}}main{{max-width:1100px;margin:auto;padding:26px 30px 65px}}h1{{font-size:34px;line-height:1.3}}h2{{font-size:25px;margin-top:36px}}a{{color:#126b7a}}nav{{display:flex;gap:20px;flex-wrap:wrap}}.note{{padding:12px 20px;border-left:4px solid #ab7c28;background:#f1e7d1}}figure{{margin:22px 0}}img{{width:100%;height:auto;display:block}}figcaption,small{{color:#536569}}figcaption{{padding-top:8px}}table{{width:100%;border-collapse:collapse}}td,th{{text-align:left;vertical-align:top;padding:12px 9px;border-bottom:1px solid #cdd5d4}}td:first-child{{width:25%}}@media(max-width:700px){{main{{padding:20px 16px}}h1{{font-size:28px}}}}</style></head><body><main>
<nav><a href="../../index.html#s288-vendor">主模型</a><a href="index.html">原端壁候选对照</a><a href="TOP_BEAM_REVIEW.md">详细检查记录</a></nav>
<h1>上梁出线候选</h1><p>用户建议：横跨两台电机的顶部横梁 · M1.58 独立候选 · 尚未应用</p>
<p class="note"><strong>上梁候选的名义路径检查通过。原端壁方案沿用下方插口及下绕路线；现在已补查上梁方向。</strong><br>改用上方插口作串接候选，在顶梁前后边缘各开一处 8 mm 宽、约 9.9 mm 长的浅槽；下方端壁保持连续。不增加零件或螺钉。</p>
<figure><a href="top_beam_installed.png"><img src="top_beam_installed.png" alt="顶部横梁两处边缘开放槽与上方余线，黄色U04串接线，蓝色U03短段"></a><figcaption>黄色：上口到上口、三根各 190 mm 名义串接线。蓝色：左下口通向控制器的短段容量示意，仅延至前方 35.5 mm，未连接新载板。原配插头尚未精细建模。</figcaption></figure>
<h2>上梁空间与开口</h2><p>补查后，上梁与 UPS 之间可以容纳这组名义余线。开口连到横梁现有边缘，允许从侧面放入导线；这套候选保留下方端壁。</p>
<figure><a href="top_beam_below_UPS.png"><img src="top_beam_below_UPS.png" alt="顶部横梁与原厂UPS参考之间的名义导线空间"></a><figcaption>当前承重板与原厂 UPS 参考保持原位置、原尺寸。对所选网格，U04 到 UPS 及承重板的间隙达到 3 mm 检索上限，即至少 3 mm；不是精确测得 3 mm。</figcaption></figure>
<p>候选只改变 Drive_Bridge：切削从 Z63.4 至 66.6 mm，作用于原 3 mm 顶板与端壁上沿。原下方端壁、轴承座、所有固定轴线及底盖保留；一件连续实体。移除约 {removed:.0f} mm³，比原端壁候选约 {old:.0f} mm³ 少约 {reduction:.0f}%。<strong>切除量更少不等于承载强度已经证明。</strong></p>
<figure><a href="top_beam_front.png"><img src="top_beam_front.png" alt="前方看上梁出线及保留连续下部端壁"></a><figcaption>从前方看：导线向上走，下部端壁保持完整。两处浅槽沿横梁前后边缘开放。</figcaption></figure>
<h2>已完成的名义检查</h2><table><thead><tr><th>项目</th><th>结果与范围</th></tr></thead><tbody>
<tr><td>完整串接路线</td><td>18 个有限组合通过：0 / 0.5 / 1 mm 外伸试值 × 6 种几何线位配对。三根线各 190 mm，线径采用用户约 1 mm；不是实际针号重排。所选 1 mm 外伸试值增粗到半径 0.6 / 0.7 mm 也未相交。</td></tr>
<tr><td>控制器侧出口</td><td>左下口 9 个名义短段通过，未与 U04 相交；真实新载板端点及完整 U03 仍 BLOCKED。没有因本研究发送硬件指令。</td></tr>
<tr><td>名义装入方式</td><td>先在台面布好电机、底盖和线，上梁从上方落下约 20 mm，同时把余线放低、展开。41 个位置中 U04 各保持 190 mm，没有硬质新增相交。保留原两块软垫接触与四处低于既有 0.01 mm³ 阈值的源轴承交叠。</td></tr>
<tr><td>螺钉与身体壳</td><td>四枚底盖螺钉各 69 个位置、前后身体壳各 275 个位置，未与 U04 及所示 U03 短段相交；其他线束未加入。</td></tr>
<tr><td>仍待完成</td><td>实际插头/端子与弯折、手持落梁操作、余线固定、完整控制器线路、全部线束并存及 PA12 打印强度。名义路径不代表全线束或实物装配放行。</td></tr>
</tbody></table><p>局部 <a href="top_beam_UNADOPTED.blend">top_beam_UNADOPTED.blend</a> 是审阅候选。主模型、20 STL、电子细模和视频等 26 个保护文件保持原散列；未提交 PR，未制造、裁线或上电放行。</p>
<details><summary>原始检查与边界</summary><p><a href="top_beam_check.json">上梁实体与路径检查</a> · <a href="top_beam_sequence.json">名义装入检查</a> · <a href="top_beam_closed_holes_check.json">最初闭孔比较</a> · <a href="candidate_check.json">原端壁候选及上口增粗失败</a> · <a href="commands.json">实际命令与日志</a></p><p>上口零外伸、增粗半径 0.7 mm 的旧局部失败仍保留。新候选的 18 组是 OD1 名义检查；增粗两组仅对所选 1 mm 外伸值检查，未声称所有增粗组合通过。真实插头外伸仍未知，不能当作 0 mm。机械试值不能成为最终供应商线束尺寸。</p></details><p><small>PROTOTYPE / UNVALIDATED · 当前仍是候选，请先确认方向和模型。</small></p></main></body></html>''')

(H/'TOP_BEAM_REVIEW.md').write_text(f'''# 上梁出线候选

2026-10-13，用户明确“上臂”指横跨两台电机的顶部横梁。本页是独立比较，未应用主模型或 STL。

先前方案沿用下方插口/下绕，仅对该路线提出端壁槽，没有充分比较上梁。check_top_beam.py 补查上口到上口路线：三根名义各190mm，OD用户约1mm；0/0.5/1外伸试值×6几何线位配对共18组通过。所选P1增粗半径0.6/0.7两组通过，并非全部增粗外伸组合通过。此前上口P0增粗0.7碰自身舵机的失败保留在candidate_check.json。

## 局部切削

两处8×9.9mm试验槽，中心(X,Y)为(+2.7,+22.45)/(-2.7,-22.45)，Z63.4..66.6；R1边角。槽沿现有横梁前后边缘开放，避免把真实插头通过未知小闭孔作为装配前提。只改Drive_Bridge，原下部端壁/轴承座/固定轴线/底盖不变。移除{removed:.9f}mm³，增加0、区域外删除0，改前改后均1件连续实体。移除量比原端壁方案{old:.9f}mm³少{reduction:.2f}%，不能据此推断强度。

初始8×5闭孔名义结果保留为check_top_beam_closed_holes.py/top_beam_closed_holes_check.json；它未验证实际插头穿孔。最终边缘开放槽的结果是top_beam_check.json，当前脚本来源散列记录在其中。

## 路径与装入

尾弯仍采用试验中心半径5mm（各线3/5/7），1mm压接直尾、2mm弯后短尾均ASSUMED。上升与转向半径3mm、上方蛇形圆弧3.5mm；U04三个平面Z69.2/70.6/72。有限24面多边形管、约0.2mm圆弧采样，没有连续间隙或线材疲劳证明。所选U04对UPS/Load_Frame min_gap检索封顶3mm，返回3表示>=3，不是精确3。

左下口U03短段延至Y35.5；9个OD1名义样本与本体/U04均无相交。它不是完整到载板的线，实际端点、针序与厂家接头仍需完整核对。本研究不修改硬件设计或发送硬件对话指令。

check_top_beam_sequence.py：电机/底盖先保持安装位，顶梁从上方下移20mm，线圈同时下移/展开。41位置中各U04的解析长度均190mm；原厂电机、原螺钉、轴承/金属件真实尺寸保持。原2软垫接触及4极小轴承交叠低于既有项目阈值仍单列，非实物资格。4枚底盖螺钉各69位置、前后壳各275位置对U04及短U03未相交。人工持线/台面临时支撑/真实插头/完整190mm U03未验证，完整柔性装配BLOCKED。20mm起始位置是有限几何检查起点，不代表整套台面摆放已经验证。

余线固定、真实弯折和源模型与实物一致性、全部线束并存、PA12强度均未完成。main_adoption=false，manufacturing_release=false。不更新视频。

## 复现

实际命令和失败保留在commands.json及日志。Blender5.2.2 LTS、Python3.13.13、numpy2.3.4、manifold3d3.5.3。

```sh
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py top_beam_open_edge check_top_beam.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py top_beam_wired_sequence check_top_beam_sequence.py --main
python3 mechanical/studies/s288_interconnect_M1_58/run_stage.py top_beam_static_views render_top_beam.py --main
python3 mechanical/studies/s288_interconnect_M1_58/publish_top_beam.py
```

top_beam_UNADOPTED.blend只含局部打印件、原厂电机/UPS、承重板及名义线段，不是最新完整总装。用于显示的原厂S288外形也尚未替换主模型的旧简化模型。
''')
print('Published independent top-beam alternative, no main adoption')
