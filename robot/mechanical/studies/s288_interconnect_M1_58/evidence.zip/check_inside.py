"""Current native rigid solids, filled motor core keepouts, unchanged prints."""
from pathlib import Path
import sys,itertools
sys.path.insert(0,str(Path(__file__).resolve().parent))
from context import *
from inside_geometry import full,tube
targets,ss,fit,src=load()
boxes={}
for name in ['Vendor_S288_L','Vendor_S288_R']:
    t=targets[name]
    m=manifold.Manifold.cube((t['hi']-t['lo']).tolist(),True).translate(((t['hi']+t['lo'])/2).tolist())
    boxes[name+'_filled']=dict(m=m,lo=t['lo'],hi=t['hi'])
rows=[]
for protrusion in [0,.5,1]:
    for permutation in itertools.permutations(range(3)):
        cs=full(protrusion,permutation);ms=[tube(c['points'],c['tangents']) for c in cs]
        hits=[];keepout=[]
        for i,(c,m) in enumerate(zip(cs,ms)):
            hits.extend(dict(wire=i,**hit) for hit in collisions(m,targets))
            cm=tube(c['core'],c['core_tangents'])
            keepout.extend(dict(wire=i,**hit) for hit in collisions(cm,boxes))
        peers=[dict(wires=[i,j],overlap_mm3=(ms[i]^ms[j]).volume())
               for i in range(3) for j in range(i+1,3) if (ms[i]^ms[j]).volume()>1e-5]
        rows.append(dict(protrusion_trial_mm=protrusion,geometric_lane_pairing=list(permutation),
            status='FAIL' if hits or peers or keepout else 'PASS',hits=hits,peer_hits=peers,
            core_filled_motor_keepout_hits=keepout,lengths_mm=[c['length_mm'] for c in cs],
            amplitudes_mm=[c['amplitude_mm'] for c in cs]))
cs=full();ms=[tube(c['points'],c['tangents']) for c in cs];margin=[];gaps=[];arrays={}
for radius in [.6,.7]:
    inflated=[tube(c['points'],c['tangents'],radius) for c in cs]
    hits=[dict(wire=i,**h) for i,m in enumerate(inflated) for h in collisions(m,targets)]
    keepout=[dict(wire=i,**h) for i,c in enumerate(cs)
             for h in collisions(tube(c['core'],c['core_tangents'],radius),boxes)]
    peers=[dict(wires=[i,j],overlap_mm3=(inflated[i]^inflated[j]).volume())
           for i in range(3) for j in range(i+1,3) if (inflated[i]^inflated[j]).volume()>1e-5]
    margin.append(dict(radius_mm=radius,hits=hits,peer_hits=peers,core_keepout_hits=keepout,
                       status='FAIL' if hits or peers or keepout else 'PASS'))
for i,(c,m) in enumerate(zip(cs,ms)):
    arrays['wire_'+str(i)]=c['points'];arrays['tangent_'+str(i)]=c['tangents']
    for name in ['Drive_Bridge','Motor_Retainer','Vendor_S288_L','Vendor_S288_R']:
        gaps.append(dict(wire=i,part=name,gap_mm=m.min_gap(targets[name]['m'],2),search_cap_mm=2))
peer_gaps=[dict(wires=[i,j],gap_mm=ms[i].min_gap(ms[j],2),search_cap_mm=2)
           for i in range(3) for j in range(i+1,3)]
np.savez_compressed(H/'inside_routes.npz',**arrays)
out=dict(status='FAIL' if any(r['status']=='FAIL' for r in rows+margin) else 'PASS',
    cases=rows,enlarged_chosen_cases=margin,chosen_gaps=gaps,chosen_peer_gaps=peer_gaps,
    printed_changes=[],new_parts=0,new_fasteners=0,main_adoption=False,manufacturing_release=False,
    lower_motor_ports_used=[0,0],source_motor_aabb_mid_gap_mm=float(targets['Vendor_S288_R']['lo'][0]-targets['Vendor_S288_L']['hi'][0]),
    core_policy='Filled source AABB excludes motor interiors; actual socket tails checked against source solids separately',
    exact_plugs='BLOCKED',actual_wire_bend='NOT_TESTED',physical_wire_restraints='NOT_TESTED',
    full_U03_and_all_harness='BLOCKED',wired_assembly='NOT_TESTED',
    assumed_parameters=dict(protrusion_trial_mm=[0,.5,1],straight_tail_mm=1,post_bend_tail_mm=.5,
        local_tail_center_radius_mm=5,core_min_radius_mm=3,central_layers_mm=[55.5,56.9,58.3],
        left_upper_coil_layers_mm=[57,58.4,59.8],return_height_drop_mm=1.5,
        return_drop_start_x_mm=[9.8,9.0,8.2],
        geometric_lane_to_pin='NOT_IDENTIFIED; no actual electrical remapping'),
    protected=protected(),sources={str(q.relative_to(PROJECT)):sha(q) for q in
        [Path(__file__),H/'inside_geometry.py',H/'route_geometry.py',H/'context.py',
         ROOT/'mori_v1_2.blend',PROJECT/'config/geometry.json',
         H.parent/'s288_vendor_fit_M1_58/vendor_mesh.json',H.parent/'s288_vendor_fit_M1_58/fit_review.json',
         H.parent/'s288_plug_space_M1_58/review.json',H.parent/'s288_plug_space_M1_58/wire_geometry.py',
         ROOT/'procurement/evidence/2026-10-13_S288_lead_measurement.json']})
(H/'inside_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],passed=sum(r['status']=='PASS' for r in rows),cases=len(rows),
    chosen_case=next(r for r in rows if r['protrusion_trial_mm']==1 and r['geometric_lane_pairing']==[0,1,2]),
    enlarged=margin,chosen_gaps=gaps,peer_gaps=peer_gaps),indent=2),flush=True)
