"""Place unscaled official S288 geometry on existing wheel axes; inspect only.

All four inboard/outboard connector-face combinations are compared. The side
assignment is a candidate, not a change to an approved installation datum.
"""
from pathlib import Path
import sys,json,hashlib,math
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid,intersect_volume

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((HERE/'vendor_mesh.json').read_text())
baseline=json.loads((HERE/'protected_before.json').read_text())
assert sha(ROOT/'mori_v1_2.blend')==baseline['mechanical/mori_v1_2.blend']
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for c in COLS.values():c.hide_viewport=False
assembled();bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
retired={n for n in ss if n.startswith(('Drive_Motor_','S288_Output_'))}
static={n:s for n,s in ss.items() if n not in retired}
meshes={};diag=[];positives=[];voids=[]
for row in source['free_shells']:
 i=row['index'];v=np.asarray(row['vertices_mm']);f=np.asarray(row['triangles'],dtype=np.uint64)
 m=manifold.Manifold(manifold.Mesh64(v,f));ok=m.status()==manifold.Error.NoError
 diag.append(dict(index=i,cad_closed=row['closed'],cad_volume_mm3=row['volume_mm3'],mesh_status=str(m.status()),mesh_volume_mm3=m.volume() if ok else None))
 if not row['closed']:continue
 assert ok,diag[-1]
 assert abs(abs(m.volume())-abs(row['volume_mm3']))<.003*max(1,abs(row['volume_mm3'])),diag[-1]
 if row['volume_mm3']>0:positives.append(m)
 else:
  m=manifold.Manifold(manifold.Mesh64(v,f[:,[0,2,1]]));assert m.volume()>0
  voids.append(m)
 meshes[i]=m
union=manifold.Manifold.batch_boolean(positives,manifold.OpType.Add)
void_report=[]
for row,m in zip([r for r in source['free_shells'] if r['closed'] and r['volume_mm3']<0],voids):
 overlap=(union^m).volume();void_report.append(dict(index=row['index'],volume_mm3=m.volume(),intersection_with_positive_mm3=overlap))
 union=union-m
assert union.status()==manifold.Error.NoError
# Analytical source cylinder axis and the two planar output mating faces.
axis_y=3.591673992714;axis_z=.612980678113
face_neg=-15.379706205442;face_pos=10.820293794558
assert abs(face_pos-face_neg-26.2)<1e-8
def transform(side,face):
 sign=-1 if side=='L' else 1
 xdirection=-sign if face=='inboard' else sign
 ydirection=sign
 zdirection=xdirection*ydirection
 R=np.diag([xdirection,ydirection,zdirection]);assert abs(np.linalg.det(R)-1)<1e-10
 outward_source_x=face_neg if face=='inboard' else face_pos
 t=np.array([sign*27-xdirection*outward_source_x,-ydirection*axis_y,52.5-zdirection*axis_z])
 mat=np.eye(4);mat[:3,:3]=R;mat[:3,3]=t
 return mat
def intersections(m,lo,hi):
 out=[]
 for n,s in static.items():
  if np.any(hi<s.lo) or np.any(lo>s.hi):continue
  v=(m^s.m).volume()
  if v>1e-4:out.append(dict(part=n,overlap_mm3=v))
 return sorted(out,key=lambda x:-x['overlap_mm3'])
poses={};pair_checks=[]
for side in ['L','R']:
 for face in ['inboard','outboard']:
  mat=transform(side,face);m=union.transform(mat[:3,:]);vs=np.asarray(m.to_mesh64().vert_properties[:,:3]);lo=vs.min(0);hi=vs.max(0)
  report=dict(side=side,connector_face=face,matrix=mat.tolist(),bounds_mm=[lo.tolist(),hi.tolist()],rigid_collisions=intersections(m,lo,hi))
  report['soft_pad_contacts']=[r for r in report['rigid_collisions'] if r['part'].startswith(('Motor_Top_Pad_','Motor_Retainer_Pad_'))]
  report['hard_part_collisions']=[r for r in report['rigid_collisions'] if r not in report['soft_pad_contacts']]
  report['hard_part_screen_status']='FAIL' if report['hard_part_collisions'] else 'PASS'
  report['soft_pad_fit_status']='NOT_TESTED'
  old=manifold.Manifold.batch_boolean([ss[n].m for n in retired if '_'+side in n],manifold.OpType.Add)
  report['outside_old_envelope_mm3']=(m-old).volume();report['old_envelope_not_in_vendor_mm3']=(old-m).volume()
  report['port_reference_bounds_mm']=[]
  for i in [0,1]:
   mm=meshes[i].transform(mat[:3,:]);verts=np.asarray(mm.to_mesh64().vert_properties[:,:3])
   report['port_reference_bounds_mm'].append(dict(source_shell=i,bounds_mm=[verts.min(0).tolist(),verts.max(0).tolist()]))
  poses[side+'_'+face]=report
  print(side,face,'BOUNDS',report['bounds_mm'],'OVERLAPS',report['rigid_collisions'],flush=True)
for lf in ['inboard','outboard']:
 for rf in ['inboard','outboard']:
  a=union.transform(transform('L',lf)[:3,:]);b=union.transform(transform('R',rf)[:3,:])
  # The disjoint X bounds give a rigorous lower bound without an expensive
  # unbounded nearest-triangle search between detailed catalogue shells.
  pa=poses['L_'+lf]['bounds_mm'];pb=poses['R_'+rf]['bounds_mm']
  gap=np.maximum(np.maximum(np.array(pa[0])-pb[1],np.array(pb[0])-pa[1]),0)
  pair_checks.append(dict(left=lf,right=rf,motor_pair_overlap_mm3=(a^b).volume(),motor_pair_aabb_gap_lower_bound_mm=float(np.linalg.norm(gap))))
checks=dict(revision=P['revision'],source_model_sha256=sha(ROOT/'mori_v1_2.blend'),source_mesh_sha256=sha(HERE/'vendor_mesh.json'),geometry_config_sha256=sha(PROJECT/'config/geometry.json'),source_step_sha256=source['source_sha256'],source_runtime=dict(blender=bpy.app.version_string,python=sys.version,numpy=np.__version__),source_shape_diagnostics=diag,negative_closed_boundaries=void_report,shape_policy='Six positive closed shells combined; signed closed inner boundaries subtracted without healing. Two open cylindrical surfaces retained for viewing only; full source/manufacturing qualification remains BLOCKED.',source_output_plane_distance_mm=face_pos-face_neg,source_axis_yz_mm=[axis_y,axis_z],source_output_planes_x_mm=[face_neg,face_pos],cases=poses,pairs=pair_checks,geometry_status='BLOCKED',full_harness='BLOCKED',main_adoption='NOT_APPLICABLE',limits=['Four connector-face assignments are compared without changing printed geometry or axes. No assignment is adopted.','Source STEP includes open surfaces and no loose mating plugs or cable: not a complete purchased assembly.','The contact plane, not the maximum housing bound, is aligned to the existing custom flange at world X +/-27.','Source-to-purchased revision identity, mounting teeth/hole clocking, fasteners and crimp details require physical confirmation.','This report does not certify new UPS-R2 carrier geometry or any complete harness.'])
(HERE/'fit_review.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
# Independent review file: retain existing main objects; hide only replaced
# reference motor bodies and the independent shell view. Nothing is saved to main.
col=bpy.data.collections.new('S288_VENDOR_CANDIDATE_ONLY');bpy.context.scene.collection.children.link(col)
for side in ['L','R']:
 mat=Matrix(transform(side,'inboard'))
 for r in source['free_shells']:
  mesh=bpy.data.meshes.new('S288_vendor_mesh');mesh.from_pydata(r['vertices_mm'],[],r['triangles']);mesh.update()
  o=bpy.data.objects.new('REVIEW_S288_'+side+'_'+str(r['index']),mesh);col.objects.link(o);o.matrix_world=mat
  o['source_shell']=r['index'];o['category']='PURCHASED_REFERENCE';o['data_status']='VENDOR_DOCUMENTED';o['physical_fit']='NOT_TESTED';o['source_sha256']=source['source_sha256'];o['candidate_only']=True
  o.color=(.95,.43,.06,1) if r['index'] in [0,1] else (.15,.19,.22,1)
for n,s in ss.items():
 if n in retired or n in ['Body_Front','Body_Rear'] or s.lo[2]>76:
  s.o.hide_render=True;s.o.hide_set(True)
bpy.context.scene['review_only']='S288 vendor reference fit; M1.58 main geometry unchanged; NOT ADOPTED'
bpy.context.scene.render.engine='BLENDER_WORKBENCH'
sh=bpy.context.scene.display.shading;sh.light='STUDIO';sh.studiolight_rotate_z=.6;sh.color_type='OBJECT';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True
bpy.context.scene.render.resolution_x=1300;bpy.context.scene.render.resolution_y=900;bpy.context.scene.render.resolution_percentage=100
bpy.context.scene.render.image_settings.file_format='PNG'
def render(name,eye,target,scale):
 cam=bpy.data.objects.new('S288_review_camera',bpy.data.cameras.new('S288_review_camera'));bpy.context.scene.collection.objects.link(cam)
 cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;bpy.context.scene.camera=cam
 bpy.context.scene.render.filepath=str(HERE/(name+'.png'));bpy.ops.render.render(write_still=True);bpy.data.objects.remove(cam,do_unlink=True)
render('current_frame_vendor',(.8*170,170,185),(0,0,53),132)
for n in ['Drive_Bridge','Load_Frame','Motor_Retainer']:
 ss[n].o.hide_render=True;ss[n].o.hide_set(True)
render('vendor_ports',(-90,145,115),(0,0,53),88)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'S288_vendor_fit_UNADOPTED.blend'),compress=True)
changed={p:{'before':h,'after':sha(PROJECT/p)} for p,h in baseline.items() if sha(PROJECT/p)!=h}
owner=json.loads((HERE/'hardware_owner_update.json').read_text())['changes']
assert set(changed)==set(owner),(changed,owner)
for p,v in changed.items():
 assert v['before']==owner[p]['before_sha256'] and v['after']==owner[p]['received_sha256'],p
(HERE/'protected_after.json').write_text(json.dumps(dict(status='PASS',checked_files=len(baseline),unchanged_files=len(baseline)-len(changed),owner_received_changes=changed,unexpected_changes={}),indent=2)+'\n')
print('PAIRS',pair_checks,'PROTECTED',len(baseline),flush=True)
