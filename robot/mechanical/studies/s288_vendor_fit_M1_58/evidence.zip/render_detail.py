from pathlib import Path
import bpy,json,sys
from mathutils import Vector
H=Path(__file__).resolve().parent
s=bpy.context.scene
for o in s.objects:
 o.hide_render=not o.name.startswith('REVIEW_S288_L_')
s.render.engine='BLENDER_WORKBENCH';s.display.shading.color_type='OBJECT'
s.render.resolution_x=1100;s.render.resolution_y=800;s.render.resolution_percentage=100
cam=bpy.data.objects.new('detail_camera',bpy.data.cameras.new('detail_camera'));s.collection.objects.link(cam);s.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=46
def render(n,eye,target):
 cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
 s.render.filepath=str(H/(n+'.png'));bpy.ops.render.render(write_still=True)
render('single_motor_inner',(100,-38,90),(-11,7.5,52.5))
render('socket_face_orthogonal',(100,7.5,52.5),(-11,7.5,52.5))
for o in s.objects:
 o.hide_render=not o.name.startswith('REVIEW_S288_')
cam.data.ortho_scale=86
render('both_inner_ports',(0,120,132),(0,0,52.5))
