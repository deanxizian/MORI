"""Abstract socket approach capacity and unplugged cartridge removal.

The 6.6 x 3.2 mm probe is NOT a selected plug, wire or purchase specification.
"""
from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;PROJECT=H.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fit=json.loads((H/'fit_review.json').read_text());src=json.loads((H/'vendor_mesh.json').read_text())
assert sha(ROOT/'mori_v1_2.blend')==fit['source_model_sha256']
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for c in COLS.values():c.hide_viewport=False
assembled();bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
retired={n for n in ss if n.startswith(('Drive_Motor_','S288_Output_'))}
pos=[];neg=[]
for r in src['free_shells']:
 if not r['closed']:continue
 v=np.array(r['vertices_mm']);f=np.array(r['triangles'],dtype=np.uint64)
 if r['volume_mm3']<0:f=f[:,[0,2,1]]
 m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError
 (pos if r['volume_mm3']>0 else neg).append(m)
body=manifold.Manifold.batch_boolean(pos,manifold.OpType.Add)
for m in neg:body=body-m
motors={side:body.transform(np.array(fit['cases'][side+'_inboard']['matrix'])[:3,:]) for side in ['L','R']}
targets={n:dict(m=s.m,lo=s.lo,hi=s.hi) for n,s in ss.items() if n not in retired}
for side,m in motors.items():
 v=np.array(m.to_mesh64().vert_properties[:,:3]);targets['Vendor_S288_'+side]=dict(m=m,lo=v.min(0),hi=v.max(0))
def hits(m,skip=()):
 v=np.array(m.to_mesh64().vert_properties[:,:3]);lo=v.min(0);hi=v.max(0);out=[]
 for n,t in targets.items():
  if n in skip or np.any(hi<t['lo']) or np.any(lo>t['hi']):continue
  vol=(m^t['m']).volume()
  if vol>1e-5:out.append(dict(part=n,overlap_mm3=vol))
 return sorted(out,key=lambda x:-x['overlap_mm3'])
approaches=[]
for side in ['L','R']:
 mat=np.array(fit['cases'][side+'_inboard']['matrix']);direction=mat[:3,:3]@np.array([1.,0,0])
 for r in src['free_shells'][:2]:
  bb=np.array(r['bounds_mm']);c=(bb[:3]+bb[3:])/2;c[0]=bb[3]+.05
  origin=mat[:3,:3]@c+mat[:3,3]
  def probe(length):
   m=manifold.Manifold.cube([length,6.6,3.2],True)
   local=c+np.array([length/2,0,0]);return m.translate(local).transform(mat[:3,:])
  lower=.001;upper=24.;begin=hits(probe(lower));blocked=hits(probe(upper))
  if begin:lower=0.;upper=.001;reason=begin
  elif not blocked:lower=upper;reason=[]
  else:
   reason=blocked
   for _ in range(12):
    mid=(lower+upper)/2;bad=hits(probe(mid))
    if bad:upper=mid;reason=bad
    else:lower=mid
  approaches.append(dict(side=side,source_socket=r['index'],position='lower' if origin[2]<52.5 else 'upper',mouth_offset_mm=.05,origin_mm=origin.tolist(),outward_direction=direction.tolist(),probe_cross_section_mm=[6.6,3.2],nominal_clear_length_lower_mm=lower,blocked_length_upper_mm=upper,limiting=reason,status='FAIL' if begin else 'PASS',scope='Abstract rectangular axial capacity only; ignores source open surfaces, no actual plug or bend qualification.'))
  print('APPROACH',side,r['index'],lower,upper,reason,flush=True)
# Confirm only the mechanical route of unplugged cartridges; all real leads must
# be disconnected. Front AND rear body shells are removed in current M1.58.
common_removed={n for n in ss if n in ['Body_Front','Body_Rear','Motor_Retainer'] or n.startswith(('Tire_','Wheel_Hub_','Wheel_End_','Wheel_Cap_Clamp_Screw_','Motor_Retainer_Pad_')) or n in ['Wheel_Spacer_L_1','Wheel_Spacer_R_1']}
services=[]
for side in ['L','R']:
 moving={n for n in ss if n=='Wheel_Axle_'+side or n=='Wheel_Spacer_'+side+'_0' or n.startswith(('Wheel_Bearing_'+side+'_','Wheel_Output_Screw_'+side+'_'))}
 moving.add('Vendor_S288_'+side)
 geometry=[targets[n]['m'] for n in moving]
 errors=[];contact=[];below_existing_threshold=[]
 for dz in range(61):
  for n,m in zip(sorted(moving),[targets[n]['m'] for n in sorted(moving)]):
   bad=hits(m.translate([0,0,-dz]),common_removed|moving)
   for row in bad:
    entry=dict(distance_mm=dz,moving=n,**row)
    if row['part']=='Motor_Top_Pad_'+side and dz==0:contact.append(entry)
    elif row['overlap_mm3']<=P['validation']['collision_volume_tolerance_mm3']:below_existing_threshold.append(entry)
    else:errors.append(entry)
 services.append(dict(side=side,moving=sorted(moving),removed_first=sorted(common_removed),direction=[0,0,-1],travel_mm=60,step_mm=1,samples=61,failures=errors,initial_soft_pad_contacts=contact,below_existing_volume_threshold=below_existing_threshold,existing_project_volume_threshold_mm3=P['validation']['collision_volume_tolerance_mm3'],rigid_sample_status='FAIL' if errors else 'PASS',complete_installation_status='BLOCKED',limits='Unplugged finite rigid samples only; initial soft-pad compression remains NOT_TESTED. Cable, human grip and source open surfaces not qualified.'))
 print('SERVICE',side,'FAILURES',len(errors),'PAD_CONTACTS',len(contact),flush=True)
# Exact sections through the two socket center planes, clipped only for SVG.
sections=[]
for side in ['L','R']:
 y=(fit['cases'][side+'_inboard']['port_reference_bounds_mm'][0]['bounds_mm'][0][1]+fit['cases'][side+'_inboard']['port_reference_bounds_mm'][0]['bounds_mm'][1][1])/2
 selected={n:t for n,t in targets.items() if n in ['Drive_Bridge','Motor_Retainer','Load_Frame','Vendor_S288_L','Vendor_S288_R'] or n.startswith(('Motor_Top_Pad_','Motor_Retainer_Pad_'))}
 paths=[]
 for n,t in selected.items():
  polys=t['m'].rotate([90,0,0]).slice(y).to_polygons()
  rings=[]
  for poly in polys:
   if len(poly)<3:continue
   d='M '+' L '.join(f'{float(x):.5f},{float(z):.5f}' for x,z in poly)+' Z'
   rings.append(d)
  color='#263b42' if n.startswith('Vendor') else '#b5584b' if '_Pad_' in n else '#c8cdd0'
  paths.append(f'<path d="{" ".join(rings)}" fill="{color}" fill-rule="evenodd" stroke="#172c34" stroke-width=".04"><title>{n}</title></path>')
 svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="-36 -71 72 38"><rect x="-36" y="-71" width="72" height="38" fill="#f5f5f2"/>'+''.join(paths)+'</svg>'
 name='section_'+side+'.svg';(H/name).write_text(svg);sections.append(dict(side=side,y_mm=y,file=name))
result=dict(revision=P['revision'],main_sha256=fit['source_model_sha256'],fit_review_sha256=sha(H/'fit_review.json'),vendor_mesh_sha256=sha(H/'vendor_mesh.json'),scope='READ_ONLY_UNADOPTED_CAPACITY_AND_UNPLUGGED_SAMPLES',approaches=approaches,services=services,sections=sections,complete_harness_status='BLOCKED',source_open_surface_qualification='NOT_TESTED',adoption_status='NOT_APPLICABLE')
(H/'access_review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert sha(ROOT/'mori_v1_2.blend')==fit['source_model_sha256']
