"""Reproduce the independent S288 study; does not rebuild or save main."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
H=Path(__file__).resolve().parent;PROJECT=H.parents[2]
B='/Applications/Blender.app/Contents/MacOS/Blender'
stages=[('extract',['/Users/dean/.cache/codex-runtimes/mori-cad/bin/python',str(H/'extract.py')]),
 ('inspect_fit',[B,'-b','mechanical/mori_v1_2.blend','-t','4','--python-exit-code','1','--python',str(H/'inspect_fit.py')]),
 ('check_access',[B,'-b','mechanical/mori_v1_2.blend','-t','4','--python-exit-code','1','--python',str(H/'check_access.py')]),
 ('render_detail',[B,'-b',str(H/'S288_vendor_fit_UNADOPTED.blend'),'-t','4','--python-exit-code','1','--python',str(H/'render_detail.py')])]
records=[]
for n,cmd in stages:
 start=datetime.datetime.now().astimezone().isoformat();log=H/(n+'.log')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=PROJECT,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(stage=n,command=cmd,cwd=str(PROJECT),started=start,finished=datetime.datetime.now().astimezone().isoformat(),returncode=r.returncode,log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (H/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(n,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
