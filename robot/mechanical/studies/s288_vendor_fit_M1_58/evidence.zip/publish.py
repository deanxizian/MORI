from pathlib import Path
import json,hashlib,html,datetime
H=Path(__file__).resolve().parent;P=H.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fit=json.loads((H/'fit_review.json').read_text());a=json.loads((H/'access_review.json').read_text());receipt=json.loads((H/'receipt.json').read_text())
assert sha(P/'mechanical/mori_v1_2.blend')==fit['source_model_sha256']
assert a['fit_review_sha256']==sha(H/'fit_review.json')
assert all(x['hard_part_screen_status']=='PASS' for k,x in fit['cases'].items() if k.endswith('_inboard'))
assert all(x['rigid_sample_status']=='PASS' for x in a['services'])
assert all(x['nominal_clear_length_lower_mm']>8.29 for x in a['approaches'])
rows=''.join(f'<tr><td>{r["side"]} / {"上" if r["position"]=="upper" else "下"}</td><td>{r["nominal_clear_length_lower_mm"]:.3f}～{r["blocked_length_upper_mm"]:.3f} mm</td><td>对侧电机</td></tr>' for r in a['approaches'])
page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>S288 原厂 CAD 复核 · M1.58</title>
<style>body{{max-width:1120px;margin:40px auto;padding:0 24px;color:#202b30;background:#f7f7f4;font:16px/1.65 system-ui}}h1{{font-size:32px;margin-bottom:4px}}h2{{font-size:24px;margin-top:44px}}p{{max-width:960px}}a{{color:#1c607b}}.status{{border-left:4px solid #a47735;padding:12px 20px;background:#f0e9dd}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}figure{{margin:0}}img{{width:100%;border-radius:5px;background:#d8d8d8}}figcaption{{font-size:14px;color:#536068}}table{{border-collapse:collapse;width:100%;background:white}}th,td{{padding:10px 14px;border-bottom:1px solid #d8dfdf;text-align:left}}code{{overflow-wrap:anywhere}}small{{color:#536068}}@media(max-width:760px){{.grid{{grid-template-columns:1fr}}h1{{font-size:26px}}}}</style>
<nav><a href="../../index.html?revision=V1.2-M1.58#controls_rear">回到当前主模型</a> · <a href="README.md">复核说明</a> · <a href="S288_vendor_fit_UNADOPTED.blend">独立 Blender 检查文件</a></nav>
<h1>S288 原厂 CAD 与当前电机座</h1><p>2026-10-13 · 对照 M1.58 · 只读检查，尚未替换主模型</p>
<p class="status"><strong>插口朝内值得继续；不能把它当作完整线束已放下。</strong><br>原厂详细外形未与现有硬质支架相交，四处软垫有约 0.073 mm 局部压入，需试配。四个插口前的轴向空间约 8.3 mm，仍要核对真实插头和导线弯折。</p>
<div class="grid"><figure><img src="single_motor_inner.png"><figcaption>原厂 S288 STEP；橙色仅用于标出两个插口。没有缩放、改壳或填补原厂开放曲面。</figcaption></figure><figure><img src="both_inner_ports.png"><figcaption>两台插口朝内的候选，沿用输出轴线及外侧法兰位置。为看清内部，隐藏了框架、车轮和上层模块；没有采用到主模型。</figcaption></figure></div>
<h2>朝内与朝外分别检查</h2><table><thead><tr><th>插口方向</th><th>硬质结构</th><th>其余限制</th></tr></thead><tbody><tr><td>左右均朝内</td><td>闭合参考实体与现有硬件/打印件未检出相交</td><td>软垫接触不计为硬质结构通过；每处约 4.056 mm³ 重叠，实际压缩仍 NOT_TESTED</td></tr><tr><td>任一台朝外</td><td>该侧与 Drive_Bridge 约 587.5 mm³ 相交，另有螺母/输出螺钉冲突</td><td>当前轴线、孔位和支架不变时，舍弃此方向</td></tr></tbody></table>
<p>原厂 CAD 两输出端安装平面相距 26.2 mm，旧图纸名义总长为 26 mm。保持外侧法兰在 X=±27 mm，原厂 CAD 的内侧端面相距至少 1.6 mm（包围盒给出的距离下界）。该数值不包含变形、公差与实物批次差异。</p>
<h2>插口前的空间</h2><p>使用 <strong>6.6 × 3.2 mm 的抽象矩形探针</strong>，从原厂插座最外面再向外偏移 0.05 mm 开始，沿插入/拔出轴连续形成实体。这个截面是容量样本，<strong>不是选定插头的外形，也没有预留最终装配间隙</strong>。二分检查得到下表：</p>
<table><thead><tr><th>插口</th><th>无相交长度与首次相交上界</th><th>限制件</th></tr></thead><tbody>{rows}</tbody></table>
<p>这只约束塑壳直出空间；尚未检查真实压接端子、拔插手指、三根导线的弯折、固定点及 U03/U04 同时存在。没有生成下料长度或供应商裁线图。</p>
<div class="grid"><figure><img src="socket_face_orthogonal.png"><figcaption>单台插接面正视图；上下插口只是几何位置，未擅自指定硬件 U03/U04 的 A/B 用途。</figcaption></figure><figure><img src="section_L.svg"><figcaption>Y={a['sections'][0]['y_mm']:.3f} mm 的真实闭合网格剖面：深色为电机参考，灰色为现有框架，砖红为软垫；不含未知线束。</figcaption></figure></div>
<h2>无导线取出检查</h2><p>前后身体壳、车轮/外隔套、共用底盖及其螺钉先卸下，并断开真实电机线；电机连同金属轴、两只轴承、内隔套和原输出螺钉向下取出。每侧 0～60 mm、每 1 mm 检查一次，共 122 个位置，未出现超过项目原有 0.01 mm³ 阈值的刚性相交。</p><p>原位轴承与座各有约 0.000022 mm³ 的数值接触，原样保留在报告中。初始顶部软垫接触另列 NOT_TESTED；这不是带线装配、人手操作或连续全过程证明。</p>
<h2>来源与交接边界</h2><p>来源是样品项目 2026-10-09 归档的<a href="{receipt['source_url']}">宇树官方模型包</a>，STEP 与压缩包中 S288 成员逐字节一致。单位 mm，缩放 1。原文件包含 14 个曲面壳：6 个正向闭壳、6 个内边界闭壳、2 个开放圆柱面；展示全部原表面，干涉计算使用闭合部分并扣除内边界，未静默补洞。</p>
<p><a href="sources/S288_official.STEP">原厂 STEP</a> · <a href="source_inspection.json">CAD 检查</a> · <a href="fit_review.json">姿态/干涉结果</a> · <a href="access_review.json">空间/拆出结果</a> · <a href="commands.json">实际运行命令</a> · <a href="protected_after.json">文件保护结果</a></p>
<p>主模型、20 个已导出 STL、参数与视频保持；硬件对话期间更新的 12 个文件通过独立接收记录追踪，未重写旧基线。当前 UPS-R2 新载板仍未有原生 PCB 布局；本检查不宣布新载板或全线束合格。</p>
<small>原 STEP SHA256：<code>{fit['source_step_sha256']}</code><br>主模型 SHA256：<code>{fit['source_model_sha256']}</code></small></html>'''
(H/'index.html').write_text(page)
(H/'README.md').write_text('''# S288 原厂 CAD 与 M1.58 电机座复核

独立、未采用的检查。主模型仍 M1.58，上充电、下开关已采用；本目录没有替换其中旧 S288 简化外形，也没有改打印件、STL、硬件源码或视频。

- [静态图和完整结果](index.html)
- [独立 Blender](S288_vendor_fit_UNADOPTED.blend)：当前默认隐藏框架/上层模块，橙色标出原厂插口；其余原主模型对象保留。
- [来源接收](receipt.json)、[原 STEP](sources/S288_official.STEP)、[原始 CAD/网格诊断](source_inspection.json)。来源为可行性样车的官方 S288 包，和压缩包成员逐字节一致，不是照片估算或实测。
- [刚性干涉](fit_review.json)：插口朝内时硬件/打印件不相交，四处软垫各约 4.056 mm³ 重叠，约 0.073 mm 局部压入，未做材料压缩资格；朝外与支架明显冲突。没有用缩小硬件或移动法兰来消除冲突。
- [插接与取出](access_review.json)：6.6×3.2 mm 抽象探针可直出约 8.3 mm，限制件是对侧电机。这不是所购插头尺寸，不包括最终装配余量或弯折。两侧断线后的组件向下 60 mm，各 61 个位置通过原项目 0.01 mm³ 硬碰阈值；初始软垫接触、线束与人手操作未通过。
- 原文件 14 个壳含 2 个开放面；仅闭合部分参与体积运算，六个负向内边界在全部包含检查后扣除。原网格没有补洞，完整厂家/实物配合仍 BLOCKED。原厂 CAD 两端面 26.2 mm 与旧名义 26 mm 分别保留。

## 复现

在产品工作树运行 `python3 mechanical/studies/s288_vendor_fit_M1_58/run.py`，然后运行同目录 `publish.py`。Blender 5.2.2 LTS / Python 3.13.13 / numpy 2.3.4 / manifold3d 3.5.3；CAD Python 3.12.14 / cadquery-ocp 7.8.1.1.post1。精确命令、时间、返回码和日志 SHA 在 commands.json。

最初两次很薄的负向内边界体积比较未通过，原日志保留；相应曲面的线性细分收紧到 0.0001 mm、角度 0.02 rad 后通过，没有放宽该校验门槛。过宽的三角距离搜索被停止，最终改用有明确含义的 1.6 mm 包围盒距离下界，未冒称精确最小间距。

## 下一步

先确定 S288 实际插头/线径、已插到底后塑壳外伸及最小可用弯折，再做 U03、U04 同时走线与带线装入。A/B 仍只是电路用途，不能直接按照片左右当腔号。原配双口串接的合并电流、端子额定和压降仍由硬件任务复核。

此次不采用任何结构变更；原厂 CAD 替换主模型之前，还要完成对插及完整当前装配比较，并明确记录四处软垫接触。不得把静态候选当作新版打印/加工放行。
''')
(H/'MECHANICAL_HANDOFF.md').write_text(f'''# S288 插接空间只读交接

2026-10-13，M1.58 主模型，UPS-R2 U03/U04 拓扑。原厂 S288 STEP 已从样品项目读入到独立检查，原文件 hash `{fit['source_step_sha256']}`。

同一输出轴和法兰安装平面下，双电机插口朝内时闭合 CAD 部分不与现有硬质支架相交；朝外每侧与 Drive_Bridge 约 587.5 mm³ 相交。朝内四个插口的 6.6×3.2 mm 抽象矩形轴向容量均约 8.3 mm（无最终装配间隙），受对侧电机限制。这里不能预先放行普通直插塑壳再直出一大段导线；应取得确切塑壳、插入深度、压接尾部及线径，再核弯折。

这个截面只是机械容量样本，绝不是替硬件冻结连接器料号。上下插口尚未分配 U03/U04 的 A/B 用途；不得按显示颜色推断引脚。总线电源并接及首段合计电流保留硬件定义。

主模型及打印件不变；同板框驱动载板端口位置仍待新的原生 PCB 交接。请在端子和线束选型中使用本限制，候选出图时交接真实插头/线材包络。资料见 [静态页](index.html) 与 [空间坐标](access_review.json)。
''')
# Small, explicitly scoped navigation additions. Do not rewrite historical reports.
nav=P/'mechanical/index.html';text=nav.read_text();marker='<!-- S288_VENDOR_M1_58 -->'
section=f'''{marker}<section id="s288-vendor"><h2>S288 原厂 CAD 复核（独立，未采用）</h2><p>原厂模型已从样品项目读入并与当前电机座比较。插口朝内无硬质支架冲突，四处软垫需试配；插口直出空间约 8.3 mm，仅为抽象截面的容量结果。<a href="studies/s288_vendor_fit_M1_58/index.html">看静态图、插口空间和无导线取出检查</a>。本页主模型仍为 M1.58，未将这个独立检查文件当作主模型更新。</p></section><!-- /S288_VENDOR_M1_58 -->'''
if marker in text:
 start=text.index(marker);end=text.index('<!-- /S288_VENDOR_M1_58 -->',start)+len('<!-- /S288_VENDOR_M1_58 -->');text=text[:start]+section+text[end:]
else:
 assert '</main>' in text;text=text.replace('</main>',section+'</main>',1)
nav.write_text(text)
def append_once(path,marker,value):
 text=path.read_text()
 if marker not in text:path.write_text(text.rstrip()+'\n\n'+value+'\n')
append_once(P/'docs/PREARRIVAL_BLOCKERS.md','S288 原厂 CAD 只读复核','## S288 原厂 CAD 只读复核\n\n官方 CAD 已在样品项目中找到并接收，完成同轴装配、两种插接面朝向、轴向容量及每侧 61 个无导线取出位置检查；[结果](../mechanical/studies/s288_vendor_fit_M1_58/index.html)。这份模型尚未替换主模型。插口朝内的四处软垫有轻微局部压入；6.6×3.2 mm 抽象截面只能直出约 8.3 mm。现在可继续按选定连接器细化路线，真实插头、线径、弯折、应力释放和带线拆装仍未完成；不能继承旧简化电机的线缆资格。')
append_once(P/'docs/PROJECT_INDEX.md','s288_vendor_fit_M1_58/index.html','- [S288 原厂 CAD / 插口空间 / 无导线取出复核](../mechanical/studies/s288_vendor_fit_M1_58/index.html)：独立检查，未应用主模型，实物插头和完整线束仍待验证。')
append_once(P/'mechanical/LATEST_MODEL.md','s288_vendor_fit_M1_58/S288_vendor_fit_UNADOPTED.blend','## 2026-10-13 S288 独立来源复核\n\n[S288_vendor_fit_UNADOPTED.blend](studies/s288_vendor_fit_M1_58/S288_vendor_fit_UNADOPTED.blend) 用原厂 S288 STEP 对照当前电机座，**不是最新主模型**。M1.58 主模型仍保留旧简化轮舵机外形；其打印件与轴线没有因此变化。见[详细复核](studies/s288_vendor_fit_M1_58/index.html)。')
files=[p for p in H.rglob('*') if p.is_file() and p.name not in ['delivery.json','publish.log']]
delivery=dict(generated_at=datetime.datetime.now().astimezone().isoformat(),status='PASS',scope='Independent reference study delivery, not adoption/complete assembly/physical qualification',main_sha256=fit['source_model_sha256'],full_harness='BLOCKED',physical_fit='NOT_TESTED',sources_hashes_preserved=True,files={str(p.relative_to(H)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in files})
(H/'delivery.json').write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
print('PUBLISHED_INDEPENDENT_S288_STUDY',len(files))
