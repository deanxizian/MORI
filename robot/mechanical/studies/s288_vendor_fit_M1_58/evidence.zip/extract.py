"""Read original S288 CAD; no healing, scaling, simplification or main edits."""
from pathlib import Path
import json, hashlib, sys, importlib.metadata
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_SHELL, TopAbs_FACE, TopAbs_REVERSED
from OCP.TopoDS import TopoDS
from OCP.TopLoc import TopLoc_Location
from OCP.BRep import BRep_Tool
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.GeomAbs import GeomAbs_Cylinder,GeomAbs_Plane
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps

HERE=Path(__file__).resolve().parent; SRC=HERE/'sources/S288_official.STEP'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()=='6857b4a8a753a473ff0e1172aeb74e464bb3d3ca694625fcbfababd5e621952a'
assert 'SI_UNIT(.MILLI.,.METRE.)' in ''.join(SRC.read_text(errors='replace').split())
r=STEPControl_Reader(); assert r.ReadFile(str(SRC))==IFSelect_RetDone
r.TransferRoots(); root=r.OneShape()
def bounds(shape):
 b=Bnd_Box();BRepBndLib.AddOptimal_s(shape,b,False,False);return list(b.Get())
def tessellate(shape,deflection=.01):
 BRepMesh_IncrementalMesh(shape,deflection,False,.02 if deflection<.01 else .08,False)
 verts=[];tris=[];lookup={};cylinders=[];planes=[];fs=TopExp_Explorer(shape,TopAbs_FACE);missing=[]
 while fs.More():
  face=TopoDS.Face_s(fs.Current());loc=TopLoc_Location();mesh=BRep_Tool.Triangulation_s(face,loc)
  surf=BRepAdaptor_Surface(face)
  if surf.GetType()==GeomAbs_Cylinder:
   c=surf.Cylinder();p=c.Location();v=c.Axis().Direction()
   cylinders.append(dict(radius=c.Radius(),axis=[v.X(),v.Y(),v.Z()],center=[p.X(),p.Y(),p.Z()],bounds=bounds(face)))
  elif surf.GetType()==GeomAbs_Plane:
   plane=surf.Plane();v=plane.Axis().Direction();p=plane.Location();g=GProp_GProps();BRepGProp.SurfaceProperties_s(face,g)
   planes.append(dict(normal=[v.X(),v.Y(),v.Z()],point=[p.X(),p.Y(),p.Z()],area_mm2=g.Mass(),bounds=bounds(face)))
  if mesh is None:missing.append(bounds(face));fs.Next();continue
  ids={}
  for i in range(1,mesh.NbNodes()+1):
   p=mesh.Node(i).Transformed(loc.Transformation());v=[p.X(),p.Y(),p.Z()];key=tuple(round(x,7) for x in v)
   if key not in lookup:lookup[key]=len(verts);verts.append(v)
   ids[i]=lookup[key]
  for i in range(1,mesh.NbTriangles()+1):
   a,b,c=mesh.Triangle(i).Get()
   if face.Orientation()==TopAbs_REVERSED:b,c=c,b
   t=[ids[a],ids[b],ids[c]]
   if len(set(t))==3:tris.append(t)
  fs.Next()
 assert not missing,missing
 return dict(vertices_mm=verts,triangles=tris,cylinders=cylinders,planes=planes)
rows=[];ex=TopExp_Explorer(root,TopAbs_SOLID)
while ex.More():
 s=ex.Current();g=GProp_GProps();BRepGProp.VolumeProperties_s(s,g)
 row=dict(index=len(rows),cad_valid=BRepCheck_Analyzer(s).IsValid(),bounds_mm=bounds(s),volume_mm3=g.Mass(),**tessellate(s));rows.append(row);ex.Next()
 print(row['index'],row['cad_valid'],row['bounds_mm'],row['volume_mm3'],len(row['triangles']),flush=True)
shells=[];ex=TopExp_Explorer(root,TopAbs_SHELL,TopAbs_SOLID)
while ex.More():
 s=ex.Current();g=GProp_GProps();BRepGProp.VolumeProperties_s(s,g)
 precision=.0001 if abs(g.Mass())<10 else .01
 row=dict(index=len(shells),cad_valid=BRepCheck_Analyzer(s).IsValid(),closed=s.Closed(),bounds_mm=bounds(s),volume_mm3=g.Mass(),deflection_mm=precision,**tessellate(s,precision));shells.append(row);ex.Next()
 print('SHELL',row['index'],row['cad_valid'],row['closed'],row['bounds_mm'],row['volume_mm3'],len(row['triangles']),flush=True)
result=dict(source_file='sources/S288_official.STEP',source_sha256=hashlib.sha256(SRC.read_bytes()).hexdigest(),units='mm',scale=1,deflection_mm=.01,angle_deflection_rad=.08,python=sys.version,ocp=importlib.metadata.version('cadquery-ocp'),root_bounds_mm=bounds(root),solid_count=len(rows),free_shell_count=len(shells),solids=rows,free_shells=shells,physical_fit='NOT_TESTED')
(HERE/'vendor_mesh.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
(HERE/'source_inspection.json').write_text(json.dumps({k:v for k,v in result.items() if k not in ['solids','free_shells']}|{name:[{k:v for k,v in x.items() if k not in ['vertices_mm','triangles']} for x in values] for name,values in [('solids',rows),('free_shells',shells)]},indent=2)+'\n')
print('SOLIDS',len(rows),'FREE_SHELL_COUNT',len(shells),'BOUNDS',result['root_bounds_mm'],flush=True)
