"""Verify local review links and exact HTTP bytes; no browser claims."""
from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,urllib.request,urllib.parse
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OUT=HERE/'neck_core_open_R2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pub=json.loads((OUT/'publication.json').read_text());assert pub['status']=='PASS'
assert all(sha(p)==h for p,h in pub['sources'].items())
assert all(sha(ROOT/p)==h for p,h in pub['protected_sources'].items())
class Links(HTMLParser):
    def __init__(self):super().__init__();self.refs=[]
    def handle_starttag(self,tag,attrs):
        self.refs.extend(v for k,v in attrs if k in ['src','href'] and v and not v.startswith('#'))
p=Links();p.feed((OUT/'index.html').read_text());files={OUT/'index.html',OUT/'publication.json'}
for ref in p.refs:
    u=urllib.parse.urlsplit(ref);assert not u.scheme and not u.netloc
    files.add((OUT/urllib.parse.unquote(u.path)).resolve())
checks=[]
for path in sorted(files):
    assert path.is_relative_to(ROOT) and path.is_file()
    url='http://127.0.0.1:58202/'+urllib.parse.quote(str(path.relative_to(ROOT)))
    with urllib.request.urlopen(url,timeout=15) as response:
        data=response.read();status=response.status
    exact=status==200 and data==path.read_bytes();checks.append(dict(file=str(path.relative_to(ROOT)),HTTP_status=status,exact_bytes=exact,sha256=sha(path)))
assert all(r['exact_bytes'] for r in checks)
assert all(sha(p)==h for p,h in pub['sources'].items())
result=dict(status='PASS',scope='Exact local HTTP bytes, links and source hashes only',publication_sha256=sha(OUT/'publication.json'),
    script_sha256=sha(Path(__file__)),link_count=len(p.refs),unique_file_count=len(checks),files=checks,browser_visual='NOT_TESTED',
    main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False)
(OUT/'delivery.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('R2_DELIVERY_PASS',len(checks),'files',len(p.refs),'links')
