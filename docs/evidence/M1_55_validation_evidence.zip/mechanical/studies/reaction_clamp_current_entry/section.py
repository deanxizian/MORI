"""Export exact native sections for display, with full 3D contact volumes."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'))
from current_context import Context,np

started=time.time();ctx=Context();ctx.record([Path(__file__)])
link=ctx.ss['Yaw_Reaction_Link'].m;fixture=ctx.ss['Pitch_Yoke'].m
def polygons(m):
    # Rx90: (x,y,z) -> (x,-z,y). Slice at original Y=-9.
    return [np.c_[np.asarray(p)[:,0],-np.asarray(p)[:,1]].tolist()
            for p in m.rotate([90,0,0]).slice(-9.).to_polygons()]
panels=[]
for lift in [0.,2.,-17.]:
    moved=link.translate([0,0,lift]);overlap=moved^fixture
    panels.append(dict(delta_Z_mm=lift,fixture_xz_polygons_mm=polygons(fixture),
        moving_xz_polygons_mm=polygons(moved),overlap_xz_polygons_mm=polygons(overlap),
        full_3D_overlap_mm3=float(overlap.volume())))
ctx.unchanged()
result=dict(status='PASS',scope='Exact native section export only; full 3D volumes retained for diagnostic comparison',
    sources=ctx.sources,section_y_mm=-9.,panels=panels,
    complete_initial_assembly='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False,
    elapsed_s=time.time()-started)
(HERE/'section.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('REACTION_SECTION_EXPORTED',len(panels),result['elapsed_s'],flush=True)
