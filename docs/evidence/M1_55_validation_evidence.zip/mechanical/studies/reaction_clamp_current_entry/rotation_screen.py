"""Bench-only order exploration: slide, rotate coaxially, then withdraw.

No runtime yaw range changes. Body bridge, servos and bearings are not yet
fitted in this isolated stage. The exact printed link is retained; no geometry
is cut to obtain an insertion path. Samples are not a continuous proof.
"""
from pathlib import Path
import json,sys,time,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'))
from current_context import Context,np

def main():
    started=time.time();ctx=Context();ctx.record([Path(__file__),HERE/'screen.json'])
    fixture=ctx.ss['Pitch_Yoke'];link=ctx.ss['Yaw_Reaction_Link'].m
    trials=[];accepted=None
    for first_lift in [-15.,-10.,-5.,0.]:
        for angle in [15.,-15.,30.,-30.,45.,-45.,60.,-60.,90.,-90.,120.,-120.,180.]:
            def pose(z,degrees):
                return link.rotate([0,0,degrees]).translate([0,0,z])
            samples=[];failure=None
            phases=[('initial_slide',[(float(z),0.) for z in np.linspace(0,first_lift,int(abs(first_lift)/.5)+1)]),
                ('bench_rotate',[(first_lift,float(d)) for d in np.linspace(0,angle,int(abs(angle)/2)+1)]),
                ('withdraw_down',[(float(z),angle) for z in np.arange(first_lift-.5,-80.01,-.5)])]
            for phase,states in phases:
                for z,d in states:
                    moved=pose(z,d);overlap=float((moved^fixture.m).volume());gap=float(moved.min_gap(fixture.m,.6))
                    row=dict(phase=phase,delta_Z_mm=z,bench_angle_Z_deg=d,overlap_mm3=overlap,gap_capped_mm=gap)
                    samples.append(row)
                    if overlap>1e-5 or gap<.3:failure=row;break
                if failure:break
            trial=dict(initial_slide_mm=first_lift,bench_angle_Z_deg=angle,
                status='BLOCKED' if failure else 'PASS',sample_count=len(samples),first_failure=failure)
            trials.append(trial)
            if failure is None:
                accepted={**trial,'samples':samples};break
        if accepted:break
    ctx.unchanged()
    result=dict(status='PASS' if accepted else 'BLOCKED',scope='Static samples of bare printed link only, bench order trial; not full assembly',
        sources=ctx.sources,trials=trials,accepted=accepted,fixture=['Pitch_Yoke'],moving=['Yaw_Reaction_Link'],
        required_nominal_gap_mm=.3,runtime_yaw_changed=False,continuous_motion='NOT_TESTED',
        horn_and_clamp_fasteners='NOT_TESTED',physical_hand_access='NOT_TESTED',complete_initial_assembly='BLOCKED',
        horn_stack='BLOCKED: user deferred accessory dimensions to arrival',
        main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'rotation_screen.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('REACTION_ROTATION_SCREEN',result['status'],len(trials),accepted,result['elapsed_s'],flush=True)
if __name__=='__main__':main()
