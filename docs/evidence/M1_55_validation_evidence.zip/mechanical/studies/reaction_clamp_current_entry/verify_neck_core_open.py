"""Independent current-source verification of the R2 open-neck proposal.

Reports finite wall/motion scope and continuous translation/shell rotation
bounds separately. Actual horn, hands, print strength and full wires excluded.
"""
from pathlib import Path
import sys,json,time,copy,itertools,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(HERE),str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np,sha
from common import P,D,manifold,Vector
from neck_capacity import construct,local_curves
from mathutils.bvhtree import BVHTree
from validate import rigidtr
from neck_core_open_candidate import quantize

def main():
    start=time.time();ctx=Context();out=HERE/'neck_core_open_R2'
    receipt=json.loads((out/'review.json').read_text());assert receipt['status']=='PASS'
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    ctx.record([Path(__file__),HERE/'neck_core_open_candidate.py',out/'review.json',out/'proposal.json',out/'candidate_mesh.npz'])
    d=np.load(out/'candidate_mesh.npz');candidate=manifold.Manifold(manifold.Mesh64(d['vertices_mm'],d['triangles'].astype(np.uint64)))
    old=ctx.ss['Pitch_Yoke'].m;added=candidate-old;removed=old-candidate
    q0=copy.deepcopy(P['neck_harness_capacity']);q1=copy.deepcopy(q0);q1['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm']=12.35
    original={n:ctx.ss[n].m for n in q0['changed_existing_ids']}
    baseline,*_=construct(original,q0);replay,_,outer,inner,pack,curves,curve_rows=construct(original,q1)
    cleanup=q0['construction']['saved_float32_cleanup_mm']
    base=quantize(baseline['Pitch_Yoke'],cleanup);full=quantize(replay['Pitch_Yoke'],cleanup)
    p=receipt['parameters'];z=p['rear_open_start_Z_mm'];height=p['rear_open_top_Z_mm']-z
    cutter=manifold.Manifold.cylinder(height,p['rear_open_max_radius_mm'],p['rear_open_max_radius_mm'],256).translate([0,0,z])
    cutter^=manifold.Manifold.cube([40.,30.+p['rear_open_max_Y_mm'],height]).translate([-20.,-30.,z])
    exact=quantize((full-cutter).simplify(cleanup),cleanup)
    sym=lambda a,b:float((a-b).volume()+(b-a).volume())
    source=dict(baseline_difference_mm3=sym(base,old),candidate_difference_mm3=sym(exact,candidate),comparison_limit_mm3=.005)
    source['status']='PASS' if max(source['baseline_difference_mm3'],source['candidate_difference_mm3'])<.005 else 'BLOCKED'
    roi=manifold.Manifold.cylinder(31.4,16.2,16.2,256).translate([0,0,148.68])
    journal=manifold.Manifold.cylinder(7.01,30.,30.,256).translate([0,0,148.99])
    upper=manifold.Manifold.cube([150.,150.,70.]).translate([-75.,-75.,180.001])
    changes=dict(outside_ROI_added_mm3=float((added-roi).volume()),outside_ROI_removed_mm3=float((removed-roi).volume()),
                 protected_lower_journal_difference_mm3=sym(candidate^journal,old^journal),
                 protected_upper_seats_difference_mm3=sym(candidate^upper,old^upper),part_count_change=0,fastener_count_change=0)
    changes['status']='PASS' if max(abs(changes[k]) for k in changes if k.endswith('mm3'))<.005 else 'BLOCKED'
    # Continuous bare-print and trial-assembly entry with midpoint distance
    # minus half the translation span and a 0.1um numerical allowance.
    entry=[]
    for label,names in [('bare_print',['Yaw_Reaction_Link']),('trial_hardware',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut']),
                        ('horn_placeholder',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut','Yaw_Horn'])]:
        moving=manifold.Manifold.batch_boolean([ctx.ss[n].m for n in names],manifold.OpType.Add)
        stack=[(-100.,0.,0)];intervals=[];failure=None
        while stack:
            a,b,depth=stack.pop();mid=(a+b)/2;motion=(b-a)/2+.0001;m=moving.translate([0,0,mid])
            gap=float(m.min_gap(candidate,.3+motion+.001));overlap=float((m^candidate).volume());lower=gap-motion
            if lower<.3 or overlap>1e-5:
                if depth<18:stack.extend([(mid,b,depth+1),(a,mid,depth+1)]);continue
                failure=dict(start_mm=a,end_mm=b,gap_lower_mm=lower,overlap_mm3=overlap);break
            intervals.append(dict(start_mm=a,end_mm=b,gap_lower_mm=lower,depth=depth))
        ok=failure is None and intervals and intervals[0]['start_mm']==-100. and intervals[-1]['end_mm']==0.
        if ok:assert all(a['end_mm']==b['start_mm'] for a,b in zip(intervals[:-1],intervals[1:]))
        entry.append(dict(group=label,status='PASS' if ok else 'BLOCKED',interval_count=len(intervals),intervals=intervals,first_failure=failure,
                          minimum_gap_lower_mm=min((r['gap_lower_mm'] for r in intervals),default=0),actual_hardware_qualified=False))
        print('R2_CONTINUOUS_ENTRY',label,entry[-1]['status'],len(intervals),failure,flush=True)
    # Source-profile side distances on retained material only. Open endfaces
    # deliberately do not form a closed tube; this is no global strength proof.
    surfaces=[]
    for m in [inner,outer]:
        d=m.to_mesh64();v=np.asarray(d.vert_properties)[:,:3];f=np.asarray(d.tri_verts);f=f[np.ptp(v[f][:,:,2],axis=1)>1e-6]
        surfaces.append((v,f,BVHTree.FromPolygons(v,f.tolist(),all_triangles=True)))
    wall=[]
    for i,(v,f,tree) in enumerate(surfaces):
        points=np.vstack([v[np.unique(f)],v[f].mean(axis=1)]);points=points[(points[:,2]>=157)&(points[:,2]<=173.1)]
        # Keep both ends of each measured normal segment outside the cutter,
        # with 0.01 mm reserve. Rim cross sections are reported separately.
        rows=[]
        for point in points:
            nearest=surfaces[1-i][2].find_nearest(Vector(point));other=np.array(nearest[0])
            if all(a[1]>p['rear_open_max_Y_mm']+.01 or a[2]<p['rear_open_start_Z_mm']-.01 for a in [point,other]):
                rows.append((float(nearest[3]),point.tolist()))
        distance,where=min(rows);wall.append(dict(direction='inner_to_outer' if i==0 else 'outer_to_inner',sample_count=len(rows),minimum_mm=distance,point_mm=where))
    # Flat rear opening edges: analytic chord lengths of inner and outer
    # source sections. Numerically sample exact mesh sections at 0.2mm Z.
    sections=[]
    for z in [156.,160.,163.4,163.6,166.,170.,173.5]:
        sections.append(dict(z_mm=z,current_area_mm2=float(old.slice(z).area()),candidate_area_mm2=float(candidate.slice(z).area()),
                             candidate_loops=len(candidate.slice(z).to_polygons())))
    # Preserve exact eleven C5 local planning curves and check distance to the
    # actual candidate at every local yaw sample with chord/halfstep reserves.
    _,curves0,_=local_curves(q0);assert all(np.array_equal(curves[k],curves0[k]) for k in curves)
    d=candidate.to_mesh64();v=np.asarray(d.vert_properties)[:,:3];f=np.asarray(d.tri_verts)
    tree=BVHTree.FromPolygons(v,f.tolist(),all_triangles=True);wires=[]
    for i,slot in enumerate(pack['selected']):
        for yaw in range(-60,61,10):
            points=curves[f'wire{i}_y{yaw}'];a=math.radians(-yaw);R=np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
            points=points@R.T;distance=min(float(tree.find_nearest(Vector(t))[3]) for t in points)
            lower=distance-slot['OD_mm']/2-max(r['chord_error_mm'] for r in curve_rows)-np.linalg.norm(np.diff(points,axis=0),axis=1).max()/2-.0001
            wires.append(dict(wire=i,yaw_deg=yaw,gap_lower_mm=float(lower),status='PASS' if lower>=.3 else 'BLOCKED'))
    # Combined nominal pose regression against all 200 other current parts.
    # Added material creates new collisions; record full candidate intersections
    # alongside native intersections so intentional contacts are not concealed.
    def corners(bounds):return np.array(list(itertools.product(*zip(bounds[:3],bounds[3:]))))
    av=corners(np.asarray(added.bounding_box()));motion=[];new_hits=[]
    for yaw in range(-60,61,10):
        tr=np.asarray(rigidtr(yaw,0));m=added.transform(tr[:3,:]);pts=av@tr[:3,:3].T+tr[:3,3];lo=pts.min(axis=0);hi=pts.max(axis=0)
        for pitch in range(-20,26,5):
            hits=[];pairs=0
            for name,s in ctx.ss.items():
                if name=='Pitch_Yoke':continue
                t=np.asarray(rigidtr(yaw,pitch if s.group=='pitch' else 0)) if s.group in ['yaw','pitch'] else np.eye(4)
                pts=corners(np.r_[s.lo,s.hi])@t[:3,:3].T+t[:3,3]
                if np.any(lo>pts.max(axis=0)) or np.any(hi<pts.min(axis=0)):continue
                target=s.m.transform(t[:3,:]);pairs+=1;vol=float((m^target).volume())
                if vol>1e-5:
                    r=dict(yaw_deg=yaw,pitch_deg=pitch,part=name,new_overlap_mm3=vol,
                           candidate_overlap_mm3=float((candidate.transform(tr[:3,:])^target).volume()),native_overlap_mm3=float((old.transform(tr[:3,:])^target).volume()))
                    hits.append(r);new_hits.append(r)
            motion.append(dict(yaw_deg=yaw,pitch_deg=pitch,broadphase_pairs=pairs,hits=hits,status='PASS' if not hits else 'BLOCKED'))
    # Bound the entire pitch interval against both head shells. Both shells and
    # neck share yaw rotation, so rigid yaw invariance covers all yaw values.
    shell_checks=[]
    for name in ['Head_Front','Head_Rear']:
        s=ctx.ss[name];R=float(np.linalg.norm(s.v-[0,0,D['head_z']],axis=1).max());stack=[(-20.,25.,0)];intervals=[];failure=None
        while stack:
            a,b,depth=stack.pop();mid=(a+b)/2;t=np.asarray(rigidtr(0,mid));m=s.m.transform(t[:3,:])
            delta=2*R*math.sin(math.radians((b-a)/2)/2)+.0001;gap=float(candidate.min_gap(m,.3+delta+.001));vol=float((candidate^m).volume());lower=gap-delta
            if lower<.3 or vol>1e-5:
                if depth<18:stack.extend([(mid,b,depth+1),(a,mid,depth+1)]);continue
                failure=dict(start_deg=a,end_deg=b,gap_lower_mm=lower,overlap_mm3=vol);break
            intervals.append(dict(start_deg=a,end_deg=b,gap_lower_mm=lower,depth=depth))
        ok=failure is None and intervals and intervals[0]['start_deg']==-20 and intervals[-1]['end_deg']==25
        if ok:assert all(a['end_deg']==b['start_deg'] for a,b in zip(intervals[:-1],intervals[1:]))
        shell_checks.append(dict(part=name,status='PASS' if ok else 'BLOCKED',interval_count=len(intervals),intervals=intervals,first_failure=failure,
                                minimum_gap_lower_mm=min((r['gap_lower_mm'] for r in intervals),default=0),yaw_scope='all by shared rigid yaw invariance'))
        print('R2_CONTINUOUS_SHELL',name,shell_checks[-1]['status'],len(intervals),failure,flush=True)
    # Changed neck only: bench lateral C-keeper insertion and head+keeper drop
    # alongside native body hardware, before fitting pitch subassembly/wires.
    keeper=ctx.ss['Yaw_Anti_Lift_Keeper'].m;keeper_hits=[];transfer_hits=[]
    for dy in np.arange(0,60.01,.5):
        vol=float((keeper.translate([0,float(dy),0])^candidate).volume())
        if vol>1e-5:keeper_hits.append(dict(Y_mm=float(dy),overlap_mm3=vol))
    yawset={n for n,s in ctx.ss.items() if s.group=='yaw'}|{'Yaw_Anti_Lift_Keeper','Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut','Yaw_Horn','Yaw_Output','Yaw_Lock_Screw'}
    fixture=set(ctx.ss)-yawset-{n for n,s in ctx.ss.items() if s.group=='pitch'}-{'Yaw_Keeper_Screw_0','Yaw_Keeper_Screw_1','Yaw_Keeper_Insert_0','Yaw_Keeper_Insert_1','Yaw_Reaction_Retainer_Screw','Yaw_Reaction_Retainer_Nut'}
    for dz in np.arange(0,90.01,.5):
        moved=candidate.translate([0,0,float(dz)]);bb=np.asarray(moved.bounding_box())
        for name in fixture:
            s=ctx.ss[name]
            if np.any(bb[:3]>s.hi) or np.any(bb[3:]<s.lo):continue
            vol=float((moved^s.m).volume())
            if vol>1e-5:transfer_hits.append(dict(Z_mm=float(dz),part=name,overlap_mm3=vol))
    ctx.unchanged()
    ok=source['status']=='PASS' and changes['status']=='PASS' and all(r['status']=='PASS' for r in entry+shell_checks+wires) and min(r['minimum_mm'] for r in wall)>=2.2 and not new_hits and not keeper_hits and not transfer_hits
    result=dict(status='PASS' if ok else 'BLOCKED',scope='Prototype R2 source/scope, continuous bare-print entry/shell sweep, finite bulk wall/local-wire/130-pose/keeper-transfer checks',
                sources=ctx.sources,source_replay=source,edit_scope=changes,continuous_entry=entry,retained_side_wall_samples=wall,
                opening_rim_strength='NOT_TESTED',global_wall_or_strength='NOT_TESTED',neck_section_areas=sections,
                unchanged_local_wire_checks=wires,full_harness='BLOCKED',combined_pose_count=len(motion),motion_rows=motion,new_hits=new_hits,
                continuous_shell_rotation=shell_checks,keeper_side_entry=dict(samples=121,hits=keeper_hits),body_vertical_transfer=dict(samples=181,hits=transfer_hits),
                complete_initial_hardware_assembly='BLOCKED: SC-0090-C001 accessories deferred to arrival; bare-print entry only resolved in this candidate',
                actual_horn_and_fasteners='BLOCKED',physical_hand_access='NOT_TESTED',main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False,elapsed_s=time.time()-start)
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('R2_VERIFY_DONE',result['status'],source,changes,wall,'new_hits',new_hits,'keeper_hits',keeper_hits,'transfer_hits',transfer_hits[:3],result['elapsed_s'],flush=True)
if __name__=='__main__':main()
