"""Locate print-to-print contact beyond the first clearance witnesses."""
from pathlib import Path
import json,sys,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'))
from current_context import Context

started=time.time();ctx=Context();ctx.record([Path(__file__)])
fixture=ctx.ss['Pitch_Yoke'].m;link=ctx.ss['Yaw_Reaction_Link'].m
rows=[]
for lift in [0.,1.5,2.,4.,-15.5,-16.,-17.,-20.]:
    moved=link.translate([0,0,lift]);common=moved^fixture;volume=float(common.volume())
    row=dict(delta_Z_mm=lift,overlap_mm3=volume,
        overlap_bounds_xyz_mm=list(common.bounding_box()) if volume>1e-6 else None,
        gap_capped_mm=float(moved.min_gap(fixture,.6)))
    rows.append(row);print('PRINT_CONTACT_LOCATION',row,flush=True)
ctx.unchanged()
result=dict(status='PASS',scope='Read-only location audit of native print-to-print contacts, not an assembly pass',
    sources=ctx.sources,fixture='Pitch_Yoke',moving='Yaw_Reaction_Link',contacts=rows,
    horn_or_fastener_required_for_witness=False,
    complete_initial_assembly='BLOCKED',other_orders='NOT_TESTED',continuous_motion='NOT_TESTED',
    main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
(HERE/'contact_locations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('CONTACT_LOCATION_AUDIT_PASS',result['elapsed_s'],flush=True)
