"""Continuous prototype entry, source replay and current-motion checks.

No adoption and no actual horn qualification. A translation interval uses
midpoint solid distance minus half the stroke and a numerical reserve. Motion
checks report added-material interference against all current native parts;
they do not discard a pre-existing problem or certify physical strength.
"""
from pathlib import Path
import json,sys,time,copy,itertools,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np,sha
from common import P,manifold,Vector
from neck_capacity import construct,local_curves
from neck_profile_geometry import make_neck
from validate import rigidtr
from mathutils.bvhtree import BVHTree

def main():
    started=time.time();ctx=Context();out=HERE/'neck_core_R1'
    receipt=json.loads((out/'review.json').read_text());assert receipt['status']=='PASS'
    assert all(sha(p)==h for p,h in receipt['sources'].items())
    ctx.record([Path(__file__),out/'review.json',out/'candidate_mesh.npz',out/'proposed_parameter.json',
        ROOT/'mechanical/scripts/neck_capacity.py',ROOT/'mechanical/scripts/neck_profile_geometry.py',ROOT/'mechanical/scripts/neck_curve_geometry.py'])
    data=np.load(out/'candidate_mesh.npz');candidate=manifold.Manifold(manifold.Mesh64(data['vertices_mm'],data['triangles'].astype(np.uint64)))
    old=ctx.ss['Pitch_Yoke'].m;q0=copy.deepcopy(P['neck_harness_capacity']);q1=copy.deepcopy(q0)
    q1['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm']=12.35
    original={n:ctx.ss[n].m for n in q0['changed_existing_ids']}
    baseline,*_=construct(original,q0);replayed,*_=construct(original,q1)
    symmetric=lambda a,b:float((a-b).volume()+(b-a).volume())
    replay=dict(baseline_idempotence_mm3=symmetric(baseline['Pitch_Yoke'],old),
        proposal_source_difference_mm3=symmetric(replayed['Pitch_Yoke'],candidate),comparison_limit_mm3=.005)
    replay['status']='PASS' if max(replay['baseline_idempotence_mm3'],replay['proposal_source_difference_mm3'])<.005 else 'BLOCKED'
    print('CORE_SOURCE_REPLAY',replay,flush=True)
    rows=[]
    for label,names in [('bare_print',['Yaw_Reaction_Link']),('trial_clamp_hardware',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut']),
                       ('horn_allocation',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut','Yaw_Horn'])]:
        moving=manifold.Manifold.batch_boolean([ctx.ss[n].m for n in names],manifold.OpType.Add)
        intervals=[];stack=[(-100.,0.,0)];failure=None
        while stack:
            a,b,depth=stack.pop();mid=(a+b)/2;motion=(b-a)/2+.0001
            posed=moving.translate([0,0,mid]);gap=float(posed.min_gap(candidate,.3+motion+.001))
            overlap=float((posed^candidate).volume());lower=gap-motion
            if lower<.3 or overlap>1e-5:
                if depth<18:
                    stack.extend([(mid,b,depth+1),(a,mid,depth+1)]);continue
                failure=dict(start_Z_mm=a,end_Z_mm=b,midpoint_gap_mm=gap,gap_lower_mm=lower,overlap_mm3=overlap);break
            intervals.append(dict(start_Z_mm=a,end_Z_mm=b,status='PASS',gap_lower_mm=lower,depth=depth))
        ok=bool(intervals) and failure is None and intervals[0]['start_Z_mm']==-100. and intervals[-1]['end_Z_mm']==0.
        if ok:assert all(a['end_Z_mm']==b['start_Z_mm'] for a,b in zip(intervals[:-1],intervals[1:]))
        rows.append(dict(group=label,moving=names,status='PASS' if ok else 'BLOCKED',interval_count=len(intervals),intervals=intervals,first_failure=failure,
            minimum_gap_lower_mm=min((r['gap_lower_mm'] for r in intervals),default=0),actual_hardware_qualified=False))
        print('CORE_ENTRY_CONTINUOUS',label,rows[-1]['status'],len(intervals),failure,flush=True)
    # Generated side-wall check in the same finite scope as the original C5
    # audit. Endcaps, printed tolerances and global strength are excluded.
    pack,curves,curve_rows=local_curves(q1);_,outer,inner,params=make_neck(pack,curves,q1)
    sides=[]
    for m in [inner,outer]:
        mesh=m.to_mesh64();v=np.asarray(mesh.vert_properties)[:,:3];f=np.asarray(mesh.tri_verts)
        f=f[np.ptp(v[f][:,:,2],axis=1)>1e-6]
        sides.append((v,f,BVHTree.FromPolygons(v,f.tolist(),all_triangles=True)))
    wall=[]
    for i,(v,f,tree) in enumerate(sides):
        points=np.vstack([v[np.unique(f)],np.mean(v[f],axis=1)]);points=points[(points[:,2]>=157)&(points[:,2]<=173.1)]
        distance,point=min((float(sides[1-i][2].find_nearest(Vector(p))[3]),p.tolist()) for p in points)
        wall.append(dict(direction='inner_to_outer' if i==0 else 'outer_to_inner',sample_count=len(points),minimum_mm=distance,point_mm=point))
    print('CORE_WALL_SAMPLES',wall,flush=True)
    # Preserve the exact eleven C5 planning curves, then inspect their current
    # local distance to the candidate instead of claiming whole-harness fit.
    _,old_curves,_=local_curves(q0)
    assert all(np.array_equal(curves[k],old_curves[k]) for k in curves)
    cmesh=candidate.to_mesh64();cv=np.asarray(cmesh.vert_properties)[:,:3];cf=np.asarray(cmesh.tri_verts)
    tree=BVHTree.FromPolygons(cv,cf.tolist(),all_triangles=True)
    wire_checks=[]
    for i,slot in enumerate(pack['selected']):
        for yaw in range(-60,61,10):
            q=curves[f'wire{i}_y{yaw}'];angle=math.radians(-yaw);c=math.cos(angle);s=math.sin(angle)
            R=np.array([[c,-s,0],[s,c,0],[0,0,1]])
            points=q@R.T;dist=min(float(tree.find_nearest(Vector(p))[3]) for p in points)
            chord=max(r['chord_error_mm'] for r in curve_rows)
            halfstep=float(np.linalg.norm(np.diff(points,axis=0),axis=1).max())/2
            lower=dist-slot['OD_mm']/2-chord-halfstep-.0001
            wire_checks.append(dict(wire=i,yaw_deg=yaw,gap_lower_mm=lower,status='PASS' if lower>=.3 else 'BLOCKED'))
    # Only newly added material can create a new collision. Compare full
    # solids too so the output does not turn pre-existing overlaps into PASS.
    added=candidate-old;ab=np.asarray(added.bounding_box());lo=ab[:3];hi=ab[3:]
    vertices=np.array(list(itertools.product(*zip(lo,hi))))
    motion=[];new_hits=[]
    for yaw in range(-60,61,10):
        ytr=np.asarray(rigidtr(yaw,0));posed=added.transform(ytr[:3,:]);pts=vertices@ytr[:3,:3].T+ytr[:3,3];al=pts.min(axis=0);ah=pts.max(axis=0)
        for pitch in range(-20,26,5):
            hits=[];pairs=0
            for name,s in ctx.ss.items():
                if name=='Pitch_Yoke':continue
                tr=np.asarray(rigidtr(yaw,pitch if s.group=='pitch' else 0)) if s.group in ['yaw','pitch'] else np.eye(4)
                bpts=np.array(list(itertools.product(*zip(s.lo,s.hi))))@tr[:3,:3].T+tr[:3,3]
                if np.any(al>bpts.max(axis=0)) or np.any(ah<bpts.min(axis=0)):continue
                target=s.m.transform(tr[:3,:]);pairs+=1;volume=float((posed^target).volume())
                if volume>1e-5:
                    hits.append(dict(part=name,added_overlap_mm3=volume));new_hits.append(dict(yaw_deg=yaw,pitch_deg=pitch,part=name,added_overlap_mm3=volume))
            motion.append(dict(yaw_deg=yaw,pitch_deg=pitch,status='PASS' if not hits else 'BLOCKED',broadphase_pairs=pairs,hits=hits))
    ctx.unchanged()
    ok=replay['status']=='PASS' and all(r['status']=='PASS' for r in rows) and min(r['minimum_mm'] for r in wall)>=2.2 and not new_hits and all(r['status']=='PASS' for r in wire_checks)
    result=dict(status='PASS' if ok else 'BLOCKED',scope='Independent prototype source replay, continuous entry, finite generated-side wall/local-wire samples and added-material motion regression',sources=ctx.sources,
        source_replay=replay,continuous_entry=rows,side_wall_samples=wall,global_wall_or_strength='NOT_TESTED',
        local_wire_checks=wire_checks,local_wire_count=len(pack['selected']),full_harness='BLOCKED',
        combined_pose_count=len(motion),motion_rows=motion,new_interference=new_hits,
        interface_groups_changed=False,part_count_change=0,hardware_dimensions_changed=False,
        actual_horn_and_fasteners='BLOCKED: supplier delivery not confirmed',physical_hand_access='NOT_TESTED',
        main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CORE_CANDIDATE_VERIFY',result['status'],len(motion),'poses;',len(new_hits),'new hits;',result['elapsed_s'],flush=True)
if __name__=='__main__':main()
