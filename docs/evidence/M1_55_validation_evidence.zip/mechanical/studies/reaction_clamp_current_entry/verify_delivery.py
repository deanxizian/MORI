"""Exact local delivery and protected-source audit; no assembly approval."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,urllib.request,urllib.parse
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
verification=json.loads((HERE/'verification.json').read_text())
assert verification['status']=='PASS'
assert all(sha(p)==h for p,h in verification['sources'].items())
files=[HERE/'index.html',HERE/'README.md',HERE/'contact_sections.png',HERE/'contact_sections.svg']
for value in re.findall(r'(?:href|src)="([^"]+)"',(HERE/'index.html').read_text()):
    part=urllib.parse.urlsplit(value)
    if part.scheme or not part.path:continue
    p=(HERE/urllib.parse.unquote(part.path)).resolve();assert p.is_file()
    if p not in files:files.append(p)
rows=[]
for p in files:
    rel=p.relative_to(ROOT).as_posix()
    with urllib.request.urlopen('http://127.0.0.1:58202/'+urllib.parse.quote(rel,safe='/'),timeout=10) as response:
        assert response.status==200;body=response.read()
    assert body==p.read_bytes()
    rows.append(dict(file=rel,sha256=sha(p),bytes=len(body),http_status=200))
report=dict(status='PASS',scope='Source, local/HTTP bytes and inspected figure audit only',
    created_utc=datetime.now(timezone.utc).isoformat(),verified_files=rows,verified_file_count=len(rows),
    inspected_image='contact_sections.png',figure_visual_review='PASS',browser_visual_review='NOT_TESTED',
    continuous_motion='NOT_TESTED',complete_initial_assembly='BLOCKED',
    main_changed=False,hardware_changed=False,manufacturing_release=False)
(HERE/'delivery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('REACTION_DELIVERY_PASS',len(rows),'exact files; assembly BLOCKED',flush=True)
