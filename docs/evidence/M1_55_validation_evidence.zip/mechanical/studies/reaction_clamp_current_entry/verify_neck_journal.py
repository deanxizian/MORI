"""Resolve the journal-scope criterion without changing R2 geometry.

The proposal widens the internal passage, including material inside the lower
journal. Requiring the *entire* journal to remain unchanged was inconsistent
with that proposal. Preserve that original result, check the actual bearing
fit skin and radial backing separately; retain all other prior checks.
"""
from pathlib import Path
import sys,json,time,math,copy
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np,sha
from common import manifold

ctx=Context();out=HERE/'neck_core_open_R2';prior=out/'verification_initial_full_journal_criterion.json'
record=json.loads(prior.read_text());assert all(sha(p)==h for p,h in record['sources'].items())
ctx.record([Path(__file__),prior,out/'candidate_mesh.npz',out/'proposal.json'])
d=np.load(out/'candidate_mesh.npz');candidate=manifold.Manifold(manifold.Mesh64(d['vertices_mm'],d['triangles'].astype(np.uint64)))
old=ctx.ss['Pitch_Yoke'].m
outer=manifold.Manifold.cylinder(7.01,30.,30.,256).translate([0,0,148.99])
inner=manifold.Manifold.cylinder(7.03,14.2,14.2,256).translate([0,0,148.98])
skin=outer-inner
sym=lambda a,b:float((a-b).volume()+(b-a).volume())
skin_difference=sym(candidate^skin,old^skin)
wall=[];missing=[]
for z in np.linspace(149.5,155.9,33):
    for angle in range(0,360,3):
        t=math.radians(angle);end=[100*math.cos(t),100*math.sin(t),float(z)]
        hits=candidate.ray_cast([0,0,float(z)],end)
        if len(hits)<2:missing.append(dict(z_mm=float(z),angle_deg=angle));continue
        first=hits[0].distance*100;second=hits[1].distance*100
        wall.append(dict(z_mm=float(z),angle_deg=angle,inner_radius_mm=float(first),outer_radius_mm=float(second),radial_backing_mm=float(second-first)))
supplement=dict(status='PASS' if skin_difference<.005 and not missing and min(r['radial_backing_mm'] for r in wall)>=2.2 else 'BLOCKED',
    scope='Lower journal outer fit skin unchanged and finite radial backing samples, not global wall/strength qualification',
    source_hashes=ctx.sources,original_criterion_result_sha256=sha(prior),candidate_mesh_sha256=sha(out/'candidate_mesh.npz'),
    original_full_journal_difference_mm3=record['edit_scope']['protected_lower_journal_difference_mm3'],
    criterion_correction='Widening the internal neck passage necessarily removes internal journal material; preserve the bearing fit skin instead of the entire journal volume.',
    fit_skin_inner_radius_mm=14.2,fit_skin_difference_mm3=skin_difference,comparison_limit_mm3=.005,
    sample_count=len(wall),minimum_radial_backing_mm=min(r['radial_backing_mm'] for r in wall),missing_radial_rays=missing,samples=wall,
    physical_strength='NOT_TESTED',main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False)
ctx.unchanged();(out/'journal_verification.json').write_text(json.dumps(supplement,indent=2)+'\n')
result=copy.deepcopy(record);result['sources'].update(ctx.sources)
result['verification_method_revision']=2;result['original_full_journal_criterion']=dict(status='BLOCKED',file=prior.name,sha256=sha(prior),scope_correction=supplement['criterion_correction'])
result['edit_scope']['protected_bearing_fit_skin_difference_mm3']=skin_difference
result['edit_scope']['internal_journal_change_mm3']=result['edit_scope'].pop('protected_lower_journal_difference_mm3')
result['edit_scope']['status']='PASS' if all(abs(result['edit_scope'][k])<.005 for k in ['outside_ROI_added_mm3','outside_ROI_removed_mm3','protected_upper_seats_difference_mm3','protected_bearing_fit_skin_difference_mm3']) else 'BLOCKED'
result['lower_journal_backing']=dict(status=supplement['status'],file='journal_verification.json',sha256=sha(out/'journal_verification.json'),sample_count=len(wall),minimum_radial_backing_mm=supplement['minimum_radial_backing_mm'])
ok=all(result[k]['status']=='PASS' for k in ['source_replay','edit_scope','lower_journal_backing']) and all(r['status']=='PASS' for r in result['continuous_entry']+result['continuous_shell_rotation']+result['unchanged_local_wire_checks']) and min(r['minimum_mm'] for r in result['retained_side_wall_samples'])>=2.2 and not result['new_hits'] and not result['keeper_side_entry']['hits'] and not result['body_vertical_transfer']['hits']
result['status']='PASS' if ok else 'BLOCKED'
result['scope']='Prototype source/scope, continuous bare-print entry/shell sweep, finite retained-side/radial-journal-wall/local-wire/130-pose/keeper-transfer checks'
result['verification_geometry_changed']=False
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('JOURNAL_CRITERION',supplement['status'],'skin_difference',skin_difference,'minimum_radial_backing',supplement['minimum_radial_backing_mm'],'samples',len(wall),'combined',result['status'],flush=True)
