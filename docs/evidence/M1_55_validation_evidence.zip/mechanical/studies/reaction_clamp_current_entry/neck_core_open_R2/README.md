# M1.54 颈部装入候选 R2

2026-10-09 · 独立候选，未采用 · PRINTABLE / ASSUMED · PROTOTYPE / UNVALIDATED

仅扩大 Pitch_Yoke 内部通道并开放后侧颈壁，不增加打印件或紧固件。轴承配合外圆、上部座、所有硬件位置不变；轴承座内部通道扩大，199.28 mm³ 内部材料变化属于候选范围，不声称整个轴承座不变。

数字几何通过：与当前参数构造一致、100 mm 连续裸反力轴装入、完整壳体俯仰区间、130 个组合姿态新增材料回归、保留侧壁及轴承座径向壁厚、11 根局部参考线、有限压板侧移和身体移入。具体边界见 verification.json 和 index.html。

初次复核错误地要求扩大孔道时整个下部轴承座仍保持不变；原 BLOCKED 记录保留在 verification_initial_full_journal_criterion.json。补充复核明确区分外配合面与内部孔道，外配合面差为 0 的数值量级，3,960 条径向采样最小约 2.35 mm。数值对照阈值未放宽，候选几何未变。

所有曲率、孔位、装入是模型证据；真实舵盘和锁紧、手操作、完整线束、开放处刚度／强度／疲劳 NOT_TESTED，manufacturing_release=false。用户确认前不能覆盖主模型或 geometry.json。
