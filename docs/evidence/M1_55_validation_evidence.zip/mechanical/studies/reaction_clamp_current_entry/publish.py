"""Publish a current diagnostic, explicitly distinct from assembly approval."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as PlotPath
from matplotlib.patches import PathPatch

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
reports={n:json.loads((HERE/f'{n}.json').read_text()) for n in ['screen','rotation_screen','contact_locations','section']}
sources={}
for r in reports.values():
    assert r['main_changed']==r['hardware_changed']==r['manufacturing_release']==False
    for p,h in r['sources'].items():
        assert p not in sources or sources[p]==h
        assert sha(p)==h;sources[p]=h
assert all(v['status']=='BLOCKED' and v['first_failure'] for v in reports['screen']['variants'])
assert reports['rotation_screen']['status']=='BLOCKED' and len(reports['rotation_screen']['trials'])==52
assert reports['rotation_screen']['accepted'] is None
assert all(v['first_failure']['phase']=='withdraw_down' for v in reports['rotation_screen']['trials'])
assert not reports['contact_locations']['horn_or_fastener_required_for_witness']
contacts={r['delta_Z_mm']:r for r in reports['contact_locations']['contacts']}
assert contacts[0]['overlap_mm3']==0
assert contacts[2]['overlap_mm3']>18 and contacts[-17]['overlap_mm3']>18

def patch(polygons,colour,alpha=1):
    paths=[]
    for coords in polygons:
        v=np.asarray(coords);codes=np.r_[PlotPath.MOVETO,np.full(len(v)-1,PlotPath.LINETO),PlotPath.CLOSEPOLY]
        paths.append(PlotPath(np.vstack([v,v[0]]),codes))
    if paths:return PathPatch(PlotPath.make_compound_path(*paths),facecolor=colour,edgecolor=colour,alpha=alpha,linewidth=.7)

fig,axes=plt.subplots(1,3,figsize=(10.5,5.4))
fig.subplots_adjust(left=.06,right=.99,top=.86,bottom=.20,wspace=.26)
for ax,row,title in zip(axes,reports['section']['panels'],['Native final pose','Up 2 mm','Down 17 mm']):
    for key,colour,alpha in [('fixture_xz_polygons_mm','#c2cad0',1),('moving_xz_polygons_mm','#588a9b',.85),('overlap_xz_polygons_mm','#d65342',1)]:
        p=patch(row[key],colour,alpha)
        if p:ax.add_patch(p)
    ax.set(xlim=(-16,16),ylim=(167,207),aspect='equal',xlabel='X (mm)',title=title)
    ax.set_ylabel('Z (mm)');ax.spines[['top','right']].set_visible(False)
    ax.text(.5,-.16,f'3D overlap: {row["full_3D_overlap_mm3"]:.3f} mm3',transform=ax.transAxes,ha='center',fontsize=9)
fig.suptitle('Printed reaction link vs pitch yoke: Y = -9 mm section',fontsize=14)
fig.text(.06,.06,'Grey: pitch yoke. Blue: printed link. Red: exact native overlap. Display cropped; checks use full solids.',fontsize=9,color='#526775')
for suffix in ['png','svg']:fig.savefig(HERE/f'contact_sections.{suffix}',dpi=180)
plt.close(fig)

text=f'''# 上部反力夹：当前打印件装入检查

2026-10-08 · M1.54 · **初装仍 BLOCKED，主模型未改**

本次把待到货舵盘与打印件初装问题分开。只有 Pitch_Yoke 和 Yaw_Reaction_Link 两件原生打印几何时，以下装入顺序也未通过；这些碰撞不依赖舵盘或螺钉尺寸。两件仍为 PRINTABLE / ASSUMED 设计几何，PA12 配合及强度未验证。

| 动作 | 当前证据 |
|---|---|
| 原装配位置 | 两打印件没有实体相交 |
| 反力轴直上 1.5 mm | 正间隙约 0.050 mm，未达 0.3 mm 目标 |
| 直上 2 mm | 与后侧舵机支撑连接区域相交约 {contacts[2]['overlap_mm3']:.3f} mm³；接触范围 Z197.55–198 mm |
| 直下 16 mm | 首个实体相交；到 17 mm 相交约 {contacts[-17]['overlap_mm3']:.3f} mm³，位于下部颈管上口 Z172–173.03 mm |
| 先下移，再绕自身 Z 轴转动后下移 | 52 个静态顺序试查均在下移阶段受阻；这些只检查裸打印件 |

已查的直上/直下三组分别包含裸打印件、夹紧螺钉/螺母、再加舵盘占位。都首先被相同打印件界面挡住，不能仅列为等舵盘到货。52 个顺序包括初始下移 0/5/10/15 mm 以及不同正负轴向转角，属于未装桥、舵机、轴承、电子件及软线时的台上研究，未改变运行偏航范围。

**不能由这些失败推断所有装入路线都不可能。** 非轴向复合装入与完整带件安装仍未完成，手部操作空间也未检验。没有修剪打印件、缩放硬件或修改孔位来获得通过。舵盘夹持、传动叠层及预紧仍按用户指示等待 SC-0090-C001 实物；打印件当前装入路径单独保留为待处理项。

图仅截取 Y=-9 mm 的局部，计算使用完整原生实体；显示裁切不参与碰撞判断。下一步先研究可连续实现的装配顺序；若必须改变已确认承力几何，做出可审阅候选后请用户确认。

[接触定位](contact_locations.json) · [原生剖面](section.json) · [轴向样点](screen.json) · [52 个转动顺序](rotation_screen.json) · [交付核对](verification.json) · [命令](commands.json)

无制造、供应商消息或采购放行。角度研究为台上装配动作，非运行行程。
'''
(HERE/'README.md').write_text(text)
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>反力夹打印件初装</title><style>body{font:16px/1.7 system-ui;color:#233541;background:#f4f7f8;margin:0}main{max-width:950px;margin:35px auto;padding:0 24px 45px}section{background:white;padding:20px 25px;border:1px solid #dce4e7;border-radius:10px;margin:20px 0}h1{font-size:29px;line-height:1.3}h2{font-size:21px}img{max-width:100%;height:auto}a{color:#006b87}.tag{display:inline-block;background:#fff0cd;color:#7e5003;padding:5px 12px;border-radius:5px}.muted{font-size:14px;color:#617481}</style><main><p class="muted">2026-10-08 · M1.54 · 原生几何，主模型未改</p><h1>反力轴打印件的初装仍有问题</h1><p class="tag">已定位打印件碰撞 · 装入顺序 BLOCKED</p><p>这项不能只归为舵盘待到货：仅保留 U 托和裸反力轴打印件，直上／直下也会受阻。还没有改已确认的承力结构。</p><section><h2>两个受阻位置</h2><img src="contact_sections.png" alt="原位无相交，直上2毫米时与上部连接臂相交，直下17毫米时与颈管上口相交"><p>灰色 U 托，蓝色裸反力轴，红色为原生实体相交。剖面仅用于显示，碰撞计算使用完整 3D 实体。</p><p>直上 1.5 mm 时只剩约 0.050 mm 间隙；到 2 mm 与后侧舵机支撑连接区相交。直下 16 mm 开始接触颈管上口。52 个先下移／绕自身轴转动／再下移的静态顺序均未通过。</p></section><section><h2>当前结论和下一步</h2><p>这些失败不证明全部装入路线都不可能。非轴向连续动作及完整带件安装仍需继续研究。舵盘、中心螺钉和预紧保持到货核对；打印件装入问题单独保留。</p><p>先寻找可实现的装配顺序。如果需要改变已确认的承力结构，会准备候选并请你确认后再应用。</p><p><a href="README.md">详细范围</a> · <a href="contact_locations.json">接触定位</a> · <a href="section.json">原生剖面</a> · <a href="screen.json">轴向样点</a> · <a href="rotation_screen.json">转动顺序</a> · <a href="verification.json">交付核对</a> · <a href="commands.json">命令</a></p></section><p class="muted">PRINTABLE / ASSUMED · PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></main></html>'''
(HERE/'index.html').write_text(page)
commands=[]
for name in ['screen','rotation_screen','diagnose','section']:
    assert 'Blender quit' in (HERE/f'{name}.log').read_text()
    commands.append(dict(command=f'/Applications/Blender.app/Contents/MacOS/Blender --background mechanical/mori_v1_2.blend --python-exit-code 1 --python {HERE.relative_to(ROOT)}/{name}.py > {HERE.relative_to(ROOT)}/{name}.log 2>&1',process_exit_code=0,log=f'{name}.log'))
commands.append(dict(command=f'/Users/dean/.cache/codex-runtimes/mori-cad/bin/python {HERE.relative_to(ROOT)}/publish.py > {HERE.relative_to(ROOT)}/publish.log 2>&1',process_exit_code=0))
commands.append(dict(command=f'/Users/dean/.cache/codex-runtimes/mori-cad/bin/python {HERE.relative_to(ROOT)}/verify_delivery.py > {HERE.relative_to(ROOT)}/verify_delivery.log 2>&1',process_exit_code=0))
(HERE/'commands.json').write_text(json.dumps(dict(created_utc=datetime.now(timezone.utc).isoformat(),working_directory=str(ROOT),Python=sys.version,
    Blender='5.2.2 LTS d13f752e3b9c',commands=commands,
    tool_lookup_attempt=dict(runtime='mori-cad Python',result='ModuleNotFoundError: manifold3d',action='Used the existing offline Blender dependency environment; no package installed'),
    engineering_assembly='BLOCKED',main_changed=False,hardware_changed=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
assert all(sha(p)==h for p,h in sources.items())
(HERE/'verification.json').write_text(json.dumps(dict(status='PASS',scope='Source, native contact and delivery audit only; not an assembly pass',
    created_utc=datetime.now(timezone.utc).isoformat(),sources=sources,source_hash_count=len(sources),
    source_reports=list(reports),bare_print_failure_independent_of_unknown_horn=True,straight_variants=6,rotation_trials=52,
    full_assembly='BLOCKED',continuous_motion='NOT_TESTED',main_changed=False,hardware_changed=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('REACTION_DIAGNOSTIC_PUBLISHED',len(sources),'source hashes; assembly BLOCKED',flush=True)
