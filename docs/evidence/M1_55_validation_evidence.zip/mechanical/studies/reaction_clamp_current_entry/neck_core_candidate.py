"""Independent one-parameter neck-core proposal on current native geometry.

The C5 profile originally enclosed an R7.7 reaction stem, not its R12 clamp.
Use R12.35 in a COPY of the approved profile parameters. Reuse the exact C5
3D wall-offset construction and the unchanged eleven local wire allocations.
No source config, hardware or main Blender model is edited.
"""
from pathlib import Path
import json,sys,time,copy,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np
from common import P,manifold
from neck_capacity import local_curves
from neck_profile_geometry import make_neck

def main():
    started=time.time();ctx=Context()
    ctx.record([Path(__file__),ROOT/'mechanical/scripts/neck_capacity.py',ROOT/'mechanical/scripts/neck_profile_geometry.py',ROOT/'mechanical/scripts/neck_curve_geometry.py'])
    old=ctx.ss['Pitch_Yoke'].m;q=copy.deepcopy(P['neck_harness_capacity'])
    field='candidate_parameters/neck_profile/reference_reaction_bore_r_mm'
    old_radius=q['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm']
    q['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm']=12.35
    pack,data,curve_rows=local_curves(q)
    tube,outer,inner,parameters=make_neck(pack,data,q)
    candidate=((old+outer)-inner).simplify(5e-6)
    assert candidate.status()==manifold.Error.NoError and len(candidate.decompose())==1
    added=candidate-old;removed=old-candidate
    out=HERE/'neck_core_R1';out.mkdir(exist_ok=True)
    mesh=candidate.to_mesh64()
    np.savez_compressed(out/'candidate_mesh.npz',vertices_mm=np.asarray(mesh.vert_properties)[:,:3],triangles=np.asarray(mesh.tri_verts))
    for name,m in [('inner',inner),('outer',outer),('added',added),('removed',removed)]:
        mmesh=m.to_mesh64()
        np.savez_compressed(out/f'{name}_mesh.npz',vertices_mm=np.asarray(mmesh.vert_properties)[:,:3],triangles=np.asarray(mmesh.tri_verts))
    (out/'proposed_parameter.json').write_text(json.dumps(dict(source='config/geometry.json#/neck_harness_capacity/'+field,
        old=old_radius,proposed=12.35,units='mm',approved=False,main_changed=False),indent=2)+'\n')
    # All changes must stay inside the original neck construction range. The
    # upper servo pads and independent-bearing journals outside it stay native.
    roi=manifold.Manifold.cylinder(27.44,30.,30.,128).translate([0,0,148.68])
    outside_added=float((added-roi).volume());outside_removed=float((removed-roi).volume())
    assert outside_added<1e-5 and outside_removed<1e-5
    neck_samples=[]
    for z in [149.,152.5,156.,158.,160.,164.,168.,171.,173.6]:
        # Circular probe is a contained-core test, not a wall-strength claim.
        probe=manifold.Manifold.cylinder(.02,12.349,12.349,256).translate([0,0,z-.01])
        intrusion=float((probe^candidate).volume())
        neck_samples.append(dict(z_mm=z,core_probe_r_mm=12.349,intrusion_mm3=intrusion))
    # Translation from below avoids the upper closed seat. Check actual native
    # bare print first, then separately the unselected fastener/horn allocations.
    groups=[('bare_print',['Yaw_Reaction_Link']),
        ('trial_clamp_hardware',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut']),
        ('horn_allocation',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut','Yaw_Horn'])]
    entry=[]
    for label,names in groups:
        checks=[]
        for shift in np.linspace(-100.,0.,201):
            rows=[]
            for name in names:
                moving=ctx.ss[name].m.translate([0,0,float(shift)])
                gap=float(moving.min_gap(candidate,.7));overlap=float((moving^candidate).volume())
                rows.append(dict(part=name,gap_capped_mm=gap,overlap_mm3=overlap))
            checks.append(dict(delta_Z_mm=float(shift),status='PASS' if all(r['gap_capped_mm']>=.3 and r['overlap_mm3']<1e-5 for r in rows) else 'BLOCKED',parts=rows))
            if checks[-1]['status']!='PASS':break
        entry.append(dict(group=label,moving=names,status='PASS' if len(checks)==201 and all(r['status']=='PASS' for r in checks) else 'BLOCKED',
            scope='Static samples only; actual horn/fastener delivery remains unqualified',samples=checks,
            minimum_gap_capped_mm=min(r['gap_capped_mm'] for c in checks for r in c['parts'])))
        print('CORE_ENTRY_STATIC',label,entry[-1]['status'],checks[-1],flush=True)
    ctx.unchanged()
    result=dict(status='PASS' if all(r['status']=='PASS' for r in entry) and max(r['intrusion_mm3'] for r in neck_samples)<1e-5 else 'BLOCKED',
        scope='Independent C5 core-radius proposal, topology, bounded edit region and vertical-entry static samples only',sources=ctx.sources,
        changed_existing_parts=['Pitch_Yoke'],part_count_change=0,fastener_count_change=0,category='PRINTABLE',data_status='ASSUMED',
        proposed_field=field,original_reference_radius_mm=old_radius,proposed_reference_radius_mm=12.35,
        original_and_proposed_local_wire_count=len(pack['selected']),original_wall_offset_radius_mm=parameters['offset_radius_mm'],
        normal_wall_reserve_mm=parameters['normal_wall_reserve_mm'],wire_allocations_changed=False,
        original_volume_mm3=float(old.volume()),proposed_volume_mm3=float(candidate.volume()),added_mm3=float(added.volume()),removed_mm3=float(removed.volume()),
        added_bounds_mm=list(added.bounding_box()),removed_bounds_mm=list(removed.bounding_box()),
        outside_edit_ROI_added_mm3=outside_added,outside_edit_ROI_removed_mm3=outside_removed,
        candidate_topology=dict(status='PASS',connected_components=1,mesh_error=str(candidate.status()),vertices=len(mesh.vert_properties),triangles=len(mesh.tri_verts)),
        neck_core_probes=neck_samples,entry_groups=entry,
        continuous_entry='NOT_TESTED',combined_motion='NOT_TESTED',wall_distance_sampling='NOT_TESTED',
        actual_SC0090_C001_horn='BLOCKED: deferred to arrival',hand_access='NOT_TESTED',full_harness='BLOCKED',
        main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('CORE_CANDIDATE_DONE',result['status'],result['elapsed_s'],flush=True)
if __name__=='__main__':main()
