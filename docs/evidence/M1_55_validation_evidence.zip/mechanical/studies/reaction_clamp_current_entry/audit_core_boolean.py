"""Audit the candidate boolean before treating its delta as a real collision."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np
from common import manifold,D
from validate import rigidtr

ctx=Context(); out=HERE/'neck_core_R1'; ctx.record([Path(__file__),out/'candidate_mesh.npz',out/'outer_mesh.npz',out/'inner_mesh.npz'])
def load(name):
    d=np.load(out/(name+'_mesh.npz'))
    return manifold.Manifold(manifold.Mesh64(d['vertices_mm'],d['triangles'].astype(np.uint64)))
old=ctx.ss['Pitch_Yoke'].m; candidate=load('candidate'); outer=load('outer'); inner=load('inner')
added=candidate-old; tr=np.asarray(rigidtr(0,25)); shell=ctx.ss['Head_Rear'].m.transform(tr[:3,:])
def record(m):
    mesh=m.to_mesh64();v=np.asarray(mesh.vert_properties)[:,:3];f=np.asarray(mesh.tri_verts)
    used=v[np.unique(f)] if len(f) else np.zeros((0,3))
    return dict(volume_mm3=float(m.volume()),bounds_mm=list(m.bounding_box()),error=str(m.status()),
                vertices=len(v),triangles=len(f),used_bounds_mm=[used.min(axis=0).tolist(),used.max(axis=0).tolist()] if len(used) else None,
                radial_min_max_mm=[float(np.linalg.norm(used[:,:2],axis=1).min()),float(np.linalg.norm(used[:,:2],axis=1).max())] if len(used) else None)
solids={'old':old,'candidate':candidate,'outer':outer,'inner':inner,'added':added,'added_outside_outer':added-outer,
        'old_shell_contact':old^shell,'candidate_shell_contact':candidate^shell,'added_shell_contact':added^shell,
        'old_intersection_outside_old':(candidate^old)-old,
        'native_candidate_removed_outside_old':(old-candidate)-old}
result=dict(status='PASS',scope='Boolean consistency diagnostic, not engineering qualification',sources=ctx.sources,
            records={n:record(m) for n,m in solids.items()},main_changed=False,hardware_changed=False,manufacturing_release=False)
ctx.unchanged();(out/'boolean_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('BOOLEAN_AUDIT',result['records'],flush=True)
