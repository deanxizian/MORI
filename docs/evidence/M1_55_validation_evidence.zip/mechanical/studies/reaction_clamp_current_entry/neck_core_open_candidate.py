"""Source-derived independent neck candidate with one open rear wall.

No main/config modification. The rear clearance is an assembly/motion opening,
not a cable hole. Preserve the bearing journal and all servo/optical datums.
"""
from pathlib import Path
import sys,json,copy,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np
from common import P,manifold
from neck_capacity import construct
from validate import rigidtr

def quantize(m,cleanup):
    # Emulate the existing two float32 mesh writes; no scene objects replaced.
    def once(m):
        d=m.to_mesh64();v=np.array(d.vert_properties[:,:3],dtype=np.float32).astype(np.float64)
        return manifold.Manifold(manifold.Mesh64(v,np.array(d.tri_verts,dtype=np.uint64)))
    m=once(m).simplify(cleanup);return once(m)

def main():
    started=time.time();ctx=Context();out=HERE/'neck_core_open_R2';out.mkdir(exist_ok=True)
    ctx.record([Path(__file__),ROOT/'mechanical/scripts/neck_capacity.py',ROOT/'mechanical/scripts/neck_profile_geometry.py',ROOT/'mechanical/scripts/neck_curve_geometry.py'])
    q0=copy.deepcopy(P['neck_harness_capacity']);q1=copy.deepcopy(q0)
    q1['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm']=12.35
    original={n:ctx.ss[n].m for n in q0['changed_existing_ids']}
    old=ctx.ss['Pitch_Yoke'].m
    baseline,*_=construct(original,q0)
    changed,_,outer,inner,pack,data,rows=construct(original,q1)
    cleanup=q0['construction']['saved_float32_cleanup_mm']
    baseline=quantize(baseline['Pitch_Yoke'],cleanup)
    full=quantize(changed['Pitch_Yoke'],cleanup)
    # Open the rear semicircle above this flat Z plane, with the front and side
    # arc retained. Restrict to the neck radius so unrelated walls remain native.
    parameters=dict(reference_reaction_bore_r_mm=12.35,rear_open_start_Z_mm=163.5,
                    rear_open_max_Y_mm=-7.5,rear_open_top_Z_mm=180.,rear_open_max_radius_mm=16.1)
    cyl=manifold.Manifold.cylinder(16.5,16.1,16.1,256).translate([0,0,163.5])
    rear=manifold.Manifold.cube([40.,22.5,16.5]).translate([-20.,-30.,163.5])
    cutter=cyl^rear;candidate=quantize((full-cutter).simplify(cleanup),cleanup)
    added=candidate-old;removed=old-candidate
    assert candidate.status()==manifold.Error.NoError and candidate.volume()>0 and len(candidate.decompose())==1
    def save(name,m):
        mesh=m.to_mesh64();np.savez_compressed(out/(name+'_mesh.npz'),vertices_mm=np.asarray(mesh.vert_properties)[:,:3],triangles=np.asarray(mesh.tri_verts))
    for name,m in [('candidate',candidate),('full',full),('cutter',cutter),('added',added),('removed',removed),('inner',inner),('outer',outer)]:save(name,m)
    symmetric=lambda a,b:float((a-b).volume()+(b-a).volume())
    replay=dict(raw_to_saved_baseline_difference_mm3=symmetric(baseline,old),
                cleanup_mm=cleanup,source='neck_capacity.construct + existing float32 write/cleanup/write pipeline',
                tolerance_not_changed=True,status='PASS' if symmetric(baseline,old)<.005 else 'BLOCKED')
    entry=[]
    moving=ctx.ss['Yaw_Reaction_Link'].m
    for z in np.linspace(-100.,0.,201):
        m=moving.translate([0,0,float(z)]);gap=float(m.min_gap(candidate,.6001));vol=float((m^candidate).volume())
        entry.append(dict(delta_Z_mm=float(z),gap_capped_mm=gap,overlap_mm3=vol))
    motion=[]
    for pitch in range(-20,26,5):
        tr=np.asarray(rigidtr(0,pitch));s=ctx.ss['Head_Rear'].m.transform(tr[:3,:])
        motion.append(dict(pitch_deg=pitch,overlap_mm3=float((candidate^s).volume()),gap_capped_mm=float(candidate.min_gap(s,2.))))
    # Full mesh comparisons against the native shell retain pre-existing
    # contacts; every runtime yaw still needs a separate complete regression.
    (out/'proposal.json').write_text(json.dumps(dict(status='CANDIDATE',approved=False,main_changed=False,
        original_parameter=q0['candidate_parameters']['neck_profile']['reference_reaction_bore_r_mm'],
        proposed_neck_parameters=parameters,changed_existing_parts=['Pitch_Yoke'],new_parts=[],retired_parts=[],
        physical_strength='NOT_TESTED',manufacturing_release=False),indent=2)+'\n')
    ctx.unchanged()
    result=dict(status='PASS' if replay['status']=='PASS' and all(r['gap_capped_mm']>=.3 and r['overlap_mm3']<1e-5 for r in entry) and all(r['gap_capped_mm']>=.3 and r['overlap_mm3']<1e-5 for r in motion) else 'BLOCKED',
        scope='Source-derived independent open-neck topology, sampled bare-print entry and rear-shell pitch checks only',
        sources=ctx.sources,parameters=parameters,source_replay=replay,category='PRINTABLE',data_status='ASSUMED',
        connected_components=len(candidate.decompose()),mesh_error=str(candidate.status()),
        original_volume_mm3=float(old.volume()),candidate_volume_mm3=float(candidate.volume()),added_mm3=float(added.volume()),removed_mm3=float(removed.volume()),
        part_count_change=0,fastener_count_change=0,wire_allocations_changed=False,
        entry_samples=entry,rear_shell_pitch_samples=motion,main_changed=False,hardware_changed=False,approved=False,
        actual_horn_and_fasteners='BLOCKED: deferred to arrival',physical_strength='NOT_TESTED',manufacturing_release=False,elapsed_s=time.time()-started)
    (out/'review.json').write_text(json.dumps(result,indent=2)+'\n')
    print('OPEN_NECK_SOURCE_REPLAY',replay,flush=True)
    print('OPEN_NECK_ENTRY_MIN',min(r['gap_capped_mm'] for r in entry),flush=True)
    print('OPEN_NECK_REAR_PITCH',motion,flush=True)
    print('OPEN_NECK_DONE',result['status'],result['elapsed_s'],flush=True)
if __name__=='__main__':main()
