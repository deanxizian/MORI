"""Bounded deterministic bare-print order search on unchanged M1.54 solids.

Search translation plus inclination in one plane, then try withdrawal along
the link's own axis. This is only a static candidate search, never a proof of
all possible orders or complete hardware installation. The yoke is detached
and empty at this bench stage; runtime joint limits are not changed.
"""
from pathlib import Path
import sys,json,time,heapq,itertools,math
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'))
from current_context import Context,np

GAP=.3
def main():
    started=time.time();ctx=Context();ctx.record([Path(__file__)])
    link=ctx.ss['Yaw_Reaction_Link'].m;fixture=ctx.ss['Pitch_Yoke'].m
    out=HERE/'composite_R1';out.mkdir(exist_ok=True)
    pivot=161.;studies=[];accepted=None
    for axis in ['Y','X']:
        index=0 if axis=='Y' else 1;cache={};count=0;edge_checks=0
        def rotation(deg):
            a=math.radians(deg);c=math.cos(a);s=math.sin(a)
            return np.array([[c,0,s],[0,1,0],[-s,0,c]]) if axis=='Y' else np.array([[1,0,0],[0,c,-s],[0,s,c]])
        def pose(state):
            lateral,z,angle=state;R=rotation(angle);t=np.array([0.,0.,pivot+z])-R@np.array([0.,0.,pivot]);t[index]+=lateral
            return np.c_[R,t]
        def checked(state):
            nonlocal count
            key=tuple(round(float(v),9) for v in state)
            if key in cache:return cache[key]
            moved=link.transform(pose(state).tolist())
            gap=float(moved.min_gap(fixture,.6001));overlap=float((moved^fixture).volume())
            row=dict(state_mm_deg=list(key),gap_capped_mm=gap,overlap_mm3=overlap,clear=bool(gap>=GAP and overlap<1e-5))
            cache[key]=row;count+=1
            return row
        def connection(a,b):
            nonlocal edge_checks
            edge_checks+=1
            for alpha in [.25,.5,.75]:
                row=checked((1-alpha)*np.asarray(a)+alpha*np.asarray(b))
                if not row['clear']:return False
            return True
        def full_exit(states):
            last=states[-1];bb=np.asarray(link.transform(pose(last).tolist()).bounding_box())
            return bool(np.any(bb[:3]>ctx.ss['Pitch_Yoke'].hi+.3) or np.any(bb[3:]<ctx.ss['Pitch_Yoke'].lo-.3))
        def escape(state):
            lateral,z,angle=state;d=rotation(angle)[:,2];states=[np.asarray(state,float)]
            for travel in np.arange(2.,122.,2.):
                next_state=np.array([lateral+d[index]*travel,z+d[2]*travel,angle])
                if not checked(next_state)['clear'] or not connection(states[-1],next_state):return None
                states.append(next_state)
                if full_exit(states):return states
            return None
        origin=(0,0,0);queue=[(0.,0.,origin)];cost={origin:0.};parent={};visited=set();goal=None;escape_states=None
        neighbours=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
        # Small diagonal steps avoid interpreting only a fixed-pivot turn as
        # representative of a coupled translation/inclination order.
        neighbours +=[(dx,dz,dt) for dx,dz,dt in itertools.product([-1,0,1],repeat=3)
                     if abs(dx)+abs(dz)+abs(dt)==2]
        expanded=0
        while queue and expanded<3500 and count<16000:
            _,g,node=heapq.heappop(queue)
            if node in visited:continue
            visited.add(node);expanded+=1
            state=np.array([node[0]*.75,node[1]*1.,node[2]*3.])
            if state[1]>=8. and abs(state[2])>=6.:
                trial=escape(state)
                if trial is not None:goal=node;escape_states=trial;break
            for dx,dz,dt in neighbours:
                nxt=(node[0]+dx,node[1]+dz,node[2]+dt)
                if not (-14<=nxt[0]<=14 and -15<=nxt[1]<=32 and -12<=nxt[2]<=12):continue
                if nxt in visited:continue
                q=np.array([nxt[0]*.75,nxt[1]*1.,nxt[2]*3.])
                ng=g+float(np.linalg.norm((q-state)*[1,1,.7]))
                if ng>=cost.get(nxt,1e12):continue
                if not checked(q)['clear'] or not connection(state,q):continue
                cost[nxt]=ng;parent[nxt]=node
                # Prioritize upward progress, but retain below-start states.
                h=max(0.,18.-q[1])*.5
                heapq.heappush(queue,(ng+h,ng,nxt))
            if expanded%300==0:print('COMPOSITE_SEARCH',axis,expanded,count,len(queue),round(time.time()-started,2),flush=True)
        candidate=None
        if goal is not None:
            graph=[goal]
            while graph[-1]!=origin:graph.append(parent[graph[-1]])
            graph.reverse()
            states=np.array([[n[0]*.75,n[1]*1.,n[2]*3.] for n in graph]+[q.tolist() for q in escape_states[1:]])
            assert np.array_equal(states[0],[0,0,0]) and full_exit(states)
            candidate=dict(axis=axis,pivot_z_mm=pivot,poses=states.tolist(),pose_count=len(states),
                maximum_inclination_deg=float(abs(states[:,2]).max()),
                state_definition='lateral translation on X for Y inclination, or Y for X inclination; world Z shift; rotation about fixed Z161 pivot',
                end_AABB_separated=True,scope='Static states and quarter-step checks only')
            np.savez_compressed(out/'sampled_candidate.npz',states=states,matrices=np.array([pose(q) for q in states]))
        study=dict(axis=axis,status='PASS' if candidate else 'BLOCKED',expanded_nodes=expanded,evaluated_poses=count,
            edge_quarter_checks=edge_checks,frontier_remaining=len(queue),search_limits=dict(lateral_mm=[-10.5,10.5],Z_mm=[-15,32],inclination_deg=[-36,36]),
            finite_search_only=True,complete_candidate=candidate,static_pose_checks=list(cache.values()))
        studies.append(study)
        print('COMPOSITE_SEARCH_RESULT',axis,study['status'],expanded,count,flush=True)
        if candidate:accepted=candidate;break
    ctx.unchanged()
    result=dict(status='PASS' if accepted else 'BLOCKED',scope='Finite planar bare-print manipulation candidate search, not continuous motion or full assembly',
        sources=ctx.sources,studies=studies,accepted=accepted,required_nominal_gap_mm=GAP,
        fixture=['Pitch_Yoke'],moving=['Yaw_Reaction_Link'],
        absent_by_sequence=['Body bridge','Servos and bearings','Head/electronics/shells','All wiring'],
        horn_or_fasteners_included=False,continuous_motion='NOT_TESTED',hand_access='NOT_TESTED',
        complete_initial_assembly='BLOCKED',runtime_joint_range_changed=False,main_changed=False,hardware_changed=False,
        manufacturing_release=False,elapsed_s=time.time()-started)
    (out/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('COMPOSITE_PLAN_DONE',result['status'],result['elapsed_s'],flush=True)
if __name__=='__main__':main()
