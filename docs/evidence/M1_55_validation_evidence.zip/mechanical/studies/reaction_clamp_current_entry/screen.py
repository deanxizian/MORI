"""Read-only current bench-entry screen; no horn/fastener qualification."""
from pathlib import Path
import json,sys,time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'))
from current_context import Context,np

def main():
    started=time.time();ctx=Context();ctx.record([Path(__file__)])
    fixture=ctx.ss['Pitch_Yoke'];variants=[]
    sets=[('bare_print',['Yaw_Reaction_Link']),
        ('clamp_fasteners',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut']),
        ('horn_allocation',['Yaw_Reaction_Link','Yaw_Reaction_Clamp_Screw','Yaw_Reaction_Clamp_Nut','Yaw_Horn'])]
    for name,names in sets:
        for direction in [1.,-1.]:
            rows=[]
            for lift in np.r_[0.,np.arange(.5,81.,.5)]:
                bad=[];minimum=.6
                for n in names:
                    moved=ctx.ss[n].m.translate([0,0,float(direction*lift)])
                    overlap=float((moved^fixture.m).volume())
                    gap=float(moved.min_gap(fixture.m,.6))
                    minimum=min(minimum,gap)
                    if overlap>1e-5 or gap<.3:
                        bad.append(dict(part=n,overlap_mm3=overlap,gap_mm=gap))
                row=dict(lift_mm=float(direction*lift),status='BLOCKED' if bad else 'PASS',minimum_gap_capped_mm=minimum,failures=bad)
                rows.append(row)
                if bad:break
            variant=dict(name=name,moving=names,direction_Z=int(direction),scope='Static samples only',
                status='PASS' if len(rows)==161 and not any(r['failures'] for r in rows) else 'BLOCKED',
                samples=rows,first_failure=next((r for r in rows if r['failures']),None))
            variants.append(variant);print('REACTION_ENTRY_SAMPLE',name,direction,variant['status'],rows[-1],flush=True)
    ctx.unchanged()
    result=dict(status='NOT_TESTED',scope='Current M1.54 vertical bench-entry static samples; no complete assembly qualification',
        sources=ctx.sources,fixture=['Pitch_Yoke'],variants=variants,
        absent_by_sequence=['Yaw/Pitch servos and their fasteners','Pitch/yaw bearings','Body bridge','Head cradle/optics/PCB/shells','All wiring'],
        part_properties={n:{k:ctx.ss[n].o.get(k) for k in ['part_type','interface_status','model_fidelity']} for n in set(sum([v[1] for v in sets],[]))},
        required_nominal_gap_mm=.3,continuous_motion='NOT_TESTED',complete_initial_assembly='BLOCKED',
        horn_stack='BLOCKED: user deferred SC-0090-C001 accessory dimensions to arrival',
        main_changed=False,hardware_changed=False,manufacturing_release=False,elapsed_s=time.time()-started)
    (HERE/'screen.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('REACTION_ENTRY_SCREEN_DONE',result['elapsed_s'],flush=True)
if __name__=='__main__':main()
