"""Publish only verified R2 prototype geometry, with explicit pending approval."""
from pathlib import Path
import json,hashlib,html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as PlotPath
from matplotlib.patches import PathPatch
from matplotlib.font_manager import fontManager,FontProperties

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OUT=HERE/'neck_core_open_R2'
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
v=json.loads((OUT/'verification.json').read_text());r=json.loads((OUT/'render_manifest.json').read_text())
assert v['status']=='PASS' and r['status']=='PASS'
for data in [v,r]:
    assert all(digest(p)==h for p,h in data['sources'].items())
for entry in r['files']:assert digest(OUT/entry['file'])==entry['sha256']
s=json.loads((OUT/'sections.json').read_text())
font=Path('/System/Library/Fonts/STHeiti Medium.ttc');fontManager.addfont(str(font))
plt.rcParams.update({'font.family':FontProperties(fname=str(font)).get_name(),'axes.unicode_minus':False,'font.size':11})
def draw(ax,polygons,color,zorder=1,alpha=1):
    vertices=[];codes=[]
    for poly in polygons:
        a=np.asarray(poly);vertices.extend(a.tolist()+[a[0].tolist()]);codes.extend([PlotPath.MOVETO]+[PlotPath.LINETO]*(len(a)-1)+[PlotPath.CLOSEPOLY])
    if vertices:ax.add_patch(PathPatch(PlotPath(vertices,codes),facecolor=color,edgecolor=color,linewidth=.45,zorder=zorder,alpha=alpha))
fig,axes=plt.subplots(1,3,figsize=(14.4,5.5),constrained_layout=True)
for ax in axes:
    ax.set_xlim(-24,24);ax.set_ylim(148,187);ax.set_aspect('equal');ax.grid(alpha=.18);ax.set_xlabel('Y（mm，左为机器人后方）');ax.set_ylabel('Z（mm）')
draw(axes[0],s['current'],'#a7b3b8');draw(axes[0],s['reaction_entry'],'#c2a878',2);draw(axes[0],s['current_entry_overlap'],'#ef574d',3)
axes[0].set_title('当前模型：夹头不能直接穿过颈管',fontweight='bold',pad=14)
axes[0].text(-22,185,'裸反力轴下移 17 mm\n红色为此剖面的真实相交',va='top',fontsize=10,color='#8d332c',bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=5),zorder=5)
draw(axes[1],s['candidate'],'#408fa5');draw(axes[1],s['reaction_entry'],'#c2a878',2)
axes[1].set_title('独立候选：孔道扩大，后壁开放',fontweight='bold',pad=14)
axes[1].text(-22,185,'同一反力轴、同一位置\n连续装入净距下界 ≥ 0.3 mm',va='top',fontsize=10,color='#225d70',bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=5),zorder=5)
draw(axes[2],s['candidate'],'#408fa5');draw(axes[2],s['reaction_final'],'#c2a878',2);draw(axes[2],s['rear_shell_pitch25'],'#adb0bc',3)
axes[2].set_title('候选：仰头 25° 时后壳可以通过',fontweight='bold',pad=14)
axes[2].text(-22,185,'灰色为后头壳下缘\n完整俯仰区间的壳体净距下界 ≥ 0.3 mm',va='top',fontsize=10,color='#394653',bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=5),zorder=5)
fig.suptitle('M1.54 颈部装入候选 R2｜X = 0 真实剖面｜未进入主模型',fontsize=16,fontweight='bold')
fig.savefig(OUT/'section_comparison.png',dpi=155);fig.savefig(OUT/'section_comparison.svg');plt.close(fig)
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.54 颈部装入候选 R2</title><style>
*{box-sizing:border-box}body{margin:0;background:#f2f5f6;color:#23333d;font:16px/1.65 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}main{max-width:1160px;margin:auto;padding:34px 24px 70px}h1{font-size:28px;line-height:1.3}h2{font-size:21px;margin-top:34px}.badge{display:inline-block;padding:4px 10px;border-radius:7px;background:#fff0ce;color:#7b4a02}.note{background:#fff;border-left:5px solid #d1a450;padding:14px 18px;margin:20px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}figure{margin:0;background:white;padding:12px;border-radius:10px}img{width:100%;height:auto;display:block}figcaption{padding:10px 4px;font-size:15px}table{border-collapse:collapse;width:100%;background:white}th,td{text-align:left;padding:12px;border-bottom:1px solid #dee7eb}a{color:#176780}code{overflow-wrap:anywhere}@media(max-width:760px){.grid{grid-template-columns:1fr}main{padding:24px 14px}}
</style><main><span class="badge">独立候选 · 需要用户确认 · PROTOTYPE / UNVALIDATED</span><h1>反力夹可以装入，同时保留完整头部运动范围</h1><p>2026-10-09 · 当前主模型仍为 M1.54。此前仅扩孔的 R1 会在仰头 25° 时碰到后头壳，已否决。R2 保留前侧和两侧颈壁，后侧做开放轮廓；没有采用到主模型。</p>
<div class="note"><strong>改动范围：</strong>只改现有 <code>Pitch_Yoke</code> 一件打印件。通道基础半径从 7.7 mm 改为 12.35 mm；颈壁后侧从 Z163.5 mm 起开放。内部孔道包括轴承座内侧，因此该处内部材料会减少；<strong>轴承配合外圆、上部舵机座、孔轴和所有硬件位置保持</strong>。不增加打印件或螺钉。所有尺寸是数字模型设计值，强度仍需 PA12 试打。</div>
<figure><img src="section_comparison.png" alt="当前与候选颈部装入和仰头真实剖面对比"><figcaption>这是精确网格在 X=0 的剖面，不是透视照片。红色相交属于当前模型裸反力轴装入检查；棕色反力轴只为示意装入位置下移。</figcaption></figure>
<h2>后侧外形对比</h2><div class="grid"><figure><img src="current_entry.png" alt="当前颈管后侧"><figcaption>当前：颈管围住夹头，直接装入受阻。</figcaption></figure><figure><img src="candidate_entry.png" alt="候选颈管后侧开放轮廓"><figcaption>候选：内孔扩大，后侧开放以避让运动的后壳下缘。</figcaption></figure></div>
<div class="grid" style="margin-top:18px"><figure><img src="candidate_overview.png" alt="候选头托完整外形"><figcaption>候选整体；上部座和双侧支撑保持，仍是一个连续实体。</figcaption></figure><figure><img src="candidate_pitch25.png" alt="候选与仰头25度的后壳"><figcaption>仰头 25° 时后壳与候选；连续转动检查覆盖低头 20° 到仰头 25°。</figcaption></figure></div>
<h2>已经核对的数字几何</h2><table><tr><th>检查</th><th>结果与边界</th></tr>
<tr><td>与参数构造一致</td><td>PASS；候选重新构造差为 0 mm³。当前源重放差约 0.0000823 mm³，未更改 0.005 mm³ 对照阈值。</td></tr>
<tr><td>裸反力轴从下方装入</td><td>PASS；100 mm 行程、294 个连续区间，净距下界 ≥0.3 mm。试配螺钉和占位舵盘另有相同范围检查，不能据此确认实发配件。</td></tr>
<tr><td>头壳完整俯仰</td><td>PASS；前后壳分别 32／35 个连续区间，−20°～+25°，净距下界 ≥0.3 mm。共享刚性偏航变换保持该距离。</td></tr>
<tr><td>现有零件的运动回归</td><td>PASS；130 个偏航／俯仰姿态，与其他 200 个当前原生零件复核，没有新增材料干涉；有限采样，不是任意整机连续运动证明。</td></tr>
<tr><td>保留颈壁</td><td>PASS；保留侧壁两向采样最小约 2.23 mm。轴承座 3,960 条径向采样最小约 2.35 mm；开放端缘和全局强度 NOT_TESTED。</td></tr>
<tr><td>当前 11 根局部参考线</td><td>PASS；参考曲线未改，143 个局部距离检查通过；完整线束仍 BLOCKED。</td></tr>
<tr><td>压板及身体移入</td><td>PASS；121 个压板侧移、181 个身体竖向移入样本，改变的头托未新增相交；手、真实线束和完整舵盘初装仍未确认。</td></tr>
<tr><td>主模型与硬件源</td><td>保持原文件哈希；未采用候选，未输出制造数据。</td></tr></table>
<h2>尚未确认</h2><p>SC-0090-C001 实发舵盘／花键／中心锁紧按用户决定等到货后核对。完整带线装配、真实工具与手操作、PA12 开放颈壁刚度、疲劳及强度均未完成。本页的 PASS 只限于列出的数字几何，不等于可以打样放行。</p>
<p><a href="verification.json">详细复核</a> · <a href="proposal.json">候选参数</a> · <a href="journal_verification.json">轴承座壁厚与配合面</a> · <a href="verification_initial_full_journal_criterion.json">初次轴承座判据与修正记录</a> · <a href="render_manifest.json">图像来源</a> · <a href="../index.html">当前模型装入诊断</a> · <a href="../../../../docs/CURRENT_STATUS.md">项目当前状态</a></p></main></html>'''
(OUT/'index.html').write_text(page,encoding='utf-8')
readme='''# M1.54 颈部装入候选 R2

2026-10-09 · 独立候选，未采用 · PRINTABLE / ASSUMED · PROTOTYPE / UNVALIDATED

仅扩大 Pitch_Yoke 内部通道并开放后侧颈壁，不增加打印件或紧固件。轴承配合外圆、上部座、所有硬件位置不变；轴承座内部通道扩大，199.28 mm³ 内部材料变化属于候选范围，不声称整个轴承座不变。

数字几何通过：与当前参数构造一致、100 mm 连续裸反力轴装入、完整壳体俯仰区间、130 个组合姿态新增材料回归、保留侧壁及轴承座径向壁厚、11 根局部参考线、有限压板侧移和身体移入。具体边界见 verification.json 和 index.html。

初次复核错误地要求扩大孔道时整个下部轴承座仍保持不变；原 BLOCKED 记录保留在 verification_initial_full_journal_criterion.json。补充复核明确区分外配合面与内部孔道，外配合面差为 0 的数值量级，3,960 条径向采样最小约 2.35 mm。数值对照阈值未放宽，候选几何未变。

所有曲率、孔位、装入是模型证据；真实舵盘和锁紧、手操作、完整线束、开放处刚度／强度／疲劳 NOT_TESTED，manufacturing_release=false。用户确认前不能覆盖主模型或 geometry.json。
'''
(OUT/'README.md').write_text(readme,encoding='utf-8')
commands=[
    dict(command='/Applications/Blender.app/Contents/MacOS/Blender --background mechanical/mori_v1_2.blend --python-exit-code 1 --python mechanical/studies/reaction_clamp_current_entry/neck_core_open_candidate.py',log='../neck_core_open_candidate.log',result='PASS: bounded initial checks'),
    dict(command='/Applications/Blender.app/Contents/MacOS/Blender --background mechanical/mori_v1_2.blend --python-exit-code 1 --python mechanical/studies/reaction_clamp_current_entry/verify_neck_core_open.py',log='../verify_neck_core_open.log',result='First attempt import error archived; corrected import, engineering BLOCKED on full-journal criterion; original report preserved'),
    dict(command='/Applications/Blender.app/Contents/MacOS/Blender --background mechanical/mori_v1_2.blend --python-exit-code 1 --python mechanical/studies/reaction_clamp_current_entry/verify_neck_journal.py',log='../verify_neck_journal.log',result='PASS: fit-skin/backing supplemental scope correction, geometry unchanged; combined prototype status PASS'),
    dict(command='/Applications/Blender.app/Contents/MacOS/Blender --background mechanical/mori_v1_2.blend --python-exit-code 1 --python mechanical/studies/reaction_clamp_current_entry/render_neck_core_open.py',log='../render_neck_core_open.log',result='PASS: exact-mesh renders and sections; display-normal pass only'),
    dict(command='/Users/dean/.cache/codex-runtimes/mori-cad/bin/python mechanical/studies/reaction_clamp_current_entry/publish_neck_core_open.py',result='First attempt font path unavailable and archived; system STHeiti selected; PASS: diagrams and review page'),
    dict(command='/Users/dean/.cache/codex-runtimes/mori-cad/bin/python mechanical/studies/reaction_clamp_current_entry/verify_neck_core_delivery.py',log='../verify_neck_core_delivery.log',result='PASS: 14 exact local HTTP files and 12 relative links; browser visual review NOT_TESTED')]
(OUT/'commands.json').write_text(json.dumps(dict(blender_version='5.2.2 LTS d13f752e3b9c',python_runtime='/Users/dean/.cache/codex-runtimes/mori-cad/bin/python',commands=commands,
    goal_turn_classification='progress',goal_turn_evidence='New source-derived candidate, continuous bare-print/shell checks, retained-wall/130-pose/transfer regression and review artifacts; main adoption awaits required user confirmation.',
    main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
protected={p:digest(ROOT/p) for p in ['mechanical/mori_v1_2.blend','config/geometry.json','contracts/components.json']}
sources={**v['sources'],**r['sources'],str(Path(__file__)):digest(Path(__file__))}
manifest=dict(status='PASS',scope='Source/hash and publication audit only; engineering scope separately in verification.json',sources=sources,
    files={p.name:digest(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['publication.json','delivery.json']},
    protected_sources=protected,main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False)
assert all(digest(p)==h for p,h in sources.items())
(OUT/'publication.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('R2_PUBLICATION_PASS',len(manifest['files']),len(sources))
