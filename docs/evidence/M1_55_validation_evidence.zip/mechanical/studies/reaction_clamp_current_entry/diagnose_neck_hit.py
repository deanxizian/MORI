"""Locate the added-neck/rear-head witness before proposing any shell edits."""
from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np
from common import P,D,manifold
from validate import rigidtr

ctx=Context();out=HERE/'neck_core_R1';ctx.record([Path(__file__),out/'candidate_mesh.npz'])
data=np.load(out/'candidate_mesh.npz');candidate=manifold.Manifold(manifold.Mesh64(data['vertices_mm'],data['triangles'].astype(np.uint64)))
added=candidate-ctx.ss['Pitch_Yoke'].m
head=ctx.ss['Head_Rear'];tr=np.asarray(rigidtr(0,25))
posed=head.m.transform(tr[:3,:]);common=added^posed
mesh=common.to_mesh64();v=np.asarray(mesh.vert_properties)[:,:3]
native=v@np.linalg.inv(tr)[:3,:3].T+np.linalg.inv(tr)[:3,3]
radii=np.linalg.norm(head.v-[0,0,D['head_z']],axis=1)
result=dict(status='PASS',scope='Contact-location and source-coordinate audit only',sources=ctx.sources,
    nominal_head_radius_mm=D['head_radius'],nominal_head_pivot_Z_mm=D['head_z'],nominal_head_bottom_Z_mm=D['head_z']+P['head_lower_opening_z_from_center_mm'],
    current_head_bounds_mm=[head.lo.tolist(),head.hi.tolist()],head_volume_mm3=float(head.m.volume()),
    current_head_radius_min_max_mm=[float(radii.min()),float(radii.max())],
    vertices_near_nominal_outer_sphere=int(np.count_nonzero(abs(radii-D['head_radius'])<.01)),
    vertices_near_nominal_inner_sphere=int(np.count_nonzero(abs(radii-(D['head_radius']-P['shell_thickness_mm']))<.01)),
    current_head_world_matrix=np.asarray(head.o.matrix_world).tolist(),parent=head.o.parent.name if head.o.parent else None,
    current_head_parent_world_matrix=np.asarray(head.o.parent.matrix_world).tolist() if head.o.parent else None,
    relevant_properties={k:head.o.get(k) for k in ['assembly_location','assembly_rotation','assembly_parent','mori_owner','group','model_fidelity']},
    added_bounds_mm=list(added.bounding_box()),witness_overlap_mm3=float(common.volume()),witness_posed_bounds_mm=list(common.bounding_box()),
    witness_native_bounds_mm=[native.min(axis=0).tolist(),native.max(axis=0).tolist()],
    witness_native_radius_min_max_mm=[float(np.linalg.norm(native-[0,0,D['head_z']],axis=1).min()),float(np.linalg.norm(native-[0,0,D['head_z']],axis=1).max())],
    main_changed=False,hardware_changed=False,manufacturing_release=False)
ctx.unchanged();(out/'rear_hit_location.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('REAR_CONTACT_COORDINATES',{k:x for k,x in result.items() if k not in ['sources','relevant_properties','current_head_parent_world_matrix']},flush=True)
