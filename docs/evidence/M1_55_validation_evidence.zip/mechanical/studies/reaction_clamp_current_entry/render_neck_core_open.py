"""Exact-mesh R2 review renders and sections, offline with no main-file save."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'mechanical/studies/harness_current_M1_54/cam_upper_reroute'),str(ROOT/'mechanical/scripts')]
from current_context import Context,np,sha
from common import bpy,manifold,Vector,P
from validate import rigidtr
from head_surface_display import planar_directions

ctx=Context();out=HERE/'neck_core_open_R2';ctx.record([Path(__file__),out/'candidate_mesh.npz',out/'proposal.json'])
d=np.load(out/'candidate_mesh.npz');candidate=manifold.Manifold(manifold.Mesh64(d['vertices_mm'],d['triangles'].astype(np.uint64)))
old=ctx.ss['Pitch_Yoke'].m;link=ctx.ss['Yaw_Reaction_Link'].m
scene=bpy.data.scenes.new('MORI_RJ_R2_REVIEW');bpy.context.window.scene=scene
scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1050;scene.render.resolution_y=850
scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL';scene.display.shading.show_shadows=False
scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
scene.world=bpy.data.worlds.new('MORI_RJ_R2_WORLD');scene.world.color=(.095,.11,.13)
cd=bpy.data.cameras.new('MORI_RJ_R2_CAMERA');camera=bpy.data.objects.new('MORI_RJ_R2_CAMERA',cd);scene.collection.objects.link(camera)
cd.type='ORTHO';cd.clip_start=.1;cd.clip_end=1000;scene.camera=camera
materials={}
for key,color in [('current',(.59,.64,.66,1)),('candidate',(.18,.48,.57,1)),('link',(.79,.77,.67,1)),('overlap',(.95,.14,.08,1)),('shell',(.79,.81,.81,1))]:
    m=bpy.data.materials.new('MORI_RJ_R2_'+key);m.diffuse_color=color;materials[key]=m
created=[]
def draw(name,m,key):
    if m.is_empty():return
    d=m.to_mesh64();mesh=bpy.data.meshes.new('MORI_RJ_R2_'+name);mesh.from_pydata(np.asarray(d.vert_properties)[:,:3].tolist(),[],np.asarray(d.tri_verts).tolist())
    mesh.materials.append(materials[key]);o=bpy.data.objects.new('MORI_RJ_R2_'+name,mesh);o['mori_owner']='reaction_clamp_current_entry_R2';scene.collection.objects.link(o);created.append(o)
    # Reuse the approved head-print display policy without running its report
    # writer or touching native objects. Validation vertices remain unchanged.
    mesh.update();directions=planar_directions('Pitch_Yoke' if name=='yoke' else '')
    s=P['head_surface_display'];tolerance=__import__('math').radians(s['planar_alignment_tolerance_deg'])
    threshold=__import__('math').cos(tolerance)
    flat=[max(abs(p.normal.dot(n)) for n in directions)>=threshold for p in mesh.polygons]
    edge_faces=[[] for _ in mesh.edges]
    for polygon,is_flat in zip(mesh.polygons,flat):
        polygon.use_smooth=not is_flat
        for k in polygon.loop_indices:edge_faces[mesh.loops[k].edge_index].append(polygon.index)
    angle=__import__('math').radians(s['sharp_edge_angle_deg'])
    for edge,fs in zip(mesh.edges,edge_faces):
        if len(fs)!=2:continue
        a,b=fs;difference=mesh.polygons[a].normal.angle(mesh.polygons[b].normal,0)
        if difference>angle or ((flat[a] or flat[b]) and difference>tolerance):edge.use_edge_sharp=True
    mesh.update();normals=[n.vector[:] for n in mesh.corner_normals]
    for polygon,is_flat in zip(mesh.polygons,flat):
        if is_flat:
            for k in polygon.loop_indices:normals[k]=polygon.normal[:]
    mesh.normals_split_custom_set(normals);mesh.update()
def clear():
    for o in created:
        assert o.get('mori_owner')=='reaction_clamp_current_entry_R2';mesh=o.data;bpy.data.objects.remove(o,do_unlink=True);bpy.data.meshes.remove(mesh)
    created.clear()
files=[]
for name,which,shift,with_shell,loc,target,scale in [
    ('current_entry',old,-17.,False,(65,-90,195),(0,-3,171.5),47.),
    ('candidate_entry',candidate,-17.,False,(65,-90,195),(0,-3,171.5),47.),
    ('candidate_overview',candidate,0.,False,(108,-138,283),(0,-9,190),105.),
    ('candidate_pitch25',candidate,0.,True,(93,-145,206),(0,-3,166),55.)]:
    clear();draw('yoke',which,'current' if which is old else 'candidate');moved=link.translate([0,0,shift]);draw('link',moved,'link')
    if which is old:draw('collision',moved^which,'overlap')
    if with_shell:
        tr=np.asarray(rigidtr(0,25));m=ctx.ss['Head_Rear'].m.transform(tr[:3,:]);draw('rear_shell',m,'shell')
    camera.location=loc;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();cd.ortho_scale=scale
    scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
    files.append(dict(file=name+'.png',sha256=sha(out/(name+'.png')),reaction_link_translation_Z_mm=shift,head_pitch_deg=25 if with_shell else 0,
                      axes='+X right, +Y front, +Z up',candidate_adopted=False))
def section(m):
    # Rotate Y=-90: X'= -Z, Y'=Y, Z'=X; exact slice at native X=0.
    return [np.c_[np.asarray(p)[:,1],-np.asarray(p)[:,0]].tolist() for p in m.rotate([0,-90,0]).slice(0.).to_polygons()]
shell=ctx.ss['Head_Rear'].m.transform(np.asarray(rigidtr(0,25))[:3,:])
sections=dict(section_X_mm=0.,coordinates='native Y,Z mm',
              current=section(old),candidate=section(candidate),reaction_final=section(link),reaction_entry=section(link.translate([0,0,-17.])),
              current_entry_overlap=section(old^link.translate([0,0,-17.])),rear_shell_pitch25=section(shell))
(out/'sections.json').write_text(json.dumps(sections,indent=2)+'\n')
ctx.unchanged();(out/'render_manifest.json').write_text(json.dumps(dict(status='PASS',scope='Exact prototype mesh rendering/section export only',sources=ctx.sources,files=files,
    normal_changes='display only',main_changed=False,hardware_changed=False,approved=False,manufacturing_release=False),indent=2)+'\n')
print('R2_RENDERS_DONE',len(files),flush=True)
