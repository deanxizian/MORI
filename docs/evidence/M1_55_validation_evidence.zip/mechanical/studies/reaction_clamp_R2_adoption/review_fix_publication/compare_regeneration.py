"""Read-only exact comparison against the saved pre-review M1.55 model."""
from pathlib import Path
import sys,hashlib,json
import bpy
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'mechanical/scripts'))
from common import parts,assembled,load_collections

def read(path):
    bpy.ops.wm.open_mainfile(filepath=str(path))
    bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly']
    load_collections();assembled()
    result={}
    for o in parts():
        vertices=np.empty(len(o.data.vertices)*3,dtype=np.float32);o.data.vertices.foreach_get('co',vertices)
        loops=np.empty(len(o.data.loops),dtype=np.int32);o.data.loops.foreach_get('vertex_index',loops)
        faces=np.empty(len(o.data.polygons),dtype=np.int32);o.data.polygons.foreach_get('loop_total',faces)
        h=hashlib.sha256(vertices.tobytes()+loops.tobytes()+faces.tobytes()).hexdigest()
        result[o.name]=dict(mesh_sha256=h,matrix_world=np.asarray(o.matrix_world).tolist(),group=o.get('group'),
                           classification={key:o[key] for key in ['category','data_status','verification_status','stage','export_candidate','interface_status']})
    return result

old=ROOT/'.state/m1_55_merge/before_regeneration/mechanical/mori_v1_2.blend'
new=ROOT/'mechanical/mori_v1_2.blend'
a=read(old);b=read(new)
changed=sorted(n for n in a.keys()&b.keys() if a[n]!=b[n])
result=dict(status='PASS' if a==b else 'FAIL',scope='Exact native part vertices, face topology, transforms and classification before and after review-only regeneration; no physical qualification',
    old_blend_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),current_blend_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),
    compared_parts=len(a),compared_classification_fields=['category','data_status','verification_status','stage','export_candidate','interface_status'],new_ids=sorted(b.keys()-a.keys()),removed_ids=sorted(a.keys()-b.keys()),changed_ids=changed,
    manufacturing_release=False)
(ROOT/'docs/review_evidence/M1_55_review_geometry_equivalence.json').write_text(json.dumps(result,indent=2)+'\n')
print('REVIEW_GEOMETRY_EQUIVALENCE',result)
assert result['status']=='PASS'
