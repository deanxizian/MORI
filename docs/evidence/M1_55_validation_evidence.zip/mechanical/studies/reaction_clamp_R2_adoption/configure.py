"""Apply only the user's approved R2 parameters and revision metadata."""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
p=ROOT/'config/geometry.json';q=json.loads(p.read_text());assert q['revision']=='V1.2-M1.54'
receipt=json.loads((HERE/'approval.json').read_text());assert receipt['approval']=='USER_APPROVED'
assert 'reaction_clamp_entry' not in q
q['revision']=receipt['new_revision']
q['reaction_clamp_entry']=dict(enabled=True,approved=True,revision=receipt['new_revision'],
    changed_existing_ids=['Pitch_Yoke'],new_ids=[],retired_ids=[],
    parameters=receipt['parameters'],construction=dict(segments=256,rear_cut_box_xy_mm=[[-20.,-30.],[20.,-7.5]]),
    approval='mechanical/studies/reaction_clamp_R2_adoption/approval.json',
    baseline='mechanical/input_assets/M1_55_reaction_entry_baseline.json',
    numerical_comparison_limit_mm3=.003,required_nominal_gap_mm=.3,retained_wall_reserve_mm=2.2,
    entry_Z_range_mm=[-100.,0.],
    numerical_edit_ROI=dict(radius_mm=16.2,z_mm=[148.68,180.08]),
    preserved_fit_skin=dict(inner_radius_mm=14.2,outer_probe_radius_mm=30.,z_mm=[148.99,156.]),
    classification='PRINTABLE / ASSUMED',
    limits='Bare-print entry only; actual SC-0090-C001 horn and locking deferred to arrival. Full wired assembly BLOCKED; open-rim PA12 stiffness/strength/fatigue NOT_TESTED; manufacturing_release=false.')
p.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n')
# Mechanical-owned handoff metadata; all purchased component fields remain.
contract=ROOT/'contracts/mechanical_interfaces.json';before=json.loads(contract.read_text());after=json.loads(json.dumps(before))
for key in ['mechanical_revision','current_geometry_revision']:
    if key in after:after[key]=q['revision']
after['reaction_clamp_entry']=dict(revision=q['revision'],geometry_source='config/geometry.json#/reaction_clamp_entry',
    changed_existing_ids=['Pitch_Yoke'],part_count_change=0,fastener_count_change=0,
    scope='Approved internal passage enlargement and open rear neck; bearing fit skin and servo datums retained.',
    bare_print_entry='PASS: reviewed prototype candidate; final saved-model recheck pending',
    actual_horn_and_locking='BLOCKED: deferred to arrival',full_wired_assembly='BLOCKED',physical_strength='NOT_TESTED',manufacturing_release=False)
contract.write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
(HERE/'configuration_receipt.json').write_text(json.dumps(dict(status='PASS',source='Direct user approval',
    changed_config_fields=['revision','reaction_clamp_entry'],
    mechanical_contract_changed_fields=[k for k in after if before.get(k)!=after[k]],
    component_contract_sha256=hashlib.sha256((ROOT/'contracts/components.json').read_bytes()).hexdigest(),
    manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('R2_CONFIGURED',q['revision'])
