"""Check R2 bench entry with earlier body parts retained despite shot visibility.

The animation hides the earlier body assembly to show the detached head seat.
Keep those objects at their saved transforms for this extra collision check;
do not turn an isolated camera shot into a claim of full wired assembly.
"""
from pathlib import Path
import sys, json, hashlib, time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from common import *
from validate import Solid
from assembly_animation import AP, SCENE_NAME
from validate_reaction_clamp_entry import translated_entry

start = time.time()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert P['revision'] == 'V1.2-M1.55'
source = ROOT / 'mori_v1_2.blend'
manifest = json.loads((ROOT / 'animation/manifest.json').read_text())
assert manifest['source_blend_sha256'] == sha(source)
scene = bpy.data.scenes['MORI_V1_Assembly']
bpy.context.window.scene = scene
load_collections()
for n in ['DATUMS', 'DOCK', 'KEEP_OUT', 'COUPONS']:
    COLS[n].hide_viewport = False
assembled()
bpy.context.view_layer.update()
solids = {o.name.removeprefix(PREFIX): Solid(o) for o in parts()
          if o.type == 'MESH' and o.get('group') not in ['dock', 'coupon']}
native = {n: s.o.matrix_world.copy() for n, s in solids.items()}
scene = bpy.data.scenes[SCENE_NAME]
bpy.context.window.scene = scene
actors = {o.name.removeprefix(AP): o for o in scene.objects if o.get('presentation_actor')}
stage = next(s for s in manifest['stages'] if s.get('source_step') == 10)
first = stage['start'] + round(.07 * (stage['end'] - stage['start']))
last = stage['start'] + round(.42 * (stage['end'] - stage['start']))
earlier = {n for n in solids if manifest['part_stages'][n] < stage['index']}
assert len(earlier) > 90
fixture_ids = earlier | {'Pitch_Yoke'}

def matrix(n):
    return np.asarray(actors[n].matrix_world @ native[n].inverted())

scene.frame_set(first)
bpy.context.view_layer.update()
fixed = {n: matrix(n) for n in fixture_ids}
bench = matrix('Pitch_Yoke')
rows = []
for frame in np.arange(first, last + .01, .5):
    scene.frame_set(int(frame), subframe=float(frame % 1))
    bpy.context.view_layer.update()
    error = max(float(np.max(abs(matrix(n) - fixed[n]))) for n in fixture_ids)
    assert error < .00005
    rows.append(dict(frame=float(frame), fixture_matrix_error_mm=error))
obstacles = manifold.Manifold.batch_boolean(
    [solids[n].m.transform(fixed[n][:3, :]) for n in fixture_ids], manifold.OpType.Add)
moving = solids['Yaw_Reaction_Link'].m.transform(bench[:3, :])
entry = translated_entry(moving, obstacles, -100., 0., P['reaction_clamp_entry']['required_nominal_gap_mm'])
result = dict(status=entry['status'], revision=P['revision'],
              source_blend_sha256=sha(source), animation_blend_sha256=sha(Path(bpy.data.filepath)),
              script_sha256=sha(Path(__file__)), entry_frame_range=[first, last],
              fixtures=sorted(fixture_ids), earlier_body_parts=len(earlier),
              matrix_readback_samples=len(rows), matrix_readback=rows,
              continuous_bare_entry=entry,
              scope='Detached bare reaction-link entry with all earlier rigid body parts retained at saved animation transforms, including parts hidden for the bench camera shot.',
              actual_horn_and_locking='BLOCKED', full_wired_assembly='BLOCKED',
              physical_hand_or_fixture='NOT_TESTED', manufacturing_release=False,
              elapsed_s=time.time()-start)
(HERE / 'bench_followup.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
assert entry['status'] == 'PASS', entry['first_failure']
print('R2_BENCH_FOLLOWUP_PASS', len(earlier), 'earlier body parts;', entry['interval_count'], 'continuous intervals', flush=True)
