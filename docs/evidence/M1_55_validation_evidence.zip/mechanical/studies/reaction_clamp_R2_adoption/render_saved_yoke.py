"""Render copies of the actual saved M1.55 objects; preserve source meshes."""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=ROOT.parent
sys.path.insert(0,str(ROOT/'scripts'))
from common import *
from validate import Solid
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=ROOT/'mori_v1_2.blend';digest=sha(source)
assert P['revision']=='V1.2-M1.55'
check=json.loads((ROOT/'reports/reaction_clamp_entry_validation.json').read_text());assert check['status']=='PASS' and check['source_blend_sha256']==digest
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for n in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:COLS[n].hide_viewport=False
assembled();bpy.context.view_layer.update()
scene=bpy.data.scenes.new('MORI_R2_ADOPTED_REVIEW');bpy.context.window.scene=scene
scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=1200;scene.render.resolution_y=950;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.display.shading.light='STUDIO';scene.display.shading.color_type='MATERIAL';scene.display.shading.show_shadows=False
scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH';scene.display.shading.background_type='WORLD'
scene.world=bpy.data.worlds.new('MORI_R2_ADOPTED_WORLD');scene.world.color=(.085,.10,.12)
cam_data=bpy.data.cameras.new('MORI_R2_ADOPTED_CAMERA');cam=bpy.data.objects.new('MORI_R2_ADOPTED_CAMERA',cam_data);scene.collection.objects.link(cam)
cam_data.type='ORTHO';cam_data.clip_start=.1;cam_data.clip_end=1000;scene.camera=cam
created=[];files=[]
for file,shift,loc,target,scale in [('saved_yoke_rear',0.,(65,-90,195),(0,-3,171.5),47.),
                                   ('saved_bare_entry',-17.,(65,-90,195),(0,-3,171.5),47.),
                                   ('saved_yoke_overview',0.,(108,-138,283),(0,-9,190),105.)]:
    for o in created:
        assert o.get('review_owner')=='R2_adoption';bpy.data.objects.remove(o,do_unlink=True)
    created=[]
    for name in ['Pitch_Yoke','Yaw_Reaction_Link']:
        original=bpy.data.objects[PREFIX+name];o=original.copy();o.data=original.data.copy();o.parent=None;o.matrix_world=original.matrix_world.copy();o.hide_render=False
        o.name='MORI_R2_ADOPTED_'+name;o['review_owner']='R2_adoption';scene.collection.objects.link(o);created.append(o)
        if name=='Yaw_Reaction_Link':o.location.z+=shift
    cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam_data.ortho_scale=scale
    scene.render.filepath=str(HERE/(file+'.png'));bpy.ops.render.render(write_still=True)
    files.append(dict(file=file+'.png',sha256=sha(HERE/(file+'.png')),reaction_link_presentation_Z_mm=shift))
assert sha(source)==digest
(HERE/'render_manifest.json').write_text(json.dumps(dict(status='PASS',revision=P['revision'],source_blend_sha256=digest,script_sha256=sha(Path(__file__)),
    files=files,source_meshes_copied_exactly=True,source_unchanged=True,method='Saved native object meshes and display normals; reaction link Z shift is presentation only',manufacturing_release=False),ensure_ascii=False,indent=2)+'\n')
print('R2_SAVED_RENDERS_PASS',len(files),flush=True)
