"""Preserve approved R2 and the current native M1.54 before adoption."""
from pathlib import Path
import sys,json,hashlib,shutil,datetime
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid
from review_geometry_fingerprint import record

assert P['revision']=='V1.2-M1.54'
target=ROOT/'input_assets/M1_55_reaction_entry_baseline.json'
assert not target.exists(),'Do not overwrite the immutable M1.54 baseline'
src=ROOT/'studies/reaction_clamp_current_entry/neck_core_open_R2'
v=json.loads((src/'verification.json').read_text());assert v['status']=='PASS'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==h for p,h in v['sources'].items())
assert v['main_changed'] is False and v['approved'] is False
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled()
for name in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:COLS[name].hide_viewport=False
bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
assets={};s=ss['Pitch_Yoke'];baseline=ROOT/'input_assets/M1_54_Pitch_Yoke_before_R2.npz'
assert not baseline.exists()
np.savez_compressed(baseline,vertices_mm=s.v,triangles=s.f)
candidate=ROOT/'input_assets/M1_55_Pitch_Yoke_R2_reference.npz';assert not candidate.exists();shutil.copy2(src/'candidate_mesh.npz',candidate)
assets['baseline']=dict(file=str(baseline.relative_to(PROJECT)),sha256=sha(baseline))
assets['approved']=dict(file=str(candidate.relative_to(PROJECT)),sha256=sha(candidate))
history=ROOT/'revisions/V1.2-M1.54_before_reaction_entry_R2';history.mkdir(parents=True,exist_ok=True)
for rel in ['mechanical/mori_v1_2.blend','config/geometry.json','contracts/mechanical_interfaces.json','mechanical/reports/validation.json','mechanical/reports/build_manifest.json']:
    dst=history/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copy2(PROJECT/rel,dst)
source_copies={}
for rel in ['mechanical/scripts/build.py','mechanical/scripts/common.py','mechanical/scripts/validate.py','mechanical/scripts/neck_reference.py','mechanical/scripts/validate_neck_capacity.py','mechanical/scripts/assembly_animation.py']:
    dst=history/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(PROJECT/rel,dst);source_copies[rel]=dict(file=str(dst.relative_to(PROJECT)),sha256=sha(dst))
protected={str(p.relative_to(PROJECT)):sha(p) for p in (PROJECT/'hardware').rglob('*') if p.is_file()}
protected['contracts/components.json']=sha(PROJECT/'contracts/components.json')
rows={n:dict(geometry=record(s.v,s.f.tolist()),matrix_world=np.asarray(s.o.matrix_world).tolist(),group=s.group,category=s.o.get('category')) for n,s in ss.items()}
save_json(target,dict(revision=P['revision'],parts=rows,part_count=len(rows),assets=assets,
    source_blend_sha256=sha(ROOT/'mori_v1_2.blend'),config_sha256=sha(PROJECT/'config/geometry.json'),snapshot=str(history.relative_to(PROJECT)),
    source_copies=source_copies,protected_hardware=protected,
    STL_sha256={str(p.relative_to(PROJECT)):sha(p) for p in (ROOT/'exports/stl').glob('*.stl')}))
receipt=dict(approval='USER_APPROVED',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    user_reply='采用 R2，继续后续装配复核（推荐）',question_id='call_0d02d3f7775349988000ef9b2fa273b9',
    scope='Only Pitch_Yoke passage enlargement and rear open neck; no new parts or fasteners; actual horn deferred to arrival',
    original_revision=P['revision'],new_revision='V1.2-M1.55',parameters=json.loads((src/'proposal.json').read_text())['proposed_neck_parameters'],
    source_geometry=assets,baseline_record=dict(file=str(target.relative_to(PROJECT)),sha256=sha(target)),
    reviewed_candidate_verification=dict(file=str((src/'verification.json').relative_to(PROJECT)),sha256=sha(src/'verification.json')),
    candidate_scripts={str(p.relative_to(PROJECT)):sha(p) for p in [src.parent/'neck_core_open_candidate.py',src.parent/'verify_neck_core_open.py',src.parent/'verify_neck_journal.py']},
    physical_strength='NOT_TESTED',actual_horn_and_locking='BLOCKED',manufacturing_release=False)
save_json(HERE/'approval.json',receipt)
print('R2_BASELINE_SAVED',len(ss),'parts;',len(protected),'protected files',flush=True)
