# M1.55：批准的 R2 已应用

只改变 Pitch_Yoke 的内部孔道与后侧颈壁，不加零件或螺钉。
主模型保存回读与独立批准网格一致；其余200件原生零件、硬件位姿与只读硬件源保持。
原C5参数保留，R2通过 geometry.json 独立后续构造步骤实现。

当前检查见 [采用页](index.html)，原候选与M1.54快照保留。
内部孔道包含下部轴承座内侧，不能称为整个轴承座没有改变。
完整线束和实发舵盘仍未完成；PA12开放颈壁强度未试打。

## 实际命令与复现

核心构造、验证、62视图和21个STL：

```sh
python mechanical/scripts/run_all.py --core --render-size 1200 --render-samples 16
```

身体装配、电子细模、可编辑动画、裸件装入及身体保留检查、最终视频解码和页面：

```sh
python mechanical/studies/reaction_clamp_R2_adoption/run_deliverables.py
```

核心命令／输入／输出／日志在 reports/pipeline_execution.zip；派生实际命令在 commands.json。
第一次页面发布因缺少本版CHANGELOG而失败，原日志保留；本脚本生成CHANGELOG后重试成功。
旧通用页面生成器仍作为原始核心管线输入保留，M1.55文案由 publish_current.py 后续出版。

delivery.json记录保存源、已执行的出版命令和最终文件哈希，不放行制造。
