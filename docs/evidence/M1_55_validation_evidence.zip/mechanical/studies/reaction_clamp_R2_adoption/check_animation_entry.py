"""Read the saved animation's actual R2 bench entry and prove its straight path."""
from pathlib import Path
import sys,json,hashlib,time
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=ROOT.parent
sys.path.insert(0,str(ROOT/'scripts'))
from common import *
from validate import Solid
from assembly_animation import AP,SCENE_NAME
from validate_reaction_clamp_entry import translated_entry

start=time.time();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert P['revision']=='V1.2-M1.55'
source=ROOT/'mori_v1_2.blend';manifest=json.loads((ROOT/'animation/manifest.json').read_text())
assert manifest['source_blend_sha256']==sha(source)
src=bpy.data.scenes['MORI_V1_Assembly'];bpy.context.window.scene=src;load_collections()
for n in ['DATUMS','DOCK','KEEP_OUT','COUPONS']:COLS[n].hide_viewport=False
assembled();bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.type=='MESH' and o.get('group') not in ['dock','coupon']}
native={n:s.o.matrix_world.copy() for n,s in ss.items()}
scene=bpy.data.scenes[SCENE_NAME];bpy.context.window.scene=scene
actors={o.name.removeprefix(AP):o for o in scene.objects if o.get('presentation_actor')}
st=next(s for s in manifest['stages'] if s.get('source_step')==10)
span=st['end']-st['start'];first=st['start']+round(.07*span);last=st['start']+round(.42*span)
def matrix(n):return np.asarray(actors[n].matrix_world@native[n].inverted())
rows=[];fixture_ids=None;fixture_matrices={};root_matrix=None
for frame in np.r_[first,np.arange(first+.5,last,.5),last]:
    scene.frame_set(int(frame),subframe=float(frame%1));bpy.context.view_layer.update()
    visible={n for n in ss if n in actors and not actors[n].hide_render};assert 'Yaw_Reaction_Link' in visible and 'Pitch_Yoke' in visible
    fixed=visible-{'Yaw_Reaction_Link'}
    if fixture_ids is None:
        fixture_ids=fixed;fixture_matrices={n:matrix(n) for n in fixed};root_matrix=matrix('Pitch_Yoke')
    assert fixed==fixture_ids,'Parts must not appear or disappear during continuous bare-print entry'
    assert all(np.max(abs(matrix(n)-fixture_matrices[n]))<1e-5 for n in fixed),'Fixture must stay still during straight entry'
    relative=np.linalg.inv(root_matrix)@matrix('Yaw_Reaction_Link')
    expected_Z=-100.+100.*(float(frame)-first)/(last-first)
    expected=np.eye(4);expected[2,3]=expected_Z
    error=float(np.max(abs(relative-expected)));assert error<.00005,(frame,error,relative)
    rows.append(dict(frame=float(frame),relative_Z_mm=float(relative[2,3]),linear_matrix_error_mm=error))
obstacles=manifold.Manifold.batch_boolean([ss[n].m.transform(fixture_matrices[n][:3,:]) for n in fixture_ids],manifold.OpType.Add)
moving=ss['Yaw_Reaction_Link'].m.transform(root_matrix[:3,:])
continuous=translated_entry(moving,obstacles,-100.,0.,P['reaction_clamp_entry']['required_nominal_gap_mm'])
assert continuous['status']=='PASS',continuous['first_failure']
# The off-device bench transform is presentation only; ensure both parts return
# exactly to their native transform at the final frame.
scene.frame_set(scene.frame_end);bpy.context.view_layer.update()
end_error=max(float(np.max(abs(matrix(n)-np.eye(4)))) for n in ['Pitch_Yoke','Yaw_Reaction_Link'])
assert end_error<.00005
result=dict(status='PASS',revision=P['revision'],animation_revision=manifest['animation_revision'],
    source_blend_sha256=sha(source),animation_blend_sha256=sha(Path(bpy.data.filepath)),script_sha256=sha(Path(__file__)),
    stage_source_id=10,entry_frame_range=[first,last],readback_samples=len(rows),matrix_rows=rows,
    fixed_ids=sorted(fixture_ids),fixed_count=len(fixture_ids),bench_world_transform=root_matrix.tolist(),
    continuous_entry=continuous,final_matrix_error_mm=end_error,
    scope='Saved straight bench-entry matrices and exact source meshes against all visible stationary native fixtures; no real horn, wires, hands or strength qualification.',
    actual_horn_and_locking='BLOCKED',full_wired_assembly='BLOCKED',physical_assembly='NOT_TESTED',manufacturing_release=False,elapsed_s=time.time()-start)
(HERE/'animation_reaction_entry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('R2_ANIMATION_ENTRY_PASS',len(rows),'matrix samples;',continuous['interval_count'],'continuous intervals;',len(fixture_ids),'fixed parts',flush=True)
