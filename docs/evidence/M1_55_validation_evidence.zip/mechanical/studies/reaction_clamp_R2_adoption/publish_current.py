"""Publish the approved R2 saved-model receipts after derived-file checks.

The historical animation page helper is retained byte-for-byte as an input to
the completed core pipeline. This revision-specific publication step supplies
its required changelog and replaces historical reaction-entry notices using
fresh M1.55 evidence. It never edits geometry or hardware.
"""
from pathlib import Path
import datetime, hashlib, html, json, re, shutil, subprocess, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROJECT = ROOT.parent
OUT = ROOT / 'animation'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
master = ROOT / 'mori_v1_2.blend'
digest = sha(master)
q = read(PROJECT / 'config/geometry.json')
focused = read(ROOT / 'reports/reaction_clamp_entry_validation.json')
check = read(ROOT / 'reports/validation.json')
manifest = read(OUT / 'manifest.json')
animation_check = read(OUT / 'validation.json')
entry = read(HERE / 'animation_reaction_entry.json')
bench = read(HERE / 'bench_followup.json')
assert q['revision'] == focused['revision'] == check['revision'] == 'V1.2-M1.55'
assert focused['status'] == animation_check['status'] == entry['status'] == bench['status'] == 'PASS'
assert not check['counts']['FAIL']
assert all(d['source_blend_sha256'] == digest for d in [focused, check, manifest, entry, bench])
assert entry['animation_blend_sha256'] == bench['animation_blend_sha256'] == sha(ROOT / 'mori_assembly_animation.blend')
assert manifest['video']['sha256'] == animation_check['video']['sha256'] == sha(OUT / 'MORI_assembly.mp4')
assert read(ROOT / 'reports/delivery_consistency.json')['status'] == 'PASS'

def backup(p, name):
    dest = HERE / name
    if not dest.exists():
        shutil.copy2(p, dest)
    return dest

backup(ROOT / 'index.html', 'before_index.html')
backup(PROJECT / 'docs/CURRENT_STATUS.md', 'before_CURRENT_STATUS.md')
backup(OUT / 'README.md', 'before_animation_README.md')

# publish_animation_update expects a versioned changelog to exist first.
changelog = OUT / 'CHANGELOG_M1.55_A1.md'
changelog.write_text('''# M1.55-A1 装配动画更新

已应用用户批准的颈部装入 R2，源模型为 V1.2-M1.55。
只改变 Pitch_Yoke 内孔及后侧开放颈壁；其他 200 件原生零件和硬件位姿保持。

第 11 个播放章节展示离机从下方装入裸反力轴，再装试配五金、耳座螺母和 C 压板。
保存后的直线路径覆盖 100 mm、294 个连续区间，并回读 85 个半帧位置。
另将镜头隐藏的 102 件已装身体零件保留在原动画位姿，连续复核仍通过。
后续身体模块及防脱压板动画路径已重新检查。

最终视频：1280×720、24 fps、2100 帧、87.5 秒。
实发舵盘／花键／中心锁紧、完整带线装配、人手／夹具与 PA12 强度仍未验证。
视频是当前数字装配说明，manufacturing_release=false。
''')
publisher = [sys.executable, str(ROOT / 'scripts/publish_animation_update.py')]
with (HERE / 'publish_animation_retry.log').open('w') as log:
    subprocess.run(publisher, cwd=PROJECT, stdout=log, stderr=subprocess.STDOUT, check=True)

note = ('M1.55 已解决裸反力轴与打印头座的装入阻挡，第11个播放章节展示离机向上装入。'
        '实际 SC-0090-C001 舵盘、最终锁紧叠层及完整带线初装仍待核对。')
page = OUT / 'index.html'
text = page.read_text()
text = re.sub(r'<p class="note"><b>新增检查：反力夹口初次装配尚未闭合。</b>.*?</p>', '', text, flags=re.S)
text = re.sub(r'<p class="note"><b>M1.52已同步两枚试配螺母的30°转正：</b>.*?</p>',
              '<p class="note"><b>R2 已应用到主模型：</b>'+note+
              ' <a href="../studies/reaction_clamp_R2_adoption/index.html">保存后复核与改动范围</a>。</p>', text, flags=re.S)
text = text.replace('完整软线束随动、反力夹初装和实物配合仍未闭合。',
                    '裸打印件装入已复核；完整软线束随动、实发舵盘装配和实物配合仍未闭合。')
page.write_text(text)

readme = (OUT / 'README.md').read_text().split('\n## M1.55 裸打印件装入复核\n', 1)[0].rstrip()+'\n'
readme = readme.replace('下部横向紧固的名义进入路径通过；上部舵盘夹口初次装配和最终五金选型仍未完成。',
                        'M1.55 R2 解决裸反力轴装入阻挡；实发舵盘与最终锁紧叠层仍待到货核对。')
readme += '''
## M1.55 裸打印件装入复核

第11个播放章节（来源步骤10）先离机从下方装入裸反力轴。
保存后的动画回读85个半帧位置；100mm直线行程分成294个连续区间，间隙下界≥0.3mm。
另外保留镜头隐藏的102件已装身体零件，台面装入路径同样通过。
试配舵盘和紧固件的示意不确认实发附件；完整柔性线束与真实装配仍未完成。

完整本版派生文件和页面重新生成（需先成功生成并复核当前主模型）：

```sh
python mechanical/studies/reaction_clamp_R2_adoption/run_deliverables.py
```

[当前采用记录](../studies/reaction_clamp_R2_adoption/index.html)
'''
(OUT / 'README.md').write_text(readme)

animation_section = re.search(r'<section id="animation">.*?</section>', (ROOT / 'index.html').read_text(), flags=re.S).group()
animation_section = re.sub(r'<p class="notice">.*?</p>', '', animation_section, flags=re.S)
animation_section = animation_section.replace('<h2>Blender 装配动画</h2>', '<h2>Blender 装配动画</h2><p>'+note+'</p>')
harness_link = ''
harness_receipt = ROOT / 'studies/harness_current_M1_55/delivery.json'
if harness_receipt.exists():
    research = read(harness_receipt)
    assert research['source_blend_sha256'] == digest
    assert research['main_changed'] is False and research['full_harness'] == 'BLOCKED'
    harness_link = ('<p><a href="studies/harness_current_M1_55/index.html">M1.55 线束材料与路线诊断</a>：'
                    '早期独立候选保留失败记录；共同排线前段已完成静态复核，完整线束未进入主模型。</p>')
    if research.get('joint_prefix_geometry') == 'PASS':
        assert research['joint_prefix_static_poses'] == 130
        harness_link += ('<p><a href="studies/harness_current_M1_55/global_bundle_layout/index.html">最新共同排线前段 R3</a>：'
                         '12条前段的130个组合姿态、连续转弯和公共参考长度通过；现有上段跨线间隙检查通过。'
                         '5条参考尚缺完整上段，真实接续、固定点、随动和带线装配仍未闭合。</p>')
    if research.get('continuous_pitch_at_key_yaws') == 'PASS':
        assert research['continuous_yaw_family'] == 'PASS' and research['remaining_work_packages'] == 4
        harness_link += ('<p><a href="studies/harness_current_M1_55/prefix_continuity/index.html">连续运动与剩余四项</a>：'
                         '最新R3的12条身体/颈部参考前段完成全偏航转弯、公共数值长度根、'
                         '全偏航/俯仰实体间隙、66组跨线与12条远端自接近；上端走线、'
                         '真实材料/端接/夹持、完整线长和带线装配/闭壳仍待完成。</p>')
    if research.get('upper_finite_native_clearance') == 'PASS':
        assert research['upper_available_references'] == 7 and research['upper_static_poses'] == 130
        harness_link += ('<p><a href="studies/harness_current_M1_55/upper_reference_review_R1/index.html">上一轮上段实体检查</a>：'
                         '7条现有上段的130姿态实体间隙通过；CC局部小半径是细分折线诊断假象。'
                         '5条上段缺完整参考，整束线长、真实端接/应力释放和带线闭壳仍未完成，参考线束未进入主模型。</p>')
    if research.get('matched_upper_finite_peer_gap') == 'PASS':
        assert research['matched_upper_finite_native_gap'] == 'PASS'
        harness_link += ('<p><a href="studies/harness_current_M1_55/upper_pairs_review_R2/index.html">此前上段配套修正与复核</a>：'
                         '纠正旧电源上段与后来CC参考混用的净距不足；同组三线候选的有限配对、'
                         '回环、自身接续、新电源实体与全部前段检查通过。只移动未采用参考的假定出口，'
                         '主模型/PCB不动；完整连续曲率、真实端接、线长和带线闭壳仍未闭合。</p>')
    if research.get('numeric_known_full_length_range_finite') == 'PASS':
        assert research['known_upper_curve_poses'] == 910 and research['final_unique_upper_peer_checks'] == 2730
        harness_link += ('<p><a href="studies/harness_current_M1_55/complete_known_upper_review_R1/index.html">本轮已知上段长度补偿与间隙</a>：'
                         '7条参考的130有限姿态曲率、数值长度、最终一致配对及实际弧长远端自接近／自身接续通过。'
                         'CAM四根重匹配原余量圈，电源／CC只调原内部控制点；未改真实接口或打印件。'
                         '缺失5条上段、中间角度、真实材料／端接／固定及带线闭壳仍未完成，候选未进入主模型。</p>')
    if research.get('upper_motion_sampled_native_and_peer_gap') == 'PASS':
        assert research['upper_motion_sampled_poses'] == 475 and research['upper_motion_unique_geometry_checks'] == 66500
        harness_link += ('<p><a href="studies/harness_current_M1_55/upper_motion_family_R1/index.html">最新线束进度与卡点</a>：'
                         '7条已知上段在475个组合姿态的曲线及66,500项实体／跨线检查通过；样本不是全角度证明。'
                         '更短CAM尾线候选与USB预留空间冲突，未采用。五条上段端点、实际材料／端接／固定与带线闭壳仍未齐，剩4类工作；主模型和视频保持。</p>')
    if research.get('upper_power_continuous_native_gap') == 'PASS':
        assert research['upper_power_native_angular_rectangles'] == 19068
        harness_link += ('<p><a href="studies/harness_current_M1_55/upper_continuity_review_R1/index.html">最新电源／CC上段连续检查</a>：'
                         '三条参考的全名义偏航／俯仰长度、弯折与当前201件实体间隙通过，原0.3mm目标保持。'
                         '三组互线间隙及独立覆盖随后通过；四条CAM新名义参考的全范围长度／弯折与201件模型实体间隙也独立通过。'
                         '7条已知上段全部21组互线组合及全部非局部自身随后独立通过；'
                         '与12条身体前段的84组名义接续／跨线随后完整通过，含7组自身接续、77组其他前段。'
                         '五条缺实际端点的线路、实际材料／粗细线接续／裁线、端接及带线闭壳仍未完成，整束未进入主模型。</p>')
    if research.get('terminal_range_preflight') == 'PASS':
        assert research['actual_material_and_connection_qualification'] == 'BLOCKED'
        assert not research['formal_H06_changed']
        harness_link += ('<p><a href="studies/harness_current_M1_55/material_terminal_review_R1/index.html">H06材料、端接与制作要求预筛</a>：'
                         '原厂字段和四针针序已核对，现行PH002／AWG28＋厂配尾线保持。'
                         '细线替代未采用，实际线径公差、弯折、CAM配对、压接与裁线尚未闭合；'
                         '制作要求是草稿，喇叭插头参数待用户补充，完整线束仍剩4类工作。</p>')
    if research.get('bare_contact_continuous_native_clearance') == 'PASS':
        assert research['bare_contact_closed_intervals'] == 6090
        assert research['bare_contact_current_native_parts_at_stage'] == 197
        harness_link += ('<p><a href="studies/harness_current_M1_55/terminal_install_review_R1/index.html">当前裸端子容量装入与改缓诊断</a>：'
                         '原单端子轨迹对当前装入阶段197件实体的两种包络、6,090个闭区间通过，384个内部姿态另检。'
                         '保护容量间隙下界约0.396mm；不是实际压接或附着导线弯折资格。'
                         '98个改缓搜索未采用，四根逐根穿入、其他线路与闭壳仍待完成，主模型和视频保持。</p>')
    tail_diagnostic=ROOT/'studies/harness_current_M1_55/cam_tail_motion_review_R4/progress_receipt.json'
    if tail_diagnostic.is_file():
        diagnostic=read(tail_diagnostic)
        assert diagnostic['status']=='PASS' and diagnostic['full_475_native_geometry']=='BLOCKED'
        harness_link += ('<p><a href="studies/harness_current_M1_55/cam_tail_motion_review_R4/index.html">CAM尾线缩短比较：不采用</a>：'
                         '零位与12个试探姿态通过后，加密检查在抬头15°／17.5°发现自碰和跨线相交。'
                         '失败见证、修正后可回读的独立对比模型已保留；继续使用原7条475姿态通过的参考，主模型和视频保持。</p>')
    if research.get('prelaid_prefix_entry') == 'BLOCKED':
        assert research['prelaid_prefix_verified_collision_witnesses'] == 12
        harness_link += ('<p><a href="studies/harness_current_M1_55/staged_prefix_entry_review_R1/index.html">预铺前段与驱动座下放诊断</a>：'
                         '12条最终容量前段直接预铺后，在实际下放途中全部与Pitch_Yoke相交，12处已独立复现。'
                         '此准备方式未采用；临时收线、真实自由端与完整带线步骤仍待完成。主模型／顺序／视频保持。</p>')
    if research.get('moving_bundle_entry') == 'BLOCKED':
        assert research['moving_bundle_reference_sections'] == 19 and research['moving_bundle_replayed_collisions'] == 10
        harness_link += ('<p><a href="studies/harness_current_M1_55/moving_bundle_entry_review_R1/index.html">松线束整体下放诊断</a>：'
                         '12条身体前段＋7条可用上段一起搬入时，10条身体段与固定Yaw_Base相交；独立复现，未采用。'
                         '仍需临时收线／分步穿线和实际端接／闭壳。</p>')
    if research.get('PHR4_public_documented_numeric_fields') == 9:
        assert not research['PHR4_detailed_CAD_received'] and research['PHR4_actual_mating'] == 'BLOCKED'
        harness_link += ('<p><a href="studies/harness_current_M1_55/phr4_source_review_R1/index.html">身体PHR-4公开资料</a>：'
                         '运动J5配对身份及两页目录字段已核对；详细CAD需登记后邮件领取，未提交资料或取得。'
                         '完整内腔／压接／线口／插合仍待确认，主模型没有新增完整插头。</p>')
    station_material=ROOT/'studies/harness_current_M1_55/restraint_station_review_R1/delivery.json'
    if research.get('PHR4_fixed_head_service_probes') == 'BLOCKED':
        assert research['PHR4_conditional_external_box_capacity'] == 'PASS'
        assert research['PHR4_replayed_service_witnesses'] == 20
        harness_link += ('<p><a href="studies/harness_current_M1_55/phr4_mating_capacity_R1/index.html">身体插头外形空间与带线插合</a>：'
                         '假定外形框容量通过；5种第一处弯整体随动候选均在插合中途与固定偏航座净距冲突，20处独立复现。'
                         '完整内腔／端子插合和临时整理／分步穿线／整束闭壳仍未完成，候选未采用。</p>')
    if research.get('prelaid_reference_bridge_entry') == 'BLOCKED':
        assert research['body_first_reference_sections'] == 19 and research['body_first_verified_bridge_witnesses'] == 38
        harness_link += ('<p><a href="studies/harness_current_M1_55/body_first_connection_R1/index.html">先端接身体／再装桥比较</a>：'
                         '提前接身体端及预铺19个参考仍未形成可用序列；原桥路线与直落候选各19处净距失败，38处独立复现。'
                         '仍需分步穿线、临时整理与真实端接／夹持；未改主模型或顺序。</p>')
    if station_material.is_file():
        evidence=read(station_material)
        assert evidence['status']=='PASS' and evidence['station_checks']==3800
        harness_link += ('<p><a href="studies/harness_current_M1_55/restraint_station_review_R1/index.html">当前CAM固定位置与实际线径边界</a>：'
                         '475姿态的3,800个参考材料位置检查完成；新补偿后不再套用旧8.0–8.5mm滑移数值。'
                         'AWG28候选最大外径的身体／颈部有限姿态检查通过，头内细线段仍需分段材料；'
                         '实际接续、夹持及带线闭壳未完成，不采用旧固定座或放行裁线。</p>')
    body_restraint=ROOT/'studies/harness_current_M1_55/body_restraint_review_R1/delivery.json'
    if body_restraint.is_file():
        evidence=read(body_restraint)
        assert evidence['status']=='PASS' and evidence['body_native_pair_checks']==3650
        harness_link += ('<p><a href="studies/harness_current_M1_55/body_restraint_review_R1/index.html">CAM身体端固定候选与对比</a>：'
                         '现有桥上一体短绑线座，无新增打印件或螺钉；身体段和固定结构的有限几何检查通过。'
                         '扎带装入、工具空间、角度间运动与完整带线装配未闭合，尚未采用；原生J5针号图已补齐。</p>')
figures = ''.join(f'<figure><img src="renders/{n}.png?revision=M1.55" alt="{label}"><figcaption>{label} · 当前保存模型</figcaption></figure>'
                  for n, label in [('front', '正视'), ('internal', '内部结构'), ('rear', '后视'), ('side', '侧视')])
root_page = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MORI M1.55 当前机械资料</title>
<style>body{{max-width:1080px;margin:3rem auto;padding:0 1rem;font:16px/1.7 system-ui;color:#24343d}}img,video{{width:100%;height:auto}}figure{{margin:2rem 0}}a{{color:#176687}}section{{margin:3rem 0}}.note{{padding:18px;background:#eef5f5;border-left:4px solid #478b93}}</style>
<h1>MORI · V1.2-M1.55</h1><p>已应用批准的 R2：扩大 Pitch_Yoke 内部孔道、开放后侧颈壁，解决裸反力轴装入阻挡。相对 M1.54，只改这一件；不增加打印件或螺钉。轴承配合外圆、上部舵机座和硬件位姿保持。</p>
<p class="note">连续裸件装入、完整壳体俯仰、130个组合姿态和后续压板／身体移入检查通过。实发舵盘与最终锁紧、完整带线装配及 PA12 强度仍未闭合，整机 PROTOTYPE / UNVALIDATED。</p>
<p><a href="studies/reaction_clamp_R2_adoption/index.html">R2 当前采用与复核</a> · <a href="mori_v1_2.blend">最新主模型</a> · <a href="mori_electronics_detail.blend">电子细模</a> · <a href="animation/index.html">装配视频</a> · <a href="current_report.html">当前检查报告</a> · <a href="../docs/CURRENT_STATUS.md">当前状态</a></p>
<p>已保留 M1.53 C6 通道与 M1.54 CAM USB 朝机器人右侧 +X。完整研究线束和电源候选未混入正式模型。</p>
{harness_link}{animation_section}{figures}</html>'''
(ROOT / 'index.html').write_text(root_page)

status = (PROJECT / 'docs/CURRENT_STATUS.md').read_text()
status = status.replace('2026-10-08：当前主模型为 **V1.2-M1.54**，装配动画为 **M1.54-A1**',
                        '2026-10-09：当前主模型为 **V1.2-M1.55**，装配动画为 **M1.55-A1**')
status = status.replace('本次同步用户已确认的 C6 穿线口加宽和 CAM USB 朝右，',
                        '已同步用户确认的 C6 穿线口加宽、CAM USB 朝右及颈部装入 R2，')
row = '| M1.55 R2 颈部装入 | 仅扩大 Pitch_Yoke 内部孔道、开放后侧颈壁；不增件或螺钉。保存后与批准候选差0mm³，其余200件和全部硬件位姿保持；轴承配合外圆保持，内部材料减少 |\n'
status = status.replace('| CAM 安装 |', row+'| CAM 安装 |') if '| M1.55 R2 颈部装入 |' not in status else status
replacement = ('| 上部反力夹初装 | **裸打印件阻挡已解决**：用户批准 R2，已进入 M1.55 主模型。'
               '[当前采用与保存后复核](../mechanical/studies/reaction_clamp_R2_adoption/index.html)：'
               '100mm连续装入、壳体−20°～+25°连续俯仰、130个组合姿态、121个压板侧移和181个身体移入样本通过。'
               '动画回读85个半帧、294个连续装入区间通过，额外保留镜头隐藏的102件身体零件后仍通过。'
               '实际 SC-0090-C001 舵盘／花键／锁紧叠层、完整带线初装仍 BLOCKED；开放处 PA12 强度 NOT_TESTED |')
status = re.sub(r'^\| 上部反力夹初装 \|.*$', lambda _: replacement, status, flags=re.M)
status = status.replace('[本次更新与复核](M1_54_MODEL_UPDATE.md)',
                        '[M1.55当前采用与复核](../mechanical/studies/reaction_clamp_R2_adoption/index.html) · [M1.54更新记录](M1_54_MODEL_UPDATE.md)')
(PROJECT / 'docs/CURRENT_STATUS.md').write_text(status)
(ROOT / 'LATEST_MODEL.md').write_text('''# 最新主模型

当前：**V1.2-M1.55**，保存后的总装文件为 [mori_v1_2.blend](mori_v1_2.blend)。
请从本文件所在的当前工作树打开它；Documents/MORI 中的历史副本不代表此次同步。

[R2采用与检查](studies/reaction_clamp_R2_adoption/index.html) · [装配动画 M1.55-A1](animation/index.html)

模型已采用 C6 通道、CAM USB 朝右及颈部装入 R2。
完整研究线束未采用，实际舵盘和柔性排线按用户决定到货后核对。
原生模型、打印件和动画来自同一保存源；数字 PASS 不代表实物或制造放行。
''')

side_wall = min(r['minimum_mm'] for r in focused['retained_side_wall_samples'])
radial_wall = focused['journal_radial_samples']['minimum_mm']
entry_stage = next(s for s in manifest['stages'] if s.get('source_step') == 10)
seek = (entry_stage['start']-1)/manifest['fps']
study = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M1.55 R2 已采用</title>
<style>body{{max-width:1080px;margin:38px auto;padding:0 20px 60px;font:16px/1.7 system-ui;color:#263b45;background:#f5f8f9}}h1{{font-size:29px}}a{{color:#126682}}img,video{{width:100%;height:auto}}figure{{margin:25px 0}}.note{{padding:18px;background:white;border-left:4px solid #408994}}td,th{{padding:12px;border-bottom:1px solid #dbe6ea;text-align:left}}table{{border-collapse:collapse;width:100%;background:white}}</style>
<h1>R2 已应用到主模型 · M1.55</h1><p>2026-10-09 · 用户确认“采用 R2，继续后续装配复核”。保存后复核通过。</p>
<p class="note">只改 Pitch_Yoke 的内部孔道与后侧颈壁；没有增加打印件或螺钉。与批准候选对照差为0mm³，其他200件原生零件与全部硬件位姿保持。轴承配合外圆保留，内部材料减少；强度仍需试打。</p>
<p><a href="../../mori_v1_2.blend">最新主模型</a> · <a href="../../mori_assembly_animation.blend">可编辑动画</a> · <a href="../../animation/index.html">完整视频与章节</a> · <a href="../../exports/stl/Pitch_Yoke.stl">当前头托 STL</a> · <a href="../../index.html?revision=V1.2-M1.55">机械主页</a></p>
<figure><img src="saved_yoke_rear.png" alt="保存后的R2后侧颈壁开放轮廓"><figcaption>从当前保存的主模型复制原生网格渲染：后侧开放，前侧及双侧颈壁保持。</figcaption></figure>
<figure><img src="../reaction_clamp_current_entry/neck_core_open_R2/section_comparison.png" alt="M1.54与已批准R2真实剖面对比"><figcaption>批准时的真实剖面对比；右侧候选已与当前保存网格独立对照一致。裸反力轴装入位置下移仅为展示。</figcaption></figure>
<table><tr><th>检查</th><th>当前证据</th></tr>
<tr><td>完整主模型</td><td>{html.escape(str(check['counts']))}；数字检查，没有制造放行。</td></tr>
<tr><td>裸反力轴连续装入</td><td>PASS · 100mm、294个连续区间，名义净距下界≥0.3mm。试配五金和占位舵盘另查，不确认实发附件。</td></tr>
<tr><td>头壳俯仰</td><td>PASS · −20°～+25°连续区间；130个组合姿态的整机有限采样回归通过。</td></tr>
<tr><td>保留壁厚采样</td><td>侧壁约{side_wall:.3f}mm，轴承座径向约{radial_wall:.3f}mm；不是全局最小壁厚或强度认证。</td></tr>
<tr><td>后续装配</td><td>121个压板侧移、181个身体移入样本及39个防脱检查通过；动画身体路径956个、压板路径705个半帧回读通过。</td></tr>
<tr><td>视频中的裸件装入</td><td>85个半帧回读与294个连续区间通过；另外保留102件已装身体零件复核，镜头隐藏不用于忽略干涉。</td></tr>
<tr><td>交付一致</td><td>21个STL导出／回读拓扑通过，仅Pitch_Yoke STL变化。62幅模型预览、电子细模和视频已从同一当前源生成。</td></tr></table>
<h2>新版装配视频</h2><p>87.5秒 · 1280×720 · 24fps。按钮跳到第11章裸反力轴装入；实发舵盘仍是未确认接口。</p>
<p><button id="jump" type="button">播放裸反力轴装入</button></p><video id="v" controls preload="metadata" poster="../../animation/step_11.png?revision=M1.55-A1"><source src="../../animation/MORI_assembly.mp4?revision={manifest['animation_revision']}-{manifest['video']['sha256'][:12]}" type="video/mp4"></video>
<script>document.getElementById('jump').onclick=()=>{{const v=document.getElementById('v');v.currentTime={seek:.3f};v.play().catch(()=>{{}})}};</script>
<h2>仍待完成</h2><p>SC-0090-C001实发舵盘／花键／中心锁紧到货后核对；完整线束的材料、端子保护、长度补偿、整理和带线闭壳继续保留 BLOCKED。PA12开放颈壁刚度、强度、疲劳及真实人手／夹具操作 NOT_TESTED。没有采用未批准的导向／固定、电源或整束路线候选。</p>
<p><a href="../../reports/reaction_clamp_entry_validation.json">保存后几何检查</a> · <a href="animation_reaction_entry.json">动画连续装入</a> · <a href="bench_followup.json">保留身体的台面复核</a> · <a href="delivery.json">本版交付哈希</a> · <a href="approval.json">批准记录</a> · <a href="README.md">命令与范围</a></p><p>PRINTABLE / ASSUMED · PROTOTYPE / UNVALIDATED · manufacturing_release=false</p></html>'''
(HERE / 'index.html').write_text(study)
(HERE / 'README.md').write_text('''# M1.55：批准的 R2 已应用

只改变 Pitch_Yoke 的内部孔道与后侧颈壁，不加零件或螺钉。
主模型保存回读与独立批准网格一致；其余200件原生零件、硬件位姿与只读硬件源保持。
原C5参数保留，R2通过 geometry.json 独立后续构造步骤实现。

当前检查见 [采用页](index.html)，原候选与M1.54快照保留。
内部孔道包含下部轴承座内侧，不能称为整个轴承座没有改变。
完整线束和实发舵盘仍未完成；PA12开放颈壁强度未试打。

## 实际命令与复现

核心构造、验证、62视图和21个STL：

```sh
python mechanical/scripts/run_all.py --core --render-size 1200 --render-samples 16
```

身体装配、电子细模、可编辑动画、裸件装入及身体保留检查、最终视频解码和页面：

```sh
python mechanical/studies/reaction_clamp_R2_adoption/run_deliverables.py
```

核心命令／输入／输出／日志在 reports/pipeline_execution.zip；派生实际命令在 commands.json。
第一次页面发布因缺少本版CHANGELOG而失败，原日志保留；本脚本生成CHANGELOG后重试成功。
旧通用页面生成器仍作为原始核心管线输入保留，M1.55文案由 publish_current.py 后续出版。

delivery.json记录保存源、已执行的出版命令和最终文件哈希，不放行制造。
''')

# Historical review pages remain available verbatim, with current status shown.
for target in [ROOT / 'studies/reaction_clamp_current_entry/index.html',
               ROOT / 'studies/reaction_clamp_current_entry/neck_core_open_R2/index.html']:
    archived = target.with_name('index_M1_54_review.html')
    if not archived.exists():
        shutil.copy2(target, archived)
    href = '../reaction_clamp_R2_adoption/index.html' if target.parent.name == 'reaction_clamp_current_entry' else '../../reaction_clamp_R2_adoption/index.html'
    original = archived.read_text()
    banner = ('<div style="padding:18px;background:#def1ee;border:2px solid #438b80;margin:20px 0">'
              '<strong>2026-10-09更新：R2已采用到M1.55。</strong>下文是M1.54诊断／候选历史，'
              '其“未采用”状态不代表最新主模型。<a href="'+href+'">查看当前采用与保存后复核</a> · '
              '<a href="index_M1_54_review.html">原始审阅页</a>。</div>')
    target.write_text(original.replace('<main>', '<main>'+banner, 1))

agents = PROJECT / 'AGENTS.md'
text = agents.read_text()
rule = ('- M1.55 user explicitly adopts neck-entry R2: only enlarge Pitch_Yoke internal passage and open its rear neck wall; '
        'no new prints or fasteners. Preserve bearing fit exterior, upper servo seats and all hardware transforms; '
        'internal journal material is intentionally reduced. Retain C5 parameters and construct R2 as a late geometry.json phase. '
        'Independently compare saved model to approved mesh and pre-adoption fingerprints, then recheck entry, shell pitch, '
        'combined motion, walls, keeper/drop paths, STL and animation. Actual SC-0090-C001 horn/locking remains deferred to arrival; '
        'full wired assembly BLOCKED and PA12 opening strength NOT_TESTED. No harness or hardware candidates adopted.\n')
if '- M1.55 user explicitly adopts neck-entry R2:' not in text:
    agents.write_text(text.rstrip()+'\n\n'+rule)

# Refresh the older animation publication fingerprint only after all text edits.
delivery = read(OUT / 'delivery.json')
assert delivery['source_blend_sha256'] == digest
delivery['files'] = {name: sha(ROOT / name) for name in delivery['files']}
delivery['reaction_entry_R2'] = dict(status='PASS', source='studies/reaction_clamp_R2_adoption/animation_reaction_entry.json',
                                  readback_samples=entry['readback_samples'], earlier_body_parts=bench['earlier_body_parts'],
                                  actual_horn_and_locking='BLOCKED', full_wired_assembly='BLOCKED')
delivery['postpublication_command'] = [sys.executable, str(Path(__file__))]
(OUT / 'delivery.json').write_text(json.dumps(delivery, ensure_ascii=False, indent=2)+'\n')

files = [master, ROOT/'mori_electronics_detail.blend', ROOT/'mori_assembly_animation.blend', ROOT/'index.html',
         ROOT/'LATEST_MODEL.md', ROOT/'current_report.html', PROJECT/'docs/CURRENT_STATUS.md', PROJECT/'AGENTS.md',
         PROJECT/'config/geometry.json', PROJECT/'contracts/mechanical_interfaces.json',
         OUT/'MORI_assembly.mp4', OUT/'delivery.json', OUT/'index.html', OUT/'README.md', changelog,
         HERE/'index.html', HERE/'README.md', HERE/'animation_reaction_entry.json', HERE/'bench_followup.json',
         HERE/'render_manifest.json', HERE/'approval.json', Path(__file__),
         ROOT/'reports/pipeline_execution.zip', ROOT/'reports/reaction_clamp_entry_validation.json',
         ROOT/'reports/validation.json', ROOT/'reports/export_manifest.json', ROOT/'reports/delivery_consistency.json',
         ROOT/'reports/current_report.json', ROOT/'reports/electronics_detail_validation.json',
         ROOT/'reports/body_split_validation.json', OUT/'manifest.json', OUT/'validation.json',
         OUT/'front_rear_path_validation.json', OUT/'head_retention_path_validation.json']
files += list((ROOT/'exports/stl').glob('*.stl')) + list((ROOT/'renders').glob('*.png')) + list(OUT.glob('step_*.png'))
files += [HERE/n for n in ['saved_yoke_rear.png', 'saved_bare_entry.png', 'saved_yoke_overview.png']]
files += [ROOT/'studies/harness_current_M1_55/delivery.json',
          ROOT/'studies/harness_current_M1_55/body_restraint_review_R1/delivery.json',
          ROOT/'studies/harness_current_M1_55/body_restraint_review_R1/publication_verification.json']
assert sha(master) == digest
receipt = dict(status='PASS', revision=q['revision'], animation_revision=manifest['animation_revision'],
               published_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               source_blend_sha256=digest, source_unchanged=True, changed_ids=['Pitch_Yoke'], unchanged_native_parts=200,
               STL_changed=['Pitch_Yoke'], STL_count=21, no_new_parts_or_fasteners=True,
               validation_counts=check['counts'], native_animation='PASS', decoded_video=animation_check['video'],
               bare_print_entry='PASS', actual_horn_and_locking='BLOCKED', full_wired_assembly='BLOCKED',
               physical_strength='NOT_TESTED', manufacturing_release=False,
               publish_command=[sys.executable,str(Path(__file__))],
               prior_publish_failure='Missing CHANGELOG_M1.55_A1.md; supplied versioned changelog and reran unchanged publisher successfully.',
               files={str(p.relative_to(PROJECT)):sha(p) for p in files})
(HERE/'delivery.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print('R2_CURRENT_PUBLICATION_PASS', len(receipt['files']), 'files', flush=True)
