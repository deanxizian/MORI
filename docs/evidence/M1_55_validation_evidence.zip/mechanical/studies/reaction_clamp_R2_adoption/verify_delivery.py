"""Independently verify current publication hashes, protected sources and links."""
from pathlib import Path
import sys, json, datetime, re
from urllib.parse import urlsplit, unquote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from pipeline_evidence import verify_pipeline_execution, verify_delivery_stamp, sha

rows = verify_pipeline_execution(PROJECT)
delivery = json.loads((ROOT / 'reports/delivery_consistency.json').read_text())
verify_delivery_stamp(PROJECT, delivery)
publications = []
for file, base in [(HERE/'delivery.json', PROJECT), (ROOT/'animation/delivery.json', ROOT)]:
    doc = json.loads(file.read_text())
    mismatches = [n for n, h in doc['files'].items()
                  if not (base/n).is_file() or sha(base/n) != h]
    assert not mismatches, mismatches
    publications.append(dict(file=str(file.relative_to(PROJECT)), files=len(doc['files']), sha256=sha(file), status='PASS'))

baseline = json.loads((ROOT/'input_assets/M1_55_reaction_entry_baseline.json').read_text())
excluded = {n: dict(before=h, after=sha(PROJECT/n),
                    reason='Python runtime cache' if '__pycache__' in n else 'macOS Finder directory metadata')
            for n, h in baseline['protected_hardware'].items()
            if '__pycache__' in n or Path(n).name == '.DS_Store'}
protected = {n: h for n, h in baseline['protected_hardware'].items() if n not in excluded}
drift = [n for n, h in protected.items() if not (PROJECT/n).is_file() or sha(PROJECT/n) != h]
assert not drift, drift
changed_STL = [n for n, h in baseline['STL_sha256'].items() if sha(PROJECT/n) != h]
assert changed_STL == ['mechanical/exports/stl/Pitch_Yoke.stl'], changed_STL
assert len(list((ROOT/'exports/stl').glob('*.stl'))) == 21

checked_links = []
for page in [ROOT/'index.html', ROOT/'animation/index.html', HERE/'index.html',
             ROOT/'studies/reaction_clamp_current_entry/index.html',
             ROOT/'studies/reaction_clamp_current_entry/neck_core_open_R2/index.html']:
    for link in re.findall(r'(?:href|src)="([^"]+)"', page.read_text()):
        parsed = urlsplit(link)
        if parsed.scheme or not parsed.path:
            continue
        target = (page.parent/unquote(parsed.path)).resolve()
        assert target.is_file(), (page, link)
        assert target.is_relative_to(PROJECT), (page, link)
        url = 'http://127.0.0.1:58202/' + str(target.relative_to(PROJECT))
        with urlopen(Request(url, method='HEAD'), timeout=10) as response:
            assert response.status == 200
        checked_links.append(dict(page=str(page.relative_to(PROJECT)), target=str(target.relative_to(PROJECT))))

animation = json.loads((ROOT/'animation/validation.json').read_text())
assert animation['status'] == 'PASS'
assert animation['video']['decoded_frames'] == 2100
assert animation['video']['decoded_dimensions_px'] == [1280,720]
assert animation['video']['decoded_fps'] == 24
assert animation['video']['duration_seconds'] == 87.5
result = dict(status='PASS', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              revision='V1.2-M1.55', source_blend_sha256=sha(ROOT/'mori_v1_2.blend'),
              script_sha256=sha(Path(__file__)), core_pipeline_stages=[r['stage'] for r in rows],
              delivery_stamp='PASS', publications=publications,
              protected_hardware_files=len(protected), protected_hardware_drift=drift,
              excluded_nonengineering_metadata=excluded,
              changed_STL=changed_STL, STL_count=21,
              current_page_links=checked_links, HTTP_HEAD='PASS', decoded_video=animation['video'],
              scope='Current input/output/log fingerprints, source preservation, published local links and previously decoded video. Not physical assembly or manufacturing qualification.',
              physical_assembly='NOT_TESTED', full_wired_assembly='BLOCKED', manufacturing_release=False)
(HERE/'publication_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print('R2_DELIVERY_VERIFIED', len(checked_links), 'links;', len(protected), 'protected hardware files', flush=True)
