# 当前状态与验证边界

2026-10-08：当前主模型为 **V1.2-M1.54**，装配动画为 **M1.54-A1**，硬件契约仍为 **V1.2-H0.5-P5R7**。本次同步用户已确认的 C6 穿线口加宽和 CAM USB 朝右，未采用仍在研究的线束或电源板候选。完整几何源为 `config/geometry.json`，不可用旧报告反推当前尺寸。

## 已进入主模型

| 改动 | 当前范围 |
|---|---|
| M1.53 C6 通道 | 仅固定偏航桥左侧现有槽口外缘加宽 0.8 mm；轴承座、孔位和五金保持。相对 M1.52，其余 200 个原生零件保持 |
| M1.54 CAM 方向 | CAM 整板及板载双麦绕不变的板中心转动 −90°，USB 朝机器人 +X；相对 M1.53，其余 198 个原生零件和全部 21 个 STL 保持 |
| CAM 安装 | 沿用四孔和原固定座；向前错开 2 mm 下放，留高 8 mm 时预接 USB，再落座锁紧。完整插头及软线仍未选定 |
| 交付文件 | 主模型、电子细模、STL、预览与装配工程／视频同步；仍为 16 件机器人本体打印件，另有维护托架和试片 |
| 采购记录 | 微雪 LCD35079、CAM33700，以及头部／轮驱舵机、调试板、WeAct F412 已由用户确认购入、待收货。头部舵机完整商品编号 SC-0090-C001 已确认 |

[本次更新与复核](M1_54_MODEL_UPDATE.md) · [CAM 改动对比](../mechanical/studies/cam_right_adoption/index.html) · [C6 剖面对比](../mechanical/studies/c6_adoption/index.html) · [当前报告](../mechanical/current_report.html) · [装配视频](../mechanical/animation/index.html) · [采购记录](../mechanical/procurement/采购记录.md)

CAM 转向后，相机 FPC 在 CAM 端朝 −X，屏幕 FPC 在 CAM 端朝 −Z；LCD 和相机模组本身未移动。板载麦克风变为上下排列，L/R 名称保留源通道身份。旧方向的上端走线结果不再代表当前路线；共享声腔的空隙检查不证明声学、声源定位或 RF 性能。

## 未完成项目

| 问题 | 当前证据与后续安排 |
|---|---|
| SCS0009 舵盘、轴与锁紧叠层 | 已购 SC-0090-C001，但实发花键、舵盘和中心螺钉未核对。用户决定到货后调整，询问稿未发送；最终传动接口仍 BLOCKED |
| 微雪 FPC／FFC | 已有官方外形及照片方向参考；完整柔性板轮廓、长度、插深、接触面和弯折性能未确认。用户决定到货后核对；旧 12.5 mm 全宽占用片的失败不能直接解释为原配 FPC 无法安装 |
| 上部反力夹初装 | 下部工具和紧固件路径已有名义检查，上部装入与完整初装仍 BLOCKED。[M1.54 打印件复查](../mechanical/studies/reaction_clamp_current_entry/index.html)确认裸反力轴也有轴向阻挡；52 个转动顺序及两平面的有限侧移／倾斜搜索未找到路线，不代表所有路线不可能。2026-10-09 已完成[开放颈壁候选 R2](../mechanical/studies/reaction_clamp_current_entry/neck_core_open_R2/index.html)：只改 Pitch_Yoke 的内部孔道和后侧颈壁，裸反力轴连续装入、壳体完整俯仰、130 个组合姿态新增材料回归、保留侧壁及轴承座径向采样、有限压板／身体移入检查通过。不加件或螺钉；轴承配合外圆保持，但内部孔道扩大。候选尚未获用户确认，未进入主模型。开放处强度、完整带线初装及实际舵盘／锁紧仍未闭合 |
| 完整线束 | CAM 信号、电源、细 CC 等局部候选有分段检查；完整材料长度补偿、两端配对、应力释放、带线闭壳和供应商裁线图仍未闭合，未进入正式模型 |
| CAM 导向与固定候选 | 原固定座与新 C2 线路不再匹配；上移 5 mm 后的名义运动检查已通过，导向处需允许约 8.0–8.5 mm 材料滑移。后续修正了临时松线的自碰；在 USB 供电线尚未装入、信号线末端无接头的条件下，台上整理与 CAM／头托移入路径检查通过。真实端子穿线、后装供电线、最终成形、闭壳和实物夹持仍未完成，主模型未采用 |
| CAM H06 交付形态 | 2026-10-08 用户接受厂家压接、身体端四个端子暂不入壳，装机穿线后插入 PHR-4。[确认方案](../mechanical/procurement/CAM_H06_身体端暂不入壳方案.md)。机械零位的四根容量参考线逐根穿入及前三根连续让位检查通过，完整线长与五根原有参考线保留；[当前研究](../mechanical/studies/harness_current_M1_54/cam_terminal_feed/index.html#four-wires)。最新[材料对照](../mechanical/studies/harness_current_M1_54/cam_terminal_feed/material_boundary/review.json)把未采用的 Alpha 2841/7 组合标为 **FAIL**：官方按最大外径需 R6.604 mm，当前送入约 R2.990 mm、第三根让位约 R1.466 mm；其 AWG30/外径也没有替代正式 AWG28/PH002。已补[逐针与入壳资料要求](../mechanical/studies/harness_current_M1_54/cam_terminal_feed/housing_requirements.md)。初始理线/头托移入、最终整理、真实端子入壳、后装供电线与闭壳仍未闭合，主模型未采用，未放行制造 |
| CAM USB 供电源端 | USB 朝右已采用；R2／R3 源端及接头研究不等于正式 PCB 更新。实际源端、完整插头／尾线、可靠线长和电流能力仍未冻结 |
| H06 独立 AWG28 参考 | [较缓候选](../mechanical/studies/harness_current_M1_54/cam_AWG28_reference/index.html)完成首根下部 1,314 个连续曲率区间及固定基线／解析上入口核对；只覆盖部分曲率。均匀最大外径参考在接口出口有 0.2634 mm 正间隙，低于 0.3 mm 目标，整束仍 BLOCKED。正式 PH002／厂配 SH 尾线未改，实际尾线与压接仍待核对 |
| 喇叭尾线与拆壳 | 2026-10-08 用户确认实物从壳体出线处至已有插头末端为 **150 mm**，含插头；不再按规格书 200 mm 判断此件可用长度。[实物记录](../mechanical/procurement/evidence/2026-10-08_SP3040_lead_measurement.json)。完整路线、配对接头、延长连接和固定仍待完成 |
| WeAct E 插合 | 原厂 STEP 自身有针孔相交；不能据此判断实物能否插合，需真实孔／针证据 |
| 电池、轮胎与电源外部件 | 部分实际选型、额定、热设计及完整装配接口未冻结；非 Pololu 降压方案是硬件独立研究，尚未替换模型或正式契约 |
| 物理断电／急停 | 原外露开关已取消，最终硬件实施和验证未闭合 |
| PA12 与真实装配 | 轴承配合、嵌件、孔径、公差、强度、疲劳和线束寿命尚未试打／实测 |
| 整机运行 | 上电、热、EMC、充电、电池安全、实机平衡和续航未验证 |

未采用研究的原始文件保留在本地 `mechanical/studies/harness_current_M1_54/`，本 PR 只发布已采用几何及其复核证据，不作为完整研究归档。资料整理前的详细研究状态另存于本地 `mechanical/studies/m1_54_pr/before_CURRENT_STATUS.md`，没有删除研究结果。

## 软件与制造状态

2026-10-07 的 F412RE 交叉编译和软件回归记录见 [审查复核](REVIEW_CLOSURE.md)。这些是编译／主机证据，真实时钟、GPIO、总线和控制端口仍待接通；旧 F413 验收不能代表当前 P5R7 的实机验证。本次机械 PR 没有重跑软件验收。

`PASS` 只针对记录中的具体检查；`FAIL` 表示该检查未通过；`NOT_TESTED` 表示未执行；`BLOCKED` 表示缺少输入或仍有未解决事项；`NOT_APPLICABLE` 表示不适用。整机保持 **PROTOTYPE / UNVALIDATED**，`manufacturing_release=false`。
