#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
cc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -g \
 -Ihardware/firmware/components/mori_core/include \
 hardware/firmware/components/mori_core/mori_core.c hardware/tests/test_core.c \
 -lm -o hardware/reports/test_core
hardware/reports/test_core
