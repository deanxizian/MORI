"""Small static review scene, separate from the main model; amber is incomplete."""
import sys,json
from pathlib import Path
H=Path(__file__).resolve().parent;PROJECT=H.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid
check=json.loads((H/'scene_check.json').read_text());data=json.loads((H/'world_geometry.json').read_text())
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled();bpy.context.view_layer.update()
specs=[]
for name in ['Load_Frame','Yaw_Base','MCU_Motion','IMU_BMI323','UPS_Module']:
    o=bpy.data.objects[PREFIX+name];s=Solid(o);mesh=s.m.to_mesh64()
    color=(.46,.50,.52,1) if name in ['Load_Frame','Yaw_Base'] else (.13,.30,.23,1) if name=='MCU_Motion' else (.35,.36,.38,1)
    status=o.get('data_status','ASSUMED')
    if status not in ['ASSUMED','VENDOR_DOCUMENTED','MEASURED']:status='ASSUMED'
    specs.append((name,mesh.vert_properties[:,:3].tolist(),mesh.tri_verts.tolist(),color,'CURRENT_M1_58_CONTEXT',status,{}))
for row in data['solids']:
    color=(.92,.48,.10,1) if row.get('placeholder') else (.05,.34,.22,1) if row['is_board'] else (.20,.23,.27,1)
    evidence='VENDOR_CAD_NOMINAL_MOUNT' if row.get('vendor_documented') else 'DIMENSION_ENVELOPE' if row.get('placeholder') else 'KICAD_LIBRARY_PARTIAL_REFERENCE'
    specs.append(('C3_'+str(row['index']),row['vertices'],row['triangles'],color,evidence,'VENDOR_DOCUMENTED' if row.get('vendor_documented') else 'ASSUMED',row.get('source_evidence',{})))
bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene;objs={}
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=.001;sc.unit_settings.length_unit='MILLIMETERS'
for name,v,f,color,evidence,status,source in specs:
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(v,[],f);mesh.update()
    o=bpy.data.objects.new(name,mesh);sc.collection.objects.link(o);o.color=color
    o['mori_owner']='hardware_receipt_C3_R86B';o['unadopted']=True;o['evidence']=evidence
    o['category']='PLACEHOLDER' if evidence=='DIMENSION_ENVELOPE' else 'PURCHASED_REFERENCE'
    if name in ['Load_Frame','Yaw_Base']:o['category']='PRINTABLE'
    o['data_status']=status
    if source:o['source_evidence']=json.dumps(source,ensure_ascii=False)
    objs[name]=o
sc['status']='BLOCKED: external package envelopes only for missing CAD; socket mating interiors and plugs unresolved. Not current main model.'
sc['source_revision']='C3 R86B native + M1.58 mechanical; independent read-only fit review'
sc.render.engine='BLENDER_WORKBENCH';sh=sc.display.shading;sh.light='STUDIO';sh.color_type='OBJECT'
sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.background_type='WORLD'
sc.world=bpy.data.worlds.new('C3ReviewWorld');sc.world.color=(.08,.10,.12)
sc.render.resolution_x=1250;sc.render.resolution_y=900;sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG'
cam=bpy.data.objects.new('ReviewCamera',bpy.data.cameras.new('ReviewCamera'));sc.collection.objects.link(cam);sc.camera=cam;cam.data.type='ORTHO'
def shot(name,eye,target,scale):
    cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale
    sc.render.filepath=str(H/(name+'.png'));bpy.ops.render.render(write_still=True)
objs['UPS_Module'].hide_render=True
shot('assembly_review',(145,175,240),(0,-5,124),130)
for name in ['MCU_Motion','Yaw_Base','Load_Frame','IMU_BMI323']:
    objs[name].hide_render=True
shot('board_review',(40,65,245),(0,-6,124),92)
shot('board_bottom_review',(80,70,35),(0,-6,120),92)
# Restore the context view in the saved independent scene.
for name in ['MCU_Motion','Yaw_Base','Load_Frame','IMU_BMI323']:
    objs[name].hide_render=False
cam.location=(145,175,240);cam.rotation_euler=(Vector((0,-5,124))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=130
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(H/'C3_R86B_PARTIAL_REVIEW.blend'),compress=True)
print('INDEPENDENT_REVIEW_ONLY',len(objs),flush=True)
