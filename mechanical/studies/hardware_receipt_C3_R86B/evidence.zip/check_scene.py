"""Check a pinned, explicitly incomplete C3 assembly in the saved M1.58 scene."""
import sys,json,hashlib,csv
from pathlib import Path
H=Path(__file__).resolve().parent;PROJECT=H.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid,rigidtr
from native_electronics import solid_from

receipt=json.loads((H/'native_receipt.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,d in receipt['protected_sources'].items():assert sha(PROJECT/p)==d,p
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled();bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
carrier=bpy.data.objects[PREFIX+'MCU_Carrier']
rotation=np.array(carrier['source_rotation']);translation=np.array(carrier['source_translation_mm'])
index=next(x for x in json.loads(carrier['component_reference_index']) if x['reference']=='PCB')
v=np.array([list(carrier.matrix_world@x.co) for x in carrier.data.vertices]);oldpcb=v[slice(*index['vertices'])]
bottom=float(oldpcb[:,2].min());old_top=float(oldpcb[:,2].max())
raw=json.loads((H/'partial_mesh.json').read_text());board=json.loads((H/'board_mesh.json').read_text())
bb=np.array(board['bounds']);substrate=bb[5]-bb[2];finished=receipt['thickness_mm'];skin=(finished-substrate)/2
assert 0<=skin<.2 and abs((old_top-bottom)-finished)<1e-4
translation[2]=bottom+skin-bb[2]
fallbacks=[];meshes=[];local_solids=[];board_indices=[]
for row in raw['solids']:
    points=np.array(row['vertices'],dtype=np.float64);faces=np.array(row['triangles'],dtype=np.uint64)
    is_board=np.allclose(row['bounds'],bb,atol=1e-6)
    if is_board:
        # Derive the nominal finished-board envelope from its native 1.6 mm
        # design value; do not scale any purchased component geometry.
        points[:,2]=bb[2]-skin+(points[:,2]-bb[2])*finished/substrate
        board_indices.append(row['index'])
    world=points@rotation.T+translation
    m=solid_from(world,faces,'C3_export_solid_'+str(row['index']),fallbacks)
    meshes.append({'index':row['index'],'is_board':is_board,'vertices':world.tolist(),'triangles':faces.tolist()})
    local_solids.append(m)
    if is_board:board_solid=m
assert len(board_indices)==1,board_indices
vendor_dir=PROJECT/'hardware/v1_2/interface_board/design/C3/review/connectors_20261016/mating_closure_20261016'
alignment=json.loads((vendor_dir/'model_alignment_receipt.json').read_text())['header']
vendor_raw=json.loads((H/'J402_vendor_mesh.json').read_text())
vendor_inspection=json.loads((H/'J402_vendor_mesh.inspection.json').read_text())
vendor_path=Path(vendor_inspection['source'])
assert sha(vendor_path)==alignment['sha256']==vendor_inspection['source_sha256']
assert vendor_inspection['scale_factor']==1 and all(r['cad_valid'] for r in vendor_inspection['solids'])
fps={r['reference']:r for r in receipt['footprints']}
f=fps['J402'];assert f['value']==alignment['selected_mpn'] and f['side']=='F'
rx=np.array([[1,0,0],[0,0,-1],[0,1,0]],dtype=float)
a=math.radians(f['rotation_deg']);rz=np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1]])
offset=np.array(alignment['kicad_model_offset_mm'])
mount=np.array([f['xy_mm'][0],-f['xy_mm'][1],bb[2]-skin+finished])
vendor_checks=[]
for row in vendor_raw['solids']:
    points=np.array(row['vertices'],dtype=np.float64);faces=np.array(row['triangles'],dtype=np.uint64)
    world=((points@rx.T+offset)@rz.T+mount)@rotation.T+translation
    m=solid_from(world,faces,'J402_VENDOR_'+str(row['index']),fallbacks)
    meshes.append({'index':'J402_VENDOR_'+str(row['index']),'is_board':False,'vertices':world.tolist(),'triangles':faces.tolist(),
        'vendor_documented':True,'source_evidence':{'source':str(vendor_path.relative_to(PROJECT)),'sha256':alignment['sha256'],
        'mount_plane':'ASSUMED seated on nominal finished PCB top; no solder standoff or mating tolerance qualification'}})
    local_solids.append(m)
    cross=m^board_solid;volume=float(cross.volume())
    vendor_checks.append({'solid':row['index'],'board_intersection_mm3':volume,'status':'PASS' if volume<1e-5 else 'FAIL'})
pin_axes=[]
for x in alignment['pin_x_centres_mm']:
    q=(np.array([x,0,0])@rz.T+mount)@rotation.T+translation
    errors=[]
    for pad in f['pads']:
        p=rotation@np.array([pad['xy_mm'][0],-pad['xy_mm'][1],mount[2]])+translation
        errors.append((float(np.linalg.norm(q[:2]-p[:2])),pad['number']))
    err,number=min(errors);pin_axes.append({'pin':number,'axis_error_mm':err,'status':'PASS' if err<1e-6 else 'FAIL'})
vendor_interface={'status':'PASS' if all(r['status']=='PASS' for r in vendor_checks+pin_axes) else 'FAIL',
    'source':str(vendor_path.relative_to(PROJECT)),'source_sha256':alignment['sha256'],'scale':1,
    'pin_axes':pin_axes,'board_solid_checks':vendor_checks,'mount_plane':'ASSUMED nominal zero standoff',
    'mating_housing':'NOT_TESTED','physical_fit':'NOT_TESTED'}
envelope_data=json.loads((H/'package_envelopes.json').read_text())
extra_data=json.loads((H/'extra_envelopes.json').read_text())
bom_path=(PROJECT/receipt['source']).parent/'bom_candidate.csv'
bom={r['ref']:r for r in csv.DictReader(bom_path.open())}
envelope_references=[]
for entry in envelope_data['parts']+extra_data['parts']:
    name=entry['reference'];f=fps[name];assert bom[name]['mpn']==entry['mpn'],name
    if name=='J402':continue # Superseded by the exact, unscaled manufacturer CAD above.
    if entry.get('source'):assert sha(PROJECT/entry['source'])==entry['source_sha256'],name
    angle=math.radians(f['rotation_deg']);c,s=math.cos(angle),math.sin(angle)
    # KiCad positive angle on native Y-down coordinates.
    native_r=np.array([[c,s,0],[-s,c,0],[0,0,1]])
    dim=np.array(entry['body_xyz_mm']);height=dim[2]+entry['solder_allocation_mm']
    side=1 if f['side']=='F' else -1
    plane=bb[2]-skin+(finished if side==1 else 0)
    local=manifold.Manifold.cube([dim[0],dim[1],height],True).translate([*entry['center_local_uv_mm'],side*height/2])
    native=local.transform(np.c_[native_r,[*f['xy_mm'],plane]])
    if entry.get('socket_mating_unresolved'):
        for pad in f['pads']:
            if not pad['number'].isdigit():continue
            length=entry['tail_length_max_mm']
            native+=manifold.Manifold.cube([*entry['nominal_tail_section_mm'],length],True).translate([*pad['xy_mm'],plane-length/2])
    # STEP/native solid convention has negative native v as Y.
    m=native.transform(np.c_[rotation@np.diag([1,-1,1]),translation])
    mesh=m.to_mesh64();meshes.append({'index':'ENVELOPE_'+name,'is_board':False,'vertices':mesh.vert_properties[:,:3].tolist(),
        'triangles':mesh.tri_verts.tolist(),'placeholder':True,'source_evidence':entry,
        'socket_mating_unresolved':bool(entry.get('socket_mating_unresolved'))})
    local_solids.append(m);envelope_references.append(name)
new=manifold.Manifold.batch_boolean(local_solids,manifold.OpType.Add)
assert new.status()==manifold.Error.NoError
newbb=np.array(new.bounding_box())
def overlaps(m,names,socket_envelope=False):
    b=np.array(m.bounding_box());out=[]
    for n in names:
        s=ss[n]
        if np.any(b[3:]<s.lo) or np.any(s.hi<b[:3]):continue
        cross=m^s.m;vol=float(cross.volume())
        if vol>1e-5:
            cb=np.array(cross.bounding_box())
            contact=n in ['Socket_AC','Socket_BD','Socket_E'] and cb[5]-cb[2]<1e-5 and abs(cb[5]-old_top)<1e-5
            classification='SUB_0P00001_MM_NOMINAL_BOARD_SOCKET_CONTACT' if contact else 'CLEARANCE_REVIEW_REQUIRED'
            if socket_envelope and n in ['MCU_Motion','E_Straight_Header']:
                classification='SOCKET_OUTER_ENVELOPE_VS_MATING_ASSEMBLY_UNRESOLVED'
            out.append({'part':n,'overlap_mm3':vol,'intersection_bounds_mm':cb.tolist(),'classification':classification})
    return sorted(out,key=lambda x:-x['overlap_mm3'])
retired_context=['MCU_Carrier','Socket_AC','Socket_BD','Socket_E']
targets=[n for n in ss if n not in retired_context]
mate_targets=['MCU_Motion','E_Straight_Header']
non_socket=manifold.Manifold.batch_boolean([m for row,m in zip(meshes,local_solids) if not row.get('socket_mating_unresolved')],manifold.OpType.Add)
hits=overlaps(new,[n for n in targets if n not in mate_targets])+overlaps(non_socket,mate_targets)
socket_mating_hits=[]
for row,m in zip(meshes,local_solids):
    if row.get('socket_mating_unresolved'):
        socket_mating_hits.append({'reference':row['source_evidence']['reference'],'status':'BLOCKED',
                                  'hits':overlaps(m,mate_targets,True)})
real_hits=[r for r in hits if r['classification']=='CLEARANCE_REVIEW_REQUIRED']
per_solid=[]
for row,m in zip(meshes,local_solids):
    h=overlaps(m,targets,row.get('socket_mating_unresolved',False))
    if h:per_solid.append({'export_solid':row['index'],'is_board':row['is_board'],'bounds_mm':list(m.bounding_box()),'hits':h})
# Do not waive the entire WeAct assembly merely because it contains mating
# pins. Independently check every other source solid against socket envelopes.
core=bpy.data.objects[PREFIX+'MCU_Motion']
corev=np.array([list(core.matrix_world@x.co) for x in core.data.vertices])
coref=np.array([list(p.vertices) for p in core.data.polygons],dtype=np.uint64)
core_index=json.loads(core['component_reference_index'])
header_refs={'VENDOR_'+str(i) for i in P['p5r7_adoption']['weact']['flipped_header_solids']}
socket_nonmate=[]
for row,m in zip(meshes,local_solids):
    if not row.get('socket_mating_unresolved'):continue
    mb=np.array(m.bounding_box());checked=0;core_hits=[]
    for item in core_index:
        if item['reference'] in header_refs:continue
        checked+=1;v=corev[slice(*item['vertices'])];lo,hi=v.min(0),v.max(0)
        if np.any(mb[3:]<lo) or np.any(hi<mb[:3]):continue
        faces=coref[slice(*item['faces'])]-item['vertices'][0]
        cm=solid_from(v,faces,'WEACT_'+item['reference'],fallbacks)
        volume=float((m^cm).volume())
        if volume>1e-5:
            hit={'part':'MCU_Motion/'+item['reference'],'socket':row['source_evidence']['reference'],
                 'overlap_mm3':volume,'classification':'CLEARANCE_REVIEW_REQUIRED'}
            core_hits.append(hit);real_hits.append(hit)
    socket_nonmate.append({'reference':row['source_evidence']['reference'],'checked_nonmating_core_solids':checked,
        'status':'FAIL' if core_hits else 'PASS','hits':core_hits,'excluded_mating_source_solids':sorted(header_refs)})
bottom_clearances=[]
for row,m in zip(meshes,local_solids):
    e=row.get('source_evidence',{});ref=e.get('reference')
    if ref in fps and fps[ref]['side']=='B':
        bottom_clearances.append({'reference':ref,'body_lower_z_mm':m.bounding_box()[2],
            'load_frame_gap_mm':float(m.min_gap(ss['Load_Frame'].m,5)),'search_cap_mm':5,
            'solder_allowance_mm':e['solder_allocation_mm'],'physical_fit':'NOT_TESTED'})
hole_checks=[]
for f in receipt['footprints']:
    if f['reference'].startswith('H'):
        q=rotation@np.array([f['xy_mm'][0],-f['xy_mm'][1],bb[2]-skin])+translation
        screws=[(n,s) for n,s in ss.items() if n.startswith('Carrier_Screw_')]
        errors=[(float(np.linalg.norm((s.lo[:2]+s.hi[:2])/2-q[:2])),n) for n,s in screws]
        error,name=min(errors)
        hole_checks.append({'reference':f['reference'],'world_xyz_mm':q.tolist(),'nearest_screw':name,'xy_axis_error_mm':error,'status':'PASS' if error<1e-4 else 'FAIL'})
motion=[];head=[s for s in ss.values() if s.group in ['yaw','pitch']]
for yaw in range(-60,61,10):
    for pitch in range(-20,26,5):
        for base in head:
            tr=rigidtr(yaw,pitch if base.group=='pitch' else 0)
            s=Solid(base.o,base,tr)
            if np.any(newbb[3:]<s.lo) or np.any(s.hi<newbb[:3]):continue
            vol=float((new^s.m).volume())
            if vol>1e-5:motion.append({'yaw_deg':yaw,'pitch_deg':pitch,'part':base.name,'overlap_mm3':vol})
gaps=[]
for n in ['Load_Frame','Yaw_Base','MCU_Motion','IMU_BMI323','Head_Buck_6V','UPS_Module','Body_Front','Body_Rear']:
    if n in ss:gaps.append({'part':n,'gap_mm':float((non_socket if n=='MCU_Motion' else new).min_gap(ss[n].m,5)),
                           'search_cap_mm':5,'socket_mate_envelopes_excluded':n=='MCU_Motion'})
ports=[]
for f in receipt['footprints']:
    if f['reference'].startswith('J'):
        pins=[]
        for p in f['pads']:
            q=rotation@np.array([p['xy_mm'][0],-p['xy_mm'][1],bb[2]-skin+finished])+translation
            pins.append({'number':p['number'],'net':p['net'],'world_xyz_mm':q.tolist()})
        ports.append({'reference':f['reference'],'value':f['value'],'source_rotation_deg':f['rotation_deg'],'pins':pins,'wire_exit':'NOT_RELEASED; footprint pad plane is not the cable-tail datum'})
before=receipt['protected_sources'];changed=[p for p,d in before.items() if sha(PROJECT/p)!=d]
assert not changed,changed
out={'status':'BLOCKED','scope':'Native finished board, available library models, J402 manufacturer CAD and 23 documented/assumed outer envelopes; socket mating interiors unresolved',
     'known_geometry_static':'FAIL' if real_hits else 'PASS','raw_static_intersections':hits,'static_hits':real_hits,'per_export_solid_hits':per_solid,
     'mounting_axes':hole_checks,'head_motion':{'status':'FAIL' if motion else 'PASS','poses':130,'failures':motion,'continuous_motion':'NOT_TESTED'},
     'component_model_coverage':{'native_footprints':len(receipt['footprints']),'missing':receipt['missing_model_references'],'complete_populated_fit':'BLOCKED'},
     'additional_package_envelopes':{**envelope_data,'active_references':envelope_references,'superseded_by_vendor_CAD':['J402']},
     'J402_vendor_interface':vendor_interface,
     'extra_package_envelopes':extra_data,'socket_mating_review':socket_mating_hits,
     'socket_vs_nonmating_core_solids':socket_nonmate,'bottom_package_clearances':bottom_clearances,
     'remaining_without_model_or_envelope':[r for r in receipt['missing_model_references'] if r not in envelope_references+['J402']],
     'source_library_model_fallbacks':fallbacks,'known_geometry_gaps':gaps,
     'mapping':{'rotation':rotation.tolist(),'translation_mm':translation.tolist(),'board_bottom_world_z_mm':bottom,'board_top_world_z_mm':old_top,
                'export_substrate_thickness_mm':substrate,'native_finished_thickness_mm':finished,'added_finished_envelope_each_mm':skin,
                'library_component_positions_unmodified':True,'export_board_indices':board_indices},
     'known_geometry_bounds_xyz_mm':[newbb[:3].tolist(),newbb[3:].tolist()],
     'port_pad_datums':ports,'retired_by_hardware_contract':['Head_Buck_6V','U05','U06'],
     'existing_socket_models':'Old three Socket_* objects excluded from new candidate; XKB/HCTL outer maximum bodies and nominal tails only, mating voids not invented',
     'main_adoption':False,'printed_changes':[],'physical_fit':'NOT_TESTED','manufacturing_release':False,
     'protected_sources_unchanged':not changed,'sources':{str(p.relative_to(PROJECT)):sha(p) for p in [Path(__file__),H/'native_receipt.json',H/'partial_mesh.json',H/'board_mesh.json',H/'package_envelopes.json',H/'extra_envelopes.json',H/'J402_vendor_mesh.json',H/'J402_vendor_mesh.inspection.json',vendor_path,vendor_dir/'model_alignment_receipt.json',PROJECT/envelope_data['source'].split('#')[0],bom_path]}}
(H/'scene_check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
# Compact coordinates for a static review; no main-scene save.
(H/'world_geometry.json').write_text(json.dumps({'solids':meshes},separators=(',',':')))
print(json.dumps({k:out[k] for k in ['status','known_geometry_static','static_hits','mounting_axes','head_motion','source_library_model_fallbacks','known_geometry_bounds_xyz_mm']},indent=2),flush=True)
