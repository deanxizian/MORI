"""Transcribed external package limits, never a fabricated manufacturer model."""
from pathlib import Path
import hashlib, json
H=Path(__file__).resolve().parent; ROOT=H.parents[2]
base='hardware/v1_2/interface_board/design/'
groups=[
    (['D1801','D1802'],'SMBJ13CA-13-F',[5.59,3.94,2.50],base+'C3/research/transients/SMBJ.pdf',5,'E, A, J maxima; includes leads',.2),
    (['D1803','D901'],'B340LA-13-F',[5.59,2.92,2.40],base+'C3/research/transients/B340LA.pdf',4,'SMA E, A, J maxima; includes leads',.2),
    (['Q1601','Q1602'],'CSD17577Q5A',[6.10,5.00,1.10],base+'C3/research/direct_power/CSD17577Q5A.pdf',8,'E, D1, A maxima; includes terminal span',.2),
    (['R1101'],'WSL2512R0200FEA',[6.604,3.434,.889],base+'C3/sources/Vishay_WSL.pdf',2,'WSL2512 L/W/H maxima; 20 milliohm row; dimensions in mm',.2),
    (['TH1501'],'NTCG163JF103FT1S',[1.7,.9,.9],base+'C3/research/head_thermal/supplier_facts.json',None,'Official product transcription: 1.6/.8/.8 plus .1 mm tolerance; local PDF unavailable',.2),
    (['U1201'],'TPS259474LRPWR',[2.1,2.1,1.0],base+'C1/sources/TPS25947.pdf',72,'RPW0010A package maxima',.2),
    (['U702','U801'],'TPS259470LRPWR',[2.1,2.1,1.0],base+'C1/sources/TPS25947.pdf',72,'RPW0010A package maxima',.2),
    (['U1601'],'LM74502DDFR',[2.95,3.25,1.10],base+'C3/research/direct_power/LM74502.pdf',27,'DDF0008A; X total lead span; Y body2.95 plus mold flash .15 per side per note3',.2),
    (['U1701'],'INA300AIDGSR',[5.05,3.4,1.10],base+'C3/research/direct_power/INA300.pdf',39,'DGS0010A; X leadspan5.05; Y body3.1 plus mold flash .15 per side per note3; note4 flash stays inside lead span',.2),
    (['J101','J102'],'X6521FV-2x15-C85D32',[38.9,5.3,8.8],base+'C3/sources/XKB_X6521FV.pdf',1,'2x15 length2.54*15+.40 plus .40; width5 and height8.5 plus general .3; no cavity/contact model',0),
    (['J105'],'PM254-2-04-Z-8.5',[5.15,10.86,8.65],base+'C1/sources/HCTL_PM254_2_04.pdf',1,'2x4 length2.54*4+.4 plus .3; width5+.15, height8.5+.15; no cavity/contact model',0),
]
parts=[]
for refs,mpn,dims,source,page,basis,solder in groups:
    for ref in refs:
        row={'reference':ref,'mpn':mpn,'body_xyz_mm':dims,'center_local_uv_mm':[0,0],
            'solder_allocation_mm':solder,'evidence':'VENDOR_DRAWING_MAX_OUTER_ENVELOPE; ASSUMED_RECTANGULAR_ENCLOSURE',
            'source':source,'source_sha256':hashlib.sha256((ROOT/source).read_bytes()).hexdigest(),
            'source_page_1based':page,'dimension_basis':basis,'full_detail':'NOT_TESTED'}
        if solder:row['evidence']+='; ASSUMED_SOLDER_ALLOWANCE'
        if ref in ['J101','J102','J105']:
            row['socket_mating_unresolved']=True
            row['center_local_uv_mm']=[1.27,3.81] if ref=='J105' else [17.78,-1.27]
            row['nominal_tail_section_mm']=[.64,.4] if ref=='J105' else [.64,.64]
            row['nominal_tail_length_mm']=3.2
            row['tail_length_max_mm']=3.45 if ref=='J105' else 3.4
            row['mating_limits']='No spring/cavity dimensions or engagement depth; nominal 11.04 mm stack only. Outer maximum box can overlap mating pins/header. Tails recorded, not included in body box.'
        parts.append(row)
out={'status':'BLOCKED','scope':'16 missing component external envelopes only; exact full bodies and mating geometry not supplied',
     'units':'mm','solder_allocation_status':'ASSUMED .2 mm; supplier process not yet known',
     'source_pages_visually_inspected':True,'parts':parts}
(H/'extra_envelopes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('EXTERNAL_ENVELOPES',len(parts),'NO_VENDOR_CAD_INVENTED')
