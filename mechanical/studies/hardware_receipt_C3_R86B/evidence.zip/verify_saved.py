"""Read the saved independent blend; verify geometry and classification."""
import bpy,json,hashlib
from pathlib import Path
import numpy as np
H=Path(__file__).resolve().parent
expected=json.loads((H/'world_geometry.json').read_text())['solids']
errors=[];max_error=0.;counts={'placeholder':0,'vendor':0,'other':0}
for row in expected:
    name='C3_'+str(row['index']);o=bpy.data.objects.get(name)
    if o is None:errors.append([name,'missing']);continue
    v=np.array([list(o.matrix_world@x.co) for x in o.data.vertices]);target=np.array(row['vertices'])
    if v.shape!=target.shape:errors.append([name,'vertex count']);continue
    delta=float(np.max(np.abs(v-target)));max_error=max(max_error,delta)
    if delta>1e-5:errors.append([name,'coordinates',delta])
    if not o.get('unadopted'):errors.append([name,'unadopted metadata'])
    if row.get('placeholder'):
        counts['placeholder']+=1
        if o.get('category')!='PLACEHOLDER' or o.get('data_status')!='ASSUMED':errors.append([name,'placeholder classification'])
    elif row.get('vendor_documented'):
        counts['vendor']+=1
        if o.get('data_status')!='VENDOR_DOCUMENTED':errors.append([name,'vendor classification'])
    else:counts['other']+=1
    if row.get('source_evidence') and json.loads(o.get('source_evidence','{}'))!=row['source_evidence']:errors.append([name,'source metadata'])
for name in ['MCU_Carrier','Socket_AC','Socket_BD','Socket_E']:
    if name in bpy.data.objects:errors.append([name,'retired context present'])
out={'status':'FAIL' if errors else 'PASS','blend':Path(bpy.data.filepath).name,
     'blend_sha256':hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest(),
     'checked_solids':len(expected),'counts':counts,'max_float32_coordinate_error_mm':max_error,
     'errors':errors,'main_model_replaced':False}
(H/'saved_model_check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False));assert not errors
