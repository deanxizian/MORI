"""Capture exact commands and hashes for this independent mechanical review."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
H=Path(__file__).resolve().parent;ROOT=H.parents[2]
stage=sys.argv[1];cmd=sys.argv[2:];now=lambda:datetime.datetime.now().astimezone().isoformat()
before=now();p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
log=H/(stage+'.log');log.write_text(p.stdout+p.stderr)
ledger=H/'commands.json';entries=json.loads(ledger.read_text()) if ledger.exists() else []
entries.append({'stage':stage,'command':cmd,'cwd':str(ROOT),'started':before,'finished':now(),'returncode':p.returncode,'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
ledger.write_text(json.dumps(entries,indent=2)+'\n');print((p.stdout+p.stderr)[-2200:]);raise SystemExit(p.returncode)
