"""Read-only native PCB interfaces; no footprint or electrical edits."""
import hashlib,json,os
from pathlib import Path
import wx
app=wx.App(False)
import pcbnew

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'hardware/v1_2/interface_board/design/C3/routing/working_power_20261016/group_closure_20261016/candidate_6L_R86B/MORI_Interface_C3.kicad_pcb'
EXPECTED='2a563d9c8a37ba7da104a20e6a5fe4b7bb076f3217f8b1f5fcc3deb4595cf641'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SOURCE)==EXPECTED
board=pcbnew.LoadBoard(str(SOURCE));mm=pcbnew.ToMM
xy=lambda p:[mm(p.x),mm(p.y)]
edges=[]
for s in board.GetDrawings():
    if s.GetLayer()==pcbnew.Edge_Cuts:
        edges.append({'type':str(s.GetShape()),'start_mm':xy(s.GetStart()),'end_mm':xy(s.GetEnd()),'stroke_width_mm':mm(s.GetWidth())})
root3d=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/3dmodels')
footprints=[]
for f in sorted(board.GetFootprints(),key=lambda f:f.GetReference()):
    pads=[]
    for p in f.Pads():
        pads.append({'number':p.GetNumber(),'xy_mm':xy(p.GetPosition()),'size_mm':xy(p.GetSize()),'drill_mm':xy(p.GetDrillSize()),'type':int(p.GetAttribute()),'net':p.GetNetname()})
    models=[]
    for m in f.Models():
        source=str(m.m_Filename)
        resolved=Path(source.replace('${KICAD10_3DMODEL_DIR}',str(root3d)).replace('${KIPRJMOD}',str(SOURCE.parent)))
        models.append({'source':source,'resolved':str(resolved),'exists':resolved.is_file(),'sha256':sha(resolved) if resolved.is_file() else None,
                       'offset_mm':[m.m_Offset.x,m.m_Offset.y,m.m_Offset.z],
                       'rotation_deg':[m.m_Rotation.x,m.m_Rotation.y,m.m_Rotation.z],
                       'scale':[m.m_Scale.x,m.m_Scale.y,m.m_Scale.z],
                       'evidence':'KICAD_LIBRARY_REFERENCE_NOT_MEASURED_VENDOR_ASSEMBLY'})
    footprints.append({'reference':f.GetReference(),'value':f.GetValue(),'footprint':str(f.GetFPID().GetLibItemName()),
                       'xy_mm':xy(f.GetPosition()),'rotation_deg':f.GetOrientationDegrees(),'side':'B' if f.IsFlipped() else 'F',
                       'pads':pads,'models':models})
unknown=[f['reference'] for f in footprints if not f['reference'].startswith('H') and (not f['models'] or not all(m['exists'] for m in f['models']))]
old=json.loads((ROOT/'mechanical/sources/populated_P5R7/inventory.json').read_text())['boards']['motion']
oldholes={f['reference']:f for f in old['footprints'] if f['reference'].startswith('H')}
holes=[]
for f in footprints:
    if f['reference'] in oldholes:
        o=oldholes[f['reference']]
        holes.append({'reference':f['reference'],'old_xy_mm':o['xy_mm'],'new_xy_mm':f['xy_mm'],'new_drill_mm':f['pads'][0]['drill_mm'],
                      'delta_xy_mm':[round(a-b,9) for a,b in zip(f['xy_mm'],o['xy_mm'])]})
paths=[SOURCE,ROOT/'contracts/components.json',ROOT/'contracts/electrical_interfaces.json',ROOT/'contracts/mechanical_interfaces.json',ROOT/'config/geometry.json',ROOT/'mechanical/mori_v1_2.blend',ROOT/'hardware/v1_2/interface_board/design/C1/MECHANICAL_HANDOFF.md']
out={'status':'PASS','scope':'Native outline, holes, pads and referenced model inventory only; not complete populated-board fit',
     'pcb_revision':'C3_R86B','kicad_version':pcbnew.Version(),'units':'mm','source':str(SOURCE.relative_to(ROOT)),'source_sha256':EXPECTED,
     'thickness_mm':mm(board.GetDesignSettings().GetBoardThickness()),'edges':edges,'footprints':footprints,
     'missing_model_references':unknown,'mount_hole_comparison':holes,
     'hardware_contract_revision':json.loads((ROOT/'contracts/components.json').read_text())['revision'],
     'contract_is_older_than_native_layout':True,'board_release':'BLOCKED','main_adoption':False,
     'protected_sources':{str(p.relative_to(ROOT)):sha(p) for p in paths}}
(HERE/'native_receipt.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
assert sha(SOURCE)==EXPECTED
print(json.dumps({'footprints':len(footprints),'missing_models':unknown,'holes':holes,'thickness_mm':out['thickness_mm']},ensure_ascii=False,indent=2))
