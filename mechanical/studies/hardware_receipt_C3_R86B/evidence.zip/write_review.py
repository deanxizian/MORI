"""Publish a small, local-only engineering receipt from the checked data."""
from pathlib import Path
import hashlib, json, os, html
from urllib.parse import quote

H=Path(__file__).resolve().parent;ROOT=H.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
n=json.loads((H/'native_receipt.json').read_text())
s=json.loads((H/'scene_check.json').read_text())
i=json.loads((H/'interface_check.json').read_text())
e=json.loads((H/'extra_envelopes.json').read_text())
source_rows=[]
for x in e['parts']:
    row=(x['source'],x.get('source_page_1based'))
    if row not in source_rows:source_rows.append(row)
links='\n'.join(f'- [{Path(p).name}](../../../{p})'+(f'，第 {page} 页' if page else '，原厂数据转录') for p,page in source_rows)
md=f'''# C3 R86B 接收检查

**BLOCKED / PROTOTYPE / UNVALIDATED。独立研究，主模型未替换。**

[静态图](index.html) · [独立 Blender](C3_R86B_PARTIAL_REVIEW.blend) · [几何结果](scene_check.json) · [接口结果](interface_check.json) · [保存模型复核](saved_model_check.json) · [命令记录](commands.json)

本次解决的是新版接口板的机械来源接收和已有结构的空间核对。保存的主模型仍为 M1.58，含 P5R7 旧载板和外置 6 V Buck；硬件已改为 C3／板载 6 V。没有将未完成的 PCB 或线束偷偷同步进主模型，也没有修改打印件、硬件设计、视频或提交 PR。

## 收到的来源

- 正式合同：`{n['hardware_contract_revision']}`；合同中的 C1 交接早于 C3 原生布局，不把旧合同的“原生板尚无”当成当前事实。
- 原生板：`{n['pcb_revision']}`，SHA256 `{n['source_sha256']}`。原生 70×35×1.6 mm，4 个安装孔；硬件当前记录为 52 项未连接、31 个网络，不可制造。本报告不是 DRC／ERC 重跑或布线放行。
- 线束：`interfaces_BT_R1/wires_BT_R1.csv`，31 个物理单线段。BT_R1 自带的旧 PCB 未连线数量不继承为 R86B 结果；本次重新比较了当前针位网络。
- J402：HC-5264-3AW 厂家 STEP，4 个有效实体，毫米、比例 1。厂家下载文件带 `-02` 后缀，保持原采购型号，不擅自替换 SKU。来源及轴变换见 `scene_check.json#/J402_vendor_interface`。

## 这次已经检查

| 项目 | 结果 | 范围 |
|---|---|---|
| 4 个安装轴 | PASS | 与 M1.58 现有载板螺钉轴一致，最大偏差小于 0.000005 mm |
| 68 个 WeAct 针位 | {i['pin_grid']['status']} | 逐针比较已接收坐标，最大误差 {i['pin_grid']['max_error_mm']:.9f} mm |
| 31 段线束定义 | {i['digital_definition_check']} | 22 个已用载板触点、53 个接插件触点、3 处分线；每触点一根线；IMU 的 NC 不接线 |
| 厂家 J402 | {s['J402_vendor_interface']['status']} | 3 针轴线与原生孔一致，针脚未与板材实体相交；零悬空安装面仍是名义假设 |
| 已覆盖几何与现有结构 | {s['known_geometry_static']} | 原生板、库实体、厂家 J402 和 23 个外部尺寸包络；未把排母内腔虚构出来 |
| 排母与非插合部件 | PASS | 每个排母包络分别检查 WeAct 的 219 个非插合原厂实体；4 个原配排针实体及独立 E 排针的配合另列 BLOCKED |
| 头部组合姿态 | {s['head_motion']['status']} | yaw −60…60°、pitch −20…25°，130 个离散组合；连续运动和带线运动未验证 |
| 板底补充包络 | PASS | D1802／D1803／D901／U1701 对承重板最小名义间隙分别 2.3／2.4／2.4／3.7 mm，含假设的 0.2 mm 焊高 |
| 源文件／主模型 | PASS | `native_receipt.json#/protected_sources` 的 7 个保护输入前后哈希一致 |

`carrier_pad_datums.csv` 是 PCB 焊盘平面坐标，不是插头后端或导线出线点，不能直接据此裁线。

## 包络与未完成边界

橙色部分是外部包络，类别 **PLACEHOLDER / ASSUMED**：厂家图确定外形上限，矩形填充、部分焊高和插合内部仍有假设。未缩放真实硬件。16 处原先缺失的外形已补齐尺寸包络，另保留先前 7 处电感／电容最大外形包络；这不表示 23 个完整精细模型已完成。

原生 KiCad 导出板芯厚度为 {s['mapping']['export_substrate_thickness_mm']:.4f} mm，而设计成品板厚为 1.6 mm。本研究只对板材包络每面增加 {s['mapping']['added_finished_envelope_each_mm']:.4f} mm；元件 STEP 保持 1:1。元件间的完整实物装配、铜／阻焊工艺和制造公差未因此获证。

三处新排母的最大外包络与对插针／排针座相交，已原样记录为 **BLOCKED**。没有把内腔填实后的包络当成实体缺陷，也没有以“排针有意插入”为由忽略核心板上的其他元件。实际内腔、簧片、插入深度、针脚公差和 11.04 mm 板间距仍需核实。精确度不足时不修改打印件来补偿。

仍可继续的数字工作：配对插头的原厂几何和尾线起点、全板元件之间的完整装配、全部线束路线与余线固定、带线装入、CAM 原板 PWR 操作通路。新 PCB 布线收尾归硬件任务；最终安装与软线、温升、强度、平衡等需实物验证。

旧机械 U03／U04 分别映射为 C3-W1／W2 的功能，不能直接继承对端姿态或裁线长度。已确认的 S288 190 mm 导线段和 SP3040 150 mm 出口到插头长度保留。外置 Buck 的 U05/U06 退休；CAM 为四芯信号＋两芯 BAT 电源，不沿用旧常驻 USB 供电模型。

## 来源尺寸页

{links}

原文件只读，逐项来源哈希、页码、尺寸解释及焊高假设写入 `extra_envelopes.json`。页面截图只用于转录复核；当前图示没有完整原厂装配模型时仍明确使用包络。

## 复现与文件范围

模型／检查的实际命令、时间、返回码和日志 SHA256 在 `commands.json`；PDF 页渲染命令及目视记录在 `source_page_review.json`。不要从本报告推断未执行的检查。`read_native.py` 使用 KiCad Python，STEP 用 KiCad 10.0.6 导出，转换为 cadquery-ocp 7.8.1.1.post1，几何与静态图用 Blender 5.2.2 LTS。保存后的独立 Blender 已重新打开，219 个载板实体逐顶点核对通过，23 个包络和 4 个厂家 J402 实体的来源／状态标签一致，见 `saved_model_check.json`。

本目录脚本仅写本目录的独立接收文件；它们不会保存到主模型或覆盖原生 PCB。维护的项目入口仅为 `docs/CURRENT_STATUS.md`、`docs/PREARRIVAL_BLOCKERS.md`、`mechanical/LATEST_MODEL.md`。没有向硬件对话发送指令，没有生成新视频、制造包或采购订单。
'''
(H/'README.md').write_text(md)

source_html=''.join(f'<li><a href="{quote(os.path.relpath(ROOT/p,H),safe="/")}">{html.escape(Path(p).name)}</a> / '+(f'第 {pg} 页' if pg else '原厂数据转录')+'</li>' for p,pg in source_rows)
body=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>C3 R86B 接口板接收检查</title>
<style>body{{font:16px/1.7 system-ui,sans-serif;max-width:1100px;margin:40px auto;padding:0 22px;background:#f4f5f4;color:#1d2c2a}}h1{{line-height:1.25;font-size:34px}}h2{{margin-top:36px}}a{{color:#126657}}.status{{background:#fff1d6;padding:18px 22px;border-left:5px solid #c47f1a;border-radius:5px}}.meta{{color:#536660}}figure{{margin:24px 0;background:#e4e9e8;border-radius:10px;overflow:hidden}}img{{width:100%;display:block}}figcaption{{padding:12px 16px}}table{{border-collapse:collapse;width:100%;background:white}}td,th{{text-align:left;padding:12px;border-bottom:1px solid #dae1df}}code{{overflow-wrap:anywhere}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}.grid figure{{margin:0}}details{{margin:22px 0}}@media(max-width:760px){{.grid{{grid-template-columns:1fr}}body{{margin-top:22px}}}}</style>
<p class="meta">机械 M1.58 / 硬件 C3 R86B / 独立检查</p><h1>接口板已接收，主模型尚未替换</h1>
<div class="status"><strong>BLOCKED · PROTOTYPE / UNVALIDATED</strong><br>安装轴、针位和本次覆盖到的空间检查通过。排母插合、配对插头、完整线束及 PCB 布线尚未完成。</div>
<p><a href="C3_R86B_PARTIAL_REVIEW.blend">打开独立 Blender</a> · <a href="README.md">完整说明</a> · <a href="../../../docs/CURRENT_STATUS.md">项目当前状态</a> · <a href="../../mori_v1_2.blend">原主模型 M1.58</a></p>
<figure><img src="assembly_review.png" alt="新载板与原承重板、偏航桥和WeAct的独立空间检查"><figcaption>保持原孔轴与 WeAct 位姿。这里只替换独立研究中的载板参考；原主模型与打印件未改。</figcaption></figure>
<h2>完成的检查</h2><table><thead><tr><th>项目</th><th>结果</th><th>边界</th></tr></thead><tbody>
<tr><td>4 个安装轴 / 68 个 WeAct 针位</td><td>PASS</td><td>坐标逐项相符；不是插入深度验证。</td></tr>
<tr><td>31 段线束 / 22 个已用载板触点</td><td>PASS</td><td>网络定义一致，每触点一根线；尚无发布线长。</td></tr>
<tr><td>已覆盖几何 / 130 个头姿</td><td>PASS</td><td>有限静态姿态；不包含配对插头、全线束或连续扫掠。</td></tr>
<tr><td>板底补充器件对承重板</td><td>PASS</td><td>最小名义间隙 2.3 mm，含 0.2 mm 假设焊高。</td></tr>
<tr><td>排母与核心板非插合部件</td><td>PASS</td><td>每个排母逐项检查 219 个非插合原厂实体。</td></tr>
<tr><td>排母簧片 / 对插 / 全板装配</td><td>BLOCKED</td><td>外包络与插合针座相交单列记录，未虚构内腔。</td></tr>
<tr><td>PCB 制造 / 实物资格</td><td>FAIL / NOT_TESTED</td><td>硬件仍有 52 项未连接；未制造或上电放行。</td></tr>
</tbody></table>
<h2>外部尺寸依据已补齐</h2><p>灰色为收到的库模型或厂家 CAD；橙色为厂家图支持的外部包络，仍含焊高、内部形状或装配假设。它们有尺寸依据，但不能称为完整精细模型。</p>
<div class="grid"><figure><img src="board_review.png" alt="载板正面与橙色外部包络"><figcaption>正面：新 XKB / HCTL 排母包络、两路降压等。</figcaption></figure><figure><img src="board_bottom_review.png" alt="载板背面器件与名义焊脚"><figcaption>背面：二极管等最大外形与名义排母焊脚。</figcaption></figure></div>
<h2>接下来还要完成</h2><p>配对插头与尾线起点、全板元件间的完整装配、全部路线与余线固定、带线装入，以及 CAM 原板 PWR 的操作通路。硬件布线收尾后再核对来源并处理主模型同步。原视频保持 M1.57-A1。</p>
<p><a href="scene_check.json">几何结果</a> · <a href="interface_check.json">接口结果</a> · <a href="carrier_pad_datums.csv">针面坐标（不是导线出线点）</a> · <a href="commands.json">实际命令</a> · <a href="extra_envelopes.json">包络尺寸与来源</a></p>
<details><summary>来源与复核范围</summary><p>PCB SHA256 <code>{n['source_sha256']}</code>。原生板、正式合同和线束文档版本分别接收；没有覆盖硬件文件。</p><ul>{source_html}</ul><p>按原尺寸导入厂家 J402，未缩放硬件。三处排母内部簧片、针腔和实际啮合仍未知；外部包络与插合零件的重叠不视为通过，也不擅自修改主模型来消除它。</p></details></html>'''
(H/'index.html').write_text(body)
print('WROTE README.md index.html; independent read-only receipt')
