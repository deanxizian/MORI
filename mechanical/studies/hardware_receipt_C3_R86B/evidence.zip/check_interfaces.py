"""Read-only receipt of BT_R1 wires against the pinned R86B native pad map.

This checks documents and pad datums, not electrical design, physical mating,
wire lengths or assembly access. It never writes hardware-owned files.
"""
import csv, hashlib, json, math
from collections import Counter, defaultdict
from pathlib import Path

H = Path(__file__).resolve().parent
ROOT = H.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
native = json.loads((H / 'native_receipt.json').read_text())
scene = json.loads((H / 'scene_check.json').read_text())
base = ROOT / 'hardware/v1_2/interface_board/design/C3'
wire_dir = base / 'routing/working_power_20261016/group_closure_20261016/interfaces_BT_R1'
fixed_path = base / 'interfaces/mechanical_C3_R6_P1.json'
paths = [fixed_path, ROOT / native['source']] + [wire_dir / n for n in [
    'wires_BT_R1.csv', 'mating_by_port_BT_R1.csv', 'terminal_constraints_BT_R1.csv',
    'head_splices_BT_R1.json', 'verification.json']]
before = {str(p.relative_to(ROOT)): sha(p) for p in paths}
assert before[native['source']] == native['source_sha256']
wire_rows = list(csv.DictReader((wire_dir / 'wires_BT_R1.csv').open(encoding='utf-8-sig')))
mate_rows = list(csv.DictReader((wire_dir / 'mating_by_port_BT_R1.csv').open(encoding='utf-8-sig')))
old_verify = json.loads((wire_dir / 'verification.json').read_text())
for name, digest in old_verify['outputs'].items():
    if (wire_dir / name).exists():
        assert sha(wire_dir / name) == digest, name

fps = {r['reference']: r for r in native['footprints']}
pads = {(r['reference'], p['number']): p for r in native['footprints'] for p in r['pads'] if p['number'] != 'MP'}
fixed = json.loads(fixed_path.read_text())['fixed68pins']
pin_checks = []
for p in fixed:
    now = pads[(p['connector'], str(p['pad']))]
    delta = math.dist(p['native_uv_mm'], now['xy_mm'])
    pin_checks.append({'vendor_pin': p['vendor_pin'], 'connector': p['connector'], 'pad': str(p['pad']),
                       'coordinate_error_mm': delta, 'status': 'PASS' if delta < 1e-6 else 'FAIL'})
assert len(fixed) == 68

# Explicit translation of the handed-off logical signal names to native nets.
# DATA is context-dependent; the two UPS return wires remain distinct segments.
aliases = {
    'J401': {'DATA': '/03 {slash} Motor_Buses/WHEEL_BUS', 'WHEEL_VM': '/WHEEL_VM', 'GND': 'GND'},
    'J402': {'DATA': '/03 {slash} Motor_Buses/HEAD_BUS', 'HEAD_VM_6V': '/HEAD_VM', 'GND': 'GND'},
    'J501': {'CAM_RX44': 'Net-(J501-RX44)', 'CAM_TX43': 'Net-(J501-TX43)', 'CAM_3V3_REF': 'CAM_3V3_REF', 'GND': 'GND'},
    'J502': {'IMU_SDA': '/01 {slash} Core/IMU_SDA', 'IMU_SCL': '/01 {slash} Core/IMU_SCL', 'MOTION_3V3': 'MOTION_3V3', 'GND': 'GND'},
    'J701': {'UPS_5V': '/06 {slash} CAM_Buck/UPS_5V', 'GND_5V_RETURN': 'GND', 'UPS_SDA': 'Net-(J701B-SDA)',
             'UPS_SCL': 'Net-(J701B-SCL)', 'GND_BAT_RETURN': 'GND', 'UPS_BAT': '/UPS_BAT'},
    'J702': {'CAM_BAT_OUT': '/07 {slash} CAM_Protection_Start/CAM_BAT_OUT', 'GND': 'GND'},
}
world_pads = {(r['reference'], p['number']): p for r in scene['port_pad_datums'] for p in r['pins'] if p['number'] != 'MP'}
counts = Counter(); splice_signals = defaultdict(set); connections = []; route_datums = []
for r in wire_rows:
    for side in ['from', 'to']:
        port, pin = r[side + '_port'], r[side + '_pin']
        key = (port, pin); counts[key] += 1
        if port.startswith('SPLICE_'):
            splice_signals[key].add(r['signal'])
        if port in aliases:
            native_pad = pads[key]; expected = aliases[port][r['signal']]
            connections.append({'segment': r['physical_segment_id'], 'port': port, 'pin': pin, 'signal': r['signal'],
                'native_net': native_pad['net'], 'expected_net': expected,
                'status': 'PASS' if expected == native_pad['net'] else 'FAIL'})
            q = world_pads[key]['world_xyz_mm']
            route_datums.append({'segment': r['physical_segment_id'], 'port': port, 'pin': pin, 'signal': r['signal'],
                'x_mm': q[0], 'y_mm': q[1], 'z_mm': q[2], 'datum_kind': 'PCB_PAD_PLANE_NOT_CABLE_TAIL'})
one_wire = all(n == 1 for (p, _), n in counts.items() if not p.startswith('SPLICE_'))
splice_degrees = {p + '.' + n: counts[(p, n)] for p, n in splice_signals}
splice_valid = all(n == 3 for n in splice_degrees.values()) and all(len(s) == 1 for s in splice_signals.values())
mate_checks = []
for r in mate_rows:
    expected = sorted(r['populated_pins'].split())
    found = sorted(pin for port, pin in counts if port == r['port'])
    mate_checks.append({'port': r['port'], 'expected_pins': expected, 'wire_pins': found,
                        'status': 'PASS' if expected == found else 'FAIL'})
nc_clear = ('J502', '1') not in counts and pads[('J502', '1')]['net'].startswith('unconnected-')
assert all(sha(ROOT / p) == h for p, h in before.items())
document_pass = (len(connections) == 22 and all(r['status'] == 'PASS' for r in connections + pin_checks + mate_checks)
                 and one_wire and splice_valid and nc_clear)
out = {
    'status': 'BLOCKED', 'digital_definition_check': 'PASS' if document_pass else 'FAIL',
    'scope': 'Native R86B pad connectivity/coordinates versus earlier BT_R1 harness documents only',
    'native_board_revision': native['pcb_revision'], 'native_board_sha256': native['source_sha256'],
    'old_BT_board_sha256': old_verify['source_board_sha256'],
    'old_BT_DRC_status_not_inherited': old_verify['full_PCB_release'],
    'pin_grid': {'status': 'PASS' if all(r['status'] == 'PASS' for r in pin_checks) else 'FAIL',
                 'count': len(pin_checks), 'max_error_mm': max(r['coordinate_error_mm'] for r in pin_checks), 'checks': pin_checks},
    'native_port_pin_checks': connections,
    'physical_segments': len(wire_rows), 'populated_carrier_contacts': len(connections),
    'connector_contacts': sum(n for (p, _), n in counts.items() if not p.startswith('SPLICE_')),
    'one_wire_per_connector_contact': one_wire, 'splice_degrees': splice_degrees,
    'splice_signals_consistent': splice_valid, 'mate_population_checks': mate_checks,
    'IMU_NC_unpopulated': nc_clear,
    'all_finished_lengths_unreleased': all(not r['finished_length_mm'] and r['cut_release'] == 'BLOCKED' for r in wire_rows),
    'mechanical_old_route_crosswalk': {'U03': 'C3-W1; re-route from new J401, old length not inherited',
        'U04': 'C3-W2; 190 mm user wire segment retained, motor socket A/B pose mapping unresolved',
        'U05/U06': 'retired external 6 V buck connections'},
    'hardware_edits': False, 'main_adoption': False, 'physical_mating': 'NOT_TESTED', 'cut_release': 'BLOCKED',
    'remaining': ['External package bounds covered; exact missing component geometry remains represented by envelopes', 'New WeAct socket stack and mated plugs incomplete',
        'Full wire routes, stock cable/slack restraint and wired assembly incomplete', 'CAM manual PWR access incomplete'],
    'sources': before, 'source_integrity': 'PASS',
}
(H / 'interface_check.json').write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
with (H / 'carrier_pad_datums.csv').open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(route_datums[0])); w.writeheader(); w.writerows(route_datums)
print(json.dumps({k: out[k] for k in ['status', 'digital_definition_check', 'physical_segments', 'populated_carrier_contacts',
    'connector_contacts', 'one_wire_per_connector_contact', 'splice_degrees', 'IMU_NC_unpopulated', 'source_integrity']}, ensure_ascii=False))
