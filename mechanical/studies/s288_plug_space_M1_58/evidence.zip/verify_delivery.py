"""Verify recorded source hashes, protected outputs and local review links."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
from urllib.request import Request, urlopen
import hashlib, json, datetime

H = Path(__file__).resolve().parent
P = H.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
base = json.loads((H / 'protected_before.json').read_text())
changed = [name for name, digest in base.items() if sha(P / name) != digest]
assert not changed, changed
r = json.loads((H / 'review.json').read_text())
assert r['source_fields_sha256'] == sha(H / 'source_fields.json')
assert r['user_receipt_sha256'] == sha(H / 'lead_receipt.json')
assert r['vendor_mesh_sha256'] == sha(H.parent / 's288_vendor_fit_M1_58/vendor_mesh.json')
source = json.loads((H / 'sources/receipt.json').read_text())
assert source['sha256'] == sha(H / 'sources/JST_PH.pdf')
receipt = json.loads((H / 'lead_receipt.json').read_text())
assert sha(P / receipt['source_path']) == receipt['source_sha256']
measurement = receipt['received']['measurement']
assert measurement['bare_wire_segment_length_mm'] == 190
assert measurement['includes_end_connector_housings'] is False
assert measurement['wire_count'] == 3 and measurement['wire_od_mm'] == 1
assert measurement['fully_seated_protrusion_mm'] is None
assert measurement['wire_od_approximate'] is True
for command in json.loads((H / 'commands.json').read_text()):
    assert sha(H / command['log']) == command['log_sha256'], command['stage']

class Links(HTMLParser):
    def __init__(self):
        super().__init__(); self.urls = set()
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in ['href', 'src'] and value:
                self.urls.add(value)

parser = Links(); parser.feed((H / 'index.html').read_text())
links = []
for value in sorted(parser.urls):
    parsed = urlsplit(value)
    if parsed.scheme or not parsed.path:
        continue
    file = (H / unquote(parsed.path)).resolve()
    assert file.is_file(), value
    url = 'http://127.0.0.1:58202/' + str(file.relative_to(P))
    with urlopen(Request(url, method='HEAD'), timeout=10) as response:
        assert response.status == 200, (value, response.status)
    links.append(value)

out = dict(checked_at=datetime.datetime.now().astimezone().isoformat(),status='PASS',
    protected_file_count=len(base),changed_protected_files=changed,
    main_model_sha256=sha(P/'mechanical/mori_v1_2.blend'),
    local_links_http_200=len(links),links=links,
    user_receipt_fields='190 mm excluding housings; 3 wires; approximate OD 1 mm; protrusion unknown',
    original_1p5mm_capacity_samples=len(r['local_bend_samples']),
    additional_1mm_samples=len(r['user_report_based_bend_samples']),
    additional_1mm_clear=sum(x['status']=='PASS' for x in r['user_report_based_bend_samples']),
    main_adoption=False,actual_harness='BLOCKED',physical='NOT_TESTED',manufacturing_release=False)
(H/'final_delivery_verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
files = [p for p in H.rglob('*') if p.is_file() and p.name!='delivery.json' and '__pycache__' not in p.parts]
manifest = {str(p.relative_to(H)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)}
(H/'delivery.json').write_text(json.dumps(dict(created_at=out['checked_at'],scope='Independent S288 local study only',files=manifest),ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='links'},ensure_ascii=False,indent=2))
