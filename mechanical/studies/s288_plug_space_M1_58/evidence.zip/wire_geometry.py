"""Shared polygonal local bend samples, not a physical wire model."""
import numpy as np
import math
import manifold3d as manifold

def bent_wire(protrusion,straight,radius,offset,plane,direction,wire_r=.75,segments=32):
    # For a bend parallel to the pin row, use concentric radii so the three
    # outgoing wires remain 2 mm apart rather than intersecting each other.
    rr=radius-direction*offset if plane=='Y' else radius
    if rr<=wire_r+.2:return None,None
    points=[];tangents=[]
    def add(p,t):points.append(np.asarray(p,float));tangents.append(np.asarray(t,float))
    add([protrusion,offset,0],[1,0,0])
    for theta in np.linspace(0,math.pi/2,33):
        if plane=='Z':p=[protrusion+straight+rr*math.sin(theta),offset,direction*rr*(1-math.cos(theta))];t=[math.cos(theta),0,direction*math.sin(theta)]
        else:p=[protrusion+straight+rr*math.sin(theta),offset+direction*rr*(1-math.cos(theta)),0];t=[math.cos(theta),direction*math.sin(theta),0]
        add(p,t)
    add(points[-1]+tangents[-1]*10,tangents[-1])
    verts=[];faces=[]
    for p,t in zip(points,tangents):
        n=np.array([0,1,0]) if plane=='Z' else np.array([0,0,1]);b=np.cross(t,n)
        for phi in np.arange(segments)*2*math.pi/segments:verts.append(p+wire_r*(math.cos(phi)*n+math.sin(phi)*b))
    for i in range(len(points)-1):
        for j in range(segments):
            a=i*segments+j;b=i*segments+(j+1)%segments;c=(i+1)*segments+(j+1)%segments;d=(i+1)*segments+j
            faces.extend([[a,b,c],[a,c,d]])
    for j in range(1,segments-1):faces.append([0,j+1,j]);a=(len(points)-1)*segments;faces.append([a,a+j,a+j+1])
    m=manifold.Manifold(manifold.Mesh64(np.array(verts),np.array(faces,dtype=np.uint64)))
    assert m.status()==manifold.Error.NoError
    length=straight+rr*math.pi/2+10;expected=math.pi*wire_r**2*length
    assert abs(m.volume()-expected)/expected<.009,(m.volume(),expected)
    return m,dict(centerline_mm=[p.tolist() for p in points],individual_bend_radius_mm=rr,centerline_length_mm=length,polygonal_relative_volume_error=(m.volume()-expected)/expected)

