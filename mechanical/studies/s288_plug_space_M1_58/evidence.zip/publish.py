"""Publish this independent measurement/capacity study without changing geometry."""
from pathlib import Path
import json, hashlib, datetime

H = Path(__file__).resolve().parent
P = H.parents[2]
r = json.loads((H / 'review.json').read_text())
lead = json.loads((H / 'lead_receipt.json').read_text())
assert lead['received']['measurement']['bare_wire_segment_length_mm'] == 190
assert lead['received']['measurement']['includes_end_connector_housings'] is False
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P / lead['source_path']) == lead['source_sha256']
nu = len(r['user_report_based_bend_samples'])
up = sum(x['status'] == 'PASS' for x in r['user_report_based_bend_samples'])
assert (nu, up) == (288, 56)
ns = len(r['local_bend_samples'])
np = sum(x['status'] == 'PASS' for x in r['local_bend_samples'])
ne = len(r['fully_exterior_box_positions'])
ep = sum(x['status'] == 'PASS' for x in r['fully_exterior_box_positions'])
nc = len(r['nominal_pass_clearance_trials'])
cp = sum(x['status'] == 'PASS' for x in r['nominal_pass_clearance_trials'])
assert (ns, np, ne, ep, nc, cp) == (448, 4, 60, 8, 8, 8)

(H / 'README.md').write_text(f'''# S288 插头空间、局部线尾与实物线长记录

2026-10-13；基准 M1.58。独立研究，**未应用主模型**。

## 已收到的实物数据

用户确认 S288 原配三芯线的**导线段约 190 mm，不含两端插头**。用户随后补充三根线、单根含绝缘外径约 1 mm，插头几乎全部藏入舵机。长度和线径均为用户约值，仪器和误差未提供；外伸毫米数仍未知，不能填成 0 mm。不是总长、不是插头外伸量，也不是供应商下单裁线长度；不推定每根随货线都相同。

原始记录：[JSON](../../procurement/evidence/2026-10-13_S288_lead_measurement.json)。[测量示意](measurement_guide.svg) 区分仍待补的 A 外伸量及已获约值的 B 单根绝缘线外径。

## 来源与方法

- 电机使用上一轮接收的[原厂 STEP 网格](../s288_vendor_fit_M1_58/vendor_mesh.json)及已记录的轴线变换；原网格、实体开口限制和机壳形状均保留，未缩放。
- 对比塑壳采用 JST 官方 PH 目录第 3 页的 PHR-3：宽 7.8、厚 4.5、长 6.85、针距 2 mm。[PDF](sources/JST_PH.pdf) · [可读页图](sources/JST_PH_housing_page.png) · [来源收据](sources/receipt.json)。**只是目录尺寸对比，未识别或选定它为 S288 实际配套插头。**详细 3D 下载要求登记，本次没有提交资料或取得连接器 CAD。
- 插口基准为电机 STEP 插座外包框中心、口外 0.05 mm，未宣称真实触点或导线出口坐标。初轮容量试算为直径 1.5 mm、2 mm 间距的圆管。收到用户补充后，另加直径 1 mm 的独立系列，并保留原系列不混称实物。
- 塑壳外伸试值 1/2/3/4 mm，直线尾段 1/3 mm，弯曲中心半径 2/3/4/5 mm，转弯后直线 10 mm；沿针排转弯时用同心半径，防止三根线在转弯后重合。各截面与四分之一圆各 32 段；管体体积与解析值误差 <0.9%。参数是容量样本，不是实际线径、压接或动态弯折资格。
- 四个插口逐一与完整主模型硬件/打印件及原厂电机实体检查，原简化 S288 排除。未做四口同时装线，也未确定 U03/U04 应使用的物理插口。

新增系列按用户约值采用直径 1 mm，外伸量 0 / 0.5 / 1 mm 为试值，直尾 1 / 3 mm、中心半径 3 / 4 / 5 mm、四个转弯方向；2 mm 针排及出口坐标仍为目录/外包框假设。

## 有限样本结果

| 检查 | 结果与边界 |
| --- | --- |
| 目录最大外包框从插座口直接起始 | 4 口均接触本机插座唇边，名义交叠约 1.147 mm³；横向增加 0.2 mm 后约 3.14 mm³。外包框保守，不能据此判定实际阶梯塑壳不兼容 |
| 外包框完全在口外的偏移位置 | {ne} 个静态位置中 {ep} 个无交叠；起点外移 0.5 或 1 mm、上下偏移 0.3 mm。未验证这些位置等于真实插到底的位置，或其插入过程 |
| 用户约 1 mm 线径的补充系列 | {nu} 个样本中 {up} 个无实体相交，各口 14 个；试值外伸 0 / 0.5 / 1 mm 分别有 24 / 20 / 12 个通过。仍不等于真实插头、端子直出或完整路线通过 |
| 初轮 1.5 mm 三芯容量 | {ns} 个样本中 {np} 个无实体相交，各插口 1 个。均为假设外伸 1 mm、直尾 1 mm、中心半径 5 mm，单线实际半径 3/5/7 mm；左电机向机身前方、右电机向后方 |
| 上述局部线尾增加间隙包络 | 每根半径增加 0.1、0.2 mm，{cp}/{nc} 个采样无实体相交；仅限该名义多边形几何 |
| 原模型与交付保护 | 主模型、几何配置、机械契约、电子细模、20 STL、动画源及视频等 26 文件 SHA 不变 |

其余样本相交只说明本次采样形状未通过，不排除其他转弯形式。图中把四口的独立样本放在一起方便定位，**并非实际完整线束或同时装线验证**。没有完整建模 190 mm 导线的余线、固定、应力释放、插拔或带线拆装。实际线束状态 **BLOCKED**，实物验证 **NOT_TESTED**，制造放行 false。

## 复现与记录

在产品工作树根目录运行：

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b mechanical/mori_v1_2.blend -t 4 --python-exit-code 1 --python mechanical/studies/s288_plug_space_M1_58/check.py
/Applications/Blender.app/Contents/MacOS/Blender -b -t 4 --python-exit-code 1 --python mechanical/studies/s288_plug_space_M1_58/render.py
python3 mechanical/studies/s288_plug_space_M1_58/publish.py
```

[commands.json](commands.json)保存实际执行命令、退出码及日志 SHA。Blender 5.2.2 LTS / Python 3.13.13 / numpy 2.3.4 / manifold3d 3.5.3。首次独立渲染因未加入项目依赖路径而失败，日志保留为 render_failed_import.log；修正路径后退出码 0。随后因新收到约 1 mm 实物线径而补充了 288 个局部样本，重新生成检查和静态图；旧结果与原 source_fields 保留为 *_before_wire_od 文件。

Poppler 渲染源 PDF 缺 Adobe-Japan1 字体包，失败输出保留 pdf_render.log；最终使用 macOS PDFKit 渲染第 3 页，文字及尺寸已目视核对。截图仅展示目录，未改动源 PDF。

新 Blender 文件 [S288_local_space_UNADOPTED.blend](S288_local_space_UNADOPTED.blend) 仅含两台原厂电机和局部容量样本，不是完整机器人或最新主模型。工程入口仍是 mechanical/mori_v1_2.blend。
''')

(H / 'index.html').write_text(f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>S288 导线记录与插头空间</title>
<style>*{{box-sizing:border-box}}body{{margin:0;background:#f5f6f3;color:#253337;font:17px/1.75 system-ui,sans-serif}}main{{max-width:1100px;margin:auto;padding:28px 30px 65px}}h1{{font-size:34px;line-height:1.3}}h2{{font-size:25px;margin-top:40px}}a{{color:#126b7a}}nav{{display:flex;gap:20px;flex-wrap:wrap}}.note{{border-left:4px solid #af822d;padding:12px 20px;background:#f2e8d4}}figure{{margin:24px 0}}img{{display:block;width:100%;height:auto}}figcaption,small{{color:#536569}}figcaption{{margin-top:9px}}table{{width:100%;border-collapse:collapse}}td,th{{text-align:left;padding:13px 10px;vertical-align:top;border-bottom:1px solid #cdd5d4}}th:first-child,td:first-child{{width:26%}}code{{overflow-wrap:anywhere}}@media(max-width:700px){{main{{padding:20px 16px}}h1{{font-size:27px}}table{{font-size:15px}}}}</style></head>
<body><main><nav><a href="../../index.html#s288-vendor">回到主模型</a><a href="../s288_vendor_fit_M1_58/index.html">原厂电机复核</a><a href="README.md">检查记录</a></nav>
<h1>S288 导线记录与插头空间</h1><p>2026-10-13 · 基准 M1.58 · 独立检查，主模型未改</p>
<p class="note"><strong>导线段约 190 mm；三根线，单根外径约 1 mm。</strong><br>均为用户提供的约值，长度不含两端插头。插头“几乎完全藏入舵机”已记录，具体外伸量仍未知。</p>
<section id="measure"><h2>实物信息与待补尺寸</h2><p>B 已按约 1 mm 记录；A 暂保留“几乎全部藏入”的观察，等后续试配再补具体毫米值。</p>
<figure><a href="measurement_guide.svg"><img src="measurement_guide.svg" alt="A 为插头外伸量，仍待具体值；B 为单根绝缘线外径，约1mm；导线段约190mm"></a><figcaption>断电测量即可。外形仅为示意，不代表已经识别出实物插头型号。<a href="../../procurement/evidence/2026-10-13_S288_lead_measurement.json">长度与线径的原始记录</a></figcaption></figure></section>
<section id="space"><h2>目前能判断什么</h2><table><thead><tr><th>项目</th><th>检查结果</th></tr></thead><tbody>
<tr><td>插头空间</td><td>对比了 JST PHR-3 目录外包框。在口外偏移位置有空间，但它是否匹配随货插头、是否对应真实插到底的位置，仍未确定。保守外包框碰到插座边缘不能直接等同于真实塑壳碰撞。</td></tr>
<tr><td>线尾转弯</td><td>按约 1 mm 线径补查了 288 个局部形状，其中 56 个无实体相交。下面展示的一组为左电机向机身前方、右电机向后方；外伸 1 mm、直尾 1 mm 仍是假设值。</td></tr>
<tr><td>整条约 190 mm 导线</td><td>长度及单线外径约值已记录。完整路线、余线收纳、固定、插拔和带线装配仍未完成。</td></tr>
</tbody></table>
<figure><a href="local_tails.png"><img src="local_tails.png" alt="原厂S288两电机及黄色局部转弯容量样本"></a><figcaption>黄色按用户报告的约 1 mm 线径绘制，转弯形状及出口坐标仍是假设；四口分别检查后合并展示方便定位，不是四口同时装线验证。没有把短线尾当作完整 190 mm 线束。</figcaption></figure>
<figure><a href="left_tail_detail.png"><img src="left_tail_detail.png" alt="单侧电机的局部线尾弯曲方向"></a><figcaption>单侧近看。电机来自原厂 CAD；线尾采用约 1 mm 线径及假设转弯形状，没有实际配套插头的详细外形。</figcaption></figure></section>
<details><summary>查看采样结果与来源</summary><p>收到约 1 mm 线径后的补充系列 {up}/{nu} 个无交叠。初轮口外塑壳位置 {ep}/{ne} 个无交叠；初轮 1.5 mm 容量系列局部转弯 {np}/{ns} 个无交叠；对通过的线尾增加 0.1 / 0.2 mm 径向包络，{cp}/{nc} 个仍无交叠。有限采样不排除其他路线，也不证明真实插头、弯折寿命和带线装配通过。</p><p>JST 目录 PHR-3：7.8 × 4.5 × 6.85 mm，针距 2 mm。仅作对比，未选为 S288 配套插头。<a href="sources/JST_PH.pdf">官方目录本地存档</a> · <a href="sources/JST_PH_housing_page.png">第 3 页</a> · <a href="https://www.jst-mfg.com/product/pdf/eng/ePH.pdf">官方来源</a>。</p><p><a href="review.json">原始检查 JSON</a> · <a href="source_fields.json">来源及假设</a> · <a href="commands.json">实际命令及日志</a> · <a href="protected_after.json">26 文件保护检查</a> · <a href="S288_local_space_UNADOPTED.blend">局部检查 Blender（非主模型）</a></p></details>
<p><small>PROTOTYPE / UNVALIDATED。实际线束 BLOCKED；实物 NOT_TESTED。主模型、STL 和视频未因本研究更新。</small></p></main></body></html>''')

updates = {
    'docs/PREARRIVAL_BLOCKERS.md': '\n## S288 线长与插头局部空间\n\n用户已确认原配三芯线的导线段约 **190 mm，不含两端插头**，见[原始记录](../mechanical/procurement/evidence/2026-10-13_S288_lead_measurement.json)。[目录外形与局部转弯研究](../mechanical/studies/s288_plug_space_M1_58/index.html)已完成有限采样；用户随后提供三根线、单根外径约 1 mm，以及插头几乎全部藏入的观察；补查 288 个局部形状，有 56 个无实体相交。具体外伸毫米值、完整路线、余线及带线拆装仍未闭合。未把目录 PHR-3 认定为随货插头，未改主模型。\n',
    'docs/PROJECT_INDEX.md': '\n- [S288 190 mm 导线记录及插头空间研究](../mechanical/studies/s288_plug_space_M1_58/index.html)：长度不含两端插头、单线外径约 1 mm；含 A/B 示意，局部假设样本未应用主模型。\n',
}
for relative, addition in updates.items():
    path = P / relative
    before = path.read_text()
    if relative.endswith("PREARRIVAL_BLOCKERS.md"):
        marker = "\n## S288 线长与插头局部空间\n"
        if marker in before:
            before = before[:before.index(marker)]
    else:
        before = "\n".join(line for line in before.split("\n") if "s288_plug_space_M1_58" not in line)
    path.write_text(before.rstrip() + "\n" + addition)
path = P / 'mechanical/index.html'
before = path.read_text()
if 'S288_LEAD_190' in before:
    start = before.index("<!-- S288_LEAD_190 -->")
    end = before.index("<!-- /S288_LEAD_190 -->", start) + len("<!-- /S288_LEAD_190 -->")
    before = before[:start] + before[end:]
if True:
    addition = '<!-- S288_LEAD_190 --><p>原配线的导线段已实物报告约 <strong>190 mm，不含两端插头</strong>；三芯、单线外径用户估计约 1 mm，插头几乎藏入舵机。<a href="studies/s288_plug_space_M1_58/index.html">查看插头外伸／线径测量示意及局部空间检查</a>；完整线束仍未闭合。</p><!-- /S288_LEAD_190 -->'
    anchor = '</section><!-- /S288_VENDOR_M1_58 -->'
    assert before.count(anchor) == 1
    path.write_text(before.replace(anchor, addition + anchor))
print('Published independent study; geometry and hardware source untouched')
