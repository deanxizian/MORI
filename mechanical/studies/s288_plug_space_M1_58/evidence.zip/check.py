"""Catalogue envelope and parametric local bend capacity; NOT a selected harness."""
from pathlib import Path
import sys, json, hashlib, math, itertools, time
H=Path(__file__).resolve().parent; PROJECT=H.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
V=H.parent/'s288_vendor_fit_M1_58'
fit=json.loads((V/'fit_review.json').read_text())
src=json.loads((V/'vendor_mesh.json').read_text())
fields=json.loads((H/'source_fields.json').read_text())
baseline=json.loads((H/'protected_before.json').read_text())
assert sha(ROOT/'mori_v1_2.blend')==fit['source_model_sha256']==baseline['mechanical/mori_v1_2.blend']
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections()
for c in COLS.values(): c.hide_viewport=False
assembled();bpy.context.view_layer.update()
ss={o.name.removeprefix(PREFIX):Solid(o) for o in parts() if o.get('group') not in ['dock','coupon']}
retired={n for n in ss if n.startswith(('Drive_Motor_','S288_Output_'))}
pos=[];neg=[]
for r in src['free_shells']:
    if not r['closed']:continue
    v=np.array(r['vertices_mm']);f=np.array(r['triangles'],dtype=np.uint64)
    if r['volume_mm3']<0:f=f[:,[0,2,1]]
    m=manifold.Manifold(manifold.Mesh64(v,f));assert m.status()==manifold.Error.NoError
    (pos if r['volume_mm3']>0 else neg).append(m)
body=manifold.Manifold.batch_boolean(pos,manifold.OpType.Add)
for m in neg:body=body-m
targets={n:dict(m=s.m,lo=s.lo,hi=s.hi) for n,s in ss.items() if n not in retired}
for side in ['L','R']:
    m=body.transform(np.array(fit['cases'][side+'_inboard']['matrix'])[:3,:])
    v=np.array(m.to_mesh64().vert_properties[:,:3])
    targets['Vendor_S288_'+side]=dict(m=m,lo=v.min(0),hi=v.max(0))
def hits(m,stop_first=False):
    v=np.array(m.to_mesh64().vert_properties[:,:3]);lo=v.min(0);hi=v.max(0);out=[]
    for n,t in targets.items():
        if np.any(hi<t['lo']) or np.any(lo>t['hi']):continue
        vol=(m^t['m']).volume()
        if vol>1e-5:
            out.append(dict(part=n,overlap_mm3=vol))
            if stop_first:return out
    return sorted(out,key=lambda x:-x['overlap_mm3'])
ports=[];envelopes=[]
for side in ['L','R']:
    mat=np.array(fit['cases'][side+'_inboard']['matrix'])
    for r in src['free_shells'][:2]:
        bb=np.array(r['bounds_mm']);c=(bb[:3]+bb[3:])/2;c[0]=bb[3]+.05
        origin=mat[:3,:3]@c+mat[:3,3]
        port=dict(side=side,source_socket=r['index'],position='lower' if origin[2]<52.5 else 'upper',origin_mm=origin.tolist(),local_origin_mm=c.tolist(),matrix=mat.tolist())
        ports.append(port)
        for margin in [0,.2]:
            def probe(length):
                # Margin around all sides would extend back into the mating mouth;
                # keep start fixed and enlarge only the transverse clearance.
                return manifold.Manifold.cube([length,7.8+2*margin,4.5+2*margin],True).translate(c+[length/2,0,0]).transform(mat[:3,:])
            low=.001;high=20.;initial=hits(probe(low));limit=[]
            if initial:low=0.;high=.001;limit=initial
            else:
                for _ in range(14):
                    mid=(low+high)/2;bad=hits(probe(mid))
                    if bad:high=mid;limit=bad
                    else:low=mid
            outside=hits(probe(6.85))
            envelopes.append(dict(side=side,source_socket=r['index'],position=port['position'],trial_margin_per_side_mm=margin,cross_section_mm=[7.8+2*margin,4.5+2*margin],clear_length_lower_mm=low,blocked_length_upper_mm=high,limiting=limit,whole_housing_outside_status='FAIL' if outside else 'PASS',whole_housing_outside_hits=outside,scope='Conservative catalogue housing AABB entirely outside the socket; no seated mating, finger grip or real cable qualification.'))
            print('ENVELOPE',side,r['index'],margin,round(low,4),round(high,4),outside,flush=True)

sys.path.insert(0,str(H))
from wire_geometry import bent_wire

bends=[];start=time.monotonic()
trial=fields['wire_capacity_samples']
# This screens local tails at each socket individually. It deliberately does not
# grant qualification to U03/U04 coexisting, global routing or wired extraction.
for port in ports:
    mat=np.array(port['matrix']);c=np.array(port['local_origin_mm'])
    for pr,st,rad,plane,di in itertools.product(trial['housing_protrusion_mm'],trial['straight_tail_mm'],trial['bend_center_radius_mm'],['Y','Z'],[-1,1]):
        if plane=='Y' and rad-2<=.95:continue
        sample=dict(side=port['side'],source_socket=port['source_socket'],position=port['position'],housing_protrusion_mm=pr,straight_tail_mm=st,bend_center_radius_mm=rad,local_bend_plane=plane,local_direction=di)
        combined=[];paths=[];bad=[]
        for i,offset in enumerate([-2,0,2]):
            m,path=bent_wire(pr,st,rad,offset,plane,di)
            m=m.translate(c).transform(mat[:3,:]);combined.append(m);paths.append(path)
            for hit in hits(m,True):bad.append(dict(wire=i,**hit))
        # Distinct wire offsets must survive each bend; report unexpected contact.
        self_hits=[dict(wires=[i,j],overlap_mm3=(combined[i]^combined[j]).volume()) for i in range(3) for j in range(i+1,3) if (combined[i]^combined[j]).volume()>1e-5]
        sample.update(status='FAIL' if bad or self_hits else 'PASS',hits=bad,self_hits=self_hits,minimum_individual_bend_radius_mm=min(p['individual_bend_radius_mm'] for p in paths))
        bends.append(sample)
    rows=[r for r in bends if r['side']==port['side'] and r['source_socket']==port['source_socket']]
    print('BENDS',port['side'],port['position'],len(rows),'CLEAR',sum(r['status']=='PASS' for r in rows),'elapsed',round(time.monotonic()-start,1),flush=True)
# A full box from the mouth is deliberately conservative: the catalogue flange
# may only reach its maximum width further out. Locate fully exterior box poses,
# without pretending they establish the missing seated housing contour.
exterior_positions=[];clearance_trials=[]
for port in ports:
    mat=np.array(port['matrix']);c=np.array(port['local_origin_mm'])
    for start_offset in [.5,1.,1.5,2.,2.5]:
        for z_offset in [-.3,0,.3]:
            m=manifold.Manifold.cube([6.85,7.8,4.5],True).translate(c+[start_offset+6.85/2,0,z_offset]).transform(mat[:3,:])
            bad=hits(m)
            exterior_positions.append(dict(side=port['side'],source_socket=port['source_socket'],start_offset_mm=start_offset,z_offset_mm=z_offset,status='FAIL' if bad else 'PASS',hits=bad))
    for row in [r for r in bends if r['side']==port['side'] and r['source_socket']==port['source_socket'] and r['status']=='PASS']:
        for margin in [.1,.2]:
            bad=[]
            for i,offset in enumerate([-2,0,2]):
                m,_=bent_wire(row['housing_protrusion_mm'],row['straight_tail_mm'],row['bend_center_radius_mm'],offset,row['local_bend_plane'],row['local_direction'],wire_r=.75+margin)
                m=m.translate(c).transform(mat[:3,:])
                bad.extend(dict(wire=i,**h) for h in hits(m))
            clearance_trials.append(dict(side=port['side'],source_socket=port['source_socket'],trial_radial_margin_mm=margin,status='FAIL' if bad else 'PASS',hits=bad))
reported=[]
u=fields.get('user_report_based_additional_samples')
if u:
    for port in ports:
        mat=np.array(port['matrix']);c=np.array(port['local_origin_mm'])
        for pr,st,rad,plane,di in itertools.product(u['housing_protrusion_mm'],u['straight_tail_mm'],u['bend_center_radius_mm'],u['local_bend_plane'],u['local_direction']):
            samples=[];bad=[];paths=[]
            for i,offset in enumerate([-2,0,2]):
                m,path=bent_wire(pr,st,rad,offset,plane,di,wire_r=u['wire_od_mm']/2)
                m=m.translate(c).transform(mat[:3,:]);samples.append(m);paths.append(path)
                bad.extend(dict(wire=i,**h) for h in hits(m,True))
            self_hits=[dict(wires=[i,j],overlap_mm3=(samples[i]^samples[j]).volume()) for i in range(3) for j in range(i+1,3) if (samples[i]^samples[j]).volume()>1e-5]
            reported.append(dict(side=port['side'],source_socket=port['source_socket'],position=port['position'],wire_od_mm=u['wire_od_mm'],housing_protrusion_mm=pr,straight_tail_mm=st,bend_center_radius_mm=rad,local_bend_plane=plane,local_direction=di,status='FAIL' if bad or self_hits else 'PASS',hits=bad,self_hits=self_hits,minimum_individual_bend_radius_mm=min(x['individual_bend_radius_mm'] for x in paths)))
        rows=[x for x in reported if x['side']==port['side'] and x['source_socket']==port['source_socket']]
        print('USER_OD_SAMPLES',port['side'],port['position'],len(rows),'CLEAR',sum(x['status']=='PASS' for x in rows),flush=True)
result=dict(main_revision=P['revision'],main_sha256=sha(ROOT/'mori_v1_2.blend'),source_fields_sha256=sha(H/'source_fields.json'),vendor_mesh_sha256=sha(V/'vendor_mesh.json'),user_receipt_sha256=sha(H/'lead_receipt.json'),ports=ports,envelopes=envelopes,local_bend_samples=bends,user_report_based_bend_samples=reported,fully_exterior_box_positions=exterior_positions,nominal_pass_clearance_trials=clearance_trials,scope='Independent catalogue envelope and parametric nominal local wire samples, not actual connector fit',actual_harness='BLOCKED',physical='NOT_TESTED',main_adoption=False,limits=['S288 has no identified matching plug MPN or confirmed seated protrusion; JST catalogue is a comparison only.','Bounding boxes are conservative; a hit does not prove the actual shaped plug cannot fit.','No inside-socket fit or terminal insertion check; two source open surfaces excluded from volume tests.','Original 1.5 mm series is capacity only; additional 1 mm OD series uses an approximate user report. Physical bend radius and crimp straight tail remain unknown.','Plug described as almost entirely recessed; 0/0.5/1 mm are trial values, not a measured protrusion or a confirmed zero.','The three wire centres use the socket bounding-box centre and catalogue 2 mm pitch, not a verified crimp-exit coordinate.','Local nominal polygonal tubes use 32 radial and 32 bend divisions; no continuous clearance or durability certificate.','Each port tested independently; all selected cables together, restraint, complete routes and wired assembly remain untested.'])
(H/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert all(sha(PROJECT/n)==h for n,h in baseline.items())
(H/'protected_after.json').write_text(json.dumps(dict(status='PASS',unchanged_files=len(baseline),main_sha256=sha(ROOT/'mori_v1_2.blend')),indent=2)+'\n')
print('COMPLETE',len(bends),'LOCAL_CAPACITY_SAMPLES',flush=True)
