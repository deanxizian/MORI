"""Small standalone view of source motors and unselected capacity probes."""
from pathlib import Path
import bpy, json, sys, math, hashlib
import numpy as np
from mathutils import Matrix,Vector
H=Path(__file__).resolve().parent;P=H.parents[2];V=H.parent/'s288_vendor_fit_M1_58'
sys.path.insert(0,str(H))
sys.path.insert(0,str(P/'mechanical/scripts/vendor'))
from wire_geometry import bent_wire
d=json.loads((H/'review.json').read_text());meshdata=json.loads((V/'vendor_mesh.json').read_text());fit=json.loads((V/'fit_review.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True);sc=bpy.context.scene
sc['scope']='Independent S288 local envelope and bend samples. No full lead route, real plug mating or adoption.'
motors=[];samples=[]
def make(name,verts,tri,color):
    me=bpy.data.meshes.new(name);me.from_pydata(np.asarray(verts).tolist(),[],np.asarray(tri).tolist());me.update()
    o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);o.color=color;o['mori_owner']='s288_plug_space_study';return o
for side in ['L','R']:
    mat=Matrix(fit['cases'][side+'_inboard']['matrix'])
    for r in meshdata['free_shells']:
        o=make('REF_S288_'+side+'_'+str(r['index']),r['vertices_mm'],r['triangles'],(.32,.37,.39,1))
        o.matrix_world=mat;o['category']='PURCHASED_REFERENCE';o['data_status']='VENDOR_DOCUMENTED';o['source_sha256']=meshdata['source_sha256'];motors.append(o)
        if r['index'] in [0,1]:o.color=(.58,.40,.16,1)
for row in [r for r in d['user_report_based_bend_samples'] if r['status']=='PASS' and r['housing_protrusion_mm']==1 and r['straight_tail_mm']==1 and r['bend_center_radius_mm']==5 and r['local_bend_plane']=='Y' and r['local_direction']==-1]:
    port=next(p for p in d['ports'] if p['side']==row['side'] and p['source_socket']==row['source_socket'])
    mat=np.array(port['matrix']);c=np.array(port['local_origin_mm'])
    for i,off in enumerate([-2,0,2]):
        m,path=bent_wire(row['housing_protrusion_mm'],row['straight_tail_mm'],row['bend_center_radius_mm'],off,row['local_bend_plane'],row['local_direction'],wire_r=row['wire_od_mm']/2)
        m=m.translate(c).transform(mat[:3,:]);msh=m.to_mesh64()
        o=make('CAPACITY_'+row['side']+'_'+row['position']+'_'+str(i),msh.vert_properties[:,:3],msh.tri_verts,(.95,.56,.12,1));o['category']='PLACEHOLDER';o['data_status']='ASSUMED';o['wire_od_sample_mm']=row['wire_od_mm'];o['wire_od_evidence']='USER_REPORTED_APPROXIMATE';o['not_a_complete_route']=True;samples.append(o)
assert len(samples)==12, 'Expected the previously clear direction at all four ports'
sc.render.engine='BLENDER_WORKBENCH';sh=sc.display.shading;sh.light='STUDIO';sh.color_type='OBJECT';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_specular_highlight=True
sc.render.resolution_x=1300;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
def view(name,eye,target,scale):
    cam=bpy.data.objects.new('ReviewCamera',bpy.data.cameras.new('ReviewCamera'));sc.collection.objects.link(cam)
    cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale;sc.camera=cam
    sc.render.filepath=str(H/(name+'.png'));bpy.ops.render.render(write_still=True)
    return cam
view('local_tails',(-70,100,94),(0,0,53),91)
for o in motors+samples:
    o.hide_render=('_R_' in o.name)
view('left_tail_detail',(60,100,68),(-4,10,52),58)
for o in motors+samples:o.hide_render=False
sc['lead_length_user_report_mm']=190;sc['lead_length_scope']='Wire segment excluding both connector housings; not modelled here in full.'
sc['unqualified']='All tails shown for location reference; each port checked individually, not combined selected U03/U04.'
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(H/'S288_local_space_UNADOPTED.blend'),compress=True)
print('RENDERED',len(motors),'SOURCE_SURFACES',len(samples),'CAPACITY_TAILS')
