"""Publish the current partial mass ledger with explicit unknowns."""
from pathlib import Path
from html import escape
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from off_shelf_delivery import document

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((HERE/'mass_ledger.json').read_text())
assert r['calculation_status']=='PASS' and all(x['status']=='PASS' for x in r['checks'])
assert sha(PROJECT/'mechanical/mori_v1_2.blend')==r['source_main_sha256']
ledger=r['ledger']
prints=[x for x in ledger if x['scope']=='robot' and x['accounting']=='PA12_SOLID_ESTIMATE']
unknown=[x for x in ledger if x['scope']=='robot' and x['mass_g'] is None]+r['unmodeled_remainders']
top=sorted(prints,key=lambda x:x['mass_g'],reverse=True)
body=f'''<p><a href="../../index.html?revision=V1.2-M1.58">当前模型</a> / 质量复核</p>
<h1>M1.58 重量表：已计算部分与待补数据</h1>
<p>2026-10-13 · 当前主模型保持上充电、下开关。计算和账目检查通过；整机重量、重心、惯量及动态载荷仍为 <strong>BLOCKED</strong>。本页没有修改模型或视频。</p>
<p>核算期间硬件对话发布 UPS-R2：10 个载板接口、轮子单口串接，独立充电检测束退出基准。这里只读接收；M1.58 仍保留 R1 接收时的几何，新载板与 R2 完整线束未集成。</p>
<div class="note">15 件本体打印件约 <strong>{r['subtotal_components_g']['PA12_SOLID_ESTIMATE']:.1f} g</strong>。
连同有厂家标称重量的部件、按既有材料假设估算的定制金属件，已纳入部分的小计为 <strong>{r['subtotal_g']:.1f} g</strong>。
这个数不是整机总重，也不是保证的质量下界；UPS、电芯、屏幕、板卡、轮胎、线束等尚未计入。</div>
<h2>已纳入的三类数据</h2>
<table><thead><tr><th>范围</th><th>小计</th><th>依据与限制</th></tr></thead><tbody>
<tr><td>本体 PA12 打印件</td><td>{r['subtotal_components_g']['PA12_SOLID_ESTIMATE']:.1f} g</td><td>当前实体体积 × 1.01 g/cm³；完整实体，无 FDM 填充折减。参考密度不是嘉立创本批实测值。</td></tr>
<tr><td>S288×2、SCS0009×2、6806ZZ</td><td>{r['subtotal_components_g']['CATALOGUE_NOMINAL']:.1f} g</td><td>厂家标称合计；未称重，随线／配件范围仍需核对。输出端不重复加重。</td></tr>
<tr><td>定制轮轴与间隔套</td><td>{r['subtotal_components_g']['CUSTOM_METAL_ESTIMATE']:.1f} g</td><td>现有实体与模型原定 7.85 g/cm³ 密度估算；钢材牌号、加工和成品重量未验收。</td></tr>
</tbody></table>
<p>相对规格 1.2 kg 工程目标，算术剩余额度约 {r['arithmetic_remaining_to_1200_g']:.1f} g，需要容纳下列全部未知项。没有据此认定重量达标，也没有自动削薄或改动结构。</p>
<h2>本体打印件</h2><p>两只轮毂合计 {sum(x['mass_g'] for x in prints if x['id'].startswith('Wheel_Hub')):.1f} g。
俯仰组打印件为 {r['printed_subset_moments']['pitch_prints']['mass_g']:.1f} g，尚不含屏幕、相机、板卡、紧固件等。</p>
<table><thead><tr><th>部件</th><th>参考重量 / g</th><th>运动组</th></tr></thead><tbody>'''
for x in top:body+=f'<tr><td>{escape(x["label_zh"])} <small>{escape(x["id"])}</small></td><td>{x["mass_g"]:.2f}</td><td>{escape(", ".join(x["groups"]))}</td></tr>'
body+='</tbody></table><h2>还缺的重量输入</h2><p>空白代表未知，不按零克处理。按整件称重，记录包含和排除哪些线材；不要求把焊接好的器件拆开。</p><table><thead><tr><th>范围</th><th>记录方法</th></tr></thead><tbody>'
for x in unknown:body+=f'<tr><td>{escape(x["label_zh"])}</td><td>{escape(x["basis"])}</td></tr>'
body+=f'''</tbody></table>
<h2>重心和惯量的边界</h2>
<p>只发布 PA12 打印子集和定制均匀金属实体的几何质量矩。板卡、舵机和 UPS 的外形体积不代表内部材料分布；厂家重量也不能直接确定其重心。
整机 COM、惯量、重力矩、主动平衡及承力校核没有填入假精确结果。补重量后还需区分固定／转动部件和实际安装位置。</p>
<h2>核查与清单更正</h2>
<ul><li>{len(r['checks'])} 项计算／账目检查通过：旋转平移长方体解析解、{sum(x['id'].startswith('used_solid_volume_') for x in r['checks'])} 个用于质量计算实体的独立体积对照、16 个本体与底座 STL 的坐标／体积回读、191 个场景部件恰好归账一次。949 个受保护文件中 941 个字节不变，另 8 个硬件文档／合同由其维护对话更新为 R2，已记录前后哈希，没有由机械修改。</li>
<li>20 个导出 STL 实际是 <strong>15 件本体件＋1 件维护底座＋4 件试片</strong>。四块软接触垫没有导出，材料也不是已确认的 PA12；先前文档中的“5 件托架 STL”已纠正。</li>
<li>维护底座 PA12 主体参考重量 {r['dock_PA12_base_mass_g']:.1f} g，软垫另计，整个维护托架排除在机器人重量之外。旧报告的实际调用也已经排除托架，并不存在重复加入托架的错误。</li>
<li>旧表确认有额外的输出端与板载麦克风行，共约 {r['old_report_audit']['confirmed_extra_subcomponent_mass_g']:.3f} g；本表合并到对应整件。旧 SP3040 的 31.5 g 预算、WeAct／载板的 12 g 假设不作为厂家数据沿用。</li>
<li>旧 mass_budget.json 保留为历史。相机镜头和 Buck 参考网格的两种体积积分有差异，已原样记录；这些外购包络没有用于本次质量、重心或惯量计算。</li></ul>
<p><small>主模型 SHA256：<code>{r['source_main_sha256']}</code>。所有结果均为 PROTOTYPE / UNVALIDATED，无制造、上电或实物强度放行。</small></p>
<h2>文件与来源</h2>
<p><a href="mass_ledger.json">完整账目与检查 JSON</a> · <a href="mass_ledger.csv">重量明细 CSV</a> · <a href="measurements_template.csv">空白称重模板</a> · <a href="commands.json">命令与日志</a> · <a href="README.md">复现与边界说明</a></p>
<p>模板请复制后填写，不要直接覆盖生成文件；本轮没有填写任何实测数字。</p><ul>'''
sources=json.loads((HERE/'sources.json').read_text())['sources']
for key,label in [('pa12_reference','Materialise PA12 MJF 密度参考'),('scs0009_nominal','飞特 SCS0009 标称重量'),('s288_nominal','宇树 S288 标称重量'),('yaw_bearing_nominal','NSK 6806ZZ 目录参考质量')]:
    body+=f'<li><a href="{escape(sources[key]["url"],quote=True)}">{label}</a>；读取日期 2026-10-13。</li>'
body+='</ul><p><a href="../../../docs/PREARRIVAL_BLOCKERS.md">其余未完成工作</a></p>'
(HERE/'index.html').write_text(document('MORI M1.58 质量复核',body))
readme=f'''# M1.58 当前质量账目与惯量输入复核

计算范围完成，完整整机质量／COM／惯量仍 BLOCKED。只读主模型，没有结构更改或视频更新。

- 15 件本体打印件：{r['subtotal_components_g']['PA12_SOLID_ESTIMATE']:.3f} g（PA12 1.01 g/cm³ 参考，非称重）。
- 厂家标称部分：{r['subtotal_components_g']['CATALOGUE_NOMINAL']:.3f} g；原模型定制金属部分：{r['subtotal_components_g']['CUSTOM_METAL_ESTIMATE']:.3f} g。
- 上述小计 {r['subtotal_g']:.3f} g，不是整机总重或可靠下界。18 组整机未知输入全部留空；不沿用旧预算假设。
- 维护底座主体 {r['dock_PA12_base_mass_g']:.3f} g 与软垫均不计入机器人。软垫虽沿袭 PRINTABLE 分类，但 build.py 明确 TPU／橡胶、export_candidate=false，不能按 PA12 计重。
- 20 STL 的实际组成是 15 本体＋1 底座＋4 试片；191 场景部件数不含试片，包含底座及四软垫。

主模型 SHA256 `{r['source_main_sha256']}`。每个场景对象被归入且只归入一个重量单元；电芯和线束等未独立建模内容以整套或额外未知项明确列出。零数据未当成零质量。

输出： [静态报告](index.html)、[账目 JSON](mass_ledger.json)、[CSV](mass_ledger.csv)、[称重模板](measurements_template.csv)、[来源](sources.json)、[实际命令](commands.json)。复制模板后再填写。实测资料未填入前不能说动力预算已经完成。

复现：从项目根目录执行 `python3 mechanical/studies/mass_inertia_M1_58/run.py`。它用 Blender 只读打开 M1.58，取得实体质量矩并核对 STL，生成本目录报告和机械页面的说明。`protected_before.json` 是本轮开始时的 949 文件哈希快照。首次保护检查发现硬件对话并发发布 R2；[单独接收记录](hardware_owner_update.json)列出 8 个文档／合同的旧、新哈希，原快照不改。其余 941 个文件，包括主模型、STL、视频和原生硬件，保持字节不变。未知的额外变化仍使校验失败。

硬件已发布 R2 的 10 接口和轮串接需求。M1.58 保存模型仍是 R1 接收时的几何，R2 原生 PCB 未生成、完整线束未集成。旧构建的合同来源哈希与当前 R2 不同，不重写构建哈希、不把旧几何 PASS 改称 R2 资格。本次只验证现存实体的质量账目。

检查包含旋转／平移长方体解析惯量，签名四面体积分与 Manifold 实体体积，STL 移到局部原点后的独立积分，重复／漏项、维护底座排除、来源哈希及未知量检查。16 个当前本体／底座 STL 用于质量回读；4 试片只核对导出归类，不算整机质量。相机镜头／Buck 包络体积积分差异保留在 JSON，未参与质量计算。校验阈值是数值检查阈值，不是制造公差。

旧 `mechanical/reports/mass_budget.json` 原样保留。确认的重复子部件共 {r['old_report_audit']['confirmed_extra_subcomponent_mass_g']:.6f} g，不将这一修正误称为整机轻量化。旧调用已排除底座，之前口头怀疑已纠正。旧35%不确定性、旧电池、旧喇叭预算和电子包络密度均不能资格化新架构。

全机COM／惯量无数值输出。打印子集和定制均匀材料件的质量矩可追溯，不能复制为控制器参数；实际模块质量分布、运动组和所有线缆仍需补齐。未制造、未上电、未提交 PR。
'''
(HERE/'README.md').write_text(readme)
# Annotate the saved static page; the normal full publisher correctly rejects
# its old contract hash after the concurrent owner update. Do not waive that.
p=PROJECT/'mechanical/index.html';s=p.read_text()
begin='<!-- MASS_M1_58_CURRENT_BEGIN -->';end='<!-- MASS_M1_58_CURRENT_END -->'
if begin in s:s=s[:s.index(begin)]+s[s.index(end)+len(end):]
note=begin+f'<section id="mass_current"><h2>质量账目与最新硬件交接</h2><p>15 件本体 PA12 打印件参考重量 {r["subtotal_components_g"]["PA12_SOLID_ESTIMATE"]:.1f} g；完整整机重量、重心和惯量待补。<a href="studies/mass_inertia_M1_58/index.html">查看账目和缺项</a>。</p><p>硬件已到 UPS-R2（10 接口、轮串接），当前保存模型仍保持 R1 接收时的几何，尚未集成 R2 完整线束和新载板。历史几何通过不代表 R2 电气／线束通过。</p><p>20 STL 的实际组成：15 本体＋1 底座＋4 试片；四软垫未导出。</p></section>'+end
s=s.replace('<main>','<main>'+note,1);p.write_text(s)
delivery_path=PROJECT/'mechanical/reports/model_review_delivery.json'
delivery=json.loads(delivery_path.read_text())
delivery['status']='BLOCKED'
delivery['previous_saved_geometry_review_status']='PASS'
delivery['hardware_source_freshness']='BLOCKED: owner published UPS-R2; old build hardware-contract hash retained, not relabeled.'
delivery['annotation_only_update']='mass_inertia_M1_58; model/export/video untouched'
delivery['files']['mechanical/index.html']=sha(p)
# Keep old nominal checks, but make the changed input freshness explicit on
# the direct report entry as well. Never replace its build/validation evidence.
report_page=PROJECT/'mechanical/current_report.html'
t=report_page.read_text()
report_begin='<!-- MASS_AUDIT_SOURCE_NOTE_BEGIN -->';report_end='<!-- MASS_AUDIT_SOURCE_NOTE_END -->'
if report_begin in t:t=t[:t.index(report_begin)]+t[t.index(report_end)+len(report_end):]
notice=report_begin+'<p class="note">来源状态更新：硬件维护对话已发布 UPS-R2；以下几何检查对应保存的 M1.58／原 R1 接收输入。主模型及 STL 未变，但新版硬件／完整线束集成仍 BLOCKED，旧构建的合同哈希未被重写。<a href="studies/mass_inertia_M1_58/index.html">当前质量账目与只读接收记录</a>。</p>'+report_end
t=t.replace('<main>','<main>'+notice,1);report_page.write_text(t)
report_path=PROJECT/'mechanical/reports/current_report.json'
current=json.loads(report_path.read_text())
current['status']='BLOCKED'
current['saved_geometry_scope_status']='PASS'
current['hardware_requirement_revision_current']='V1.2-H0.6-UPS-R2'
current['hardware_requirement_revision_at_saved_build']='V1.2-H0.6-UPS-R1'
current['source_freshness_note']='Known owner metadata update recorded in mass_inertia_M1_58/hardware_owner_update.json; existing geometry checks retained, new complete electrical/harness fit not qualified.'
current['mass_ledger']='studies/mass_inertia_M1_58/mass_ledger.json'
current['html_sha256']=sha(report_page)
report_path.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
delivery['files']['mechanical/current_report.html']=sha(report_page)
delivery_path.write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(published='mechanical/studies/mass_inertia_M1_58/index.html',model_unchanged=True,video_unchanged=True),ensure_ascii=False))
