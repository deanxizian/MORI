"""Execute and log the readonly mass audit. No Blender save, export or video call."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
PROJECT=HERE.parents[2]
BLENDER='/Applications/Blender.app/Contents/MacOS/Blender'
records=[]
stages=[('inventory',[BLENDER,'-b','mechanical/mori_v1_2.blend','--python-exit-code','1','--python',str((HERE/'inspect_inventory.py').relative_to(PROJECT))]),
        ('ledger',[BLENDER,'-b','--python-exit-code','1','--python',str((HERE/'build_ledger.py').relative_to(PROJECT))]),
        ('publish',[sys.executable,str((HERE/'publish.py').relative_to(PROJECT))])]
for stage,command in stages:
    start=datetime.datetime.now().astimezone().isoformat()
    log=HERE/(stage+'.log')
    with log.open('w') as f:result=subprocess.run(command,cwd=PROJECT,stdout=f,stderr=subprocess.STDOUT)
    records.append(dict(stage=stage,command=command,cwd=str(PROJECT),started=start,
                        completed=datetime.datetime.now().astimezone().isoformat(),returncode=result.returncode,
                        log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (HERE/'commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    print(stage,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
