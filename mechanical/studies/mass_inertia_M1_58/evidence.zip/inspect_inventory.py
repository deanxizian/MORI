from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[2]
sys.path.insert(0,str(PROJECT/'mechanical/scripts'))
from common import *
from validate import Solid,volume_moments
def plain(value):
 if isinstance(value,(str,int,float,bool)) or value is None:return value
 if hasattr(value,'items'):return {str(k):plain(v) for k,v in value.items()}
 return [plain(v) for v in value]
bpy.context.window.scene=bpy.data.scenes['MORI_V1_Assembly'];load_collections();assembled()
for c in COLS.values():c.hide_viewport=False
bpy.context.view_layer.update();rows=[]
for o in parts():
 n=o.name.removeprefix(PREFIX);s=Solid(o);V,c,Q=volume_moments(s)
 props={k:plain(o[k]) for k in o.keys() if any(w in k for w in ['mass','density','source','material','category','data_status','group','model_fidelity'])}
 rows.append(dict(id=n,label_zh=o.get('label_zh'),group=s.group,category=o.get('category'),export_candidate=bool(o.get('export_candidate')),data_status=o.get('data_status'),volume_mm3=V,manifold_volume_mm3=s.m.volume(),geometric_center_mm=c.tolist(),second_volume_moment_mm5=Q.tolist(),bounds_mm=[s.lo.tolist(),s.hi.tolist()],properties=props))
report=dict(revision=P['revision'],runtime=dict(blender=bpy.app.version_string,python=sys.version,numpy=np.__version__),source_sha256=hashlib.sha256((ROOT/'mori_v1_2.blend').read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),parts=rows)
(HERE/'inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([dict(id=r['id'],group=r['group'],volume=round(r['volume_mm3'],2),props={k:v for k,v in r['properties'].items() if 'mass' in k or 'density' in k}) for r in rows],ensure_ascii=False),flush=True)
