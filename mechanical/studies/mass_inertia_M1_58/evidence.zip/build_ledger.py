"""Read-only M1.58 mass accounting. Never infer board mass from its CAD envelope."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, math, sys
import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT / 'mechanical/scripts'))
from common import manifold
from validate import volume_moments

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

inventory = read(HERE / 'inventory.json')
geometry = read(PROJECT / 'config/geometry.json')
assert geometry['revision'] == inventory['revision'] == 'V1.2-M1.58'
assert sha(PROJECT / 'mechanical/mori_v1_2.blend') == inventory['source_sha256']
sources = read(HERE / 'sources.json')['sources']
by_id = {row['id']: row for row in inventory['parts']}
assert len(by_id) == len(inventory['parts']) == 191
rho = geometry['prearrival_completion']['printing']['density_kg_m3_reference'] / 1e6
assert math.isclose(rho * 1000, sources['pa12_reference']['value_g_cm3'])
checks = []

def check(name, passed, **data):
    checks.append(dict(id=name, status='PASS' if passed else 'FAIL', **data))
    if not passed:
        raise AssertionError((name, data))

def inertia(V, c, Q, density):
    m = V * density
    origin = density * (np.trace(Q) * np.eye(3) - Q)
    central = origin - m * (np.dot(c, c) * np.eye(3) - np.outer(c, c))
    return m, origin, central

# Independent analytic cuboid and transformed-cuboid checks for volume moments.
dims = np.array([7., 11., 13.])
angle = .37
R = np.array([[math.cos(angle), -math.sin(angle), 0.],
              [math.sin(angle), math.cos(angle), 0.], [0., 0., 1.]])
offset = np.array([81., -34., 222.])
box = manifold.Manifold.cube(tuple(dims), center=True).to_mesh64()
class Mesh:
    pass
s = Mesh()
s.v = np.array(box.vert_properties[:, :3]) @ R.T + offset
s.f = np.array(box.tri_verts)
V, c, Q = volume_moments(s)
mass, _, Ic = inertia(V, c, Q, rho)
expected_I = R @ np.diag(mass / 12 * (np.sum(dims ** 2) - dims ** 2)) @ R.T
check('translated_rotated_cuboid_moments', abs(V - np.prod(dims)) < 1e-6
      and np.max(abs(c - offset)) < 1e-7 and np.max(abs(Ic - expected_I)) < 1e-6,
      volume_error_mm3=abs(V - np.prod(dims)), centroid_error_mm=float(np.max(abs(c - offset))),
      inertia_error_g_mm2=float(np.max(abs(Ic - expected_I))))

# Independent binary-STL readback, translated near the mesh before integration.
exports = {r['id']: r for r in read(PROJECT / 'mechanical/reports/export_manifest.json')['parts']}
stl_checks = []
unused_envelope_volume_differences = []
for row in inventory['parts']:
    error = abs(row['volume_mm3'] - row['manifold_volume_mm3'])
    if row['export_candidate'] or row['properties'].get('mass_density_g_cm3') is not None:
        check('used_solid_volume_' + row['id'], row['volume_mm3'] > 0 and
              error < max(.001, row['volume_mm3'] * 1e-8), error_mm3=error)
    elif error > .0001:
        unused_envelope_volume_differences.append(dict(id=row['id'], error_mm3=error,
            used_for_mass=False, meaning='Raw triangle versus Manifold volume discrepancy retained. Purchased-envelope volume moments are not used for mass, COM or inertia.'))
    if not row['export_candidate']:
        continue
    rec = exports[row['id']]
    path = PROJECT / 'mechanical' / rec['file']
    check('stl_hash_' + row['id'], sha(path) == rec['sha256'])
    data = path.read_bytes()
    count = int.from_bytes(data[80:84], 'little')
    assert len(data) == 84 + count * 50
    dtype = np.dtype([('normal', '<f4', (3,)), ('vertices', '<f4', (3, 3)), ('attr', '<u2')])
    tris = np.frombuffer(data, dtype=dtype, count=count, offset=84)['vertices'].astype(float)
    shift = .5 * (tris.min(axis=(0, 1)) + tris.max(axis=(0, 1)))
    local = tris - shift
    tetra = np.einsum('ij,ij->i', np.cross(local[:, 0], local[:, 1]), local[:, 2]) / 6
    vol = float(tetra.sum())
    center = (tetra[:, None] * local.sum(axis=1) / 4).sum(axis=0) / vol + shift
    ve = abs(vol - row['volume_mm3'])
    ce = float(np.max(abs(center - row['geometric_center_mm'])))
    stl_checks.append(dict(id=row['id'], volume_error_mm3=ve, centroid_error_mm=ce))
    check('stl_moments_' + row['id'], ve < .5 and ce < .001,
          volume_error_mm3=ve, centroid_error_mm=ce)

ledger = []
claimed = set()

def entry(key, label, members, kind, mass=None, basis='', source=None, scope='robot'):
    assert members and not (set(members) & claimed) and all(n in by_id for n in members)
    claimed.update(members)
    groups = sorted({by_id[n]['group'] for n in members})
    row = dict(id=key, label_zh=label, members=members, groups=groups, scope=scope,
               accounting=kind, mass_g=mass, data_status='ASSUMED', basis=basis, source=source,
               physical_mass_status='NOT_TESTED', center_of_mass_mm=None, inertia_at_COM_kg_m2=None)
    if kind == 'CATALOGUE_NOMINAL':
        row['data_status'] = 'VENDOR_DOCUMENTED'
    ledger.append(row)
    return row

for row in inventory['parts']:
    if not row['export_candidate']:
        continue
    V = row['volume_mm3']
    c = np.array(row['geometric_center_mm'])
    Q = np.array(row['second_volume_moment_mm5'])
    m, Io, Ic = inertia(V, c, Q, rho)
    r = entry(row['id'], row['label_zh'] or row['id'], [row['id']], 'PA12_SOLID_ESTIMATE', m,
              'Actual current solid volume × reference density; full PA12 solid, no FDM infill factor; excludes paint, trapped powder and dimensional/process variation.',
              'pa12_reference', 'dock' if row['group'] == 'dock' else 'robot')
    r.update(volume_mm3=V, density_g_cm3=rho*1000, center_of_mass_mm=c.tolist(),
             inertia_at_COM_kg_m2=(Ic * 1e-9).tolist(), raw_inertia_g_mm2=Io.tolist(),
             moments_status='ASSUMED_UNIFORM_DENSITY')

entry('Dock_Soft_Pads', '维护底座四块软接触垫（未导出）',
      ['Dock_Pad_'+str(i) for i in range(4)], 'UNKNOWN', scope='dock',
      basis='build.py 明确为 TPU 或橡胶软垫、export_candidate=false。场景旧 PRINTABLE 分类不能作为 PA12 材料依据。')

for side in ['L', 'R']:
    entry('S288_' + side, 'S288 舵机 ' + side,
          ['Drive_Motor_' + side, 'S288_Output_' + side + '_Inner', 'S288_Output_' + side + '_Outer'],
          'CATALOGUE_NOMINAL', sources['s288_nominal']['mass_g'],
          sources['s288_nominal']['meaning'], 's288_nominal')
for axis in ['Yaw', 'Pitch']:
    entry('SCS0009_' + axis, 'SCS0009 ' + axis,
          [axis + '_Servo', axis + '_Output'], 'CATALOGUE_NOMINAL',
          sources['scs0009_nominal']['mass_g'], sources['scs0009_nominal']['meaning'], 'scs0009_nominal')
entry('Yaw_Bearing', '6806ZZ 偏航轴承', ['Yaw_Bearing'], 'CATALOGUE_NOMINAL',
      sources['yaw_bearing_nominal']['mass_g'], sources['yaw_bearing_nominal']['meaning'], 'yaw_bearing_nominal')

for row in inventory['parts']:
    density = row['properties'].get('mass_density_g_cm3')
    if density is None:
        continue
    V = row['volume_mm3']; c = np.array(row['geometric_center_mm']); Q = np.array(row['second_volume_moment_mm5'])
    m, Io, Ic = inertia(V, c, Q, density / 1000)
    r = entry(row['id'], row['id'], [row['id']], 'CUSTOM_METAL_ESTIMATE', m,
              'Retained custom-metal nominal solid × existing model density. Stock grade, machining dimensions and actual weight remain unqualified.')
    r.update(volume_mm3=V, density_g_cm3=density, center_of_mass_mm=c.tolist(),
             inertia_at_COM_kg_m2=(Ic*1e-9).tolist(), raw_inertia_g_mm2=Io.tolist(),
             moments_status='ASSUMED_UNIFORM_DENSITY')

unknown_bundles = [
    ('UPS_Bundle', 'UPS＋三节实际电芯＋原厂绝缘板', ['UPS_Module'], '不含遥置 DC、开关及单独线束；原厂简模体积不换算质量。', 'ups_unknown'),
    ('CAM_Board', '微雪 CAM 主板（含板载麦克风）', ['CAM_Mainboard','Onboard_MIC_L','Onboard_MIC_R'], '整板称一次，麦克风不另计；不含 OV3660 和外接线。', None),
    ('Camera_Module', 'OV3660 小模组（板＋镜头）', ['Camera_PCB','Camera_Lens'], '含原配不可分引线时需在称重记录中说明；不可拆引线不得再次计入线束。', None),
    ('LCD_Module', '1.85 寸屏完整模块', ['Display_PCB'], '含原盖板和背板；外接 FFC 如一同称重应从线束中排除。', None),
    ('WeAct_Core', 'WeAct F412 核心板＋实际装好的排针', ['MCU_Motion','E_Straight_Header'], '旧 12g 属性是预算假设，未作为厂家重量；含模型已有其他排针。', None),
    ('Custom_Carrier', '新驱动载板＋三组排母', ['MCU_Carrier','Socket_AC','Socket_BD','Socket_E'], '当前仅 P5R7 布局参考；UPS-R2 PCB 未定，旧 12g 属性不沿用。', None),
    ('IMU_Module', 'BMI323 无排针成品板', ['IMU_BMI323'], '不含未焊的竖直排针和单独线缆。', 'bmi323_unknown'),
    ('Head_Buck', '微雪 6V Buck', ['Head_Buck_6V'], '7.2V 同系列几何不是 6V 实测质量。', None),
    ('Speaker_Assembly', 'SP3040 含确认的 150mm 线及插头', ['Speaker'], '整套称一次；旧 31.5g 来自被替换的大喇叭，不能移植；排除重复喇叭线重量。', None),
    ('DC_Assembly', 'DC 插座＋螺母＋不可分尾线', ['DC_Jack_Sample_Allocation','DC_Nut_Sample_Allocation'], '样品包络不是实体材料；尾线若同称不得再次计入线束。', None),
    ('Switch_Assembly', 'UPS 开关＋螺母＋不可分尾线', ['UPS_Switch_Sample_Allocation','UPS_Switch_Nut_Sample_Allocation'], '样品包络不是实体材料；尾线若同称不得再次计入线束。', None),
    ('Tyres', '两只轮胎', ['Tire_L','Tire_R'], '没有选定材料密度和真实中空形状，不继续用 70% 实心假设。', None),
    ('Wheel_Bearings', '四只 686ZZ 轴承', ['Wheel_Bearing_L_Inner','Wheel_Bearing_L_Outer','Wheel_Bearing_R_Inner','Wheel_Bearing_R_Outer'], '外边界环不是轴承内圈、外圈、滚珠真实材料分布。', None),
    ('Pitch_Transmission', '俯仰轴承／短轴及两只最终舵盘', ['Pitch_Bearing_L','Pitch_Bearing_R','Pitch_Trunnion_L','Pitch_Trunnion_R','Yaw_Horn','Pitch_Horn'], '最终接口及配件仍待实物；先按成套质量单列。', None)
]
for key, label, members, basis, source in unknown_bundles:
    entry(key, label, members, 'UNKNOWN', basis=basis, source=source)

pads = [n for n in by_id if n not in claimed and ('Pad' in n or 'Gasket' in n)]
entry('Pads_and_Gasket', '非打印缓冲垫与喇叭垫片', pads, 'UNKNOWN', basis='材料和实际压缩厚度未称量；不按显示颜色取密度。')
hardware = [n for n in by_id if n not in claimed]
check('remaining_ids_are_fasteners', all(any(w in n for w in ['Screw','Nut','Insert','Washer']) for n in hardware), ids=hardware)
entry('Fasteners', '独立螺钉、螺母、嵌件和垫圈', hardware, 'UNKNOWN', basis='整套清单称重；不含 DC/开关已分组螺母，不含已纳入电机商品重量的内部件。模型螺纹简化体不等于真实材料体积。')
check('exactly_once_inventory_accounting', claimed == set(by_id) and sum(len(r['members']) for r in ledger) == len(by_id), current_parts=len(by_id))
check('dock_excluded_from_robot', all(r['scope'] == 'dock' for r in ledger if 'dock' in r['groups']))
check('export_count_meaning', set(exports)-set(by_id) == {'Coupon_Insert','Coupon_Mating_Tab','Coupon_Plane_Fit','Coupon_Wheel_Fit'}
      and len(stl_checks) == 16 and len(exports) == 20,
      robot_prints=15, dock_base_prints=1, coupon_exports=4, unexported_soft_pads=4)

# Missing physical content is explicit: no anonymous zero-gram row or invented allowance.
extra = [
    dict(id='Remaining_Harness', label_zh='其余线束、FFC/FPC、压接端子及塑壳', mass_g=None,
         basis='仅计入各模块称重范围之外的部分；舵机厂家重量的随线范围需核对后拆分，不能把两边都算全。'),
    dict(id='Finish_and_Restraints', label_zh='喷漆、标签、扎带、绝缘与最终固定耗材', mass_g=None,
         basis='按最终装配清单补；不能假设其全部已包含在 CAD。')
]
robot = [r for r in ledger if r['scope'] == 'robot']
totals = {kind: sum(r['mass_g'] for r in robot if r['accounting'] == kind) for kind in
          ['PA12_SOLID_ESTIMATE','CATALOGUE_NOMINAL','CUSTOM_METAL_ESTIMATE']}
subtotal = sum(totals.values())
known_prints = [r for r in robot if r['accounting'] == 'PA12_SOLID_ESTIMATE']
group_moments = {}
for label, groups in [('all_robot_prints', None), ('pitch_prints', ['pitch']), ('yaw_and_pitch_prints', ['yaw','pitch'])]:
    chosen = [r for r in known_prints if groups is None or any(g in groups for g in r['groups'])]
    mass = sum(r['mass_g'] for r in chosen)
    first = sum(np.array(r['center_of_mass_mm'])*r['mass_g'] for r in chosen)
    center = first/mass
    Io = sum(np.array(r['raw_inertia_g_mm2']) for r in chosen)
    Ic = Io - mass*(np.dot(center,center)*np.eye(3)-np.outer(center,center))
    group_moments[label] = dict(mass_g=mass, center_of_mass_mm=center.tolist(),
                               inertia_at_COM_kg_m2=(Ic*1e-9).tolist(),
                               scope='PRINTED SUBSET ONLY, uniform reference density; not the whole assembly or a controller parameter')

old = read(PROJECT / 'mechanical/reports/mass_budget.json')
old_entries = old['density_and_component_mass_assumptions']
duplicates = [r for r in old_entries if r['id'] in [
    'S288_Output_L_Inner','S288_Output_L_Outer','S288_Output_R_Inner','S288_Output_R_Outer',
    'Yaw_Output','Pitch_Output','Onboard_MIC_L','Onboard_MIC_R']]
old_audit = dict(old_report_sha256=sha(PROJECT / 'mechanical/reports/mass_budget.json'),
    current=False, old_report_left_unchanged=True,
    confirmed_extra_subcomponent_rows=[dict(id=r['id'],mass_g=r['mass_g']) for r in duplicates],
    confirmed_extra_subcomponent_mass_g=sum(r['mass_g'] for r in duplicates),
    dock_was_in_old_report=any(r['group']=='dock' for r in old_entries),
    correction='The old validate.py caller already excluded the dock. No subtraction of dock mass is justified.',
    other_issues=['Old 31.5g speaker allowance is not SP3040 data.',
                  'Property named documented_mass_g on retained WeAct/carrier is explicitly BUDGET_ASSUMPTION_NOT_MEASURED.',
                  'Old uniform envelope-density fallbacks and +/-35% cannot qualify new UPS architecture.',
                  'Camera module mass scope was ambiguous; new ledger combines PCB and lens without claiming their old entries were proven duplicate.'])
check('no_whole_robot_inertia_inference', all(r['center_of_mass_mm'] is None for r in robot if r['accounting'] in ['UNKNOWN','CATALOGUE_NOMINAL']))
protected = read(HERE/'protected_before.json')
owner = read(HERE/'hardware_owner_update.json')
received = {x['file']:x for x in owner['deltas']}
changed = {f for f,h in protected.items() if sha(PROJECT/f)!=h}
check('protected_files_and_owner_receipt', changed == set(received) and
      all(x['before_sha256']==protected[f] and x['received_sha256']==sha(PROJECT/f)
          and (f.startswith('hardware/') or f in ['contracts/components.json','contracts/electrical_interfaces.json'])
          for f,x in received.items()), protected_count=len(protected),
      unchanged_count=len(protected)-len(changed), received_owner_metadata_changes=len(changed))
report = dict(revision=inventory['revision'], date='2026-10-13', status='BLOCKED',
    calculation_status='PASS', source_main_sha256=inventory['source_sha256'],
    inputs_sha256={str(p.relative_to(PROJECT)):sha(p) for p in [HERE/'inventory.json', HERE/'sources.json',
        PROJECT/'config/geometry.json', PROJECT/'mechanical/reports/export_manifest.json',
        PROJECT/'mechanical/scripts/validate.py', PROJECT/'mechanical/scripts/common.py',
        HERE/'hardware_owner_update.json', Path(__file__)]},
    inventory_count=len(by_id), ledger_units=len(ledger), ledger=ledger, unmodeled_remainders=extra,
    subtotal_g=subtotal, subtotal_components_g=totals, complete_mass_g=None,
    complete_COM_mm=None, complete_inertia_kg_m2=None, dynamic_torque_validation='BLOCKED',
    mass_target_status='BLOCKED', whole_mass_target_g=geometry['validation']['whole_mass_target_g'],
    arithmetic_remaining_to_1200_g=1200-subtotal,
    remainder_meaning='Arithmetic difference only under reference assumptions, not a measured margin or a guaranteed lower bound. All unknowns remain to be added.',
    dock_PA12_base_mass_g=sum(r['mass_g'] for r in ledger if r['scope']=='dock' and r['mass_g'] is not None),
    dock_soft_pad_mass_g=None, export_split=dict(robot=15,dock_base=1,coupons=4,soft_pads_not_exported=4),
    printed_subset_moments=group_moments, old_report_audit=old_audit, checks=checks,
    hardware_owner_receipt=owner,
    hardware_integration='BLOCKED: saved M1.58 received UPS-R1 metadata; owner UPS-R2 topology has not been routed into the model. No native PCB or geometry changed by this audit.',
    stl_readback=stl_checks, unused_envelope_volume_differences=unused_envelope_volume_differences,
    physical_validation='NOT_TESTED', manufacturing_release=False,
    limitations=['No physical mass measurements were provided or invented.',
                'Catalogue mass does not determine physical center of mass or inertia; servo outputs span moving groups.',
                'Only modeled homogeneous prints/custom metal have geometric density-derived moments.',
                'Unknown hardware, three cells, harness and finish must be recorded once with explicit weighing scope.',
                'The old report is retained as history and must not be used for current balancing/controller/load approval.'])
save(HERE/'mass_ledger.json', report)
with (HERE/'mass_ledger.csv').open('w', newline='') as f:
    w=csv.writer(f);w.writerow(['id','label','scope','accounting','mass_g','members','basis'])
    for r in ledger:w.writerow([r['id'],r['label_zh'],r['scope'],r['accounting'],'' if r['mass_g'] is None else f"{r['mass_g']:.6f}",';'.join(r['members']),r['basis']])
with (HERE/'measurements_template.csv').open('w', newline='') as f:
    w=csv.writer(f);w.writerow(['ledger_id','label','measured_mass_g','scale_resolution_g','included_parts_and_leads','excluded_parts','evidence_file','date'])
    for r in robot:
        if r['accounting'] in ['UNKNOWN','CATALOGUE_NOMINAL']:w.writerow([r['id'],r['label_zh'],'','','','','',''])
    for r in extra:w.writerow([r['id'],r['label_zh'],'','','','','',''])
print(json.dumps(dict(status=report['status'],calculation_status='PASS',subtotal_g=subtotal,totals=totals,unknown_units=sum(r['accounting']=='UNKNOWN' for r in robot)+len(extra),print_groups=group_moments,checks=len(checks)),ensure_ascii=False),flush=True)
